package kouchan.siddhesh.com.BookARideAndroid.Interface.getprofile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import kouchan.siddhesh.com.BookARideAndroid.View.Activities.NavHome;
import kouchan.siddhesh.com.BookARideAndroid.async.AsyncInteractor;
import kouchan.siddhesh.com.BookARideAndroid.async.OnRequestListener;
import kouchan.siddhesh.com.BookARideAndroid.utils.AppConstants;
import kouchan.siddhesh.com.BookARideAndroid.utils.NetworkStatus;
import kouchan.siddhesh.com.BookARideAndroid.utils.Sharedpreferences;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;


public class GetProfilePresenterImpl implements IGetProfilePresnter, OnRequestListener {

    NavHome navHome;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IGetProfileView getProfileView;

    public GetProfilePresenterImpl(IGetProfileView getProfileView) {
        this.navHome = (NavHome) getProfileView;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(navHome);
        this.asyncInteractor = new AsyncInteractor(navHome);
        this.getProfileView = getProfileView;
    }

    @Override
    public void getProfile(String mobileNo) {
        if (NetworkStatus.checkNetworkStatus(navHome)) {
            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_GETPROFILE, "https://bookarideworldwide.com/CAB2.V.1/passenger_api/getPassengerProfile.php?mobile=" + mobileNo);
        } else {
            Utils.showToast(navHome, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if (pid == AppConstants.TAG_ID_GETPROFILE) {
            if (responseJson != null) {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    getProfileView.getProfileSuccess(pid, responseJson);
                } else {
                    getProfileView.getProfileError(pid, jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        getProfileView.getProfileError(pid, error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        getProfileView.getProfileError(pid, error);
    }
}
