package kouchan.siddhesh.com.BookARideAndroid.FCM;

import android.content.Intent;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import kouchan.siddhesh.com.BookARideAndroid.View.Activities.RideRequestActivity;

import static android.content.ContentValues.TAG;

/**
 * Created by KOUCHAN-ADMIN on 2/18/2017.
 */

public class PassengerMessagingService extends FirebaseMessagingService
{
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage)
    {
        super.onMessageReceived(remoteMessage);

        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
            try {
                JSONObject jsonObject = new JSONObject(remoteMessage.getData().toString());

                sendPushNotification(jsonObject);
            }
            catch (Exception e){}
        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }
    }

    public void sendPushNotification(JSONObject jsonObject)
    {
        try {
           JSONObject data = jsonObject.getJSONObject("data");

            String title=data.getString("title");
            String message=data.getString("message");

            Intent intent = new Intent(getApplicationContext(), RideRequestActivity.class);
            JSONObject values = new JSONObject(message);

            NotificationOperator notificationOperator=new NotificationOperator(getApplicationContext());

            if(values.getString("stage").equals("Ride Request"))
            {

                intent.putExtra("message", "reached");
                intent.putExtra("stage", values.getString("stage"));
                intent.putExtra("passengername", values.getString("passengername"));
                intent.putExtra("passengermobile", values.getString("passengermobile"));
                intent.putExtra("vehicle", values.getString("vehicle"));
                intent.putExtra("whenrequired", values.getString("whenrequired"));
                Log.d(TAG, "whenrequired " + values.getString("whenrequired"));
                intent.putExtra("typeofrate", values.getString("typeofrate"));
                intent.putExtra("rate", values.getString("rate"));
                intent.putExtra("from", values.getString("from"));
                intent.putExtra("to", values.getString("to"));
                intent.putExtra("fromlatitude", values.getString("fromlatitude"));
                intent.putExtra("fromlongitude", values.getString("fromlongitude"));
                intent.putExtra("tolatitude", values.getString("tolatitude"));
                intent.putExtra("tolongitude", values.getString("tolongitude"));
                intent.putExtra("final_amount_val", values.getString("final_amount_val"));
                intent.putExtra("service_charge_val", values.getString("service_charge_val"));
                intent.putExtra("service_tax_val", values.getString("service_tax_val"));

            }

            notificationOperator.showNotification(title,values.getString("stage"),intent);
        }
        catch (Exception e){}
    }
}
