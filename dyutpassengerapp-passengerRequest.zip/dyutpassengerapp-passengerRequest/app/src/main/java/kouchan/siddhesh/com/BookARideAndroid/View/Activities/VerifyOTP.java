package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.otto.Subscribe;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Database.PrefManager;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Interface.bookRideOTPVerification.IBookRideOTPVerificationPresenter;
import kouchan.siddhesh.com.BookARideAndroid.Interface.bookRideOTPVerification.IBookRideOTPVerificationView;
import kouchan.siddhesh.com.BookARideAndroid.Interface.bookrideotpresend.BookRideOTPResendPresenterImpl;
import kouchan.siddhesh.com.BookARideAndroid.Interface.bookrideotpresend.IBookRideOTPResendPresenter;
import kouchan.siddhesh.com.BookARideAndroid.Interface.bookrideotpresend.IBookRideOTPResendView;
import kouchan.siddhesh.com.BookARideAndroid.Otto.EventBusManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.VolleyJsonObjectRequest;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.SMSOtpMessage;

public class VerifyOTP extends AppCompatActivity implements IBookRideOTPVerificationView,IBookRideOTPResendView {

    IBookRideOTPVerificationPresenter iBookRideOTPVerificationPresenter;
    IBookRideOTPResendPresenter  bookRideOTPResendPresenter;
    private TextView phoneNoView;
    private EditText phoneCodeView;
    private Button phoneVerifyButton;
    private TextView phoneTimer;
    private TextView resendOtpButton,resendOtpButton1;
    private TextView resendOtpDesc;

    private EditText mFirstDigitEdtTxt, mSecondDigitEdtTxt, mThirdDigitEdtTxt, mFourthDigitEdtTxt;

    TextView verify_otp_textView,phone_verify_desc;
    String languageCode;
    Resources resources;

    String mobile, otpmsg;

    String type;

    SessionManager sessionManager;
    PrefManager prefManager;
    HashMap<String, String> user = new HashMap<String, String>();

   /*  Bus eventBus;*/

    String VERIFY_OTP_URL = "";

    String RESEND_OTP_URL = "";

    private final int COUNT_DOWN_TIME = 60 * 1000; // 60 sec
    private final int COUNT_DOWN_INTERVAL = 1000;  // 1 sec
    private boolean isCodeFetchDone = false;

    Toolbar mToolbar;
    ImageView verifyOTPBackImageView;

    String otpFromServer;
    String otpEntered;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_otp);

        prefManager = new PrefManager(getApplicationContext());
        prefManager.setIsWaitingForSms(true);

        sessionManager = new SessionManager(getApplicationContext());
        user = sessionManager.getUserDetails();
        mobile = user.get("mobile");

        type = sessionManager.getType();

        VERIFY_OTP_URL = Url.PASSENGER_API + "register.php";
        RESEND_OTP_URL = Url.PASSENGER_API + "sendotpforregistration.php";

        EventBusManager.getInstance().getEventBus().register(this);

        phoneNoView = (TextView) findViewById(R.id.phone_verify_number_tv);
        phoneCodeView = (EditText) findViewById(R.id.phone_verify_code);
        phoneTimer = (TextView) findViewById(R.id.phone_verify_timer);
        phoneVerifyButton = (Button) findViewById(R.id.phone_verification_submit);/*
        resendOtpDesc = (TextView) findViewById(R.id.phone_verify_resend_otp_description);*/
        resendOtpButton = (TextView) findViewById(R.id.phone_verification_resend_otp_button);
        resendOtpButton1 = (TextView) findViewById(R.id.phone_verification_resend_otp_button1);
/*
        phone_verify_desc = (TextView) findViewById(R.id.phone_verify_desc);*/
        verify_otp_textView = (TextView) findViewById(R.id.verify_otp_textView);

        mFirstDigitEdtTxt = (EditText) findViewById(R.id.otp_code_first_digit_edtTxt);
        mSecondDigitEdtTxt = (EditText) findViewById(R.id.otp_code_second_digit_edtTxt);
        mThirdDigitEdtTxt = (EditText) findViewById(R.id.otp_code_third_digit_edtTxt);
        mFourthDigitEdtTxt = (EditText) findViewById(R.id.otp_code_fourth_digit_edtTxt);

        resendOtpButton.setVisibility(View.GONE);
        resendOtpButton1.setVisibility(View.GONE);
        /*
        resendOtpDesc.setVisibility(View.GONE);*/
        phoneNoView.setText("Enter the 4-digit code sent to you at "+getIntent().getStringExtra("mobile"));
        phoneVerifyButton.setEnabled(true);

        phoneCodeView.setInputType(InputType.TYPE_CLASS_NUMBER);

        final CountDownTimer countDownTimer = new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
                phoneTimer.setText(resources.getString(R.string.seconds_remaining) + millisUntilFinished / 1000);
            }

            public void onFinish() {
                //phoneTimer.setText(resources.getString(R.string.sms_otp_not_recieved));
                resendOtpButton1.setVisibility(View.VISIBLE);
                //resendOtpButton1.setText(resources.getString(R.string.sms_otp_not_recieved));
                resendOtpButton.setVisibility(View.VISIBLE);
                /*resendOtpDesc.setVisibility(View.VISIBLE);*/
            }
        }.start();


        phoneVerifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // otpEntered = phoneCodeView.getText().toString();
                String firstDigit = mFirstDigitEdtTxt.getText().toString();
                String secondDigit = mSecondDigitEdtTxt.getText().toString();
                String thirdDigit = mThirdDigitEdtTxt.getText().toString();
                String fourthDigit = mFourthDigitEdtTxt.getText().toString();
                otpEntered = firstDigit + secondDigit + thirdDigit + fourthDigit;
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(phoneCodeView.getWindowToken(),
                        InputMethodManager.RESULT_UNCHANGED_SHOWN);

                if (!otpEntered.isEmpty()) {
                    //otpFromServer=Integer.toString(getIntent().getIntExtra("otp",0));

                    //if(otpEntered.equals(otpFromServer)){

                        sendValues();

                    /*}else{

                     }*/


                } else {

                }
            }
        });

        resendOtpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                resendOtpButton.setVisibility(View.GONE);
               // resendOtpDesc.setVisibility(View.GONE);
                bookRideOTPResendPresenter = new BookRideOTPResendPresenterImpl(VerifyOTP.this);
                bookRideOTPResendPresenter.getBookRideOTPResend(getIntent().getStringExtra("mobile"));
                //sendOtpRequest();
//                sendValues();
                countDownTimer.start();
            }
        });
        // mDialog.show();
        //  countDownTimer.start();

        initializeViews();

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }


        mFirstDigitEdtTxt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(count == 1)
                    mSecondDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mSecondDigitEdtTxt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(count == 1)
                    mThirdDigitEdtTxt.requestFocus();

                // detect backspace key
                if(count == 0)
                    mFirstDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mThirdDigitEdtTxt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(count == 1)
                    mFourthDigitEdtTxt.requestFocus();

                // detect backspace key
                if(count == 0)
                    mSecondDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mFourthDigitEdtTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                // detect backspace key
                if(count == 0)
                    mThirdDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        verify_otp_textView.setText(resources.getString(R.string.verify_otp));
        phoneCodeView.setHint(resources.getString(R.string.enter_otp));
       // phoneVerifyButton.setText(resources.getString(R.string.verify));
        resendOtpButton.setText(resources.getString(R.string.resend_otp));
    }


    @Override
    protected void onResume() {
        super.onResume();
    }

    @Subscribe
    public void onOTPReceivedFromSMS(SMSOtpMessage smsOtpMessage) {
        isCodeFetchDone = true;
        otpmsg = smsOtpMessage.getOtp();
    //    phoneCodeView.setText(otpmsg);

      if(otpmsg!=null){
          char[] splitted = otpmsg.toCharArray();
          char one = splitted[0];
          char two = splitted[1];
          char the = splitted[2];
          char four = splitted[3];
          mFirstDigitEdtTxt.setText(""+one);
          mSecondDigitEdtTxt.setText(""+two);
          mThirdDigitEdtTxt.setText(""+the);
          mFourthDigitEdtTxt.setText(""+four);
      }

    }


    public void sendValues() {

        Map<String, String> params = new HashMap<String, String>();

        params.put("email",getIntent().getStringExtra("email"));
        params.put("mobile",getIntent().getStringExtra("mobile"));
        params.put("password",getIntent().getStringExtra("password"));
        params.put("name",getIntent().getStringExtra("name"));
        //params.put("bdate",getIntent().getStringExtra("bdate"));
        //params.put("gender",getIntent().getStringExtra("gender"));
        //params.put("alternateName",getIntent().getStringExtra("alternateName"));
        //params.put("alternateMobile",getIntent().getStringExtra("alternateMobile"));
        params.put("messagingid",getIntent().getStringExtra("messagingid"));
        params.put("pin",getIntent().getStringExtra("pin"));
        params.put("address",getIntent().getStringExtra("address"));
        params.put("state_name",getIntent().getStringExtra("state"));
        //params.put("adharno",getIntent().getStringExtra("adharno"));
        params.put("otp",otpEntered);
        JSONObject json = new JSONObject(params);

        final ProgressDialog loading = ProgressDialog.show(this, resources.getString(R.string.logging), resources.getString(R.string.please_wait), false, false);
        VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST ,VERIFY_OTP_URL,json,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response.toString());
                            boolean error = jObj.getBoolean("error");
                            if (!error) {


                                prefManager.setIsWaitingForSms(false);
                                sessionManager.setIsLogin(true);

                                String id = jObj.getString("id");

                                JSONObject user = jObj.getJSONObject("user");
                                String stringName = user.getString("name");
                                String stringMobile = user.getString("mobile");
                                String email = user.getString("email");
                                String created_at = user.getString("created_at");

                                String blockStatus = user.getString("block_status");

                                String m3otpStatus = user.getString("m3otp_status");

                                //String m3adharOtpStatus = user.getString("m3adhar_otp_status");

                                String uniqueId = user.getString("unique_id");

                                sessionManager.createLoginSession(stringName, stringMobile);
                                sessionManager.createId(id);
                                sessionManager.createEmail(email);
                                sessionManager.setUniqueId(uniqueId);
                                sessionManager.setBlockstatus(blockStatus);
                                //sessionManager.setM3adharotpstatus(m3adharOtpStatus);
                                sessionManager.setM3otpstatus(m3otpStatus);
                                sessionManager.setPassword(getIntent().getStringExtra("password"));

                                final Dialog dialog = new Dialog(VerifyOTP.this);
                                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                dialog.setCancelable(false);
                                dialog.setContentView(R.layout.custom_alert_dialog);
                                Window window = dialog.getWindow();
                                window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                                TextView text = (TextView) dialog.findViewById(R.id.txt_dia);
                                text.setText("Want to Create M3 e-wallet Account for Easy and Cashless Payment");

                                Button okButton = (Button) dialog.findViewById(R.id.btn_yes);
                                okButton.setText("Now");
                                Button cancleButton = (Button) dialog.findViewById(R.id.btn_no);
                                cancleButton.setText("Later");

                                okButton.setOnClickListener(new View.OnClickListener() {

                                    @Override
                                    public void onClick(View v) {
                                        //Perfome Action
                                        Intent intent = new Intent(VerifyOTP.this, AadharRegistrationActivity.class);
                                        intent.putExtra("email", getIntent().getStringExtra("email"));
                                        intent.putExtra("mobile", getIntent().getStringExtra("mobile"));
                                        intent.putExtra("password", getIntent().getStringExtra("password"));
                                        intent.putExtra("name", getIntent().getStringExtra("name"));
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                                cancleButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        dialog.dismiss();
                                        startActivity(new Intent(VerifyOTP.this, NavHome.class));
                                        finish();
                                    }
                                });

                                dialog.show();




                            } else {

                                // Error occurred in registration. Get the error
                                // message
                                String errorMsg = jObj.getString("error_msg");
                                Toast.makeText( VerifyOTP.this, errorMsg, Toast.LENGTH_SHORT ).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }) /*{
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                params.put("email",getIntent().getStringExtra("email"));
                params.put("mobile",getIntent().getStringExtra("mobile"));
                params.put("password",getIntent().getStringExtra("password"));
                params.put("name",getIntent().getStringExtra("name"));
                //params.put("bdate",getIntent().getStringExtra("bdate"));
                //params.put("gender",getIntent().getStringExtra("gender"));
                //params.put("alternateName",getIntent().getStringExtra("alternateName"));
                //params.put("alternateMobile",getIntent().getStringExtra("alternateMobile"));
                params.put("messagingid",getIntent().getStringExtra("messagingid"));
                params.put("pin",getIntent().getStringExtra("pin"));
                //params.put("adharno",getIntent().getStringExtra("adharno"));
                params.put("otp",otpEntered);

                return params;
            }

        }*/;

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public void sendOtpRequest() {
        final ProgressDialog loading = ProgressDialog.show(this, resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, RESEND_OTP_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                PrefManager prefManager = new PrefManager(getApplicationContext());
                                prefManager.setIsWaitingForSms(true);

                                otpFromServer=Integer.toString(jObj.getInt("otp"));
                                Toast.makeText( VerifyOTP.this, jObj.getString("message"), Toast.LENGTH_SHORT ).show();

                            } else {
                                // Error occurred in registration. Get the error
                                // message
                                String errorMsg = jObj.getString("error_msg");
                                Toast.makeText( VerifyOTP.this, errorMsg, Toast.LENGTH_SHORT ).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                params.put("email",getIntent().getStringExtra("email"));
                params.put("mobile",getIntent().getStringExtra("mobile"));
                params.put("password",getIntent().getStringExtra("password"));
                params.put("name",getIntent().getStringExtra("name"));
                params.put("bdate",getIntent().getStringExtra("bdate"));
                params.put("gender",getIntent().getStringExtra("gender"));
                params.put("alternateName",getIntent().getStringExtra("alternateName"));
                params.put("alternateMobile",getIntent().getStringExtra("alternateMobile"));
                params.put("messagingid",getIntent().getStringExtra("messagingid"));
                params.put("pin",getIntent().getStringExtra("pin"));
                params.put("adharno",getIntent().getStringExtra("adharno"));

                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    private void initializeViews() {
        setSupportActionBar(mToolbar);
        verifyOTPBackImageView = (ImageView) findViewById(R.id.verifyOTPBackImageView);

        verifyOTPBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();
            }
        });
    }

    @Override
    public void addContentView(View view, ViewGroup.LayoutParams params) {
        super.addContentView(view, params);
    }

    @Override
    public void onGetBookRideOTPSuccess(int pid, String String) {

    }

    @Override
    public void onGetBookRideOTPError(int pid, String error) {
        Toast.makeText(getApplicationContext(),error,Toast.LENGTH_LONG).show();
    }

    @Override
    public void onGetBookRideOTPResendSuccess(int pid, String String) {

    }

    @Override
    public void onGetBookRideOTPResendError(int pid, String error) {
        Toast.makeText(getApplicationContext(),error,Toast.LENGTH_LONG).show();
    }
}






