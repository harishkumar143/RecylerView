package kouchan.siddhesh.com.BookARideAndroid.models;

/**
 * Created by KOUCHAN-ADMIN on 30-May-18.
 */

public class OttoRepeatRide {

    String from,
            to,
            fromlatitude,
            fromlongitude,
            tolatitude,
            tolongitude,
            vehicle_type;


    public OttoRepeatRide(String from, String to, String fromlatitude, String fromlongitude, String tolatitude, String tolongitude, String vehicle_type) {
        this.from = from;
        this.to = to;
        this.fromlatitude = fromlatitude;
        this.fromlongitude = fromlongitude;
        this.tolatitude = tolatitude;
        this.tolongitude = tolongitude;
        this.vehicle_type = vehicle_type;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getFromlatitude() {
        return fromlatitude;
    }

    public String getFromlongitude() {
        return fromlongitude;
    }

    public String getTolatitude() {
        return tolatitude;
    }

    public String getTolongitude() {
        return tolongitude;
    }

    public String getVehicle_type() {
        return vehicle_type;
    }


}
