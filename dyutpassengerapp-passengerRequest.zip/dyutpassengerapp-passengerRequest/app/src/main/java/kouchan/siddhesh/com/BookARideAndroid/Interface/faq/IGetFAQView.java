package kouchan.siddhesh.com.BookARideAndroid.Interface.faq;

import java.util.ArrayList;

public interface IGetFAQView {

    void getFAQSuccess(int pid, String response);

    void getFAQError(int pid, String error);

}
