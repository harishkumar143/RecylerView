package kouchan.siddhesh.com.BookARideAndroid.View.Fragments;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.BounceInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.squareup.otto.Subscribe;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;

import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.CurrentRide;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Otto.EventBusManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.DriverLocationTracking;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.FeedbackActivity;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.NavHome;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.PaymentActivity;
import kouchan.siddhesh.com.BookARideAndroid.functions.Functions;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoAllDriversRejected;
import kouchan.siddhesh.com.BookARideAndroid.other.CustomDialogClass;
import kouchan.siddhesh.com.BookARideAndroid.other.CustomDialogFavorites;
import kouchan.siddhesh.com.BookARideAndroid.other.OttoSelectedFromFavorite;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;
import static android.content.ContentValues.TAG;


public class MenuPassengerMain extends Fragment implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, LocationListener {

    private GoogleMap mGoogleMap;
    private SupportMapFragment mapFrag;
    private BitmapDrawable bitmapdraw;
    private LatLng latLng;
    private int count;
    private int countAddress;
    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private LatLng mCenterLatLong;

    android.support.v7.app.AlertDialog.Builder ad;
    AlertDialog.Builder alert;

    private RadioGroup choose_vehicle;
    private RadioGroup when_required;
    private RadioGroup type_of_rate;
    private RadioButton taxi;
    private RadioButton auto;
    private RadioButton bike;
    private RadioButton any;
    private RadioButton immediate;
    private RadioButton later;
    private RadioButton fixed_amount;
    private RadioButton ride_per_meter;
    private RadioButton meter_plus_extra;
    private RadioButton meter_minus_extra;

    private EditText later_time;
    private EditText edit_fixed_amount;
    private EditText edit_per_meter;
    private EditText edit_meter_plus;
    private EditText edit_meter_less;
    private EditText bookaridefrom;
    private EditText bookarideto;


    private HorizontalScrollView choose_your_ride_horizontal_scroll_view;

    private ProgressBar passenger_offer_progressbar;

    private ImageView infoImagePerMeter;
    private ImageView nextImageChooseYourRide;
    private ImageView backImageTypeOfMeter;
    private ImageView nextImageTypeOfMeter;
    private ImageView backImagebookingWhenRequired;
    private ImageView marker_logo;
    private ImageView selected_vehicle_type_of_meter;
    private ImageView selected_vehicle_WhenRequire;
    private ImageView imageViewFevoritDestination;
    private ImageView imageViewFevoritSource;
    private ImageView destination_marker_logo;

    private LinearLayout linearLayoutChooseYourRide;
    private LinearLayout linearLayoutChooseYourRideButtons;
    private LinearLayout linearLayoutTypeOfMeter;
    private LinearLayout linearLayoutTypeOfMeterButtons;
    private LinearLayout linearLayoutWhenRequire;
    private LinearLayout linearLayoutWhenRequiredButtons;
    private LinearLayout linearLayout_background_blur;
    private LinearLayout linearLayout_retry_cancel_buttons;

    private TextInputLayout book_a_ride_from_TextInput;
    private TextInputLayout book_a_ride_to_TextInput;
    private TextView type_of_meter_textView;
    private TextView when_require_textView;
    private TextView selected_TypeOfMeter_WhenRequire_textView;
    private TextView selected_Rate_WhenRequire_textView;
    private TextView selected_TypeOfMeter_as_per_any_WhenRequire_textView;
    private TextView finding_nearest_textView;
    private TextView driver_response_textView;
    private TextView selected_Rate_RupeesSymbol_textView;
    private TextView date;
    private TextView book_a_ride_weekDay;

    private String languageCode;
    private Resources resources;

    private FrameLayout passenger_home_frame_layout;

    private double startLatitude;
    private double startLongitude;
    private double endLatitude;
    private double endLongitude;
    private Double trakingLatitude;
    private Double trackingLongitude;

    private Button submit_button;
    private Button cancel_ride_request_button;
    private Button retry_ride_request_button;


    private String choose_vehicle_value;
    private String when_required_value;
    private String when_required_type;
    private String type_of_rate_value;
    private String meter_value;

    private AlertDialog.Builder ab;

    private SessionManager sessionManager;

    private HashMap<String, String> user;

    private final String getPriceAndTIme = Url.PASSENGER_API + "distanceCalculateByLatLong.php";
    private final String updateLocationOfDrivers = Url.PASSENGER_API + "getNearByDrivers.php";

    private String string_type_of_rate;

    private static final int PLACE_PICKER_REQUEST_FROM = 1000;
    private static final int PLACE_PICKER_REQUEST_TO = 2000;
    private GoogleApiClient mClient;

    private String tolatitude;
    private String tolongitude;
    private String fromlatitude;
    private String fromlongitude;

    private LatLngBounds latLngBounds;
    private View view;

    private ProgressDialog loading;

    private String date_time;
    private int mHour;
    private int mMinute;
    private Calendar c;

    private String taxi_rate;
    private String auto_rate;
    private String distance;
    private String taxi_rate_in_area;
    private String auto_rate_in_area;
    private String bike_rate;
    String bike_rate_in_area;


    private String minimum_fare_taxi;
    private String per_km_taxi;
    private String minimum_fare_auto;
    private String per_km_auto;
    private String displayRateInISymbol;
    private String minimum_fare_bike;
    private String per_km_bike;
    private String currency_symbol;

    PlaceAutocompleteFragment places;

    private String city;
    private Marker mk;

    private int range_count;
    private CountDownTimer waitingTimerRideRequest;
    private android.support.v7.app.AlertDialog.Builder builder;
    private String bookingid;
    private String status;
    private String message;
    private String retryUrl;

    private AlphaAnimation fadeIn;
    private AlphaAnimation fadeOut;

    private CustomDialogFavorites cdd;
    int cursorStatus;

    String notChangeAddress;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_booking, container, false);

        notChangeAddress = "a";

        CurrentRide currentRide = new CurrentRide(getActivity());
        String statusofride = currentRide.getIsridestarted();
        String statusOfFeedback = currentRide.getFeedback();
        String getPaymentstatus = currentRide.getPaymentstatus();

        retryUrl = Url.COMUNICATE_API + "rideRequest.php";
        status = "searching";
        range_count = 1;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new android.support.v7.app.AlertDialog.Builder(getActivity(), android.R.style.Theme_Material_Dialog_Alert);
        }

        fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeOut = new AlphaAnimation(1.0f, 0.0f);


        if (statusofride.equals("started"))

        {

            Intent i = new Intent(getActivity(), DriverLocationTracking.class);
            i.putExtra("bookingid", currentRide.getRideid());
            i.putExtra("drivermobile", currentRide.getDrivermobile());
            i.putExtra("vehicle", currentRide.getVehicle());


            startActivity(i);
            getActivity().finish();


        } else if (statusOfFeedback.equals("notgiven"))

        {

            Intent f = new Intent(getActivity(), FeedbackActivity.class);

            f.putExtra("drivermobile", currentRide.getDrivermobile());
            f.putExtra("booking_id", currentRide.getRideid());

            startActivity(f);
            getActivity().finish();

        } else if (getPaymentstatus.equals("notpaid"))

        {

            Intent f = new Intent(getActivity(), PaymentActivity.class);
            f.putExtra("booking_id", currentRide.getRideid());
            startActivity(f);
            getActivity().finish();

        } else

        {


            Timer timer = new Timer();
            initializeWidget();
            setValuesBasedOnOptions();
            infoImages();
            getDriversLocations();
            checkLocationPermission();

        }

        sessionManager = new SessionManager(getActivity());
        if (sessionManager.getLanguageCode() != null)

        {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        EventBusManager.getInstance().getEventBus().register(this);


        retry_ride_request_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (waitingTimerRideRequest != null) {
                    waitingTimerRideRequest.cancel();
                    waitingTimerRideRequest = null;

                }
                status = "searching";

                linearLayout_background_blur.setBackgroundResource(R.color.white_light_transparent_1);

                /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white_light_transparent_1));*/
                finding_nearest_textView.setVisibility(View.VISIBLE);
                passenger_offer_progressbar.setVisibility(View.VISIBLE);
                retry_ride_request_button.setVisibility(View.GONE);
                cancel_ride_request_button.setVisibility(View.GONE);
                driver_response_textView.setVisibility(View.GONE);

                setTimerForRideRequest();
            }
        });

        cancel_ride_request_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (waitingTimerRideRequest != null) {
                    waitingTimerRideRequest.cancel();
                    waitingTimerRideRequest = null;

                }
                Intent i = new Intent(getActivity(), NavHome.class);
                startActivity(i);

            }
        });

        cursorStatus = 1;

        return view;
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(getActivity(), languageCode);
        resources = context.getResources();
        /*taxi.setText(resources.getString(R.string.taxi));
        auto.setText(resources.getString(R.string.auto));
        bike.setText(resources.getString(R.string.bike));
        any.setText(resources.getString(R.string.any));*/
        immediate.setText(resources.getString(R.string.immediate));
        later.setText(resources.getString(R.string.later));
        fixed_amount.setText(resources.getString(R.string.fixed_amount));
        ride_per_meter.setText(resources.getString(R.string.per_meter));
        meter_plus_extra.setText(resources.getString(R.string.meter_plus_extra));
        meter_minus_extra.setText(resources.getString(R.string.meter_less_extra));
        submit_button.setText(resources.getString(R.string.submit));
        /*choose_your_ride_textView.setText(resources.getString(R.string.choose_your_ride));*/
        type_of_meter_textView.setText(resources.getString(R.string.type_of_meter));
        /*nextTextChooseYourRide.setText(resources.getString(R.string.next));
        backTextTypeOfMeter.setText(resources.getString(R.string.back));
        nextTextTypeOfMeter.setText(resources.getString(R.string.next));
        backTextWhenRequiredButtons.setText(resources.getString(R.string.back));*/
        when_require_textView.setText(resources.getString(R.string.when_require));
        //book_a_ride_from_TextInput.setHint(resources.getString(R.string.pickup_point));
        //book_a_ride_to_TextInput.setHint(resources.getString(R.string.destination_point));
        edit_fixed_amount.setHint(resources.getString(R.string.fixed_amount));
        /*edit_per_meter.setHint(resources.getString(R.string.per_meter));*/
        edit_meter_plus.setHint(resources.getString(R.string.meter_plus_extra));
        edit_meter_less.setHint(resources.getString(R.string.meter_less_extra));
        later_time.setHint(resources.getString(R.string.date_and_time));
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle(sessionManager.getUserDetails().get("name") + " - Passenger");
    }

    @Override
    public void onConnected(Bundle connectionHint) {

        LocationRequest mLocationRequestPassenger = new LocationRequest();
        mLocationRequestPassenger.setInterval(1000);
        mLocationRequestPassenger.setFastestInterval(1000);
        mLocationRequestPassenger.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mClient, mLocationRequestPassenger, this);
        }


        LocationSettingsRequest req = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequestPassenger)
                .build();
        PendingResult<LocationSettingsResult> result = LocationServices.SettingsApi.checkLocationSettings(mClient, req);
        result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
            @Override
            public void onResult(@NonNull LocationSettingsResult result) {
                final Status status = result.getStatus();
                switch (status.getStatusCode()) {
                    case LocationSettingsStatusCodes.SUCCESS:

                        break;

                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                        // Location settings are not satisfied. But could be fixed by showing the user a dialog.
                        try {
                            // Show the dialog by calling startResolutionForResult(),
                            // and check the result in onActivityResult().
                            status.startResolutionForResult(getActivity(), 110);
                        } catch (IntentSender.SendIntentException e) {
                            Log.e(TAG, e.getLocalizedMessage());
                        }
                        break;

                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:

                        break;
                }
            }
        });


    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    private void initializeWidget() {

        passenger_home_frame_layout = (FrameLayout) view.findViewById(R.id.passenger_home_frame_layout);

        choose_vehicle = (RadioGroup) view.findViewById(R.id.book_a_ride_choose_vehicle);
        when_required = (RadioGroup) view.findViewById(R.id.book_a_ride_when_required);

        taxi = (RadioButton) view.findViewById(R.id.book_a_ride_taxi);
        auto = (RadioButton) view.findViewById(R.id.book_a_ride_auto);
        bike = (RadioButton) view.findViewById(R.id.book_a_ride_bike);
        any = (RadioButton) view.findViewById(R.id.book_a_ride_any);

        immediate = (RadioButton) view.findViewById(R.id.book_a_ride_immediate);

        later = (RadioButton) view.findViewById(R.id.book_a_ride_later);
        later_time = (EditText) view.findViewById(R.id.book_a_ride_later_time);
        type_of_rate = (RadioGroup) view.findViewById(R.id.book_a_ride_type_of_rate);
        fixed_amount = (RadioButton) view.findViewById(R.id.book_a_ride_fixed_amount);
        ride_per_meter = (RadioButton) view.findViewById(R.id.book_a_ride_per_meter);
        meter_plus_extra = (RadioButton) view.findViewById(R.id.book_a_ride_meter_plus_extra);
        meter_minus_extra = (RadioButton) view.findViewById(R.id.book_a_ride_meter_minus_extra);
        edit_fixed_amount = (EditText) view.findViewById(R.id.edit_fixed_amount);

        edit_per_meter = (EditText) view.findViewById(R.id.edit_per_meter);
        edit_per_meter.setEnabled(false);

        edit_meter_plus = (EditText) view.findViewById(R.id.edit_meter_plus);
        edit_meter_less = (EditText) view.findViewById(R.id.edit_meter_less);
        bookaridefrom = (EditText) view.findViewById(R.id.book_a_ride_from);
        bookarideto = (EditText) view.findViewById(R.id.book_a_ride_to);
        submit_button = (Button) view.findViewById(R.id.book_a_ride_submit_button);
        cancel_ride_request_button = (Button) view.findViewById(R.id.cancel_ride_request_button);
        retry_ride_request_button = (Button) view.findViewById(R.id.retry_ride_request_button);

        finding_nearest_textView = (TextView) view.findViewById(R.id.finding_nearest_textView);
        passenger_offer_progressbar = (ProgressBar) view.findViewById(R.id.passenger_offer_progressbar);

        book_a_ride_weekDay = (TextView) view.findViewById(R.id.book_a_ride_weekDay);
        date = (TextView) view.findViewById(R.id.book_a_ride_date);

        ab = new AlertDialog.Builder(getActivity());

        // choose_your_ride_horizontal_scroll_view = (HorizontalScrollView) view.findViewById(R.id.choose_your_ride_horizontal_scroll_view);

        infoImagePerMeter = (ImageView) view.findViewById(R.id.infoImagePerMeter);

        marker_logo = (ImageView) view.findViewById(R.id.pickup_marker_logo);
        destination_marker_logo = (ImageView) view.findViewById(R.id.destination_marker_logo);

        selected_vehicle_type_of_meter = (ImageView) view.findViewById(R.id.selected_vehicle_type_of_meter);
        selected_vehicle_WhenRequire = (ImageView) view.findViewById(R.id.selected_vehicle_WhenRequire);

        nextImageChooseYourRide = (ImageView) view.findViewById(R.id.nextImageChooseYourRide);
        backImageTypeOfMeter = (ImageView) view.findViewById(R.id.backImageTypeOfMeter);
        nextImageTypeOfMeter = (ImageView) view.findViewById(R.id.nextImageTypeOfMeter);
        backImagebookingWhenRequired = (ImageView) view.findViewById(R.id.backImagebookingWhenRequired);
        imageViewFevoritDestination = (ImageView) view.findViewById(R.id.imageViewFevoritDestination);
        imageViewFevoritSource = (ImageView) view.findViewById(R.id.imageViewFevoritSource);


        linearLayoutChooseYourRide = (LinearLayout) view.findViewById(R.id.linearLayoutChooseYourRide);
        linearLayoutTypeOfMeter = (LinearLayout) view.findViewById(R.id.linearLayoutTypeOfMeter);
        linearLayoutWhenRequire = (LinearLayout) view.findViewById(R.id.linearLayoutWhenRequire);
        linearLayoutChooseYourRideButtons = (LinearLayout) view.findViewById(R.id.linearLayoutChooseYourRideButtons);
        linearLayoutTypeOfMeterButtons = (LinearLayout) view.findViewById(R.id.linearLayoutTypeOfMeterButtons);
        linearLayoutWhenRequiredButtons = (LinearLayout) view.findViewById(R.id.linearLayoutWhenRequiredButtons);
        linearLayout_background_blur = (LinearLayout) view.findViewById(R.id.linearLayout_background_blur);
        linearLayout_retry_cancel_buttons = (LinearLayout) view.findViewById(R.id.linearLayout_retry_cancel_buttons);

        //book_a_ride_from_TextInput = (TextInputLayout) view.findViewById(R.id.book_a_ride_from_TextInput);
        //book_a_ride_to_TextInput = (TextInputLayout) view.findViewById(R.id.book_a_ride_to_TextInput);

        /*choose_your_ride_textView = (TextView) view.findViewById(R.id.choose_your_ride_textView);*/
        type_of_meter_textView = (TextView) view.findViewById(R.id.type_of_meter_textView);

        when_require_textView = (TextView) view.findViewById(R.id.when_require_textView);

        driver_response_textView = (TextView) view.findViewById(R.id.driver_response_textView);
        selected_Rate_RupeesSymbol_textView = (TextView) view.findViewById(R.id.selected_Rate_RupeesSymbol_textView);


        selected_TypeOfMeter_WhenRequire_textView = (TextView) view.findViewById(R.id.selected_TypeOfMeter_WhenRequire_textView);
        selected_Rate_WhenRequire_textView = (TextView) view.findViewById(R.id.selected_Rate_WhenRequire_textView);
        selected_TypeOfMeter_as_per_any_WhenRequire_textView = (TextView) view.findViewById(R.id.selected_TypeOfMeter_as_per_any_WhenRequire_textView);

        sessionManager = new SessionManager(getActivity());
        sessionManager.couterZero();

        later_time.setEnabled(false);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        Date dates = cal.getTime();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateformat = new SimpleDateFormat("MMM dd, yyyy");
        date.setText(dateformat.format(dates));

        String weekDay;
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);

        Calendar calendar = Calendar.getInstance();
        weekDay = dayFormat.format(calendar.getTime());
        book_a_ride_weekDay.setText(weekDay);


        mapFrag = (SupportMapFragment) this.getChildFragmentManager().findFragmentById(R.id.mapViewPassenger);
        mapFrag.getMapAsync(this);
        count = 1;
        countAddress = 1;
        linearLayoutWhenRequire.setVisibility(View.GONE);

    }


    private void infoImages() {
        /*final String alertmsg = getResources().getString(R.string.alert);*/
        infoImagePerMeter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(getActivity())
                        /*.setTitle(alertmsg)*/
                        .setMessage(displayRateInISymbol)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        }).show();
            }
        });

        /*-------------------------------------------------------------------*/

        marker_logo.clearAnimation();
        TranslateAnimation transAnim = new TranslateAnimation(0, 0, -200, 0);
        transAnim.setStartOffset(100);
        transAnim.setDuration(2000);
        transAnim.setFillAfter(true);
        /*transAnim.setRepeatMode(0);*/
        transAnim.setRepeatCount(2);
        /*transAnim.setRepeatCount(Animation.INFINITE);*/
        transAnim.setInterpolator(new BounceInterpolator());
        transAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                Log.i(TAG, "Starting button dropdown animation");
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Log.i(TAG,
                        "Ending button dropdown animation. Clearing animation and setting layout");
                marker_logo.clearAnimation();
                final int left = marker_logo.getLeft();
                final int top = marker_logo.getTop();
                final int right = marker_logo.getRight();
                final int bottom = marker_logo.getBottom();
                marker_logo.layout(left, top, right, bottom);
            }
        });
        marker_logo.startAnimation(transAnim);

        /*-------------------------------------------------------------------*/


        nextImageChooseYourRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bookaridefrom.setEnabled(false);
                bookarideto.setEnabled(false);

                linearLayoutChooseYourRide.setVisibility(View.GONE);
                linearLayoutChooseYourRideButtons.setVisibility(View.GONE);
                linearLayoutTypeOfMeter.setVisibility(View.VISIBLE);
                linearLayoutTypeOfMeterButtons.setVisibility(View.VISIBLE);
                linearLayoutWhenRequire.setVisibility(View.GONE);
                linearLayoutWhenRequiredButtons.setVisibility(View.GONE);
                finding_nearest_textView.setVisibility(View.GONE);
                passenger_offer_progressbar.setVisibility(View.GONE);
            }
        });

        backImageTypeOfMeter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                notChangeAddress = "a";

                bookaridefrom.setEnabled(true);
                bookarideto.setEnabled(true);

                taxi.setChecked(false);
                auto.setChecked(false);
                bike.setChecked(false);
                any.setChecked(false);

                notChangeAddress = "a";

                linearLayoutChooseYourRide.setVisibility(View.VISIBLE);
                /*linearLayoutChooseYourRideButtons.setVisibility(View.VISIBLE);*/
                linearLayoutTypeOfMeter.setVisibility(View.GONE);
                linearLayoutTypeOfMeterButtons.setVisibility(View.GONE);
                linearLayoutWhenRequire.setVisibility(View.GONE);
                linearLayoutWhenRequiredButtons.setVisibility(View.GONE);
                finding_nearest_textView.setVisibility(View.GONE);
                passenger_offer_progressbar.setVisibility(View.GONE);
            }
        });

        nextImageTypeOfMeter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bookaridefrom.setEnabled(false);
                bookarideto.setEnabled(false);

                if (string_type_of_rate == null) {

                } else if (string_type_of_rate.equals("Permeter")) {
                    if (meter_value.isEmpty()) {
                    } else {
                        linearLayoutChooseYourRide.setVisibility(View.GONE);
                        linearLayoutTypeOfMeter.setVisibility(View.GONE);
                        linearLayoutTypeOfMeterButtons.setVisibility(View.GONE);
                        linearLayoutWhenRequire.setVisibility(View.VISIBLE);
                        linearLayoutWhenRequiredButtons.setVisibility(View.VISIBLE);
                        finding_nearest_textView.setVisibility(View.GONE);
                        passenger_offer_progressbar.setVisibility(View.GONE);
                    }
                } else if (type_of_rate_value.isEmpty()) {
                } else {
                    linearLayoutChooseYourRide.setVisibility(View.GONE);
                    linearLayoutTypeOfMeter.setVisibility(View.GONE);
                    linearLayoutTypeOfMeterButtons.setVisibility(View.GONE);
                    linearLayoutWhenRequire.setVisibility(View.VISIBLE);
                    linearLayoutWhenRequiredButtons.setVisibility(View.VISIBLE);
                    finding_nearest_textView.setVisibility(View.GONE);
                    passenger_offer_progressbar.setVisibility(View.GONE);
                }
            }
        });

        backImagebookingWhenRequired.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bookaridefrom.setEnabled(false);
                bookarideto.setEnabled(false);

                linearLayoutChooseYourRide.setVisibility(View.GONE);
                /*linearLayoutChooseYourRideButtons.setVisibility(View.GONE);*/
                linearLayoutTypeOfMeter.setVisibility(View.VISIBLE);
                linearLayoutTypeOfMeterButtons.setVisibility(View.VISIBLE);
                linearLayoutWhenRequire.setVisibility(View.GONE);
                linearLayoutWhenRequiredButtons.setVisibility(View.GONE);
                finding_nearest_textView.setVisibility(View.GONE);
                passenger_offer_progressbar.setVisibility(View.GONE);
                /*getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);*/
            }
        });
        /*-------------------------------------------------------------------*/


        /*----------------------------------fevoritdestination  button------------------------ */
        imageViewFevoritDestination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String address = bookarideto.getText().toString();
                if (address.equals("")) {

                    /* bookarideto.setError("please select the destination address");*/
                } else {
                    CustomDialogClass cdd = new CustomDialogClass(getActivity(), address, tolatitude, tolongitude, sessionManager.getUserDetails().get("mobile"), "destination");
                    cdd.setCancelable(false);
                    cdd.show();
                    Window window = cdd.getWindow();
                    assert window != null;
                    window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);

                }

            }
        });

        imageViewFevoritSource.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String address = bookaridefrom.getText().toString();
                if (address.equals("")) {

                    /* bookarideto.setError("please select the destination address");*/
                } else {
                    CustomDialogClass cdd = new CustomDialogClass(getActivity(), address, tolatitude, tolongitude, sessionManager.getUserDetails().get("mobile"), "source");
                    cdd.setCancelable(false);
                    cdd.show();
                    Window window = cdd.getWindow();
                    assert window != null;
                    window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);

                }

            }
        });

    }

    private void setValuesBasedOnOptions() {

        user = new HashMap<String, String>();

        user = sessionManager.getUserDetails();
        //-------------------------------------------------------------------------------------------------------------------------
//--------------------------set the selected values for vehicle choice based choice of passenger---------------------------
//-------------------------------------------------------------------------------------------------------------------------

        choose_vehicle.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.book_a_ride_taxi:

                        when_required.clearCheck();
                        type_of_rate.clearCheck();
                        when_required_value = null;
                        when_required_type = null;
                        string_type_of_rate = null;
                        type_of_rate_value = null;
                        meter_value = null;

                        if (!(Functions.isFromToSelected(fromlatitude, fromlongitude, tolatitude, tolongitude))) {

                            choose_vehicle.clearCheck();
                        } else {

                            choose_vehicle_value = "Taxi";
                            /*  priceVehicle = 15;*/

                            notChangeAddress = "b";

                            selected_vehicle_type_of_meter.setBackgroundResource(R.drawable.micro);
                            selected_vehicle_WhenRequire.setBackgroundResource(R.drawable.micro);

                            getDistanceByServer();

                            /*----------------------------------------------------------------------------------------------------------*/



                            /*----------------------------------------------------------------------------------------------------------*/


                            /* getDistance(startLatitude, startLongitude, endLatitude, endLongitude);*/
                        }
                        break;

                    case R.id.book_a_ride_auto:

                        when_required.clearCheck();
                        type_of_rate.clearCheck();
                        when_required_value = null;
                        when_required_type = null;
                        string_type_of_rate = null;
                        type_of_rate_value = null;
                        meter_value = null;

                        if (!(Functions.isFromToSelected(fromlatitude, fromlongitude, tolatitude, tolongitude))) {

                            choose_vehicle.clearCheck();
                        } else {

                            choose_vehicle_value = "Auto";
                          /*  priceVehicle = 12;
                            getDistance(startLatitude, startLongitude, endLatitude, endLongitude);*/

                            notChangeAddress = "b";

                            selected_vehicle_type_of_meter.setBackgroundResource(R.drawable.auto);
                            selected_vehicle_WhenRequire.setBackgroundResource(R.drawable.auto);
                            /*selected_TypeOfMeter_as_per_any_WhenRequire_textView.setVisibility(View.GONE);*/
                            getDistanceByServer();

                            /*----------------------------------------------------------------------------------------------------------*/


                            /*----------------------------------------------------------------------------------------------------------*/

                        }
                        break;

                    case R.id.book_a_ride_bike:

                        when_required.clearCheck();
                        type_of_rate.clearCheck();
                        when_required_value = null;
                        when_required_type = null;
                        string_type_of_rate = null;
                        type_of_rate_value = null;
                        meter_value = null;

                        if (!(Functions.isFromToSelected(fromlatitude, fromlongitude, tolatitude, tolongitude))) {

                            choose_vehicle.clearCheck();
                        } else {

                            choose_vehicle_value = bike.getText().toString();
                            choose_vehicle_value = "Bike";
                          /*  priceVehicle = 8;
                            getDistance(startLatitude, startLongitude, endLatitude, endLongitude);*/

                            notChangeAddress = "b";

                            selected_vehicle_type_of_meter.setBackgroundResource(R.drawable.bike);
                            selected_vehicle_WhenRequire.setBackgroundResource(R.drawable.bike);

                            getDistanceByServer();

                            /*----------------------------------------------------------------------------------------------------------*/


                            /*----------------------------------------------------------------------------------------------------------*/

                        }
                        break;

                    case R.id.book_a_ride_any:

                        when_required.clearCheck();
                        type_of_rate.clearCheck();
                        when_required_value = null;
                        when_required_type = null;
                        string_type_of_rate = null;
                        type_of_rate_value = null;
                        meter_value = null;

                        if (!(Functions.isFromToSelected(fromlatitude, fromlongitude, tolatitude, tolongitude))) {

                            choose_vehicle.clearCheck();
                        } else {


                            choose_vehicle_value = "Any";

                            /*priceVehicle = 15;
                            getDistance(startLatitude, startLongitude, endLatitude, endLongitude);*/

                            notChangeAddress = "b";

                            selected_vehicle_type_of_meter.setBackgroundResource(R.drawable.radio_logo_any_ride);
                            selected_vehicle_WhenRequire.setBackgroundResource(R.drawable.radio_logo_any_ride);

                            getDistanceByServer();

                            /*----------------------------------------------------------------------------------------------------------*/


                            /*----------------------------------------------------------------------------------------------------------*/


                        }
                        break;
                }
            }
        });
//----------------------------------------------------------------------------------------------------------------
//-----------------------------set the when required values based choice of passenger-----------------------------
//----------------------------------------------------------------------------------------------------------------

        when_required.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    //-------------------------------------------------------------------
                    //-----sets the current time because immediate option is selected----
                    //-------------------------------------------------------------------
                    case R.id.book_a_ride_immediate:


                        later_time.setEnabled(false);
                        later_time.setVisibility(View.GONE);

                        Calendar mcurrentTime = Calendar.getInstance();
                        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                        int minute = mcurrentTime.get(Calendar.MINUTE);
                        when_required_type = "immediate";

                        /*linearLayoutWhenRequire.setVisibility(View.GONE);*/
                        /*submit_button.setVisibility(View.VISIBLE);*/
                        submit_button.requestFocus();

                        /*backButtonCount=3;*/

                        String AM_PM;
                        if (hour < 12) {
                            AM_PM = "AM";
                        } else {
                            AM_PM = "PM";
                            hour -= 12;
                        }


                        when_required_value = +hour % 12 + ":" + minute + AM_PM;

                        break;
                    //--------------------------------------------------------------------------------------------
                    //----gives the choice to select time by a dialog of clock when cloice "later is selected"----
                    //--------------------------------------------------------------------------------------------
                    case R.id.book_a_ride_later:
                        when_required_type = "later";
                        later_time.setEnabled(true);
                        later_time.setVisibility(View.VISIBLE);

                       /*linearLayoutWhenRequire.setVisibility(View.GONE);
                        submit_button.setVisibility(View.VISIBLE);
                        submit_button.requestFocus();*/

                        /*backButtonCount=3;*/

                        later_time.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                // Get Current Date
                                c = Calendar.getInstance();
                                int mYear = c.get(Calendar.YEAR);
                                int mMonth = c.get(Calendar.MONTH);
                                int mDay = c.get(Calendar.DAY_OF_MONTH);

                                Calendar minCal = Calendar.getInstance();
                                minCal.set(Calendar.YEAR, minCal.get(Calendar.YEAR));
                                minCal.set(Calendar.MONTH, minCal.get(Calendar.MONTH));
                                minCal.set(Calendar.DAY_OF_MONTH, minCal.get(Calendar.DAY_OF_MONTH));

                                Calendar maxCal = Calendar.getInstance();
                                maxCal.set(Calendar.YEAR, maxCal.get(Calendar.YEAR));
                                maxCal.set(Calendar.MONTH, maxCal.get(Calendar.MONTH));
                                maxCal.set(Calendar.DAY_OF_MONTH, maxCal.get(Calendar.DAY_OF_MONTH) + 3);

                                DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                                        new DatePickerDialog.OnDateSetListener() {

                                            @Override
                                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                                                date_time = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                                                //*************Call Time Picker Here ********************
                                                if (dayOfMonth == c.get(Calendar.DAY_OF_MONTH)) {
                                                    timePicker();
                                                } else {
                                                    timePickerNextDay();
                                                }

                                            }
                                        }, mYear, mMonth, mDay);

                                datePickerDialog.getDatePicker().setMaxDate(maxCal.getTimeInMillis());
                                datePickerDialog.getDatePicker().setMinDate(minCal.getTimeInMillis());
                                datePickerDialog.show();



                              /*  Calendar mcurrentTime = Calendar.getInstance();
                                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                                int minute = mcurrentTime.get(Calendar.MINUTE);
                                TimePickerDialog mTimePicker;
                                mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener()
                                {
                                    @Override
                                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                                        String AM_PM;
                                        if(selectedHour<12)
                                        {
                                            AM_PM="AM";
                                        }
                                        else
                                        {
                                            AM_PM="PM";
                                            selectedHour-=12;
                                        }

                                        later_time.setText(selectedHour%12 + ":" + selectedMinute+" "+AM_PM);
                                        when_required_value=later_time.getText().toString();
                                    }
                                }, hour, minute, false);//Yes 24 hour time
                                mTimePicker.setTitle("Select Time");
                                mTimePicker.show();*/
                            }
                        });
                        break;
                }
            }
        });

//----------------------------------------------------------------------------------------------------------------
//-----------------------------Selection of type of rate and the value--------------------------------------------
//----------------------------------------------------------------------------------------------------------------

        type_of_rate.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.book_a_ride_fixed_amount:

                        edit_fixed_amount.setEnabled(true);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(false);

                        edit_fixed_amount.requestFocus();
                        edit_fixed_amount.setFocusableInTouchMode(true);

                        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.showSoftInput(edit_fixed_amount, InputMethodManager.SHOW_FORCED);

                        // edit_per_meter.setText("");
                        edit_meter_plus.setText("");
                        edit_meter_less.setText("");

                        type_of_rate_value = edit_fixed_amount.getText().toString();
                        string_type_of_rate = "Fixed Amount";
                        /*type_of_rate_value = edit_fixed_amount.getText().toString();*/
                        selected_TypeOfMeter_WhenRequire_textView.setText(resources.getString(R.string.fixed_amount));
                        selected_Rate_WhenRequire_textView.setText(type_of_rate_value);

                        /*---------------------------------------------------------------------------------------------*/


                        /*---------------------------------------------------------------------------------------------*/

                        edit_fixed_amount.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                type_of_rate_value = edit_fixed_amount.getText().toString();
                                selected_Rate_WhenRequire_textView.setText(type_of_rate_value);
                            }
                        });


                        break;

                    case R.id.book_a_ride_per_meter:

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(false);
                        meter_value = edit_per_meter.getText().toString();
                        type_of_rate_value = "0";
                        /*type_of_rate_value=edit_per_meter.getText().toString();*/
                        string_type_of_rate = "Permeter";


                        edit_fixed_amount.setText("");
                        edit_meter_plus.setText("");
                        edit_meter_less.setText("");

                        /*type_of_rate_value = edit_per_meter.getText().toString();*/

                        selected_TypeOfMeter_WhenRequire_textView.setText(resources.getString(R.string.per_meter));
                        selected_Rate_WhenRequire_textView.setText(meter_value);
                        /*---------------------------------------------------------------------------------------------*/


                        /*---------------------------------------------------------------------------------------------*/


                        edit_per_meter.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                                /*string_type_of_rate="permeter";*/
                            }
                        });

                        break;

                    case R.id.book_a_ride_meter_plus_extra:

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(true);
                        edit_meter_less.setEnabled(false);


                        edit_meter_plus.requestFocus();
                        edit_meter_plus.setFocusableInTouchMode(true);

                        InputMethodManager imm2 = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm2.showSoftInput(edit_meter_plus, InputMethodManager.SHOW_FORCED);

                        edit_fixed_amount.setText("");
                        // edit_per_meter.setText("");
                        edit_meter_less.setText("");

                        type_of_rate_value = edit_meter_plus.getText().toString();
                        string_type_of_rate = "Meter Plus Extra";
                        /*type_of_rate_value = edit_meter_plus.getText().toString();*/

                        selected_TypeOfMeter_WhenRequire_textView.setText(resources.getString(R.string.meter_plus_extra));
                        selected_Rate_WhenRequire_textView.setText(type_of_rate_value);
                        /*---------------------------------------------------------------------------------------------*/



                        /*---------------------------------------------------------------------------------------------*/

                        edit_meter_plus.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                                type_of_rate_value = edit_meter_plus.getText().toString();
                                selected_Rate_WhenRequire_textView.setText(type_of_rate_value);
                            }
                        });

                        break;

                    case R.id.book_a_ride_meter_minus_extra:

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(true);

                        edit_fixed_amount.setText("");
                        //   edit_per_meter.setText("");
                        edit_meter_plus.setText("");

                        edit_meter_less.requestFocus();
                        edit_meter_less.setFocusableInTouchMode(true);

                        InputMethodManager imm3 = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm3.showSoftInput(edit_meter_less, InputMethodManager.SHOW_FORCED);

                        type_of_rate_value = edit_meter_less.getText().toString();
                        string_type_of_rate = "Meter Minus Extra";
                        /*type_of_rate_value = edit_meter_less.getText().toString();*/

                        selected_TypeOfMeter_WhenRequire_textView.setText(resources.getString(R.string.meter_less_extra));
                        selected_Rate_WhenRequire_textView.setText(type_of_rate_value);
                        /*---------------------------------------------------------------------------------------------*/



                        /*---------------------------------------------------------------------------------------------*/

                        edit_meter_less.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                                type_of_rate_value = edit_meter_less.getText().toString();
                                selected_Rate_WhenRequire_textView.setText(type_of_rate_value);
                            }
                        });

                        break;
                }
            }
        });

        bookaridefrom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cursorStatus = 1;

                callPlaceAutocompleteActivityIntentFrom();
                choose_vehicle.setOnCheckedChangeListener(null);

                edit_per_meter.setText("");
                choose_vehicle.clearCheck();
                when_required.clearCheck();
                type_of_rate.clearCheck();
                choose_vehicle_value = null;
                when_required_value = null;
                when_required_type = null;
                string_type_of_rate = null;
                type_of_rate_value = null;
                meter_value = null;

                setValuesBasedOnOptions();

                marker_logo.setVisibility(View.VISIBLE);
                destination_marker_logo.setVisibility(View.GONE);

            }
        });

        bookarideto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cursorStatus = 2;
                if (fromlatitude == null) {

                } else {

                    callPlaceAutocompleteActivityIntentTo();

                }
                edit_per_meter.setText("");

                choose_vehicle.setOnCheckedChangeListener(null);


                choose_vehicle.clearCheck();
                when_required.clearCheck();
                type_of_rate.clearCheck();
                choose_vehicle_value = null;
                when_required_value = null;
                when_required_type = null;
                string_type_of_rate = null;
                type_of_rate_value = null;
                meter_value = null;

                setValuesBasedOnOptions();

                marker_logo.setVisibility(View.GONE);
                destination_marker_logo.setVisibility(View.VISIBLE);
            }
        });

        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                meter_value = edit_per_meter.getText().toString();
                if (!(Functions.isAllBookingFieldSelected(choose_vehicle_value, when_required_value, string_type_of_rate, type_of_rate_value, fromlatitude, tolatitude))) {
                } else //noinspection ObjectEqualsNull
                    if (when_required_value.equals(null)) {
                        later_time.requestFocus();
                        later_time.setError(resources.getString(R.string.please_enter_time));
                    } else {
                        later_time.clearFocus();
                        later_time.setError(null);

                        linearLayout_background_blur.setVisibility(View.VISIBLE);
                        finding_nearest_textView.setVisibility(View.VISIBLE);
                        passenger_offer_progressbar.setVisibility(View.VISIBLE);
                        passenger_offer_progressbar.setBackgroundColor(getResources().getColor(R.color.white));
                        passenger_offer_progressbar.setMax(100);
                        passenger_offer_progressbar.setProgress(40);
                        passenger_offer_progressbar.setIndeterminate(true);
                        /*sendRideRequest();*/
                        setTimerForRideRequest();

                    }
            }
        });

    }


    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PLACE_PICKER_REQUEST_FROM) {
            if (resultCode == RESULT_OK) {

                cdd.dismiss();

                bookaridefrom.setEnabled(true);

                Place place = PlacePicker.getPlace(data, getActivity());
                @SuppressWarnings("MismatchedQueryAndUpdateOfStringBuilder") StringBuilder stBuilder = new StringBuilder();
                String placename = String.format("%s", place.getName());
                fromlatitude = String.valueOf(place.getLatLng().latitude);
                fromlongitude = String.valueOf(place.getLatLng().longitude);
                String address = String.format("%s", place.getAddress());

                String locale = String.format("%s", place.getLocale());

                stBuilder.append("Name: ");
                stBuilder.append(placename);
                stBuilder.append("\n");
                stBuilder.append("Latitude: ");
                stBuilder.append(fromlatitude);
                stBuilder.append("\n");
                stBuilder.append("Logitude: ");
                stBuilder.append(fromlongitude);
                stBuilder.append("\n");
                stBuilder.append("Address: ");
                stBuilder.append(address);

                stBuilder.append("Locale: ");
                stBuilder.append(locale);

                bookaridefrom.setText(place.getAddress());
                latLngBounds = new LatLngBounds(new LatLng(place.getLatLng().latitude, place.getLatLng().longitude), new LatLng(place.getLatLng().latitude, place.getLatLng().longitude));

                latLng = new LatLng(place.getLatLng().latitude, place.getLatLng().longitude);

                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {

                bookaridefrom.setEnabled(true);
                Status status = PlaceAutocomplete.getStatus(getActivity(), data);
                Log.i(TAG, status.getStatusMessage());
            } else if (resultCode == RESULT_CANCELED) {


                bookaridefrom.setEnabled(true);
                // The user canceled the operation.
            }
        } /*else if (requestCode == PLACE_PICKER_REQUEST_TO) {
            if (resultCode == RESULT_OK) {
                Place place = PlacePicker.getPlace(data, getActivity());
                StringBuilder stBuilder = new StringBuilder();

                String placename = String.format("%s", place.getName());
                tolatitude = String.valueOf(place.getLatLng().latitude);
                tolongitude = String.valueOf(place.getLatLng().longitude);
                String address = String.format("%s", place.getAddress());
                stBuilder.append("Name: ");
                stBuilder.append(placename);
                stBuilder.append("\n");
                stBuilder.append("Latitude: ");
                stBuilder.append(tolatitude);
                stBuilder.append("\n");
                stBuilder.append("Logitude: ");
                stBuilder.append(tolongitude);
                stBuilder.append("\n");
                stBuilder.append("Address: ");
                stBuilder.append(address);
                bookarideto.setText(place.getAddress());

                latLngBounds = new LatLngBounds(
                        new LatLng(place.getLatLng().latitude, place.getLatLng().longitude), new LatLng(place.getLatLng().latitude, place.getLatLng().longitude));

                startLatitude = Double.parseDouble(fromlatitude);
                startLongitude = Double.parseDouble(fromlongitude);
                endLatitude = Double.parseDouble(tolatitude);
                endLongitude = Double.parseDouble(tolongitude);

            }
        }*/ else if (requestCode == PLACE_PICKER_REQUEST_TO) {

            if (resultCode == RESULT_OK) {

                cdd.dismiss();

                bookarideto.setEnabled(true);
                Place place = PlaceAutocomplete.getPlace(getActivity(), data);
                @SuppressWarnings("MismatchedQueryAndUpdateOfStringBuilder") StringBuilder stBuilder = new StringBuilder();

                String placename = String.format("%s", place.getName());
                tolatitude = String.valueOf(place.getLatLng().latitude);
                tolongitude = String.valueOf(place.getLatLng().longitude);
                String address = String.format("%s", place.getAddress());
                stBuilder.append("Name: ");
                stBuilder.append(placename);
                stBuilder.append("\n");
                stBuilder.append("Latitude: ");
                stBuilder.append(tolatitude);
                stBuilder.append("\n");
                stBuilder.append("Logitude: ");
                stBuilder.append(tolongitude);
                stBuilder.append("\n");
                stBuilder.append("Address: ");
                stBuilder.append(address);
                bookarideto.setText(place.getAddress());

                latLngBounds = new LatLngBounds(
                        new LatLng(place.getLatLng().latitude, place.getLatLng().longitude), new LatLng(place.getLatLng().latitude, place.getLatLng().longitude));

                startLatitude = Double.parseDouble(fromlatitude);
                startLongitude = Double.parseDouble(fromlongitude);
                endLatitude = Double.parseDouble(tolatitude);
                endLongitude = Double.parseDouble(tolongitude);

                latLng = new LatLng(place.getLatLng().latitude, place.getLatLng().longitude);
                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                bookarideto.setEnabled(true);
                Status status = PlaceAutocomplete.getStatus(getActivity(), data);
                Log.i(TAG, status.getStatusMessage());
            } else if (resultCode == RESULT_CANCELED) {
                bookarideto.setEnabled(true);

            }

        }
    }


    private void timePicker() {

        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        /*hourOfDay=c.get(Calendar.HOUR_OF_DAY);*/

                        if (hourOfDay <= (c.get(Calendar.HOUR_OF_DAY)) &&
                                (minute <= (c.get(Calendar.MINUTE)))) {
                            timePicker();

                        } else if (hourOfDay == (c.get(Calendar.HOUR_OF_DAY))) {
                            timePicker();
                        } else if (hourOfDay == (c.get(Calendar.HOUR_OF_DAY) + 1)) {
                            timePickerMinute();
                        } else {
                            mHour = hourOfDay;
                            mMinute = minute;
                            later_time.setText(date_time + " " + hourOfDay + ":" + minute);
                            when_required_value = later_time.getText().toString();
                        }
                    }
                }, mHour, mMinute, false);

        timePickerDialog.show();
    }

    private void timePickerMinute() {

        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        if (minute == (c.get(Calendar.MINUTE))) {
                            timePickerMinute();
                        } else if (minute <= (c.get(Calendar.MINUTE))) {
                            timePickerMinute();
                        } else if (minute >= (c.get(Calendar.MINUTE))) {
                            mHour = hourOfDay;
                            mMinute = minute;
                            later_time.setText(date_time + " " + hourOfDay + ":" + minute);
                            when_required_value = later_time.getText().toString();
                        } else {
                            mHour = hourOfDay;
                            mMinute = minute;
                            later_time.setText(date_time + " " + hourOfDay + ":" + minute);
                            when_required_value = later_time.getText().toString();
                        }
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }


    private void timePickerNextDay() {
        // Get Current Time

        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        // Launch Time Picker Dialog
        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        mHour = hourOfDay;
                        mMinute = minute;

                        later_time.setText(date_time + " " + hourOfDay + ":" + minute);
                        when_required_value = later_time.getText().toString();

                    }
                }, mHour, mMinute, false);

        timePickerDialog.show();

    }


    private void getDistanceByServer() {
        loading = ProgressDialog.show(getActivity(), resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequestNotification = new StringRequest(Request.Method.POST, getPriceAndTIme,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String responses) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(responses);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                currency_symbol = jObj.getString("currency_symbol");

                                sessionManager.setCurrency(currency_symbol);
                                selected_Rate_RupeesSymbol_textView.setText(sessionManager.getCurrency());

                                distance = jObj.getString("distance");
                                linearLayoutChooseYourRide.setVisibility(View.GONE);
                                linearLayoutChooseYourRideButtons.setVisibility(View.GONE);
                                linearLayoutTypeOfMeter.setVisibility(View.VISIBLE);
                                linearLayoutTypeOfMeterButtons.setVisibility(View.VISIBLE);
                                linearLayoutWhenRequire.setVisibility(View.GONE);
                                linearLayoutWhenRequiredButtons.setVisibility(View.GONE);
                                bookaridefrom.setEnabled(false);
                                bookarideto.setEnabled(false);


                                Bundle bundle = new Bundle();

                                bundle.putString("currency_symbol", currency_symbol);
                                bundle.putString("from", bookaridefrom.getText().toString());
                                bundle.putString("to", bookarideto.getText().toString());
                                bundle.putString("distance", distance);
                                bundle.putString("fromlatitude", fromlatitude);
                                bundle.putString("fromlongitude", fromlongitude);
                                bundle.putString("tolatitude", tolatitude);
                                bundle.putString("tolongitude", tolongitude);
                                bundle.putString("state_name", tolongitude);


                                FragmentBooking2 nextFragment = new FragmentBooking2();
                                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();

                                switch (choose_vehicle_value) {
                                    case "Taxi":

                                        taxi_rate = jObj.getString("taxi_rate");
                                        edit_per_meter.setText(taxi_rate);

                                        minimum_fare_taxi = jObj.getString("minimum_fare");
                                        per_km_taxi = jObj.getString("per_km");

                                        displayRateInISymbol = "Minimum Fair of taxi is " + minimum_fare_taxi +
                                                "\nTaxi Rate per kilometer is " + per_km_taxi;


                                        bundle.putString("vehicle_type", "Taxi");
                                        bundle.putString("rate", taxi_rate);
                                        bundle.putString("minimum_fare", minimum_fare_taxi);
                                        bundle.putString("per_km", per_km_taxi);
                                        nextFragment.setArguments(bundle);
                                        fragmentManager.beginTransaction()
                                                .replace(R.id.content_frame, nextFragment)
                                                .commit();


                                        break;

                                    case "Auto":
                                        auto_rate = jObj.getString("auto_rate");
                                        edit_per_meter.setText(auto_rate);
                                        minimum_fare_auto = jObj.getString("minimum_fare");
                                        per_km_auto = jObj.getString("per_km");
                                        displayRateInISymbol = "Minimum Fair of Auto is " + minimum_fare_auto +
                                                "\nAuto Rate per kilometer is " + per_km_auto;


                                        bundle.putString("vehicle_type", "Auto");
                                        bundle.putString("rate", auto_rate);
                                        bundle.putString("minimum_fare", minimum_fare_auto);
                                        bundle.putString("per_km", per_km_auto);


                                        nextFragment.setArguments(bundle);


                                        fragmentManager.beginTransaction()
                                                .replace(R.id.content_frame, nextFragment)
                                                .commit();


                                        break;

                                    case "Bike":
                                        bike_rate = jObj.getString("bike_rate");
                                        edit_per_meter.setText(bike_rate);

                                        minimum_fare_bike = jObj.getString("minimum_fare");
                                        per_km_bike = jObj.getString("per_km");

                                        displayRateInISymbol = "Minimum Fair of Bike is " + minimum_fare_bike +
                                                "\nBike Rate per kilometer is " + per_km_bike;


                                        bundle.putString("vehicle_type", "Bike");
                                        bundle.putString("rate", bike_rate);
                                        bundle.putString("minimum_fare", minimum_fare_bike);
                                        bundle.putString("per_km", per_km_bike);


                                        nextFragment.setArguments(bundle);


                                        fragmentManager.beginTransaction()
                                                .replace(R.id.content_frame, nextFragment)
                                                .commit();


                                        break;
                                    case "Any":

                                        taxi_rate = jObj.getString("taxi_rate");
                                        auto_rate = jObj.getString("auto_rate");
                                        edit_per_meter.setText(taxi_rate);

                                        taxi_rate_in_area = jObj.getString("taxi_rate");
                                        auto_rate_in_area = jObj.getString("auto_rate");

                                        minimum_fare_taxi = jObj.getString("minimum_fare_taxi");
                                        per_km_taxi = jObj.getString("per_km_taxi");
                                        minimum_fare_auto = jObj.getString("minimum_fare_auto");
                                        per_km_auto = jObj.getString("per_km_auto");


                                        displayRateInISymbol = "Minimum Fair of taxi is " + minimum_fare_taxi +
                                                "\nMinimum Fair of Auto is " + minimum_fare_auto +
                                                "\nTaxi Rate per kilometer is " + per_km_taxi +
                                                "\nAuto Rate per kilometer is " + per_km_auto;
                                        break;
                                }


                            } else {
                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                        choose_vehicle.clearCheck();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("from_lat", fromlatitude);
                params.put("from_long", fromlongitude);
                params.put("to_lat", tolatitude);
                params.put("to_long", tolongitude);
                params.put("vehicle_type", choose_vehicle_value);
                params.put("city", city);
                params.put("mobile_no", user.get("mobile"));

                return params;
            }
        };

        stringRequestNotification.setRetryPolicy(new DefaultRetryPolicy(4500, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequestNotification);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {


        mGoogleMap = googleMap;
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mGoogleMap.setMyLocationEnabled(true);


        @SuppressWarnings("ConstantConditions") View locationButton = ((View) mapFrag.getView().findViewById(Integer.parseInt("1")).getParent()).findViewById(Integer.parseInt("2"));
        RelativeLayout.LayoutParams rlp = (RelativeLayout.LayoutParams) locationButton.getLayoutParams();
        // position on right bottom
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0);
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        rlp.setMargins(0, 450, 0, 0);


        //Initialize Google Play Services
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (ContextCompat.checkSelfPermission(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mGoogleMap.setMyLocationEnabled(true);
                rlp.setMargins(0, 450, 0, 0);
            }
        } else {
            buildGoogleApiClient();
            mGoogleMap.setMyLocationEnabled(true);
            rlp.setMargins(0, 450, 0, 0);
        }


        mGoogleMap.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener() {
            @Override
            public void onCameraChange(CameraPosition cameraPosition) {

                Log.d("Camera postion change" + "", cameraPosition + "");

                mCenterLatLong = cameraPosition.target;

                if (cursorStatus == 1) {
                    getAddress(mCenterLatLong);
                } else {
                    getAddressTo(mCenterLatLong);
                }
            }
        });


    }

    private void getAddress(final LatLng mCenterLatLong) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    Location mLocation = new Location("");
                    mLocation.setLatitude(mCenterLatLong.latitude);
                    mLocation.setLongitude(mCenterLatLong.longitude);
                    Geocoder geocoder;
                    List<android.location.Address> yourAddresses;
                    geocoder = new Geocoder(getActivity(), Locale.getDefault());
                    yourAddresses = geocoder.getFromLocation(mLocation.getLatitude(), mLocation.getLongitude(), 1);

                    final String yourAddress = yourAddresses.get(0).getAddressLine(0);
                    if (yourAddresses != null && yourAddresses.size() > 0) {
                        android.location.Address address = yourAddresses.get(0);
                        @SuppressWarnings("MismatchedQueryAndUpdateOfStringBuilder") StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                            sb.append(address.getAddressLine(i)).append("\n");
                        }
                        city = address.getLocality();
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            bookaridefrom.setText(yourAddress);
                            fromlatitude = Double.toString(mCenterLatLong.latitude);
                            fromlongitude = Double.toString(mCenterLatLong.longitude);
                        }
                    });
                } catch (Exception e) {

                }
            }
        }).start();
    }

    private void getAddressTo(final LatLng mCenterLatLong) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    Location mLocation = new Location("");
                    mLocation.setLatitude(mCenterLatLong.latitude);
                    mLocation.setLongitude(mCenterLatLong.longitude);
                    Geocoder geocoder;
                    List<android.location.Address> yourAddresses;
                    geocoder = new Geocoder(getActivity(), Locale.getDefault());
                    yourAddresses = geocoder.getFromLocation(mLocation.getLatitude(), mLocation.getLongitude(), 1);

                    final String yourAddress = yourAddresses.get(0).getAddressLine(0);
                 /*   if (yourAddresses != null && yourAddresses.size() > 0) {
                        android.location.Address address = yourAddresses.get(0);
                        @SuppressWarnings("MismatchedQueryAndUpdateOfStringBuilder") StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                            sb.append(address.getAddressLine(i)).append("\n");
                        }
                        city = address.getLocality();
                    }*/

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            /*if (notChangeAddress.equals("a")) {
                                bookarideto.setText(yourAddress);
                                tolatitude = Double.toString(mCenterLatLong.latitude);
                                tolongitude = Double.toString(mCenterLatLong.longitude);
                            }*/
                            bookarideto.setText(yourAddress);
                            tolatitude = Double.toString(mCenterLatLong.latitude);
                            tolongitude = Double.toString(mCenterLatLong.longitude);
                        }
                    });
                } catch (Exception e) {

                }
            }
        }).start();
    }


    @Override
    public void onLocationChanged(Location location) {
        {

            Location mLastLocation = location;

            trakingLatitude = mLastLocation.getLatitude();
            trackingLongitude = mLastLocation.getLongitude();

            latLng = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());


            if (count == 1) {
                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));
                count++;
            }

            bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.carmarker);
           /* getAddress();*/

        }
    }

    private synchronized void buildGoogleApiClient() {
        mClient = new GoogleApiClient.Builder(getActivity())
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .addApi(Places.PLACE_DETECTION_API)
                .build();
        mClient.connect();
    }


    private void getDriversLocations() {


        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!Thread.interrupted())
                    try {
                        Thread.sleep(2000);
                        /*getActivity().runOnUiThread(new Runnable() // start actions in UI thread
                        {*/


                        //noinspection StatementWithEmptyBody
                        if (trakingLatitude == null && trackingLongitude == null) {

                        } else {


                            locationRequest();
                       }

                    } catch (InterruptedException ignored) {

                    }
            }
        });

        t.start();

    }


    private void locationRequest() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, updateLocationOfDrivers,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                mGoogleMap.clear();
                                /*mGoogleMap.clear();*/

                                JSONArray contacts = jObj.getJSONArray("user");

                                for (int i = 0; i < contacts.length(); i++) {
                                    JSONObject c = contacts.getJSONObject(i);

                                    String lat = c.getString("lat");
                                    String lng = c.getString("lng");
                                    String vehicle_type = c.getString("vehicle_type");

                                    double value1 = Double.parseDouble(lat);
                                    double value2 = Double.parseDouble(lng);
                                    int height = 70;
                                    int width = 110;

                                    LatLng latLngForNearLocation = new LatLng(value1, value2);

                                    if (vehicle_type.equals("Taxi(4+1)")) {

                                        bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.carmarker);
                                    } else {

                                        bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.mipmap.rickshawtopview);

                                    }

                                    Bitmap b = bitmapdraw.getBitmap();
                                    Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);

                                    mk = mGoogleMap.addMarker(new MarkerOptions().position(latLngForNearLocation)
                                            .icon(BitmapDescriptorFactory.fromBitmap((smallMarker))));

                                }

                            } else {


                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();


                params.put("lat", Double.toString(trakingLatitude));
                params.put("lng", Double.toString(trackingLongitude));

                return params;
            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        Context context1 = context;
    }


    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION)) {


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return;
        } else {
            return;
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                    if (ContextCompat.checkSelfPermission(getActivity(),
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mClient == null) {
                            buildGoogleApiClient();
                        }
                        /*mGoogleMap.setMyLocationEnabled(true);*/
                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }
        }
    }


    private void callPlaceAutocompleteActivityIntentTo() {
        try {

            bookarideto.setEnabled(false);
            Intent intent =
                    new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY)
                            .build(getActivity());
            startActivityForResult(intent, PLACE_PICKER_REQUEST_TO);


            cdd = new CustomDialogFavorites(getActivity(), "destination");
            cdd.show();
            Window window = cdd.getWindow();
            assert window != null;
            window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);

//PLACE_AUTOCOMPLETE_REQUEST_CODE is integer for request code
        } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
            // TODO: Handle the error.
        }

    }

    private void callPlaceAutocompleteActivityIntentFrom() {

        try {

            bookaridefrom.setEnabled(false);
            Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY)
                    .build(getActivity());

            startActivityForResult(intent, PLACE_PICKER_REQUEST_FROM);

            cdd = new CustomDialogFavorites(getActivity(), "source");
            cdd.setCancelable(false);
            cdd.show();
            Window window = cdd.getWindow();
            assert window != null;
            window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);


        } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
            // TODO: Handle the error.
        }

    }


  /*---------------------------------------------------------------------------------------------------------*/

    private void sendRideRequest() {

        StringRequest stringRequestNotification = new StringRequest(Request.Method.POST, retryUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String responses) {
                        try {

                            JSONObject jObj = new JSONObject(responses);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                status = jObj.getString("status");

                                if (status.equals("got")) {
                                    bookingid = jObj.getString("bookingid");
                                        /*waitingTimerRideRequest.cancel();*/

                                }
                                message = jObj.getString("message");


                            } else {
                                String errorMsg = jObj.getString("error_msg");
                                Intent home = new Intent(getActivity(), NavHome.class);
                                startActivity(home);


                                if (waitingTimerRideRequest != null) {
                                    waitingTimerRideRequest.cancel();
                                    waitingTimerRideRequest = null;
                                }

                                getActivity().finish();

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("passengername", user.get("name"));
                params.put("passengermobile", user.get("mobile"));
                params.put("vehicle", choose_vehicle_value);
                params.put("whenrequired", when_required_value);
                params.put("whenrequiredtype", when_required_type);
                params.put("typeofrate", string_type_of_rate);
                params.put("rate", type_of_rate_value);
               /* params.put("metervalue", getIntent().getStringExtra("metervalue"));*/
                params.put("from", bookaridefrom.getText().toString());
                params.put("to", bookarideto.getText().toString());
                params.put("fromlatitude", fromlatitude);
                params.put("fromlongitude", fromlongitude);
                params.put("tolatitude", tolatitude);
                params.put("tolongitude", tolongitude);
                params.put("paymenttype", "cash");
                params.put("distance", distance);
                params.put("range_count", Integer.toString(range_count));

                if (choose_vehicle_value.equals("Any")) {
                    params.put("auto_rate", auto_rate);
                    params.put("taxi_rate", taxi_rate);
                }

                if (choose_vehicle_value.equals("Taxi")) {
                    params.put("taxi_rate", taxi_rate);
                }
                if (choose_vehicle_value.equals("Auto")) {
                    params.put("auto_rate", auto_rate);
                }
                if (choose_vehicle_value.equals("Bike")) {
                    params.put("bike_rate", bike_rate);
                }

                return params;
            }
        };

        // remove caching
        stringRequestNotification.setShouldCache(false);
        // Wait 30 seconds and don't retry more than once
        stringRequestNotification.setRetryPolicy(new DefaultRetryPolicy(240000, 0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequestNotification);


    }

    private void setTimerForRideRequest() {

        waitingTimerRideRequest = new CountDownTimer(130000, 10000) {

            public void onTick(long millisUntilFinished) {

                if (millisUntilFinished >= 80000 && status.equals("searching")) {

                    range_count++;
                    sendRideRequest();
                } else if (status.equals("searching")) {
                    linearLayout_background_blur.setBackgroundResource(R.color.white);
                /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white));*/
                    finding_nearest_textView.setVisibility(View.GONE);
                    passenger_offer_progressbar.setVisibility(View.GONE);
                    retry_ride_request_button.setVisibility(View.VISIBLE);
                    cancel_ride_request_button.setVisibility(View.VISIBLE);
                    driver_response_textView.setVisibility(View.VISIBLE);
                    driver_response_textView.setText("Driver not found in your area");
                }
            }

            public void onFinish() {

                linearLayout_background_blur.setBackgroundResource(R.color.white);
            /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white));*/
                finding_nearest_textView.setVisibility(View.GONE);
                passenger_offer_progressbar.setVisibility(View.GONE);
                retry_ride_request_button.setVisibility(View.VISIBLE);
                cancel_ride_request_button.setVisibility(View.VISIBLE);
                driver_response_textView.setVisibility(View.VISIBLE);
                driver_response_textView.setText("Responce Timeout");
            }
        }.start();
    }


    /*---------------------------------------------------------------------------------------------------------*/
    @Subscribe
    public void getButtonStatus(OttoAllDriversRejected data) {
        Log.i("Activity", data.getRejection());

        if (data.getRejection().equals("All Drivers Rejected Please Try Again")) {

            if (waitingTimerRideRequest != null) {
                waitingTimerRideRequest.cancel();
                waitingTimerRideRequest = null;

            }
            linearLayout_background_blur.setBackgroundResource(R.color.white);
        /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white));*/
            finding_nearest_textView.setVisibility(View.GONE);
            passenger_offer_progressbar.setVisibility(View.GONE);
            retry_ride_request_button.setVisibility(View.VISIBLE);
            cancel_ride_request_button.setVisibility(View.VISIBLE);
            driver_response_textView.setVisibility(View.VISIBLE);
            driver_response_textView.setText("All drivers rejected your offers");

        }
        if (data.getRejection().equals("Request timeout")) {
            if (waitingTimerRideRequest != null) {
                waitingTimerRideRequest.cancel();
                waitingTimerRideRequest = null;

            }

            linearLayout_background_blur.setBackgroundResource(R.color.white);

        /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white));*/
            finding_nearest_textView.setVisibility(View.GONE);
            passenger_offer_progressbar.setVisibility(View.GONE);
            retry_ride_request_button.setVisibility(View.VISIBLE);
            cancel_ride_request_button.setVisibility(View.VISIBLE);
            driver_response_textView.setVisibility(View.VISIBLE);
            driver_response_textView.setText("Responce Timeout");

        }
    }

    @Subscribe
    public void setLatLongFromFavorite(OttoSelectedFromFavorite ottoSelectedFromFavorite) {

        Double latitude = Double.parseDouble(ottoSelectedFromFavorite.getTolatitude());
        Double longitude = Double.parseDouble(ottoSelectedFromFavorite.getTolongitude());

        if ((ottoSelectedFromFavorite.getSetTo()).equals("source")) {

            fromlatitude = ottoSelectedFromFavorite.getTolatitude();
            fromlongitude = ottoSelectedFromFavorite.getTolongitude();

            bookaridefrom.setText(ottoSelectedFromFavorite.getAddress());
            latLngBounds = new LatLngBounds(new LatLng(latitude, longitude), new LatLng(latitude, longitude));

            latLng = new LatLng(latitude, longitude);

            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

        } else {
            bookarideto.setText(ottoSelectedFromFavorite.getAddress());

            tolatitude = ottoSelectedFromFavorite.getTolatitude();
            tolongitude = ottoSelectedFromFavorite.getTolongitude();

            latLngBounds = new LatLngBounds(
                    new LatLng(latitude, longitude), new LatLng(latitude, longitude));

            startLatitude = Double.parseDouble(fromlatitude);
            startLongitude = Double.parseDouble(fromlongitude);
            endLatitude = Double.parseDouble(ottoSelectedFromFavorite.getTolatitude());
            endLongitude = Double.parseDouble(ottoSelectedFromFavorite.getTolongitude());

        }
    }

}
