package kouchan.siddhesh.com.BookARideAndroid.Interface;

/**
 * Created by Siddhesh on 28-02-2018.
 */

public interface IRemoveItem {

    void removeItemAfterTimerFinished();
}
