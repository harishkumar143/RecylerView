package kouchan.siddhesh.com.BookARideAndroid.Interface.deletefavourite;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import kouchan.siddhesh.com.BookARideAndroid.View.Activities.NavHome;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.SearchActivity;
import kouchan.siddhesh.com.BookARideAndroid.async.AsyncInteractor;
import kouchan.siddhesh.com.BookARideAndroid.async.OnRequestListener;
import kouchan.siddhesh.com.BookARideAndroid.utils.AppConstants;
import kouchan.siddhesh.com.BookARideAndroid.utils.NetworkStatus;
import kouchan.siddhesh.com.BookARideAndroid.utils.Sharedpreferences;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

public class DeleteFavouritePresenterImpl implements IDeleteFavouritePresnter,OnRequestListener {

    SearchActivity navHome;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IDeleteFavouriteView deleteFavouriteView;

    public DeleteFavouritePresenterImpl(IDeleteFavouriteView deleteFavouriteView) {
        this.navHome =(SearchActivity) deleteFavouriteView;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(navHome);
        this.asyncInteractor = new AsyncInteractor(navHome);
        this.deleteFavouriteView = deleteFavouriteView;
    }

    @Override
    public void deleteFavourite(String id) {
        if(NetworkStatus.checkNetworkStatus(navHome)){
            Utils.showProgress(navHome);
            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_DELETEFAVOURITE, "https://bookarideworldwide.com/CAB2.V.1/passenger_api/favoritesdelete.php?add_id="+id);
        } else {
            Utils.showToast(navHome, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if(pid==AppConstants.TAG_ID_DELETEFAVOURITE){
            Utils.stopProgress(navHome);
            if(responseJson!=null){
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if(!error) {
                    deleteFavouriteView.deleteFavouriteSuccess(pid,jObj.getString("message"));
                }
                else {
                    deleteFavouriteView.deleteFavouriteError(pid,jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(navHome);
        deleteFavouriteView.deleteFavouriteError(pid,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        Utils.stopProgress(navHome);
        deleteFavouriteView.deleteFavouriteError(pid,error);
    }
}
