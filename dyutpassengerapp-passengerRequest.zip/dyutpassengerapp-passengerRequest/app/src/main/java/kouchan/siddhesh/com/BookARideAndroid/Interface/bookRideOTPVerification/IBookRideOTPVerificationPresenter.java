package kouchan.siddhesh.com.BookARideAndroid.Interface.bookRideOTPVerification;

public interface IBookRideOTPVerificationPresenter {

    void getBookRideOTP(String email, String mobile, String password, String name,
                        String otp);

}
