package kouchan.siddhesh.com.BookARideAndroid.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.LoginActivity;
import kouchan.siddhesh.com.BookARideAndroid.holders.LanguageSelectionViewHolder;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

/**
 * Created by kouchan on 22-12-2016.
 */

public class LanguageSelectionAdapter extends RecyclerView.Adapter<LanguageSelectionViewHolder> {

    private ArrayList<String> chooseYourLanguageForM3 = new ArrayList<>();
    private ArrayList<String> chooseYourLanguageForM3ArrayListInRespectiveLanguage = new ArrayList<>();

    SessionManager sessionManager;

    //    private int[] imagesForOtherTransactionsWithM3Array;
    Context context;
    LayoutInflater layoutInflater;


    public LanguageSelectionAdapter(Context context, ArrayList<String> chooseYourLanguageForM3, ArrayList<String> chooseYourLanguageForM3ArrayListInRespectiveLanguage) {
        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
        this.chooseYourLanguageForM3 = chooseYourLanguageForM3;
        this.chooseYourLanguageForM3ArrayListInRespectiveLanguage = chooseYourLanguageForM3ArrayListInRespectiveLanguage;

        sessionManager = new SessionManager(context);

    }


    @Override
    public LanguageSelectionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        Log.d("onCreateViewHolder", "onCreateViewHolder");
        View v = layoutInflater.inflate(R.layout.item_select_language_list, parent, false);
        LanguageSelectionViewHolder viewHolder = new LanguageSelectionViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(LanguageSelectionViewHolder holder, final int position) {

        //  holder.mLanguageNameInRespectiveTextView.setTypeface(Typeface.createFromAsset(context.getAssets(), "fonts/hindi.ttf"));
        holder.mLanguageNameInRespectiveTextView.setText(chooseYourLanguageForM3ArrayListInRespectiveLanguage.get(position));
        holder.mLanguageNameTextView.setText(chooseYourLanguageForM3.get(position));

        holder.mItemRowOfLanguageSelectionLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (position == 0) {

                    Utils.appCode = "en";

                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);
                    sessionManager.setKeyLanguageCode("en");

                } else if (position == 1) {

                    Utils.appCode = "hi";

                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);
                    sessionManager.setKeyLanguageCode("hi");


                } else if (position == 2) {

                    Utils.appCode = "kn";

                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);
                    sessionManager.setKeyLanguageCode("kn");

                } else if (position == 3) {

                    Utils.appCode = "tl";

                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);
                    sessionManager.setKeyLanguageCode("tl");

                } else if (position == 4) {

                    Utils.appCode = "tm";

                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);
                    sessionManager.setKeyLanguageCode("tm");

                } else if (position == 5) {

                    Utils.appCode = "ml";

                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);
                    sessionManager.setKeyLanguageCode("ml");

                } else if (position == 6) {
                    Utils.appCode = "mr";

                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);
                    sessionManager.setKeyLanguageCode("mr");

                } else if (position == 7) {
                    Utils.appCode = "gu";

                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);
                    sessionManager.setKeyLanguageCode("gu");

                } else if (position == 8) {
                    Utils.appCode = "ru";

                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);

                } else if (position == 9) {
                    Utils.appCode = "ar";

                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);
                    sessionManager.setKeyLanguageCode("ar");

                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return chooseYourLanguageForM3.size();
    }
}
