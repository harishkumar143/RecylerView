package kouchan.siddhesh.com.BookARideAndroid.async;

import android.content.Context;
import android.os.Handler;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Api.ApiClient;
import kouchan.siddhesh.com.BookARideAndroid.GenerateOAuthToken;
import kouchan.siddhesh.com.BookARideAndroid.VolleyJsonObjectRequest;
import kouchan.siddhesh.com.BookARideAndroid.models.OAuthToken;
import kouchan.siddhesh.com.BookARideAndroid.preferences.PreferenceManager;
import kouchan.siddhesh.com.BookARideAndroid.utils.AppConstants;
import kouchan.siddhesh.com.BookARideAndroid.utils.Sharedpreferences;

public class AsyncInteractor implements IAsyncInteractor {

    /******************************************************************************************
     * An Interactor helps models cross application boundaries such as networks or serialization
     * This LoginInteractor knows nothing about a UI or the LoginPresenter
     * Because this is an asynchronous call it will call back on the OnRequestListener when complete
     * ******************************************************************************************
     */

    Context context;
    boolean isTokenExpired = false;
    int count = 0;
    Sharedpreferences sharedpreferences;

    public AsyncInteractor(Context context) {
        this.context = context;
        sharedpreferences = Sharedpreferences.getUserDataObj(context);
    }

    public void validateCredentialsAsync(final OnRequestListener listener, final int pid, final
    String url) {
        // creating a handler to delay the answer a couple of seconds
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                onPostMethodServerCall(listener, pid, url, new JSONObject());
            }
        }, 500);
    }


    public void validateCredentialsAsync(final OnRequestListener listener, final int pid, final
    String url, final JSONObject paramsMap) {
        // creating a handler to delay the answer a couple of seconds
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                onPostMethodServerCall(listener, pid, url, paramsMap);
            }
        }, 500);
    }


    public void onPostMethodServerCall(final OnRequestListener listener, final int pid,
                                       final String url, final JSONObject jsonObject) {

        if (pid == AppConstants.TAG_ID_VALIDATE_AADHAR_OTP) {
            // JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {


                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }


                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                    /*if (isTokenExpered(error)) {
                      reGenerateToken(listener, pid, url, jsonObject);
                    } else {*/
                                listener.onRequestCompletionError(pid, error.toString());
                                // }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_AADHAR_OTP) {
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                   /* if (isTokenExpered(error)) {
                      reGenerateToken(listener, pid, url, jsonObject);
                    } else {*/
                                listener.onRequestCompletionError(pid, error.toString());
                                // }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) /*{
        @Override
        public Map<String, String> getHeaders() throws AuthFailureError {
          Map<String, String> params = new HashMap<String, String>();
          params.put("Content-Type", "application/json; charset=UTF-8");
          params.put("Authorization", "bearer" + sharedpreferences.getOauthToken());
          return params;
        }
      }*/;


            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_REGISTER) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                    /*if (isTokenExpered(error)) {
                      reGenerateToken(listener, pid, url, jsonObject);
                    } else {*/
                                listener.onRequestCompletionHomeError(pid, error.toString());
                                // }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_VERIFY_OTP) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                     /*if (isTokenExpered(error)) {
                       reGenerateToken(listener, pid, url, jsonObject);
                     } else {*/
                                listener.onRequestCompletionHomeError(pid, error.toString());
                                // }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    })/*{
         @Override
         public Map<String, String> getHeaders() throws AuthFailureError {
           Map<String, String> params = new HashMap<String, String>();
           params.put("Content-Type", "application/json; charset=UTF-8");
           params.put("Authorization", "bearer" + sharedpreferences.getOauthToken());
           return params;
         }
       }*/;
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_OTP) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                     /*if (isTokenExpered(error)) {
                       reGenerateToken(listener, pid, url, jsonObject);
                     } else {*/
                                listener.onRequestCompletionHomeError(pid, error.toString());
                                //}
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GENERATE_TOKEN) {
            GenerateOAuthToken oAuthToken = new GenerateOAuthToken(Request.Method.POST, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        listener.onRequestCompletion(pid, response.toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    try {
             /*if (isTokenExpered(error)){
               reGenerateToken(listener,pid,url,jsonObject);
             }else {*/
                        listener.onRequestCompletionError(pid, error.toString());
                        // }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(oAuthToken);
        } else if (pid == AppConstants.TAG_ID_PAYMENT) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                listener.onRequestCompletionHomeError(pid, error.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GETBALANCE) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                listener.onRequestCompletionHomeError(pid, error.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_BOOKRIDERESENDOTP) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                listener.onRequestCompletionHomeError(pid, error.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GETPROFILE) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                listener.onRequestCompletionHomeError(pid, error.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_EDITPROFILE) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.PUT, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                listener.onRequestCompletionHomeError(pid, error.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_AFTERCANCEL) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                listener.onRequestCompletionHomeError(pid, error.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_BEFORECANCEL) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                listener.onRequestCompletionHomeError(pid, error.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_FAQ) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                listener.onRequestCompletionHomeError(pid, error.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_CHANGEDESTINATION) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                listener.onRequestCompletionHomeError(pid, error.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_DELETEFAVOURITE) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                listener.onRequestCompletionHomeError(pid, error.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        }
    }

}