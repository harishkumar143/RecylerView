package kouchan.siddhesh.com.BookARideAndroid.Interface.getBalance;

public interface IGetBalancePresnter {

    void getBalance(String mobileNumber);

}
