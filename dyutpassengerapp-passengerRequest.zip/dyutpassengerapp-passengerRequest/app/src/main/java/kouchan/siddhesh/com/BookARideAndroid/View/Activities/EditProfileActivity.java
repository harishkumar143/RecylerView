package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.Gson;

import kouchan.siddhesh.com.BookARideAndroid.Interface.editprofile.EditProfilePresenterImpl;
import kouchan.siddhesh.com.BookARideAndroid.Interface.editprofile.IEditProfilePresnter;
import kouchan.siddhesh.com.BookARideAndroid.Interface.editprofile.IEditProfileView;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.models.PassengerModel;

public class EditProfileActivity extends AppCompatActivity implements IEditProfileView {

    EditText register_mobile,register_firstname,register_emailid;

    Button submit_button;

    IEditProfilePresnter editProfilePresnter;

    PassengerModel passengerModel;

    ImageView editprofileBackImageViewPassengerDriver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        String data = getIntent().getStringExtra("PassengerData");
        Gson gson=new Gson();

        passengerModel = gson.fromJson(data,PassengerModel.class);
        register_mobile = (EditText) findViewById(R.id.register_mobile);
        register_mobile.setText(passengerModel.getMobile());
        register_firstname = (EditText) findViewById(R.id.register_firstname);
        register_firstname.setText(passengerModel.getName());
        register_emailid = (EditText) findViewById(R.id.register_emailid);
        register_emailid.setText(passengerModel.getEmail());
        submit_button = (Button) findViewById(R.id.submit_button);

        editprofileBackImageViewPassengerDriver = (ImageView)findViewById(R.id.editprofileBackImageViewPassengerDriver);
        editprofileBackImageViewPassengerDriver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editProfilePresnter = new EditProfilePresenterImpl(EditProfileActivity.this);
                editProfilePresnter.editProfile(register_mobile.getText().toString().trim(),
                        register_firstname.getText().toString().trim(),
                        register_emailid.getText().toString().trim(),passengerModel.getAdharno(),
                        passengerModel.getBdate(),passengerModel.getGender(),passengerModel.getAddress(),
                        passengerModel.getState(),passengerModel.getPin());

            }
        });

        register_emailid.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                register_emailid.setCursorVisible(true);
                register_emailid.setFocusable(true);
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(register_emailid, InputMethodManager.SHOW_IMPLICIT);
                return false;
            }
        });
    }

    @Override
    public void editProfileSuccess(int pid, String response) {
        Toast.makeText(getApplicationContext(),response,Toast.LENGTH_LONG).show();
        Intent intent = new Intent(EditProfileActivity.this,NavHome.class);
        startActivity(intent);
        finish();

    }

    @Override
    public void editProfileError(int pid, String error) {
        Toast.makeText(getApplicationContext(),error,Toast.LENGTH_LONG).show();
    }
}
