package kouchan.siddhesh.com.BookARideAndroid.View.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Adapter.AdvanceBookingAdapter;
import kouchan.siddhesh.com.BookARideAndroid.Adapter.RecyclerTouchListener;
import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.BookingExpand;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.Booking;
import kouchan.siddhesh.com.BookARideAndroid.other.DividerItemDecoration;


public class AdvanceBookingFragment extends Fragment{

    RecyclerView  recyclerView;
    private AdvanceBookingAdapter mAdapter;
    private List<Booking> bookingList = new ArrayList<>();

    HashMap<String, String> user;
    String passengermobile,type;
    SessionManager sessionManager;
    View view;

    String languageCode;
    Resources resources;

    String bookingUrl="";

    ProgressDialog loading;

    public AdvanceBookingFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view= inflater.inflate(R.layout.fragment_one, container, false);
        recyclerView = (RecyclerView)view.findViewById(R.id.recycler_view_booking);
        bookingList.clear();
        mAdapter = new AdvanceBookingAdapter(bookingList,getActivity());
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        sessionManager=new SessionManager(getActivity());

        user = new HashMap<String, String>();
        user=sessionManager.getUserDetails();
        passengermobile=user.get("mobile");

        type=sessionManager.getType();

        /*switch (type){
            case "passenger":*/
        bookingUrl= Url.COMUNICATE_API+"advanceBookingOfPassenger.php";
        displayPassengerBookings();
                /*break;
            case "driver":
                bookingUrl= Url.COMUNICATE_API+"advanceBookingOfDriver.php";
                displayDriverBookings();
                break;
            case "both":
                bookingUrl= Url.COMUNICATE_API+"advanceBookingOfDriver.php";
                break;
        }
*/

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                Booking booking = bookingList.get(position);
                Intent i=new Intent(getActivity(),BookingExpand.class);
                i.putExtra("booking_id",booking.getBooking_id());
                startActivity(i);

                getActivity().finish();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        sessionManager = new SessionManager(getActivity());
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        return view;
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(getActivity(), languageCode);
        resources = context.getResources();
        /*forgot_password_tv.setText(resources.getString(R.string.forgot_password));*/
    }

    public void displayDriverBookings(){

        final ProgressDialog loading = ProgressDialog.show(getActivity(),getString(R.string.processing),getString(R.string.please_wait),false,false);

        StringRequest stringRequest=new StringRequest(Request.Method.POST, bookingUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            if (!error) {

                                JSONArray bookings = jsonObj.getJSONArray("bookings");

                                for (int i = 0; i < bookings.length(); i++) {

                                    JSONObject c = bookings.getJSONObject(i);
                                    String id = c.getString("bookingid");
                                    String passengerdrivername = c.getString("passengername");
                                    String passengerdrivermobile = c.getString("passengermobile");
                                    String whenrequired = c.getString("whenrequired");
                                    String typeofrate = c.getString("typeofrate");
                                    String rate = c.getString("rate");
                                    String type="driver";
                                    Booking booking=new Booking(id, passengerdrivername, passengerdrivermobile,whenrequired,typeofrate,rate,type);
                                    bookingList.add(booking);
                                    mAdapter.notifyDataSetChanged();
                                }
                            }else {
                                String errorMsg = jsonObj.getString("error_msg");
                            }

                        }

                            catch (JSONException e) {

                            e.printStackTrace();

                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                })
        {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {

                Map<String,String> params=new HashMap<String, String>();

                params.put("mobile",passengermobile);


                return params ;
            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);

    }


    public void displayPassengerBookings(){

        final ProgressDialog loading = ProgressDialog.show(getActivity(),getString(R.string.processing),getString(R.string.please_wait),false,false);

        StringRequest stringRequest=new StringRequest(Request.Method.POST, bookingUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            if (!error) {


                                JSONArray bookings = jsonObj.getJSONArray("bookings");

                                for (int i = 0; i < bookings.length(); i++) {
                                    JSONObject c = bookings.getJSONObject(i);

                                    String id = c.getString("bookingid");
                                    String passengerdrivername = c.getString("drivername");
                                    String passengerdrivermobile= c.getString("drivermobile");
                                    String whenrequired = c.getString("whenrequired");
                                    String typeofrate = c.getString("typeofrate");
                                    String rate = c.getString("rate");
                                    String type="passenger";
                                    
                                    Booking booking=new Booking(id, passengerdrivername, passengerdrivermobile,whenrequired,typeofrate,rate,type);
                                    bookingList.add(booking);
                                    mAdapter.notifyDataSetChanged();

                                }
                            }else {
                                String errorMsg = jsonObj.getString("error_msg");
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {

                Map<String,String> params=new HashMap<String, String>();
                params.put("mobile",passengermobile);
                return params ;
            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        bookingList.clear();
        mAdapter.notifyDataSetChanged();
    }
}
