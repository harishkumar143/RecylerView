
package kouchan.siddhesh.com.BookARideAndroid.BroadcastReceivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import kouchan.siddhesh.com.BookARideAndroid.Otto.EventBusManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.SMSConstants;
import kouchan.siddhesh.com.BookARideAndroid.models.SMSOtpMessage;

public class BookARideSMSReceiver extends BroadcastReceiver {

    private final static String SMS_PDU_IDENTIFIER = "pdus";
    private static final String TAG = BookARideSMSReceiver.class.getName();


    @Override
    public void onReceive(Context context, Intent intent) {

            final Bundle bundle = intent.getExtras();

        try {
            if (bundle != null) {
                final Object[] pdusObj = (Object[]) bundle.get(SMS_PDU_IDENTIFIER);
                SmsMessage currentMessage;
                for (int i = 0; i < pdusObj.length; i++) {

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        String format = bundle.getString("format");
                        currentMessage = SmsMessage.createFromPdu((byte[]) pdusObj[i], format);
                    } else {
                        currentMessage = SmsMessage.createFromPdu((byte[]) pdusObj[i]);
                    }
                    String senderNum = currentMessage.getDisplayOriginatingAddress();
                    String message = currentMessage.getDisplayMessageBody();
                    //check if message is a M3 OTP Message
                    if (message.endsWith(SMSConstants.OTP_SMS_END_STRING)) {
                        String otp = message.substring(0, 4);
                        onOtpReceived(otp);
                    }
                }
            }
        } catch (Exception e) {

            Log.e(TAG, "Exception smsReceiver" + e.toString());

        }
    }

    private void onOtpReceived(String otp) {

        SMSOtpMessage SMSOtpMessage = new SMSOtpMessage(otp);
        EventBusManager.getInstance().getEventBus().post(SMSOtpMessage);

    }
}

