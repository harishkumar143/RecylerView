package kouchan.siddhesh.com.BookARideAndroid.Interface.deletefavourite;

public interface IDeleteFavouritePresnter {

    void deleteFavourite(String id);

}
