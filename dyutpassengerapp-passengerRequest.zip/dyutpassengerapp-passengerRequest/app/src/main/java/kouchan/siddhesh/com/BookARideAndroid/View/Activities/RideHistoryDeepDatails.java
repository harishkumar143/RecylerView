package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Otto.EventBusManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoRepeatRide;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

public class RideHistoryDeepDatails extends AppCompatActivity {

    String historyExand = "";
    String id;
    TextView booking_id, vehicle, fromplace, toplace, paymenttype, distance,
            bookingtime, ride_start_time, ride_end_time, journey_time,
            ridestatus, actualprice;

    TextView history_details_textView, drive_completed_textView, reference_no_textView, vehicle_type_textView,
            from_place_textView, to_place_textView, payment_type_textView, distance_covered_textView, booking_time_textView,
            ride_start_time_textView, ride_end_time_textView, journey_time_textView, ride_status_textView, fair_in_rs_textView;

    String languageCode;
    Resources resources;

    String type;
    SessionManager sessionManager;

    Toolbar mToolbar;
    ImageView historyExpandBackImageView, historyExpandHomeImageView;

    EditText complaint_registration_et;
    Button repeat_ride, register_complaint, complaint_submit_button;

    boolean first_Click;
    private String complaint = "", complaint_URL, repeat_ride_URL;
    ProgressDialog loading;
    String booking_id_str, user_id, complaint_type, comments;

    String from, to, fromlatitude, fromlongitude, tolatitude, tolongitude, choose_vehicle_value;

    CountDownTimer waitingTimerRideRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_expand);

        id = getIntent().getStringExtra("booking_id");
        booking_id = (TextView) findViewById(R.id.booking_id);
        vehicle = (TextView) findViewById(R.id.vehicle);
        fromplace = (TextView) findViewById(R.id.fromplace);
        toplace = (TextView) findViewById(R.id.toplace);
        paymenttype = (TextView) findViewById(R.id.paymenttype);
        distance = (TextView) findViewById(R.id.distance);
        bookingtime = (TextView) findViewById(R.id.bookingtime);
        ride_start_time = (TextView) findViewById(R.id.ridestarttime);
        ride_end_time = (TextView) findViewById(R.id.rideendtime);
        journey_time = (TextView) findViewById(R.id.journytime);
        ridestatus = (TextView) findViewById(R.id.ridestatus);
        actualprice = (TextView) findViewById(R.id.actualprice);

        history_details_textView = (TextView) findViewById(R.id.history_details_textView);
        drive_completed_textView = (TextView) findViewById(R.id.drive_completed_textView);
        reference_no_textView = (TextView) findViewById(R.id.reference_no_textView);
        vehicle_type_textView = (TextView) findViewById(R.id.vehicle_type_textView);
        from_place_textView = (TextView) findViewById(R.id.from_place_textView);
        to_place_textView = (TextView) findViewById(R.id.to_place_textView);
        payment_type_textView = (TextView) findViewById(R.id.payment_type_textView);
        distance_covered_textView = (TextView) findViewById(R.id.distance_covered_textView);
        booking_time_textView = (TextView) findViewById(R.id.booking_time_textView);
        ride_start_time_textView = (TextView) findViewById(R.id.ride_start_time_textView);
        ride_end_time_textView = (TextView) findViewById(R.id.ride_end_time_textView);
        journey_time_textView = (TextView) findViewById(R.id.journey_time_textView);
        ride_status_textView = (TextView) findViewById(R.id.ride_status_textView);
        fair_in_rs_textView = (TextView) findViewById(R.id.fair_in_rs_textView);

        complaint_registration_et = (EditText) findViewById(R.id.complaint_registration_et);
        repeat_ride = (Button) findViewById(R.id.repeat_ride);
        register_complaint = (Button) findViewById(R.id.register_complaint);
        complaint_submit_button = (Button) findViewById(R.id.complaint_submit_button);

        sessionManager = new SessionManager(getApplicationContext());

        type = sessionManager.getType();
        user_id = sessionManager.getId();

        complaint_type = "regarding_ride";

        historyExand = Url.PASSENGER_API + "passengerHistoryByBookingId.php";

        complaint_URL = Url.PASSENGER_API + "complaintregisterforride.php";

        repeat_ride_URL = Url.PASSENGER_API + "complaintregisterforride.php";

        initializeViews();

        historyExpantionRequest();

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }


        repeat_ride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                repeatRide();
            }
        });

        first_Click = true;
        register_complaint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (first_Click) {
                    complaint_registration_et.setVisibility(View.VISIBLE);
                    complaint_submit_button.setVisibility(View.VISIBLE);
                    first_Click = false;
                } else {
                    complaint_registration_et.setVisibility(View.GONE);
                    complaint_submit_button.setVisibility(View.GONE);
                    first_Click = true;
                }
            }
        });

        complaint_submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                complaint = complaint_registration_et.getText().toString();
                if (complaint.equals("")) {
                } else {
                    sendComplaint();
                }
            }
        });

    }

    private void repeatRide() {
        Intent intent = new Intent(RideHistoryDeepDatails.this, NavHome.class);
/*        intent.putExtra("from", from);
        intent.putExtra("to", to);
        intent.putExtra("fromlatitude", fromlatitude);
        intent.putExtra("fromlongitude", fromlongitude);
        intent.putExtra("tolatitude", tolatitude);
        intent.putExtra("tolongitude", tolongitude);
        intent.putExtra("vehicle_type", choose_vehicle_value);*/
        startActivity(intent);
        Utils.showProgress(RideHistoryDeepDatails.this);
        waitingTimerRideRequest = new CountDownTimer(3000, 1000) {
            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {

                OttoRepeatRide ottoRepeatRide = new OttoRepeatRide(from, to, fromlatitude, fromlongitude, tolatitude, tolongitude, choose_vehicle_value);
                EventBusManager.getInstance().getEventBus().post(ottoRepeatRide);
                finish();
            }
        }.start();


    }

    private void sendComplaint() {

        loading = ProgressDialog.show(this, getString(R.string.processing), getString(R.string.please_wait), false, false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, complaint_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                Toast.makeText(RideHistoryDeepDatails.this, jObj.getString("message"), Toast.LENGTH_SHORT).show();
                            } else {

                                String errorMsg = jObj.getString("error_msg");
                                Toast.makeText(RideHistoryDeepDatails.this, errorMsg, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("booking_id", booking_id_str);
                params.put("user_id", user_id);
                params.put("complaint_type", complaint_type);
                params.put("comments", complaint);
                params.put("user_type", type);
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        history_details_textView.setText(resources.getString(R.string.rides_history_details));
        drive_completed_textView.setText(resources.getString(R.string.drive_completed));
        reference_no_textView.setText(resources.getString(R.string.ref_no));
        vehicle_type_textView.setText(resources.getString(R.string.vehicle_type));
        from_place_textView.setText(resources.getString(R.string.from_place));
        to_place_textView.setText(resources.getString(R.string.to_place));
        payment_type_textView.setText(resources.getString(R.string.payment_type));
        distance_covered_textView.setText(resources.getString(R.string.distance_covered));
        booking_time_textView.setText(resources.getString(R.string.booking_time));
        ride_start_time_textView.setText(resources.getString(R.string.ride_start_time));
        ride_end_time_textView.setText(resources.getString(R.string.ride_end_time));
        journey_time_textView.setText(resources.getString(R.string.journey_time));
        ride_status_textView.setText(resources.getString(R.string.ride_status));
        fair_in_rs_textView.setText(resources.getString(R.string.fair_in_rs));
    }


    public void historyExpantionRequest() {
        final ProgressDialog loading = ProgressDialog.show(this, getString(R.string.processing), getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, historyExand,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                booking_id.setText(jObj.getString("booking_id"));
                                booking_id_str = booking_id.getText().toString();

                                vehicle.setText(jObj.getString("vehicle"));
                                choose_vehicle_value = vehicle.getText().toString();

                                fromplace.setText(jObj.getString("fromplace"));
                                from = fromplace.getText().toString();

                                toplace.setText(jObj.getString("toplace"));
                                to = toplace.getText().toString();

                                fromlatitude = jObj.getString("fromlatitude");
                                fromlongitude = jObj.getString("fromlongitude");
                                tolatitude = jObj.getString("tolatitude");
                                tolongitude = jObj.getString("tolongitude");

                                paymenttype.setText(jObj.getString("paymenttype"));
                                distance.setText(jObj.getString("distance"));
                                bookingtime.setText(jObj.getString("bookingtime"));
                                ride_start_time.setText(jObj.getString("ride_start_time"));
                                ride_end_time.setText(jObj.getString("ride_end_time"));
                                journey_time.setText(jObj.getString("journey_time"));
                                ridestatus.setText(jObj.getString("ridestatus"));
                                actualprice.setText(" " + jObj.getString("total_fare"));


                            } else {

                                // Error occurred in registration. Get the error
                                // message
                                String errorMsg = jObj.getString("message");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("booking_id", id);

                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        historyExpandBackImageView = (ImageView) findViewById(R.id.historyExpandBackImageView);
        historyExpandHomeImageView = (ImageView) findViewById(R.id.historyExpandHomeImageView);

        historyExpandBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        historyExpandHomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RideHistoryDeepDatails.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });
    }
}

