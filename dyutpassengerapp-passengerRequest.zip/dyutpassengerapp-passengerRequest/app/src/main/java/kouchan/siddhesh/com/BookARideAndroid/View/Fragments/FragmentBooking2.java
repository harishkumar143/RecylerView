package kouchan.siddhesh.com.BookARideAndroid.View.Fragments;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.squareup.otto.Subscribe;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.DirectionsJSONParser;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Otto.EventBusManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.NavHome;
import kouchan.siddhesh.com.BookARideAndroid.functions.Functions;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoAllDriversRejected;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoDialogPersonalOther;

/**
 * Created by Belal on 18/09/16.
 */


public class FragmentBooking2 extends Fragment implements OnMapReadyCallback {

    String from, to, distance,
            fromlatitude, fromlongitude, tolatitude,
            tolongitude, vehicle_type, rate,
            minimum_fare, per_km, when_required_value, when_required_type,total_fare,paymentType;

    int phonePosIndex, namePosIndex;
    public Button yes, no;
    Cursor cursor = null;
    String userNameValue, userPhoneNumberValue = null;
    TextView book_a_ride_from, book_a_ride_to, type_of_meter_textView,
            selected_vehicle_type_of_meter_textView;

    private static final int TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT = 1001;
    private EditText idname, idmobile;
    private ImageView selectContactImage;
    Dialog mDialog;
    private ImageView infoImagePerMeter;
    private ImageView backImageTypeOfMeter;
    private ImageView nextImageTypeOfMeter;
    private ImageView marker_logo;
    private ImageView destination_marker_logo;
    private ImageView selected_vehicle_type_of_meter;
    private ImageView booking_fragment2_back;

    private RadioGroup type_of_rate;
    private RadioButton fixed_amount;
    private RadioButton ride_per_meter;
    private RadioButton meter_plus_extra;
    private RadioButton meter_minus_extra;

    private EditText edit_fixed_amount;
    private EditText edit_per_meter;
    private EditText edit_meter_plus;
    private EditText edit_meter_less;

    private TextView finding_nearest_textView,walletBal,vehicleType;
    private TextView driver_response_textView;
    private TextView selected_Rate_RupeesSymbol_textView;

    private ProgressBar passenger_offer_progressbar;

    private Button retry_ride_request_button;
    private Button cancel_ride_request_button;

private  boolean apikey=true,apikey1=true;
    private Button book_a_ride_submit_button;

    private String languageCode;
    private Resources resources;

    private String type_of_rate_value;
    private String meter_value;

    private String string_type_of_rate;
    private View view;

    private LinearLayout linearLayout_background_blur;
    private LinearLayout linearLayout_retry_cancel_buttons;

    private String displayRateInISymbol;
    private String currency_symbol;

    private String city,state;
    private CountDownTimer waitingTimerRideRequest;

    String status;
    SessionManager sessionManager;
    private int range_count;

    String bookingid, message;

    private String retryUrl;

    RadioGroup rideForRadioGroup,paymentModeRadioGroup;
    RadioButton selfRadioButton,otherRadioButton,cashRadioButton,m3RadioButton;
    SupportMapFragment mapFrag;
    private GoogleMap mGoogleMap;
    Marker mCurrLocationMarker;
    LatLng source;

    Button personal,otherBooking;

    String type, othermobile, othername;

    String rupees_symbol;

    String booking_type, name, mobile_no;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments

        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
        view = inflater.inflate(R.layout.activity_booking_2, container, false);

        sessionManager = new SessionManager(getActivity());

        rupees_symbol = getString(R.string.rupee_symbol);

        currency_symbol = this.getArguments().getString("currency_symbol");
        from = this.getArguments().getString("from");
        to = this.getArguments().getString("to");
        distance = this.getArguments().getString("distance");
        fromlatitude = this.getArguments().getString("fromlatitude");
        fromlongitude = this.getArguments().getString("fromlongitude");
        tolatitude = this.getArguments().getString("tolatitude");
        tolongitude = this.getArguments().getString("tolongitude");
        vehicle_type = this.getArguments().getString("vehicle_type");
        rate = this.getArguments().getString("rate");
        minimum_fare = this.getArguments().getString("minimum_fare");
        total_fare = this.getArguments().getString("total_rate");
        per_km = this.getArguments().getString("per_km");
        when_required_value = this.getArguments().getString("when_required_value");
        when_required_type = this.getArguments().getString("when_required_type");
        city = this.getArguments().getString("comingFromCity");
        state = this.getArguments().getString("comingFromState");

        /*booking_type = this.getArguments().getString("booking_type");
        name = this.getArguments().getString("name");
        mobile_no = this.getArguments().getString("mobile_no");*/

        type = "Self";

        initializeWidget();
        checkVehicleType();
        vehicleType.setText(vehicle_type);
        ride_per_meter.setChecked(true);
        /*ride_per_meter.setBackgroundResource(R.color.yesbankbluecolorblur_inside);*/
        ride_per_meter.setBackgroundResource(R.color.vistara_color_blur_1);

        meter_value = edit_per_meter.getText().toString();
        type_of_rate_value = "0";
        string_type_of_rate = "Permeter";
        edit_fixed_amount.setEnabled(false);
        edit_per_meter.setEnabled(false);
        edit_meter_plus.setEnabled(false);
        edit_meter_less.setEnabled(false);

        typeOfMeter();
        infoImageValues();
        m3RadioButton.setChecked(true);
        if(m3RadioButton.isChecked()){
            paymentType="M3";
        }
        book_a_ride_from.setText(from);
        book_a_ride_to.setText(to);
        edit_per_meter.setText(rate);

        radioGroupOoperation();
        status = "searching";
        range_count = 1;
        retryUrl = Url.COMUNICATE_API + "rideRequest1.php";

        EventBusManager.getInstance().getEventBus().register(this);

        if(sessionManager.getWalletBal()!=null){
            walletBal.setText("Your M3 e-w avaliable balance: ₹"+sessionManager.getWalletBal());
        }


        return view;
    }

    private void radioGroupOoperation() {
        paymentModeRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                View radioButton = paymentModeRadioGroup.findViewById(checkedId);
                int index = paymentModeRadioGroup.indexOfChild(radioButton);

                switch (index) {
                    case 0: // first button
                        paymentType="CASH";
                        break;
                    case 1: // secondbutton
                        paymentType="M3";
                }
            }
        });
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }


    private void infoImageValues() {

        infoImagePerMeter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(getActivity())
                        .setMessage(displayRateInISymbol)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        }).show();
            }
        });
    }

    private void checkVehicleType() {
        switch (vehicle_type) {
            case "Taxi(4+1)":
                selected_vehicle_type_of_meter.setBackgroundResource(R.drawable.car_selected_ic);

                displayRateInISymbol = "Minimum Fair of Taxi(4+1) is " + rupees_symbol + minimum_fare +
                        "\nTaxi Rate per kilometer is " + rupees_symbol + per_km+
                "\n Total Amount is " + rupees_symbol + total_fare;

                break;
            case "Auto":
                selected_vehicle_type_of_meter.setBackgroundResource(R.drawable.auto_selected_ic);

                displayRateInISymbol = "Minimum Fair of Auto is " + rupees_symbol + minimum_fare +
                        "\nAuto Rate per kilometer is " + rupees_symbol + per_km+
                        "\n Total Amount is " + rupees_symbol + total_fare;

                break;
            case "Bike":

                selected_vehicle_type_of_meter.setBackgroundResource(R.drawable.bike_selected_ic);

                displayRateInISymbol = "Minimum Fair of Bike is " + rupees_symbol + minimum_fare +
                        "\nBike Rate per kilometer is " + rupees_symbol + per_km+
                        "\n Total Amount is " + rupees_symbol + total_fare;

                break;

            case "Taxi(7+1)":
                selected_vehicle_type_of_meter.setBackgroundResource(R.drawable.suv_selected_ic);

                displayRateInISymbol = "Minimum Fair of Taxi(7+1) is " + rupees_symbol + minimum_fare +
                        "\nAuto Rate per kilometer is " + rupees_symbol + per_km+
                        "\n Total Amount is " + rupees_symbol + total_fare;

                break;

        }
    }

    private void initializeWidget() {

        /*nextImageTypeOfMeter = (ImageView) view.findViewById(R.id.nextImageTypeOfMeter);
        backImageTypeOfMeter = (ImageView) view.findViewById(R.id.backImageTypeOfMeter);*/
        infoImagePerMeter = (ImageView) view.findViewById(R.id.infoImagePerMeter);
        marker_logo = (ImageView) view.findViewById(R.id.pickup_marker_logo);
        destination_marker_logo = (ImageView) view.findViewById(R.id.destination_marker_logo);
        selected_vehicle_type_of_meter = (ImageView) view.findViewById(R.id.selected_vehicle_type_of_meter);
        booking_fragment2_back = (ImageView) view.findViewById(R.id.booking_fragment2_back);

        book_a_ride_submit_button = (Button) view.findViewById(R.id.book_a_ride_submit_button);

        rideForRadioGroup = (RadioGroup) view.findViewById(R.id.rideForRadioGrouop);
        selfRadioButton = (RadioButton) view.findViewById(R.id.selfRadioButton);
        otherRadioButton = (RadioButton) view.findViewById(R.id.otherRadioButton);

        paymentModeRadioGroup = (RadioGroup) view.findViewById(R.id.paymentModeRadioGroup);
        m3RadioButton = (RadioButton) view.findViewById(R.id.m3RadioButton);
        cashRadioButton = (RadioButton) view.findViewById(R.id.cashRadioButton);

        type_of_rate = (RadioGroup) view.findViewById(R.id.book_a_ride_type_of_rate);
        fixed_amount = (RadioButton) view.findViewById(R.id.book_a_ride_fixed_amount);
        ride_per_meter = (RadioButton) view.findViewById(R.id.book_a_ride_per_meter);
        meter_plus_extra = (RadioButton) view.findViewById(R.id.book_a_ride_meter_plus_extra);
        meter_minus_extra = (RadioButton) view.findViewById(R.id.book_a_ride_meter_minus_extra);

        book_a_ride_from = (TextView) view.findViewById(R.id.book_a_ride_from);
        book_a_ride_to = (TextView) view.findViewById(R.id.book_a_ride_to);
        type_of_meter_textView = (TextView) view.findViewById(R.id.type_of_meter_textView);
        selected_vehicle_type_of_meter_textView = (TextView) view.findViewById(R.id.selected_vehicle_type_of_meter_textView);

        edit_fixed_amount = (EditText) view.findViewById(R.id.edit_fixed_amount);
        edit_per_meter = (EditText) view.findViewById(R.id.edit_per_meter);
        edit_per_meter.setEnabled(false);
        edit_meter_plus = (EditText) view.findViewById(R.id.edit_meter_plus);
        edit_meter_less = (EditText) view.findViewById(R.id.edit_meter_less);

        passenger_offer_progressbar = (ProgressBar) view.findViewById(R.id.passenger_offer_progressbar);

        linearLayout_background_blur = (LinearLayout) view.findViewById(R.id.linearLayout_background_blur);
        linearLayout_retry_cancel_buttons = (LinearLayout) view.findViewById(R.id.linearLayout_retry_cancel_buttons);
        /*linearLayout_background_blur.setBackgroundResource(R.color.white);*/

        finding_nearest_textView = (TextView) view.findViewById(R.id.finding_nearest_textView);
        driver_response_textView = (TextView) view.findViewById(R.id.driver_response_textView);
        selected_Rate_RupeesSymbol_textView = (TextView) view.findViewById(R.id.selected_Rate_RupeesSymbol_textView);
        retry_ride_request_button = (Button) view.findViewById(R.id.retry_ride_request_button);
        cancel_ride_request_button = (Button) view.findViewById(R.id.cancel_ride_request_button);
        walletBal = (TextView) view.findViewById(R.id.walletBal);
        vehicleType = (TextView) view.findViewById(R.id.vehicleType);


        mapFrag = (SupportMapFragment) this.getChildFragmentManager().findFragmentById(R.id.mapViewPassengerBooking2);
        mapFrag.getMapAsync(this);

        personal = (Button) view.findViewById(R.id.personal);
        otherBooking = (Button) view.findViewById(R.id.otherBooking);


    }

    private void typeOfMeter() {
        type_of_rate.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.book_a_ride_fixed_amount:

                        fixed_amount.setBackgroundResource(R.drawable.curved_shape_light_colour);
                        ride_per_meter.setBackgroundResource(R.color.vistara_color);
                        meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                        meter_minus_extra.setBackgroundResource(R.color.vistara_color);

                        edit_fixed_amount.setEnabled(true);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(false);
                        edit_fixed_amount.requestFocus();
                        edit_fixed_amount.setFocusableInTouchMode(true);
                        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.showSoftInput(edit_fixed_amount, InputMethodManager.SHOW_FORCED);
                        edit_meter_plus.setText("");
                        edit_meter_less.setText("");
                        type_of_rate_value = edit_fixed_amount.getText().toString();
                        string_type_of_rate = "Fixed Amount";
/*
                        fixed_amount.setBackgroundResource(R.color.vistara_color_blur_1);
                        ride_per_meter.setBackgroundResource(R.color.vistara_color);
                        meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                        meter_minus_extra.setBackgroundResource(R.color.vistara_color);*/

                        edit_fixed_amount.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                type_of_rate_value = edit_fixed_amount.getText().toString();
                                string_type_of_rate = "Fixed Amount";
                            }
                        });
                        break;

                    case R.id.book_a_ride_per_meter:

                        fixed_amount.setBackgroundResource(R.color.vistara_color);
                        ride_per_meter.setBackgroundResource(R.drawable.curved_shape_light_colour);
                        meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                        meter_minus_extra.setBackgroundResource(R.color.vistara_color);

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(false);
                       // meter_value = edit_per_meter.getText().toString();
                       // type_of_rate_value = "0";
                        string_type_of_rate = "Permeter";
                        edit_fixed_amount.setText("");
                        edit_meter_plus.setText("");
                        edit_meter_less.setText("");
                        type_of_rate_value = edit_per_meter.getText().toString();

                        break;

                    case R.id.book_a_ride_meter_plus_extra:

                        fixed_amount.setBackgroundResource(R.color.vistara_color);
                        ride_per_meter.setBackgroundResource(R.color.vistara_color);
                        meter_plus_extra.setBackgroundResource(R.drawable.curved_shape_light_colour);
                        meter_minus_extra.setBackgroundResource(R.color.vistara_color);

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(true);
                        edit_meter_less.setEnabled(false);


                        edit_meter_plus.requestFocus();
                        edit_meter_plus.setFocusableInTouchMode(true);

                        InputMethodManager imm2 = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm2.showSoftInput(edit_meter_plus, InputMethodManager.SHOW_FORCED);

                        edit_fixed_amount.setText("");
                        edit_meter_less.setText("");

                        type_of_rate_value = edit_meter_plus.getText().toString();
                        string_type_of_rate = "Meter Plus Extra";/*

                        fixed_amount.setBackgroundResource(R.color.vistara_color);
                        ride_per_meter.setBackgroundResource(R.color.vistara_color);
                        meter_plus_extra.setBackgroundResource(R.color.vistara_color_blur_1);
                        meter_minus_extra.setBackgroundResource(R.color.vistara_color);*/

                        edit_meter_plus.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                                type_of_rate_value = edit_meter_plus.getText().toString();
                                string_type_of_rate = "Meter Plus Extra";
                            }
                        });

                        break;

                    case R.id.book_a_ride_meter_minus_extra:

                        fixed_amount.setBackgroundResource(R.color.vistara_color);
                        ride_per_meter.setBackgroundResource(R.color.vistara_color);
                        meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                        meter_minus_extra.setBackgroundResource(R.drawable.curved_shape_light_colour);

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(true);

                        edit_fixed_amount.setText("");
                        //   edit_per_meter.setText("");
                        edit_meter_plus.setText("");

                        edit_meter_less.requestFocus();
                        edit_meter_less.setFocusableInTouchMode(true);

                        InputMethodManager imm3 = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm3.showSoftInput(edit_meter_less, InputMethodManager.SHOW_FORCED);

                        type_of_rate_value = edit_meter_less.getText().toString();
                        string_type_of_rate = "Meter Minus Extra";
                        /*type_of_rate_value = edit_meter_less.getText().toString();*/
/*
                        fixed_amount.setBackgroundResource(R.color.vistara_color);
                        ride_per_meter.setBackgroundResource(R.color.vistara_color);
                        meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                        meter_minus_extra.setBackgroundResource(R.color.vistara_color_blur_1);*/

                        edit_meter_less.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                                type_of_rate_value = edit_meter_less.getText().toString();
                                string_type_of_rate = "Meter Minus Extra";
                            }
                        });

                        break;
                }
            }
        });


        booking_fragment2_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("from", from);
                bundle.putString("to", to);
                bundle.putString("fromlatitude", fromlatitude);
                bundle.putString("fromlongitude", fromlongitude);
                bundle.putString("tolatitude", tolatitude);
                bundle.putString("tolongitude", tolongitude);
                bundle.putString("vehicle_type", vehicle_type);
//                MenuPassenger backFragment = new MenuPassenger();
//                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//                backFragment.setArguments(bundle);
//                fragmentManager.beginTransaction()
//                        .replace(R.id.content_frame, backFragment)
//                        .commit();

                Intent i=new Intent(getActivity(),NavHome.class); //todo loading current location not enterd location
                i.putExtras(bundle);
                startActivity(i);
                getActivity().finish();

            }
        });




        book_a_ride_submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (paymentModeRadioGroup.getCheckedRadioButtonId() == -1)
                {
                    Toast.makeText(getActivity(), "Selecet payment mode", Toast.LENGTH_LONG).show();
                }
                else
                {
                    meter_value = edit_per_meter.getText().toString();
                    if (!(Functions.isAllBookingFieldSelected(vehicle_type, when_required_value, string_type_of_rate, type_of_rate_value, fromlatitude, tolatitude))) {
                    } else if (when_required_value.equals(null)) {


                    } else {

                        linearLayout_background_blur.setVisibility(View.VISIBLE);
                        finding_nearest_textView.setVisibility(View.VISIBLE);
                        passenger_offer_progressbar.setVisibility(View.VISIBLE);
                        passenger_offer_progressbar.setBackgroundColor(getResources().getColor(R.color.white));
                        passenger_offer_progressbar.setMax(100);
                        passenger_offer_progressbar.setProgress(40);
                        passenger_offer_progressbar.setIndeterminate(true);
                        /*sendRideRequest();*/

                        booking_fragment2_back.setEnabled(false);
                        setTimerForRideRequest();

                    }
                }

            }
        });


        retry_ride_request_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (waitingTimerRideRequest != null) {
                    waitingTimerRideRequest.cancel();
                    waitingTimerRideRequest = null;

                }
                status = "searching";

                linearLayout_background_blur.setBackgroundResource(R.color.white_light_transparent_1);

                /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white_light_transparent_1));*/
                finding_nearest_textView.setVisibility(View.VISIBLE);
                passenger_offer_progressbar.setVisibility(View.VISIBLE);
                retry_ride_request_button.setVisibility(View.GONE);
                cancel_ride_request_button.setVisibility(View.GONE);
                driver_response_textView.setVisibility(View.GONE);

                setTimerForRideRequest();
            }
        });

        cancel_ride_request_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (waitingTimerRideRequest != null) {
                    waitingTimerRideRequest.cancel();
                    waitingTimerRideRequest = null;
                }
                Bundle bundle = new Bundle();
                bundle.putString("from", from);
                bundle.putString("to", to);
                bundle.putString("fromlatitude", fromlatitude);
                bundle.putString("fromlongitude", fromlongitude);
                bundle.putString("tolatitude", tolatitude);
                bundle.putString("tolongitude", tolongitude);
                bundle.putString("vehicle_type", vehicle_type);
                PassengerHomeFragment backFragment = new PassengerHomeFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                backFragment.setArguments(bundle);
                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, backFragment)
                        .commit();
            }
        });

        otherBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    private void pickContactBookForOther(int type) {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(intent, type);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode== Activity.RESULT_OK){
            if(requestCode==TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT){
                pickedContact(data,requestCode);
            }
        }
    }

    private void pickedContact(Intent data, int requestCode) {

        try {
            // getData() method will have the Content Uri of the selected contact
            Uri uri = data.getData();
            cursor = getContext().getContentResolver().query(uri, null, null, null, null);
            cursor.moveToFirst();
            // sendToParentLinearLayout.setVisibility(GONE);
            //pickedContactDetailsLinearLayout.setVisibility(View.VISIBLE);
            // column index of the phone number
            phonePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            // column index of the contact name
            namePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

            userPhoneNumberValue = cursor.getString(phonePosIndex);
            userNameValue = cursor.getString(namePosIndex);


            Log.d("pickedPhoneNum", ":" + cursor.getString(phonePosIndex));
            String[] splitStrPhoneNumber = cursor.getString(phonePosIndex).split("\\s+");

            String refinedNumber = "";

            for (int i = 0; i < splitStrPhoneNumber.length; i++) {

                StringBuilder sb = new StringBuilder();

                Log.d("splitted", "Values" + i + "   " + splitStrPhoneNumber[i]);
                sb.append(refinedNumber).append(splitStrPhoneNumber[i]);

                Log.d("data", ":data came" + sb.toString());

                refinedNumber = sb.toString();
                Log.d("data", ":data came" + refinedNumber);


            }


            if (userPhoneNumberValue != null && userNameValue != null) {


                Log.d("data", ":Length" + refinedNumber.length());

                Log.d("data123", ":data came" + refinedNumber);


                if (refinedNumber.length() == 10) {
                    refinedNumber = refinedNumber;
                } else if (refinedNumber.length() > 10) {
                    refinedNumber = refinedNumber.replaceAll("[^0-9]+", "");
                    refinedNumber = refinedNumber.substring(refinedNumber.length() - 10);
                    //
                } else {
                    // whatever is appropriate in this case
                    throw new IllegalArgumentException("Please Enter Valid Mobile Number");
                }

                Log.d("data123", ":data came" + refinedNumber);
                if (requestCode == TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT) {
                    idname.setText(userNameValue);
                    idmobile.setText(refinedNumber);
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendRideRequest() {

        StringRequest stringRequestNotification = new StringRequest(Request.Method.POST, retryUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String responses) {
                        try {

                            JSONObject jObj = new JSONObject(responses);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                status = jObj.getString("status");

                                if (status.equals("got")) {
                                    bookingid = jObj.getString("bookingid");
                                        /*waitingTimerRideRequest.cancel();*/

                                }
                                message = jObj.getString("message");


                            } else {
                                String errorMsg = jObj.getString("error_msg");
                              /*  Intent home = new Intent(getActivity(), NavHome.class);
                                startActivity(home);*/

                                linearLayout_background_blur.setVisibility(View.GONE);
                                finding_nearest_textView.setVisibility(View.GONE);
                                passenger_offer_progressbar.setVisibility(View.GONE);
                                booking_fragment2_back.setEnabled(true);

                                android.support.v7.app.AlertDialog.Builder builder1 = new android.support.v7.app.AlertDialog.Builder(getContext(),R.style.MyDialogTheme);
                                builder1.setMessage(errorMsg);
                                builder1.setCancelable(true);
                                builder1.setTitle("Alert !");

                                builder1.setPositiveButton(
                                        "OK",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.cancel();
                                            }
                                        });

                                android.support.v7.app.AlertDialog mDialog = builder1.create();
                                mDialog.show();

                                if (waitingTimerRideRequest != null) {
                                    waitingTimerRideRequest.cancel();
                                    waitingTimerRideRequest = null;
                                }

                                //getActivity().finish();

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("passengername", sessionManager.getUserDetails().get("name"));
                params.put("passengermobile", sessionManager.getUserDetails().get("mobile"));
                params.put("vehicle", vehicle_type);
                params.put("whenrequired", when_required_value);
                params.put("whenrequiredtype", when_required_type);
                params.put("typeofrate", string_type_of_rate);
                params.put("rate", type_of_rate_value);
               /* params.put("metervalue", getIntent().getStringExtra("metervalue"));*/
                params.put("from", from);
                params.put("to", to);
                params.put("fromlatitude", fromlatitude);
                params.put("fromlongitude", fromlongitude);
                params.put("tolatitude", tolatitude);
                params.put("tolongitude", tolongitude);
                params.put("paymenttype", paymentType);
                params.put("distance", distance);
                params.put("range_count", "2"/*Integer.toString(range_count)*/);
                params.put("metervalue",rate);
                params.put("city_name",city);
                params.put("state_name",state);
                params.put("minimum_fare",minimum_fare);


                params.put("booking_type", type);

                if (type.equals("Other")) {

                    params.put("other_passengername", othername);
                    params.put("other_passengernumber", othermobile);
                }

                return params;
            }
        };

        // remove caching
        stringRequestNotification.setShouldCache(false);
        // Wait 30 seconds and don't retry more than once
        stringRequestNotification.setRetryPolicy(new DefaultRetryPolicy(240000, 0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequestNotification);


    }



    /*---------------------------------------------------------------------------------------------------------*/
    @Subscribe
    public void getButtonStatus(OttoAllDriversRejected data) {
        Log.i("Activity", data.getRejection());

        if (data.getRejection().equals("All Drivers Rejected Please Try Again")) {

            if (waitingTimerRideRequest != null) {
                waitingTimerRideRequest.cancel();
                waitingTimerRideRequest = null;

            }
            /*linearLayout_background_blur.setBackgroundResource(R.color.white);*/

            finding_nearest_textView.setVisibility(View.GONE);
            passenger_offer_progressbar.setVisibility(View.GONE);
            retry_ride_request_button.setVisibility(View.VISIBLE);
            cancel_ride_request_button.setVisibility(View.VISIBLE);
            driver_response_textView.setVisibility(View.VISIBLE);
            driver_response_textView.setText("Drivers not responding. Try again");

        }
        if (data.getRejection().equals("Request timeout")) {
            if (waitingTimerRideRequest != null) {
                waitingTimerRideRequest.cancel();
                waitingTimerRideRequest = null;

            }

            /*linearLayout_background_blur.setBackgroundResource(R.color.white);*/


            finding_nearest_textView.setVisibility(View.GONE);
            passenger_offer_progressbar.setVisibility(View.GONE);
            retry_ride_request_button.setVisibility(View.VISIBLE);
            cancel_ride_request_button.setVisibility(View.VISIBLE);
            driver_response_textView.setVisibility(View.VISIBLE);
            driver_response_textView.setText("Responce Timeout");

        }
    }

    private void setTimerForRideRequest() {

        waitingTimerRideRequest = new CountDownTimer(130000, 10000) {

            public void onTick(long millisUntilFinished) {

                if (millisUntilFinished >= 80000 && status.equals("searching")) {

                    range_count++;
                    sendRideRequest();
                } else if (status.equals("searching")) {
                    linearLayout_background_blur.setBackgroundResource(R.color.white);
                /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white));*/
                    finding_nearest_textView.setVisibility(View.GONE);
                    passenger_offer_progressbar.setVisibility(View.GONE);
                    paymentModeRadioGroup.setVisibility(View.GONE);
                    retry_ride_request_button.setVisibility(View.VISIBLE);
                    cancel_ride_request_button.setVisibility(View.VISIBLE);
                    driver_response_textView.setVisibility(View.VISIBLE);
                    driver_response_textView.setText("Driver not found in your area");
                }
            }

            public void onFinish() {

                linearLayout_background_blur.setBackgroundResource(R.color.white);
            /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white));*/
                finding_nearest_textView.setVisibility(View.GONE);
                passenger_offer_progressbar.setVisibility(View.GONE);
                retry_ride_request_button.setVisibility(View.VISIBLE);
                cancel_ride_request_button.setVisibility(View.VISIBLE);
                driver_response_textView.setVisibility(View.VISIBLE);
                driver_response_textView.setText("Responce Timeout");
            }
        }.start();
    }

    LatLng latLng,latLng2;
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;

        /*mGoogleMap.getUiSettings().setCompassEnabled(true);*/

        @SuppressWarnings("ConstantConditions") View locationButton = ((View) mapFrag.getView().findViewById(Integer.parseInt("1")).getParent()).findViewById(Integer.parseInt("2"));
        RelativeLayout.LayoutParams rlp = (RelativeLayout.LayoutParams) locationButton.getLayoutParams();
        // position on right bottom
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0);
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        rlp.setMargins(0, 450, 0, 0);


        //Initialize Google Play Services
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (ContextCompat.checkSelfPermission(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {

                mGoogleMap.setMyLocationEnabled(true);
            }
        } else {
            mGoogleMap.setMyLocationEnabled(true);

        }
         latLng = new LatLng(Double.parseDouble(fromlatitude), Double.parseDouble(fromlongitude));
        MarkerOptions markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.from_location));

        markerOptions.position(latLng);
        markerOptions.title("Pickup Point");
        mGoogleMap.addMarker(markerOptions);
        mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(11));


         latLng2 = new LatLng(Double.parseDouble(tolatitude), Double.parseDouble(tolongitude));
        MarkerOptions markerOptionsDestination = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.to_location));

        markerOptionsDestination.position(latLng2);
        markerOptionsDestination.title("Destination Point");
        mGoogleMap.addMarker(markerOptionsDestination);
        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(11));

        /*Below code is written by harish*/
        // Getting URL to the Google Directions API
        if(apikey) {
            apikey=false;

            String url = getDirectionsUrl(latLng, latLng2, "" + getResources().getString(R.string.google_apikey));
            Log.e("directionsurl", "url is " + url);
            DownloadTask downloadTask = new DownloadTask();

            // Start downloading json data from Google Directions API
            downloadTask.execute(url);
        }
    }


    @Subscribe
    public void ottoDialogBoxLogout(OttoDialogPersonalOther ottoDialogPersonalOther) {

        type = ottoDialogPersonalOther.getType();
        othermobile = ottoDialogPersonalOther.getMobile();
        othername = ottoDialogPersonalOther.getName();
     //   personal.setText(type);

    }


    /*Below code is written by Harish Kumar
    * Getting the directions from 2 points using google apis.*/

    private class DownloadTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... url) {

            String data = "";

            try {
                data = downloadUrl(url[0]);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ParserTask parserTask = new ParserTask();


            parserTask.execute(result);

        }
    }

private boolean readjsonfile=true;
    /**
     * A class to parse the Google Places in JSON format
     */
    private class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {

        // Parsing the data in non-ui thread
        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try {
                jObject = new JSONObject(jsonData[0]);
                DirectionsJSONParser parser = new DirectionsJSONParser();

                routes = parser.parse(jObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return routes;
        }

        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {
            ArrayList points = null;
            PolylineOptions lineOptions = null;
            MarkerOptions markerOptions = new MarkerOptions();

            for (int i = 0; i < result.size(); i++) {
                points = new ArrayList();
                lineOptions = new PolylineOptions();

                List<HashMap<String, String>> path = result.get(i);

                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);

                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);

                    points.add(position);
                }

                lineOptions.addAll(points);
                lineOptions.width(12);
                lineOptions.color(Color.RED);
                lineOptions.geodesic(true);

            }

// Drawing polyline in the Google Map for the i-th route
            if(lineOptions!=null) {
                mGoogleMap.addPolyline(lineOptions);

            }else{
                if(apikey1){
                    apikey1=false;
                    String url = getDirectionsUrl(latLng, latLng2,""+getResources().getString(R.string.google_key));
                    Log.e("directionsurl","url is "+url);
                    DownloadTask downloadTask = new DownloadTask();

                    // Start downloading json data from Google Directions API
                    downloadTask.execute(url);
                }else{

                        String json = null;
                        try {
                            InputStream is = getActivity().getAssets().open("location.json");
                            int size = is.available();
                            byte[] buffer = new byte[size];
                            is.read(buffer);
                            is.close();
                            json = new String(buffer, "UTF-8");
                        } catch (IOException ex) {
                            ex.printStackTrace();

                        }
                         if(readjsonfile) {
                             readjsonfile=false;
                             if (json != null) {
                                 ParserTask parserTask = new ParserTask();
                                 parserTask.execute(json);

                             }
                         }

                }

            }
        }
    }

    private String getDirectionsUrl(LatLng origin, LatLng dest,String key) {

        // Origin of route
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;

        // Destination of route
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;

        // Sensor enabled
        String sensor = "sensor=false";
        String mode = "mode=driving";
        String key1="key="+key;
        // Building the parameters to the web service
        String parameters = str_origin + "&" + str_dest + "&" + sensor + "&" + mode+"&"+key1;

        // Output format
        String output = "json";

        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;
        Log.e("url","url is "+url);

        return url;
    }

    /**
     * A method to download json data from url
     */
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);

            urlConnection = (HttpURLConnection) url.openConnection();

            urlConnection.connect();

            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();

            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        } catch (Exception e) {
            Log.d("Exception", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }
}
