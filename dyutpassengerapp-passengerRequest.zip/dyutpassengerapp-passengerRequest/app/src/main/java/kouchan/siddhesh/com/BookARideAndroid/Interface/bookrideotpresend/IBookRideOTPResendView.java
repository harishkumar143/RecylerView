package kouchan.siddhesh.com.BookARideAndroid.Interface.bookrideotpresend;

public interface IBookRideOTPResendView {

    void onGetBookRideOTPResendSuccess(int pid, String String);

    void onGetBookRideOTPResendError(int pid, String regModel);

}
