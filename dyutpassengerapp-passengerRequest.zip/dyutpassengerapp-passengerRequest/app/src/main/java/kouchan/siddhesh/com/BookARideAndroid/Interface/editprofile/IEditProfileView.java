package kouchan.siddhesh.com.BookARideAndroid.Interface.editprofile;

public interface IEditProfileView {

    void editProfileSuccess(int pid, String balance);

    void editProfileError(int pid, String error);

}
