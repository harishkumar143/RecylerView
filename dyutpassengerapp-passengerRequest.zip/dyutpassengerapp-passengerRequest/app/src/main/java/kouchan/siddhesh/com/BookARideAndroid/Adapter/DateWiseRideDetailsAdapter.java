package kouchan.siddhesh.com.BookARideAndroid.Adapter;

import android.content.Context;
import android.content.res.Resources;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.MonthExpand;

/**
 * Created by KOUCHAN-ADMIN on 1/12/2018.
 */

public class DateWiseRideDetailsAdapter extends RecyclerView.Adapter<DateWiseRideDetailsAdapter.MyViewHolder> {

    private List<MonthExpand> monthExpandList;
    String languageCode;
    Resources resources;
    SessionManager sessionManager;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView date_month_expand,ttoatal_rides_month_expand,total_fair_month_expand,rides_completed_textView;

        public MyViewHolder(View view) {
            super(view);
            date_month_expand = (TextView) view.findViewById(R.id.date_month_expand);
            ttoatal_rides_month_expand = (TextView) view.findViewById(R.id.ttoatal_rides_month_expand);
            total_fair_month_expand = (TextView) view.findViewById(R.id.total_fair_month_expand);
            rides_completed_textView = (TextView) view.findViewById(R.id.rides_completed_textView);
        }
    }


    public DateWiseRideDetailsAdapter(List<MonthExpand> cancelList, Context context) {
        this.monthExpandList = cancelList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.month_expand_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        MonthExpand monthExpand = monthExpandList.get(position);

        holder.date_month_expand.setText(monthExpand.getDate());
        holder.ttoatal_rides_month_expand .setText(" "+monthExpand.getTotal_no_of_rides());
        holder.total_fair_month_expand.setText(" "+monthExpand.getTotal_fare());
        sessionManager = new SessionManager(context);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();

            Context contexta = LocaleHelper.setLocale(context, languageCode);
            resources = contexta.getResources();
            holder.rides_completed_textView.setText(resources.getString(R.string.rides_completed));
        }
    }

    @Override
    public int getItemCount() {
        return monthExpandList.size();
    }
}
