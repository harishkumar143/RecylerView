package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

public class ForgotPassword extends AppCompatActivity {

    EditText otp, newPassword, confirmPassword;
    String stringOtp, stringNewPassword, stringConfirmPassword;
    String mobile, type;
    Button updatePassword;

    TextInputLayout otpToChangePasswordTextInput, newPasswordTextInput, confirmPasswordTextInput;
    TextView forgot_password_tv, forgot_password_tv_b;

    String languageCode;
    Resources resources;
    SessionManager sessionManager;

    String updatePasswordUrl = "";

    Toolbar mToolbar;
    ImageView forgotPasswordBackImageView;

    public AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        otp = (EditText) findViewById(R.id.otpToChangePassword);
        newPassword = (EditText) findViewById(R.id.newPassword);
        confirmPassword = (EditText) findViewById(R.id.confirmPassword);
        forgot_password_tv = (TextView) findViewById(R.id.forgot_password_tv);
        forgot_password_tv_b = (TextView) findViewById(R.id.forgot_password_tv_b);
        otpToChangePasswordTextInput = (TextInputLayout) findViewById(R.id.otpToChangePasswordTextInput);
        newPasswordTextInput = (TextInputLayout) findViewById(R.id.newPasswordTextInput);
        confirmPasswordTextInput = (TextInputLayout) findViewById(R.id.confirmPasswordTextInput);
        sessionManager = new SessionManager(getApplicationContext());
        type = sessionManager.getType();

        updatePasswordUrl = Url.PASSENGER_API + "updatePassword.php";

        updatePassword = (Button) findViewById(R.id.updatePassword);
        updatePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                asignValue();

            }
        });

        initializeViews();

       /* if (Utils.appCode != null) {
            languageCode = Utils.appCode.toString();
            updateViews(languageCode);
        }*/

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }


    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        forgot_password_tv.setText(resources.getString(R.string.bar_titel_name));
        forgot_password_tv_b.setText(resources.getString(R.string.f_p_head));
        otpToChangePasswordTextInput.setHint(resources.getString(R.string.enter_otp));
        newPasswordTextInput.setHint(resources.getString(R.string.new_password));
        confirmPasswordTextInput.setHint(resources.getString(R.string.confirm_password));
        updatePassword.setText(resources.getString(R.string.confirm));
    }

    public void asignValue() {

        mobile = getIntent().getStringExtra("mobile");
        stringOtp = otp.getText().toString();
        stringNewPassword = newPassword.getText().toString();
        stringConfirmPassword = confirmPassword.getText().toString();

        sendPassword();

    }

    public void sendPassword() {

        if (!(awesomeValidation.validate())) {

            //process the data further
        } else {


            if (Utils.isInternetAvailable(ForgotPassword.this)) {

                Utils.showProgress(ForgotPassword.this);

                StringRequest stringRequest = new StringRequest(Request.Method.POST, updatePasswordUrl,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    Utils.stopProgress(ForgotPassword.this);
                                    JSONObject jObj = new JSONObject(response);
                                    boolean error = jObj.getBoolean("error");
                                    if (!error) {

                                        startActivity(new Intent(ForgotPassword.this, LoginActivity.class));
                                        Toast.makeText(ForgotPassword.this, jObj.getString("message"), Toast.LENGTH_SHORT).show();
                                        finish();

                                    } else {

                                        String errorMsg = jObj.getString("error_msg");
                                        Toast.makeText(ForgotPassword.this, errorMsg, Toast.LENGTH_SHORT).show();
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Utils.stopProgress(ForgotPassword.this);
                            }
                        }) {

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {

                        Map<String, String> params = new HashMap<String, String>();

                        params.put("mobile", mobile);
                        params.put("otp", stringOtp);
                        params.put("password", stringNewPassword);


                        return params;
                    }
                };

                VolleySingleton.getInstance(ForgotPassword.this).addToRequestQueue(stringRequest);
            } else {

                Utils.showToast(ForgotPassword.this, "please connect to the internate");
            }
        }
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(ForgotPassword.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        forgotPasswordBackImageView = (ImageView) findViewById(R.id.forgotPasswordBackImageView);

        forgotPasswordBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ForgotPassword.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        /*String regexPassword = ".{8,}";*/
        String regexPassword = ".{6,}";

        awesomeValidation.addValidation(this, R.id.newPassword, regexPassword, R.string.passworderror);
        awesomeValidation.addValidation(this, R.id.confirmPassword, R.id.newPassword, R.string.invalid_confirm_password);

        /*String passworderror = resources.getString(R.string.passworderror);
        String invalid_confirm_password = resources.getString(R.string.invalid_confirm_password);
        awesomeValidation.addValidation(this, R.id.newPassword, regexPassword, Integer.parseInt(passworderror));
        awesomeValidation.addValidation(this, R.id.confirmPassword, R.id.newPassword, Integer.parseInt(invalid_confirm_password));
*/

    }

}


