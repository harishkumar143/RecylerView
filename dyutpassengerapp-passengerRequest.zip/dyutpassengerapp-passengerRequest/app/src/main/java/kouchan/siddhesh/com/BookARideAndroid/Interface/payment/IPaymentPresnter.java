package kouchan.siddhesh.com.BookARideAndroid.Interface.payment;

public interface IPaymentPresnter {

    void payment(String bookingId,String paymentMode);

}
