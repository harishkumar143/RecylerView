package com.kouchan.dyutpassenger.View.Activities;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.CurrentRide;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Modules.DirectionFinder;
import com.kouchan.dyutpassenger.Modules.DirectionFinderListener;
import com.kouchan.dyutpassenger.Modules.Route;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.OttoEventActivityFinish;
import com.kouchan.dyutpassenger.other.TimerForAvailability;
import com.kouchan.dyutpassenger.sendLocation;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;
import com.squareup.otto.Subscribe;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, DirectionFinderListener,OnRequestListener {

    private GoogleMap mMap;
    private Button btnFindPath;
    private EditText etOrigin;
    private EditText etDestination;
    TextView cost;
    Button endride, startride;
    TextView passengerphone;
    TextView passengername;
    private List<Marker> originMarkers = new ArrayList<>();
    private List<Marker> destinationMarkers = new ArrayList<>();
    private List<Polyline> polylinePaths = new ArrayList<>();
    private ProgressDialog progressDialog;
    private TextView uniqueID;

    TextView pickup_point_textView, destination_point_textView;

    AsyncInteractor asyncInteractor;

    String languageCode;
    Resources resources;

    String distanceinKM;
    String rate;
    double doublerate;
    double doubledistanceinKM;
    String typeofrate;

    String stringStatus, rideToken, reason = "";

    AlertDialog.Builder ab;

    String startURL = Url.COMUNICATE_API + "rideStart.php";
    String endURL = Url.COMUNICATE_API + "endRideFromDriver.php";

    String cancelRideUrl = Url.COMUNICATE_API + "bookingCancellationOfDriver.php";
    String sendReadReceiptUrl = Url.COMUNICATE_API + "read_track.php";

    SessionManager sessionManager;
    TimerForAvailability timerForAvailability;

    HashMap<String, String> user = new HashMap<String, String>();

    Button cancelridema, startNavigationButton;
    CurrentRide currentRide;

    /*ImageView navigationImageButton;*/
    CountDownTimer waitTimer;

    Boolean wantToCloseDialog;
    EditText otp_edittext;
    AlertDialog.Builder builder;
    AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        wantToCloseDialog = false;

        otp_edittext = new EditText(MapsActivity.this);
        builder = new AlertDialog.Builder(MapsActivity.this);
        asyncInteractor=new AsyncInteractor(this);


        currentRide = new CurrentRide(getApplicationContext());

        if (currentRide.getIsridestarted().equals("started")) {

        } else {
            currentRide.setMessage("reached");
            currentRide.setStage("Driver Selected");
            currentRide.setDrivername(getIntent().getStringExtra("drivername"));
            currentRide.setDrivermobile(getIntent().getStringExtra("drivermobile"));
            currentRide.setPassengername(getIntent().getStringExtra("passengername"));
            currentRide.setPassengermobile(getIntent().getStringExtra("passengermobile"));
            currentRide.setVehicle(getIntent().getStringExtra("vehicle"));
            currentRide.setWhenrequired(getIntent().getStringExtra("whenrequired"));
            currentRide.setWhenrequiredtype(getIntent().getStringExtra("whenrequiredtype"));
            currentRide.setTypeofrate(getIntent().getStringExtra("typeofrate"));
            currentRide.setRate(getIntent().getStringExtra("rate"));
            currentRide.setFrom(getIntent().getStringExtra("from"));
            currentRide.setTo(getIntent().getStringExtra("to"));
            currentRide.setFromlatitude(getIntent().getStringExtra("fromlatitude"));
            currentRide.setFromlongitude(getIntent().getStringExtra("fromlongitude"));
            currentRide.setTolatitude(getIntent().getStringExtra("tolatitude"));
            currentRide.setTolongitude(getIntent().getStringExtra("tolongitude"));
            currentRide.setRideid(getIntent().getStringExtra("rideid"));
            currentRide.setIsRideStarted("started");

            currentRide.setTokenStatus("notentered");

        }

       /* sendPassengerReadREceiptNetworkCall(getIntent().getStringExtra("rideid"), getIntent().getStringExtra("passengermobile"),
                getIntent().getStringExtra("drivermobile"));*/


        startNavigationButton = (Button) findViewById(R.id.startNavigationButton);

        Intent s = new Intent(getApplicationContext(), sendLocation.class);
        startService(s);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        EventBusManager.getInstance().getEventBus().register(this);

        NotificationManager notificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
        notificationManager.cancelAll();

        sessionManager = new SessionManager(getApplicationContext());
        user = sessionManager.getUserDetails();
        sessionManager.createTimer("1");

        timerForAvailability = new TimerForAvailability(getApplicationContext());
        // timerForAvailability.stopTimer("NOTAVAILABLE");


        btnFindPath = (Button) findViewById(R.id.btnFindPath);
        etOrigin = (EditText) findViewById(R.id.etOrigin);
        etDestination = (EditText) findViewById(R.id.etDestination);

        etOrigin.setText(getIntent().getStringExtra("from"));
        etOrigin.setEnabled(false);
        etDestination.setText(getIntent().getStringExtra("to"));
        etDestination.setEnabled(false);

        passengername = (TextView) findViewById(R.id.passengernames);
        passengerphone = (TextView) findViewById(R.id.passengerphones);

        passengername.setText(getIntent().getStringExtra("passengername"));

        cost = (TextView) findViewById(R.id.totalcostofride);

        passengerphone.setText(getIntent().getStringExtra("passengermobile"));

        uniqueID = (TextView) findViewById(R.id.uniqueid);
        uniqueID.setText(getString(R.string.reference_no) + getIntent().getStringExtra("rideid"));

        rate = getIntent().getStringExtra("rate");
        typeofrate = getIntent().getStringExtra("typeofrate");

        endride = (Button) findViewById(R.id.endride);
        startride = (Button) findViewById(R.id.startride);
        cancelridema = (Button) findViewById(R.id.cancelride);

        pickup_point_textView = (TextView) findViewById(R.id.pickup_point_textView);
        destination_point_textView = (TextView) findViewById(R.id.destination_point_textView);

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        doublerate = Double.parseDouble(rate);

        passengerphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Here, thisActivity is the current activity

                String phone_no = passengerphone.getText().toString();
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + phone_no));
                callIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (ActivityCompat.checkSelfPermission(MapsActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                startActivity(callIntent);
            }
        });


        endride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                androidx.appcompat.app.AlertDialog.Builder builder;
                builder = new androidx.appcompat.app.AlertDialog.Builder(MapsActivity.this, android.R.style.Theme_Material_Dialog_Alert);

                builder.setTitle(resources.getString(R.string.end_ride))
                        .setMessage(resources.getString(R.string.do_you_want_to_end_the_ride))
                        .setPositiveButton(resources.getString(R.string.yes), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                rideEnd();

                            }
                        })
                        .setNegativeButton(resources.getString(R.string.no), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        }).setIcon(android.R.drawable.ic_dialog_alert)
                        .show();


            }
        });


        startride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
                /*buildingAlertbox();*/
                customAlertBox();
                imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

                //  startRide();
            }
        });


        cancelridema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
                cancelRide();
//
            }

        });


        startNavigationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String format = "geo:0,0?q=" + getIntent().getStringExtra("tolatitude") +
                        "," + getIntent().getStringExtra("tolongitude") + "( Destination)";

                Uri uri = Uri.parse(format);

                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });


        /*sendRequest();*/
        endride.setEnabled(false);
        startride.setEnabled(true);

       /* Intent s=new Intent(MapsActivity.this,sendLocation.class);
        startService(s);*/
        waitTimer = new CountDownTimer(2500, 1000) {

            public void onTick(long millisUntilFinished) {


            }

            public void onFinish() {
                //After 15000 milliseconds (60 sec) finish current

                sendRequest();

            }
        }.start();

        if (currentRide.getIsridestarted().equals("started")) {

            if (currentRide.getTokenstatus().equals("entered")) {

                startride.setEnabled(false);
                endride.setEnabled(true);
            }
            cost.setText(getString(R.string.cost) + rate);
            ((TextView) findViewById(R.id.tvDuration)).setText(currentRide.getTime());
            ((TextView) findViewById(R.id.tvDistance)).setText(currentRide.getDistanceInKm());

        }


    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        pickup_point_textView.setText(resources.getString(R.string.pickup_point));
        destination_point_textView.setText(resources.getString(R.string.destination_point));

        /*startNavigationButton.setText(resources.getString(R.string.start_navigation));*/
        startride.setText(resources.getString(R.string.start_ride));
        endride.setText(resources.getString(R.string.end_ride));
        cancelridema.setText(resources.getString(R.string.cancel_ride));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.


                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    private void sendRequest() {

        String origin = getIntent().getStringExtra("fromlatitude") + "," + getIntent().getStringExtra("fromlongitude");
        String destination = getIntent().getStringExtra("tolatitude") + "," + getIntent().getStringExtra("tolongitude");

        try {
            new DirectionFinder(this, origin, destination,MapsActivity.this).execute();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng hcmus = new LatLng(19.07, 72.87);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(hcmus, 12));
        //originMarkers.add(mMap.addMarker(new MarkerOptions()
        //.title("Đại học Khoa học tự nhiên")
        //.position(hcmus)));

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);
    }


    @Override
    public void onDirectionFinderStart() {
        progressDialog = ProgressDialog.show(this, resources.getString(R.string.please_wait),
                resources.getString(R.string.finding_direction), true);

        if (originMarkers != null) {
            for (Marker marker : originMarkers) {
                marker.remove();
            }
        }

        if (destinationMarkers != null) {
            for (Marker marker : destinationMarkers) {
                marker.remove();
            }
        }

        if (polylinePaths != null) {
            for (Polyline polyline : polylinePaths) {
                polyline.remove();
            }
        }
    }

    @Override
    public void onDirectionFinderSuccess(List<Route> routes) {
        progressDialog.dismiss();
        polylinePaths = new ArrayList<>();
        originMarkers = new ArrayList<>();
        destinationMarkers = new ArrayList<>();

        for (Route route : routes) {
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(route.startLocation, 12));
            ((TextView) findViewById(R.id.tvDuration)).setText(route.duration.text);
            ((TextView) findViewById(R.id.tvDistance)).setText(route.distance.text);

            distanceinKM = route.distance.text;

            currentRide.setDistanceInKm(distanceinKM);
            currentRide.setTime(route.duration.text);
            //
            if (typeofrate.equals("permeter") || typeofrate.equals("meterplusextra") || typeofrate.equals("meterminusextra")) {
                /*doubledistanceinKM=Math.random();
                double intcost=Math.round(doubledistanceinKM*1000*doublerate);
                cost.setText("Cost : \n"+intcost+"\n"+"Type of rate : \n"+typeofrate);*/
                cost.setText(resources.getString(R.string.cost) + rate);
            } else {
                cost.setText(resources.getString(R.string.cost) + rate);
            }

            originMarkers.add(mMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker))
                    .title(route.startAddress)
                    .position(route.startLocation)));
            destinationMarkers.add(mMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker))
                    .title(route.endAddress)
                    .position(route.endLocation)));

            PolylineOptions polylineOptions = new PolylineOptions().
                    geodesic(true).
                    color(Color.BLUE).
                    width(10);

            for (int i = 0; i < route.points.size(); i++)
                polylineOptions.add(route.points.get(i));

            polylinePaths.add(mMap.addPolyline(polylineOptions));
        }
    }



    public void rideEnd() {

        Map<String, String> params = new HashMap<String, String>();
        params.put("id", getIntent().getStringExtra("rideid"));
        // params.put("ridestatus","completed");
        params.put("drivermobile", user.get("mobile"));
        asyncInteractor.validateCredentialsAsync(this,AppConstants.endRideFromDriver,Url.COMUNICATE_API+ServerApiNames.endRideFromDriver,new JSONObject(params));

    }


    public void buildingAlertbox() {

        final EditText edittext = new EditText(MapsActivity.this);
        ab = new AlertDialog.Builder(MapsActivity.this);
        edittext.setInputType(InputType.TYPE_CLASS_NUMBER);
        edittext.setGravity(Gravity.CENTER);
        edittext.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
        ab.setMessage(resources.getString(R.string.ask_passenger_for_ride_token));
        ab.setTitle(resources.getString(R.string.enter_the_ride_token));

        ab.setView(edittext);

        ab.setPositiveButton(resources.getString(R.string.ok), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                //What ever you want to do with the value
            /*Editable YouEditTextValue = edittext.getText();
            //OR*/
                rideToken = edittext.getText().toString();
                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

                startRide();

            }
        });

        ab.setNegativeButton(resources.getString(R.string.cancel), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // what ever you want to do with No option.
            }
        });

        ab.show();

        //automatically open keyboard

        edittext.requestFocus();
        edittext.setFocusableInTouchMode(true);

        InputMethodManager imm3 = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm3.showSoftInput(edittext, InputMethodManager.SHOW_FORCED);

    }

    /*--------------------------------------------------------------------------------------------------*/

    public void customAlertBox() {

        /*final EditText otp_edittext = new EditText(MapsActivity.this);*/

        otp_edittext.setInputType(InputType.TYPE_CLASS_NUMBER);
        otp_edittext.setGravity(Gravity.CENTER);
        otp_edittext.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});

        /*AlertDialog.Builder builder = new AlertDialog.Builder(this);*/
        builder.setMessage("Enter OTP");
        builder.setTitle("Ride OTP");
        builder.setView(otp_edittext);

        builder.setPositiveButton(resources.getString(R.string.ok), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub

            }
        });
        builder.setNegativeButton(resources.getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub

            }
        });


        /*dialog = new AlertDialog.Builder(MapsActivity.this).setView();*/
        dialog = builder.create();
        dialog.show();
        //Overriding the handler immediately after show is probably a better approach than OnShowListener as described below
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                rideToken = otp_edittext.getText().toString();
                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

                startRide();
                //Do stuff, possibly set wantToCloseDialog to true then...
                if (wantToCloseDialog)
                    dialog.dismiss();
                //else dialog stays open. Make sure you have an obvious way to close the dialog especially if you set cancellable to false.
            }
        });

        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*Boolean wantToCloseDialog = true;*/
                //Do stuff, possibly set wantToCloseDialog to true then...
                /*if(wantToCloseDialog)*/
                dialog.dismiss();
                //else dialog stays open. Make sure you have an obvious way to close the dialog especially if you set cancellable to false.
            }
        });

    }

    /*--------------------------------------------------------------------------------------------------*/

    public void startRide() {


        Utils.showProgress(this);

        user = sessionManager.getUserDetails();

        Map<String, String> params = new HashMap<String, String>();
        params.put("id", getIntent().getStringExtra("rideid"));
        // params.put("ridestatus","completed");
        params.put("rideToken", rideToken);

        asyncInteractor.validateCredentialsAsync(this,AppConstants.rideStart,Url.COMUNICATE_API+ServerApiNames.rideStart,new JSONObject(params));

       /* final ProgressDialog loading = ProgressDialog.show(this, resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, startURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                wantToCloseDialog = true;
                                currentRide.setTokenStatus("entered");
                                startride.setEnabled(false);
                                endride.setEnabled(true);
                                *//*customAlertBox();*//*
                                dialog.dismiss();

                                *//*--------------automatically open google map--------------*//*

                                String format = "geo:0,0?q=" + getIntent().getStringExtra("tolatitude") +
                                        "," + getIntent().getStringExtra("tolongitude") + "( Destination)";

                                Uri uri = Uri.parse(format);

                                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);


                            } else {

                                // Error occurred in registration. Get the error
                                *//*String errorMsg = jObj.getString("error_msg");*//*
                                otp_edittext.setError("Entered OTP is Wrong");
                                wantToCloseDialog = false;
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                params.put("id", getIntent().getStringExtra("rideid"));
                // params.put("ridestatus","completed");
                params.put("rideToken", rideToken);


                return params;
            }
        };
        VolleySingleton.getInstance(MapsActivity.this).addToRequestQueue(stringRequest);*/
    }


    public void cancelRide() {

        final EditText edittext2 = new EditText(MapsActivity.this);
        ab = new AlertDialog.Builder(MapsActivity.this);

        edittext2.setInputType(InputType.TYPE_CLASS_TEXT);
        edittext2.setFilters(new InputFilter[]{new InputFilter.LengthFilter(40)});
        ab.setMessage(resources.getString(R.string.please_enter_the_reason_for_cancellation));
        ab.setTitle(resources.getString(R.string.reason));
        ab.setView(edittext2);

        ab.setPositiveButton(resources.getString(R.string.ok), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {


                reason = edittext2.getText().toString();
                if (reason.equals("")) {
                    Toast.makeText(MapsActivity.this, "Please enter reason", Toast.LENGTH_SHORT).show();
                } else {
                    cancelReason();
                }

            }
        });

        ab.setNegativeButton(resources.getString(R.string.cancel), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

            }
        });

        ab.show();

    }


    public void cancelReason() {

        //final ProgressDialog loading = ProgressDialog.show(this, resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);

        Utils.showProgress(this);
        Map<String, String> params = new HashMap<String, String>();

        params.put("bookingid", getIntent().getStringExtra("rideid"));
        params.put("reason", reason);
        params.put("passengermobile", getIntent().getStringExtra("passengermobile"));
        params.put("drivermobile", user.get("mobile"));

        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_bookingCancellationOfDriver,Url.COMUNICATE_API+ServerApiNames.bookingCancellationOfDriver,new JSONObject(params));

    }


    @Override
    public void onBackPressed() {
        Utils.showToast(getApplicationContext(), resources.getString(R.string.do_not_press_back_button));
    }

    @Subscribe
    public void ottoEventActivityFinish(OttoEventActivityFinish finish) {
        if (finish.getFinishActivity().equals("map")) {
            finish();
        }
    }


    private void sendPassengerReadREceiptNetworkCall(final String id, final String passengerMobile, final String drivermobile) {

        if (Utils.isInternetAvailable(MapsActivity.this)) {

            Utils.showProgress(MapsActivity.this);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, sendReadReceiptUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                Utils.stopProgress(MapsActivity.this);
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {


                                } else {


                                    String errorMsg = jObj.getString("error_msg");
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Utils.stopProgress(MapsActivity.this);
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("bookingid", id);
                    params.put("passengermobile", passengerMobile);
                    params.put("drivermobile", drivermobile);
                    params.put("timestamp", String.valueOf(Calendar.getInstance().getTime()));
                    params.put("status", "6");

                    return params;
                }
            };

            VolleySingleton.getInstance(MapsActivity.this).addToRequestQueue(stringRequest);

        } else {

            Utils.showToast(MapsActivity.this, "please connect to the internate");
        }
    }


    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        Utils.stopProgress(this);

        if(pid==AppConstants.TAG_ID_bookingCancellationOfDriver) {
            try {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    Intent s = new Intent(getApplicationContext(), sendLocation.class);
                    stopService(s);

                    startActivity(new Intent(MapsActivity.this, NavHome.class));
                    sessionManager.setUpdateButton("started");
                    currentRide.setIsRideStarted("ended");


                    finish();


                } else {


                    String errorMsg = jObj.getString("error_msg");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

       else if(pid==AppConstants.endRideFromDriver){
            try {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    Intent s = new Intent(getApplicationContext(), sendLocation.class);
                    stopService(s);

                    Intent intent = new Intent(MapsActivity.this, EndRide.class);
                    intent.putExtra("ids", getIntent().getStringExtra("rideid"));
                    intent.putExtra("rate", getIntent().getStringExtra("rate"));
                    intent.putExtra("passengermobile", getIntent().getStringExtra("passengermobile"));
                    startActivity(intent);
                    finish();

                } else {

                    // Error occurred in registration. Get the error

                    String errorMsg = jObj.getString("error_msg");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        else if(pid==AppConstants.rideStart){

            try {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    Intent s = new Intent(getApplicationContext(), sendLocation.class);
                    stopService(s);

                    startActivity(new Intent(MapsActivity.this, NavHome.class));
                    sessionManager.setUpdateButton("started");
                    currentRide.setIsRideStarted("ended");


                    finish();

                } else {


                    String errorMsg = jObj.getString("error_msg");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
