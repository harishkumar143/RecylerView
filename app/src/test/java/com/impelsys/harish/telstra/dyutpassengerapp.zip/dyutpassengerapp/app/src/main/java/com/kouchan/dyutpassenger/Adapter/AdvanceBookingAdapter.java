package com.kouchan.dyutpassenger.Adapter;

import android.content.Context;
import android.content.res.Resources;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.Booking;

import java.util.List;

//import org.com.kouchan.dyutpassenger.Database.SessionManager;
//import org.com.kouchan.dyutpassenger.R;
//import org.com.kouchan.dyutpassenger.helper.LocaleHelper;
//import org.com.kouchan.dyutpassenger.models.Booking;

/**
 * Created by KOUCHAN-ADMIN on 10/17/2017.
 */

public class AdvanceBookingAdapter extends RecyclerView.Adapter<AdvanceBookingAdapter.MyViewHolder> {

    private List<Booking> bookingList;

    String languageCode;
    Resources resources;
    SessionManager sessionManager;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView passenger_name, passenger_mobile, whenrequired, rate, typeofrate,
                passengernamebookingtext, passengermobilebookingtext;

        public TextView whenrequiredbookingtext, ratebookingtext, typeofratebookingtext;


        public MyViewHolder(View view) {
            super(view);
            passenger_name = (TextView) view.findViewById(R.id.passengernamebooking);
            passenger_mobile = (TextView) view.findViewById(R.id.passengermobilebooking);
            whenrequired = (TextView) view.findViewById(R.id.whenrequiredbooking);
            rate = (TextView) view.findViewById(R.id.ratebooking);
            typeofrate = (TextView) view.findViewById(R.id.typeofratebooking);
            passengernamebookingtext = (TextView) view.findViewById(R.id.passengernamebookingtext);
            passengermobilebookingtext = (TextView) view.findViewById(R.id.passengermobilebookingtext);

            whenrequiredbookingtext = (TextView) view.findViewById(R.id.whenrequiredbookingtext);
            ratebookingtext = (TextView) view.findViewById(R.id.ratebookingtext);
            typeofratebookingtext = (TextView) view.findViewById(R.id.typeofratebookingtext);

        }
    }


    public AdvanceBookingAdapter(List<Booking> bookingList, Context context) {
        this.bookingList = bookingList;
        this.context = context;
    }

    @Override
        public AdvanceBookingAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.booking_list_item, parent, false);

        return new AdvanceBookingAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(AdvanceBookingAdapter.MyViewHolder holder, int position) {
        Booking booking = bookingList.get(position);

        sessionManager = new SessionManager(context);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();

            Context contexta = LocaleHelper.setLocale(context, languageCode);
            resources = contexta.getResources();

            if (booking.getType().equals("passenger")) {
                holder.passengernamebookingtext.setText(resources.getString(R.string.driver_name));
                holder.passengermobilebookingtext.setText(resources.getString(R.string.driver_mobile));
            } else {
                holder.passengernamebookingtext.setText(resources.getString(R.string.passenger_name));
                holder.passengermobilebookingtext.setText(resources.getString(R.string.passenger_mobile));
            }
            holder.whenrequiredbookingtext.setText(resources.getString(R.string.when_required));
            holder.ratebookingtext.setText(resources.getString(R.string.total_price));
            holder.typeofratebookingtext.setText(resources.getString(R.string.type_of_rate));
        }

        holder.passenger_name.setText(booking.getPassenger_name());
        holder.passenger_mobile.setText(booking.getPassenger_mobile());
        holder.whenrequired.setText(booking.getWhen_required());
        holder.rate.setText(booking.getRate());
        holder.typeofrate.setText(booking.getTypeofrate());
    }

    @Override
    public int getItemCount() {
        return bookingList.size();
    }

}
