package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ForgotPassword extends AppCompatActivity implements OnRequestListener {

    EditText otp, newPassword, confirmPassword;
    String stringOtp, stringNewPassword, stringConfirmPassword;
    String mobile, type;
    Button updatePassword;
    AsyncInteractor asyncInteractor;

    TextInputLayout otpToChangePasswordTextInput, newPasswordTextInput, confirmPasswordTextInput;
    TextView forgot_password_tv, forgot_password_tv_b;

    String languageCode;
    Resources resources;
    SessionManager sessionManager;

    String updatePasswordUrl = "";

    Toolbar mToolbar;
    ImageView forgotPasswordBackImageView;

    public AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        otp = (EditText) findViewById(R.id.otpToChangePassword);
        newPassword = (EditText) findViewById(R.id.newPassword);
        confirmPassword = (EditText) findViewById(R.id.confirmPassword);
        forgot_password_tv = (TextView) findViewById(R.id.forgot_password_tv);
        forgot_password_tv_b = (TextView) findViewById(R.id.forgot_password_tv_b);
        otpToChangePasswordTextInput = (TextInputLayout) findViewById(R.id.otpToChangePasswordTextInput);
        newPasswordTextInput = (TextInputLayout) findViewById(R.id.newPasswordTextInput);
        confirmPasswordTextInput = (TextInputLayout) findViewById(R.id.confirmPasswordTextInput);
        sessionManager = new SessionManager(getApplicationContext());
        type = sessionManager.getType();

        asyncInteractor=new AsyncInteractor(this);
        updatePasswordUrl = Url.PASSENGER_API + "updatePassword.php";

        updatePassword = (Button) findViewById(R.id.updatePassword);
        updatePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                asignValue();

            }
        });

        initializeViews();

       /* if (Utils.appCode != null) {
            languageCode = Utils.appCode.toString();
            updateViews(languageCode);
        }*/

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }


    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        forgot_password_tv.setText(resources.getString(R.string.reset_password));
        forgot_password_tv_b.setText(resources.getString(R.string.f_p_head));
        otpToChangePasswordTextInput.setHint(resources.getString(R.string.enter_otp));
        newPasswordTextInput.setHint(resources.getString(R.string.new_password));
        confirmPasswordTextInput.setHint(resources.getString(R.string.confirm_password));
        updatePassword.setText(resources.getString(R.string.confirm));
    }

    public void asignValue() {

        mobile = getIntent().getStringExtra("mobile");
        stringOtp = otp.getText().toString();
        stringNewPassword = newPassword.getText().toString();
        stringConfirmPassword = confirmPassword.getText().toString();

        sendPassword();

    }

    public void sendPassword() {

        if (!(awesomeValidation.validate())) {

            //process the data further
        } else {


            if (Utils.isInternetAvailable(ForgotPassword.this)) {

                Utils.showProgress(ForgotPassword.this);
                Map<String, String> params = new HashMap<String, String>();

                params.put("mobile", mobile);
                params.put("otp", stringOtp);
                params.put("password", stringNewPassword);

                asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_UPDATE_PASSWORD, Url.PASSENGER_API+ServerApiNames.UPDATE_PASSWORD,new JSONObject(params),"");

            } else {

                Utils.showToast(ForgotPassword.this, "please connect to the internate");
            }
        }
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(ForgotPassword.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        forgotPasswordBackImageView = (ImageView) findViewById(R.id.forgotPasswordBackImageView);

        forgotPasswordBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ForgotPassword.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        /*String regexPassword = ".{8,}";*/
        String regexPassword = ".{6,}";

        awesomeValidation.addValidation(this, R.id.newPassword, regexPassword, R.string.passworderror);
        awesomeValidation.addValidation(this, R.id.confirmPassword, R.id.newPassword, R.string.invalid_confirm_password);

        /*String passworderror = resources.getString(R.string.passworderror);
        String invalid_confirm_password = resources.getString(R.string.invalid_confirm_password);
        awesomeValidation.addValidation(this, R.id.newPassword, regexPassword, Integer.parseInt(passworderror));
        awesomeValidation.addValidation(this, R.id.confirmPassword, R.id.newPassword, Integer.parseInt(invalid_confirm_password));
*/

    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        Utils.stopProgress(this);

        if(pid==AppConstants.TAG_ID_UPDATE_PASSWORD)
        try {
            Utils.stopProgress(ForgotPassword.this);
            JSONObject jObj = new JSONObject(responseJson);
            boolean error = jObj.getBoolean("error");
            if (!error) {

                startActivity(new Intent(ForgotPassword.this, LoginActivity.class));
                Toast.makeText(ForgotPassword.this, jObj.getString("message"), Toast.LENGTH_SHORT).show();
                finish();

            } else {

                String errorMsg = jObj.getString("error_msg");
                Toast.makeText(ForgotPassword.this, errorMsg, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}


