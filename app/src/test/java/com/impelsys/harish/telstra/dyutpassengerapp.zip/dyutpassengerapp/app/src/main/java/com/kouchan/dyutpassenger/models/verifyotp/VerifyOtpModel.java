package com.kouchan.dyutpassenger.models.verifyotp;

import com.google.gson.annotations.SerializedName;

public class VerifyOtpModel {


    /**
     * error : false
     * message : Success
     * access_token : 0E079DE0192F446EAB7AC0687ACFA7E110E45343336C475A12
     * expires_in : 6000
     * token_type : Bearer
     * scope : BOOKARIDE
     * next_step : REGISTRATION_COMPLETED
     * id : 7
     * user : {"unique_id":"BRP5007","name":"Shivaraj","mobile":"7676060664","email":"s.raaj46@gmail.com","block_status":"0","created_at":"2019-12-09 13:10:30","ride_cancel_count":"0","dyut_account_balance":"0.00","encrypted_password":"rnxFMZxnnPL3ZNXQ4MbnWN4KwoQ1OTMwZWJkMjc3"}
     */

    @SerializedName("error")
    private boolean mError;
    @SerializedName("message")
    private String mMessage;
    @SerializedName("access_token")
    private String mAccessToken;
    @SerializedName("expires_in")
    private String mExpiresIn;
    @SerializedName("token_type")
    private String mTokenType;
    @SerializedName("scope")
    private String mScope;
    @SerializedName("next_step")
    private String mNextStep;
    @SerializedName("id")
    private int mId;
    @SerializedName("user")
    private UserBean mUser;

    public boolean isError() {
        return mError;
    }

    public void setError(boolean error) {
        mError = error;
    }

    public String getMessage() {
        return mMessage;
    }

    public void setMessage(String message) {
        mMessage = message;
    }

    public String getAccessToken() {
        return mAccessToken;
    }

    public void setAccessToken(String accessToken) {
        mAccessToken = accessToken;
    }

    public String getExpiresIn() {
        return mExpiresIn;
    }

    public void setExpiresIn(String expiresIn) {
        mExpiresIn = expiresIn;
    }

    public String getTokenType() {
        return mTokenType;
    }

    public void setTokenType(String tokenType) {
        mTokenType = tokenType;
    }

    public String getScope() {
        return mScope;
    }

    public void setScope(String scope) {
        mScope = scope;
    }

    public String getNextStep() {
        return mNextStep;
    }

    public void setNextStep(String nextStep) {
        mNextStep = nextStep;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        mId = id;
    }

    public UserBean getUser() {
        return mUser;
    }

    public void setUser(UserBean user) {
        mUser = user;
    }

    public static class UserBean {
        /**
         * unique_id : BRP5007
         * name : Shivaraj
         * mobile : 7676060664
         * email : s.raaj46@gmail.com
         * block_status : 0
         * created_at : 2019-12-09 13:10:30
         * ride_cancel_count : 0
         * dyut_account_balance : 0.00
         * encrypted_password : rnxFMZxnnPL3ZNXQ4MbnWN4KwoQ1OTMwZWJkMjc3
         */

        @SerializedName("unique_id")
        private String mUniqueId;
        @SerializedName("name")
        private String mName;
        @SerializedName("mobile")
        private String mMobile;
        @SerializedName("email")
        private String mEmail;
        @SerializedName("block_status")
        private String mBlockStatus;
        @SerializedName("created_at")
        private String mCreatedAt;
        @SerializedName("ride_cancel_count")
        private String mRideCancelCount;
        @SerializedName("dyut_account_balance")
        private String mDyutAccountBalance;
        @SerializedName("encrypted_password")
        private String mEncryptedPassword;

        public String getUniqueId() {
            return mUniqueId;
        }

        public void setUniqueId(String uniqueId) {
            mUniqueId = uniqueId;
        }

        public String getName() {
            return mName;
        }

        public void setName(String name) {
            mName = name;
        }

        public String getMobile() {
            return mMobile;
        }

        public void setMobile(String mobile) {
            mMobile = mobile;
        }

        public String getEmail() {
            return mEmail;
        }

        public void setEmail(String email) {
            mEmail = email;
        }

        public String getBlockStatus() {
            return mBlockStatus;
        }

        public void setBlockStatus(String blockStatus) {
            mBlockStatus = blockStatus;
        }

        public String getCreatedAt() {
            return mCreatedAt;
        }

        public void setCreatedAt(String createdAt) {
            mCreatedAt = createdAt;
        }

        public String getRideCancelCount() {
            return mRideCancelCount;
        }

        public void setRideCancelCount(String rideCancelCount) {
            mRideCancelCount = rideCancelCount;
        }

        public String getDyutAccountBalance() {
            return mDyutAccountBalance;
        }

        public void setDyutAccountBalance(String dyutAccountBalance) {
            mDyutAccountBalance = dyutAccountBalance;
        }

        public String getEncryptedPassword() {
            return mEncryptedPassword;
        }

        public void setEncryptedPassword(String encryptedPassword) {
            mEncryptedPassword = encryptedPassword;
        }
    }
}
