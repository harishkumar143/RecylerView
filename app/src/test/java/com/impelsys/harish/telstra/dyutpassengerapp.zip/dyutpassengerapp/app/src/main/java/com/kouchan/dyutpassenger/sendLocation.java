package com.kouchan.dyutpassenger;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Created by Siddhesh on 13-11-2017.
 */

public class sendLocation extends Service implements OnRequestListener {

    private LocationListener listener;
    private LocationManager manager;
    String locationUpdateURL = Url.COMUNICATE_API + "updateLatLong.php";
    double latitude, longitude;
    Geocoder geocoder;
    AsyncInteractor asyncInteractor;
     String address;

    String lat, longi;

    SessionManager sessionManager;
    HashMap<String, String> user = new HashMap<String, String>();
    String name, mobile;

    @Nullable

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {

        sessionManager = new SessionManager(getApplicationContext());
        user = sessionManager.getUserDetails();
        user = sessionManager.getUserDetails();
        name = user.get("name");
        mobile = user.get("mobile");
        asyncInteractor=new AsyncInteractor(getApplicationContext());

        listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                latitude = location.getLatitude();
                longitude = location.getLongitude();

                lat = Double.toString(latitude);
                longi = Double.toString(longitude);

                sendLocationUpdate();

            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {
                Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        };

        Location mLocation = new Location("");
        mLocation.setLatitude(latitude);
        mLocation.setLongitude(longitude);
        List<Address> yourAddresses;
        geocoder = new Geocoder(this, Locale.getDefault());
        try {
            yourAddresses = geocoder.getFromLocation(mLocation.getLatitude(), mLocation.getLongitude(), 1);
            address = yourAddresses.get(0).getAddressLine(0);
        } catch (IOException e) {
            e.printStackTrace();
        }

        manager = (LocationManager) getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
        //noinspection MissingPermission
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 0, listener);
    }

    private void sendLocationUpdate() {


        Map<String, String> params = new HashMap<String, String>();

        params.put("latitude", lat);
        params.put("longitude", longi);
        params.put("mobile", mobile);
        params.put("address", address);

        asyncInteractor.validateCredentialsAsync(this,AppConstants.updateLatLong,Url.COMUNICATE_API+ServerApiNames.updateLatLong,new JSONObject(params));


       /* StringRequest updateDriverLocation = new StringRequest(Request.Method.POST, locationUpdateURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                             } else {
                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("latitude", lat);
                params.put("longitude", longi);
                params.put("mobile", mobile);
                params.put("address", address);
                return params;
            }
        };
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(updateDriverLocation);*/
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(manager!=null){
            manager.removeUpdates(listener);
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        if(pid==AppConstants.updateLatLong){
            try {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                } else {
                    String errorMsg = jObj.getString("error_msg");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
