package com.kouchan.dyutpassenger.View.Fragments;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.getBalance.GetBalancePresenterImpl;
import com.kouchan.dyutpassenger.Interface.getBalance.IGetBalancePresnter;
import com.kouchan.dyutpassenger.Interface.getBalance.IGetBalanceView;
import com.kouchan.dyutpassenger.Interface.paytm.PaytmApiPresenter;
import com.kouchan.dyutpassenger.Interface.paytm.PaytmApiPresenterImpl;
import com.kouchan.dyutpassenger.Interface.paytm.PaytmApiView;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.PaymentStatusActivity;
import com.kouchan.dyutpassenger.VolleyJsonObjectRequest;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.ccAvenue.activity.CcAvenueWebViewActivity;
import com.kouchan.dyutpassenger.ccAvenue.utility.AvenuesParams;
import com.kouchan.dyutpassenger.ccAvenue.utility.CCAvenueConstants;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.GenerateHashModelForHDFC;
import com.kouchan.dyutpassenger.models.HDFCResponseModel;
import com.kouchan.dyutpassenger.models.PaytmChecksumModel;
import com.kouchan.dyutpassenger.paytm.AddMoneyToDyutAccActivity;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Utils;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;
import com.payu.india.Model.PaymentParams;
import com.payu.india.Model.PayuConfig;
import com.payu.india.Model.PayuHashes;
import com.payu.india.Payu.Payu;
import com.payu.india.Payu.PayuConstants;
import com.payu.payuui.Activity.PayUBaseActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddmoneyFragment extends Fragment implements PaytmApiView, PaytmPaymentTransactionCallback, IGetBalanceView, OnRequestListener {

    EditText amount;
    TextView currentBal, currentBalTextView;
    Button payButton;
    PaytmApiPresenter paytmApiPresenter;
    IGetBalancePresnter iGetBalancePresnter;
    long orderId;
    SessionManager sessionManager;
    View view;
    AsyncInteractor asyncInteractor;
    String url = Url.BASE_URL + "payu/genrateHash.php";
    String addMoneyurl = Url.BASE_URL + "payu/addmoneybyhdfc.php";
    PayuHashes payuHashes = new PayuHashes();
    private String languageCode;
    private Resources resources;
    private GenerateHashModelForHDFC generateHashModelForHDFC;
    private HDFCResponseModel hdfcResponseModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.add_money_fragment, container, false);

        sessionManager = new SessionManager(getActivity());
        asyncInteractor = new AsyncInteractor(getActivity());
        paytmApiPresenter = new PaytmApiPresenterImpl(this, getActivity());
        intailizeViews();

        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        return view;

    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(getActivity(), languageCode);
        resources = context.getResources();
        currentBalTextView.setText(resources.getString(R.string.your_current_balance));
        amount.setHint(resources.getString(R.string.enter_amount_to_load));
        payButton.setText(resources.getString(R.string.proceed));
    }

    private void intailizeViews() {

        currentBal = (TextView) view.findViewById(R.id.currentBal);
        currentBalTextView = (TextView) view.findViewById(R.id.currentBalTextView);
        amount = (EditText) view.findViewById(R.id.amount);
        payButton = (Button) view.findViewById(R.id.loadMoneyButton);
        Payu.setInstance(getActivity());
        iGetBalancePresnter = new GetBalancePresenterImpl(this, getActivity());

        HashMap<String, String> user = sessionManager.getUserDetails();
        iGetBalancePresnter.getBalance(user.get("mobile"));


        payButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (amount.getText().toString().isEmpty() && amount.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "PLease enter Amount", Toast.LENGTH_SHORT).show();
                } else {
                    showPaymentOptionDialog();
                }

            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    public void onTransactionResponse(Bundle inResponse) {
        Log.e("checksum ", " respon true " + inResponse.toString());
        Toast.makeText(getActivity(), inResponse.getString("RESPMSG"), Toast.LENGTH_SHORT).show();

        addMoneyToDyutApiCall(inResponse);
    }

    private void addMoneyToDyutApiCall(final Bundle inResponse) {

        if (NetworkStatus.checkNetworkStatus(getActivity())) {

            Utils.showProgress(getActivity());
            Map<String, String> params = new HashMap<String, String>();

            params.put("UNIQUE_ID", sessionManager.getUniqueId());
            params.put("STATUS", inResponse.getString("STATUS"));
            params.put("CHECKSUMHASH", inResponse.getString("CHECKSUMHASH"));
            params.put("BANKNAME", inResponse.getString("BANKNAME"));
            params.put("ORDERID", inResponse.getString("ORDERID"));
            params.put("TXNAMOUNT", inResponse.getString("TXNAMOUNT"));
            params.put("TXNDATE", inResponse.getString("TXNDATE"));
            params.put("MID", inResponse.getString("MID"));
            params.put("TXNID", inResponse.getString("TXNID"));
            params.put("RESPCODE", inResponse.getString("RESPCODE"));
            params.put("PAYMENTMODE", inResponse.getString("PAYMENTMODE"));
            params.put("BANKTXNID", inResponse.getString("BANKTXNID"));
            params.put("CURRENCY", inResponse.getString("CURRENCY"));
            params.put("GATEWAYNAME", inResponse.getString("GATEWAYNAME"));
            params.put("RESPMSG", inResponse.getString("RESPMSG"));

            asyncInteractor.validateCredentialsAsync(this, AppConstants.addmoneytodyut, "https://bookarideworldwide.com/CAB2.V.1/paytmlib/addmoneytodyut.php", new JSONObject(params));

        } else {
            Utils.showToast(getActivity(), "Please connect to internet");
        }
    }

    @Override
    public void networkNotAvailable() {

    }

    @Override
    public void clientAuthenticationFailed(String inErrorMessage) {

    }

    @Override
    public void someUIErrorOccurred(String inErrorMessage) {
        Log.e("checksum ", " ui fail respon  " + inErrorMessage);
    }

    @Override
    public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {
        Log.e("checksum ", " error loading pagerespon true " + inErrorMessage + "  s1 " + inFailingUrl);
    }

    @Override
    public void onBackPressedCancelTransaction() {

    }

    @Override
    public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {

    }


    @Override
    public void checksumGenerationSucess(PaytmChecksumModel checksumModel) {

        Utils.stopProgress(getActivity());
        PaytmPGService Service = PaytmPGService.getProductionService();
        // when app is ready to publish use production service
        // PaytmPGService  Service = PaytmPGService.getProductionService();
        // now call paytm service here
        //below parameter map is required to construct PaytmOrder object, Merchant should replace below map values with his own values
        HashMap<String, String> paramMap = new HashMap<String, String>();
        //these are mandatory parameters
        paramMap.put("MID", checksumModel.getMERCHANTID()); //MID provided by paytm
        paramMap.put("ORDER_ID", checksumModel.getORDERID());
        paramMap.put("CUST_ID", sessionManager.getUniqueId());
        paramMap.put("CHANNEL_ID", checksumModel.getCHANNELID());
        paramMap.put("TXN_AMOUNT", amount.getText().toString());
        paramMap.put("WEBSITE", checksumModel.getWEBSITE());
        paramMap.put("CALLBACK_URL", checksumModel.getCALLBACKURL());
        //paramMap.put( "EMAIL" , "abc@gmail.com");   // no need
        //paramMap.put( "MOBILE_NO" , "7676060664");  // no need
        paramMap.put("CHECKSUMHASH", checksumModel.getCHECKSUMHASH());
        //  paramMap.put("PAYMENT_TYPE_ID" ,"CC");    // no need
        paramMap.put("INDUSTRY_TYPE_ID", checksumModel.getINDUSTRYTYPEID());

        PaytmOrder Order = new PaytmOrder(paramMap);
        Log.e("checksum ", "param " + paramMap.toString());

        Service.initialize(Order, null);
        // start payment service call here

        Service.startPaymentTransaction(getActivity(), true, true,
                this);
    }

    @Override
    public void checksumGenerationError(String error) {
        Utils.stopProgress(getActivity());
        Utils.showToast(getActivity(), error);
    }

    @Override
    public void getBalanceSuccess(int pid, String balance) {
        currentBal.setText("₹ " + balance);
    }

    @Override
    public void getBalanceError(int pid, String error) {
        Utils.showToast(getActivity(), error);
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if (pid == AppConstants.addmoneytodyut) {
            try {

                Utils.stopProgress(getActivity());
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    try{
                        if(iGetBalancePresnter !=null){

                            HashMap<String, String> user = sessionManager.getUserDetails();
                            iGetBalancePresnter.getBalance(user.get("mobile"));
                        }else{
                            Log.e("AddMoneyFragment","AddMoneyFragmentiGetBalancePresnter is null ");
                        }

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                } else {
                    String errorMsg = jObj.getString("error_msg");
                    Toast.makeText(getActivity(), errorMsg, Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else if (pid == AppConstants.HDFC_PAYMENT_HASH) {
            Gson gson = new Gson();

            generateHashModelForHDFC = gson.fromJson(responseJson, GenerateHashModelForHDFC.class);
            Log.d("HDFC_PAYMENT_HASH", generateHashModelForHDFC.toString());

            PaymentParams mPaymentParams = new PaymentParams();
            /**
             * For Test Environment, merchantKey = please contact mobile.integration@payu.in with your app name and registered email id

             */
            mPaymentParams.setKey(generateHashModelForHDFC.getMERCHANTKEY());
            mPaymentParams.setAmount(amount.getText().toString());
            mPaymentParams.setProductInfo("DYUT");
            mPaymentParams.setFirstName(sessionManager.getUserDetails().get("name"));
            mPaymentParams.setEmail(sessionManager.getKeyEmail());
            mPaymentParams.setPhone(sessionManager.getUserDetails().get("mobile"));


            /*
             * Transaction Id should be kept unique for each transaction.
             * */
            mPaymentParams.setTxnId(generateHashModelForHDFC.getTxnid());

            /**
             * Surl --> Success url is where the transaction response is posted by PayU on successful transaction
             * Furl --> Failre url is where the transaction response is posted by PayU on failed transaction
             */
            mPaymentParams.setSurl("https://payuresponse.firebaseapp.com/success");
            mPaymentParams.setFurl("https://payuresponse.firebaseapp.com/failure");
            mPaymentParams.setNotifyURL(mPaymentParams.getSurl());  //for lazy pay

            /*
             * udf1 to udf5 are options params where you can pass additional information related to transaction.
             * If you don't want to use it, then send them as empty string like, udf1=""
             * */
            mPaymentParams.setUdf1("udf1");
            mPaymentParams.setUdf2("udf2");
            mPaymentParams.setUdf3("udf3");
            mPaymentParams.setUdf4("udf4");
            mPaymentParams.setUdf5("udf5");

            /**
             * These are used for store card feature. If you are not using it then user_credentials = "default"
             * user_credentials takes of the form like user_credentials = "merchant_key : user_id"
             * here merchant_key = your merchant key,
             * user_id = unique id related to user like, email, phone number, etc.
             * */
            mPaymentParams.setUserCredentials(generateHashModelForHDFC.getUserCredentials());
            payuHashes.setPaymentRelatedDetailsForMobileSdkHash(generateHashModelForHDFC.getPaymentRelatedDetailsForMobileSdkHash());
            payuHashes.setVasForMobileSdkHash(generateHashModelForHDFC.getVasForMobileSdkHash());
            payuHashes.setMerchantIbiboCodesHash(generateHashModelForHDFC.getGetMerchantIbiboCodesHash());
            payuHashes.setPaymentHash(generateHashModelForHDFC.getPaymentHash());

            mPaymentParams.setHash(payuHashes.getPaymentHash());

            PayuConfig payuConfig = new PayuConfig();
            payuConfig.setEnvironment(PayuConstants.STAGING_ENV);

            // generateHashFromSDK(generateHashModelForHDFC);
            Intent intent = new Intent(getActivity(), PayUBaseActivity.class);
            intent.putExtra(PayuConstants.PAYU_CONFIG, payuConfig);
            intent.putExtra(PayuConstants.PAYMENT_PARAMS, mPaymentParams);
            intent.putExtra(PayuConstants.PAYU_HASHES, payuHashes);
            intent.putExtra(PayuConstants.SALT, generateHashModelForHDFC.getSALT());
            startActivityForResult(intent, PayuConstants.PAYU_REQUEST_CODE);
        } else if (pid == AppConstants.Add_To_Dyut_Wallet_From_HDFC) {
            try {

                Utils.stopProgress(getActivity());
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    Intent intent = new Intent(getActivity(), PaymentStatusActivity.class);
                    intent.putExtra("comingFrom", "HDFC");
                    intent.putExtra("txnId", hdfcResponseModel.getTxnid());
                    intent.putExtra("amount", hdfcResponseModel.getAmount());
                    intent.putExtra("mode", hdfcResponseModel.getMode());
                    startActivity(intent);

                } else {
                    String errorMsg = jObj.getString("error_msg");
                    Toast.makeText(getActivity(), errorMsg, Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(getActivity(), error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }

    private void showPaymentOptionDialog() {
        final Dialog dialog = new Dialog(getActivity());
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.show_payement_options);

        TextView hdfc = (TextView) dialog.findViewById(R.id.hdfc);
        TextView paytm = (TextView) dialog.findViewById(R.id.paytm);
        TextView ccEvenue = (TextView) dialog.findViewById(R.id.ccEvenue);

        hdfc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hdfcApiCall();
                dialog.dismiss();
            }
        });


        paytm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Utils.showProgress(getActivity());
                orderId = Utils.uniqIdWithTimeStamp();
                paytmApiPresenter.paytmGenerateChecksum("" + orderId, sessionManager.getUniqueId(), amount.getText().toString());
                dialog.dismiss();

            }
        });

        ccEvenue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), CcAvenueWebViewActivity.class);
                intent.putExtra(AvenuesParams.ACCESS_CODE, CCAvenueConstants.ACCESS_CODE);
                intent.putExtra(AvenuesParams.MERCHANT_ID, CCAvenueConstants.MERCHANT_ID);
                intent.putExtra(AvenuesParams.ORDER_ID, "" + System.currentTimeMillis());
                intent.putExtra(AvenuesParams.CURRENCY, "INR");
                intent.putExtra(AvenuesParams.AMOUNT, amount.getText().toString());

                intent.putExtra(AvenuesParams.REDIRECT_URL, CCAvenueConstants.REDIRECT_URL);
                intent.putExtra(AvenuesParams.CANCEL_URL, CCAvenueConstants.CANCEL_URL);
                intent.putExtra(AvenuesParams.RSA_KEY_URL, CCAvenueConstants.GET_RSA_URL);

                startActivity(intent);
                dialog.dismiss();
            }
        });

        dialog.show();

    }

    private void hdfcApiCall() {

        Map<String, String> params = new HashMap<>();

        HashMap<String, String> user;
        user = sessionManager.getUserDetails();

        params.put("amount", amount.getText().toString());
        params.put("firstname", user.get("name"));
        params.put("unique_id", sessionManager.getUniqueId());
        params.put("email", sessionManager.getKeyEmail());
        params.put("productinfo", "DYUT");
        params.put("phone", user.get("mobile"));
        params.put("udf1", "udf1");
        params.put("udf2", "udf2");
        params.put("udf3", "udf3");
        params.put("udf4", "udf4");
        params.put("udf5", "udf5");
        params.put("offerKey", "");
        params.put("cardBin", "");

        asyncInteractor.onPostMethodServerCall(this, AppConstants.HDFC_PAYMENT_HASH, url, new JSONObject(params));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PayuConstants.PAYU_REQUEST_CODE) {
            if (data != null) {

                Log.d("Payu's Data : ", data.getStringExtra("payu_response"));

                /**
                 * Here, data.getStringExtra("payu_response") ---> Implicit response sent by PayU
                 * data.getStringExtra("result") ---> Response received from merchant's Surl/Furl
                 *
                 * PayU sends the same response to merchant server and in app. In response check the value of key "status"
                 * for identifying status of transaction. There are two possible status like, success or failure
                 * */

                Gson gson = new Gson();
                hdfcResponseModel = gson.fromJson(data.getStringExtra("payu_response"), HDFCResponseModel.class);

                if (hdfcResponseModel.getStatus().equalsIgnoreCase("success")) {

                    HashMap<String, String> params = new HashMap<>();

                    HashMap<String, String> user;
                    user = sessionManager.getUserDetails();

                    params.put("firstname", user.get("name"));
                    params.put("email", sessionManager.getKeyEmail());
                    params.put("user_id", sessionManager.getUniqueId());
                    params.put("id", "" + hdfcResponseModel.getId());
                    params.put("status", hdfcResponseModel.getStatus());
                    params.put("txnid", hdfcResponseModel.getTxnid());
                    params.put("transaction_fee", hdfcResponseModel.getTransactionFee());
                    params.put("amount", hdfcResponseModel.getAmount());
                    params.put("addedon", hdfcResponseModel.getAddedon());
                    params.put("productinfo", hdfcResponseModel.getProductinfo());
                    params.put("hash", generateHashModelForHDFC.getPaymentHash());
                    params.put("payment_source", hdfcResponseModel.getPaymentSource());
                    params.put("PG_TYPE", hdfcResponseModel.getPGTYPE());
                    params.put("bank_ref_no", hdfcResponseModel.getBankRefNo());
                    params.put("error_code", hdfcResponseModel.getErrorCode());

                    asyncInteractor.onPostMethodServerCall(this, AppConstants.Add_To_Dyut_Wallet_From_HDFC, addMoneyurl, new JSONObject(params));

                }

            } else {
                Toast.makeText(getActivity(), getString(R.string.could_not_receive_data), Toast.LENGTH_LONG).show();
            }
        }
    }
}
