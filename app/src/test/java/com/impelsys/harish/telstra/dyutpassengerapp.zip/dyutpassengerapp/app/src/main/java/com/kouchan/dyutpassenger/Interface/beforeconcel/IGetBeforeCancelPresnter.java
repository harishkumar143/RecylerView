package com.kouchan.dyutpassenger.Interface.beforeconcel;

public interface IGetBeforeCancelPresnter {

    void getBeforeCancel();

}

