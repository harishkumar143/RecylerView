package com.kouchan.dyutpassenger.models;

import com.google.gson.annotations.SerializedName;

public class PaytmChecksumModel {


    /**
     * error : false
     * payt_STATUS : 1
     * CHECKSUMHASH : Dt8QMjQppga79XXSsaXXrNM+puPOtQtLXyCZweEHZJjPvUKwww2lre+Btd22+VqRBFoKfQ0MOvBha/1yP9009Tq/VmD5gCBc5894xMhmG1I=
     * ORDER_ID : ORDER0000000001
     * MERCHANT_ID : KOUCHA25265991839069
     * CHANNEL_ID : WAP
     * WEBSITE : APPSTAGING
     * CALLBACK_URL : https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=ORDER0000000001
     * INDUSTRY_TYPE_ID : Retail
     */

    @SerializedName("error")
    private boolean error;
    @SerializedName("payt_STATUS")
    private String paytSTATUS;
    @SerializedName("CHECKSUMHASH")
    private String CHECKSUMHASH;
    @SerializedName("ORDER_ID")
    private String ORDERID;
    @SerializedName("MERCHANT_ID")
    private String MERCHANTID;
    @SerializedName("CHANNEL_ID")
    private String CHANNELID;
    @SerializedName("WEBSITE")
    private String WEBSITE;
    @SerializedName("CALLBACK_URL")
    private String CALLBACKURL;
    @SerializedName("INDUSTRY_TYPE_ID")
    private String INDUSTRYTYPEID;

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public String getPaytSTATUS() {
        return paytSTATUS;
    }

    public void setPaytSTATUS(String paytSTATUS) {
        this.paytSTATUS = paytSTATUS;
    }

    public String getCHECKSUMHASH() {
        return CHECKSUMHASH;
    }

    public void setCHECKSUMHASH(String CHECKSUMHASH) {
        this.CHECKSUMHASH = CHECKSUMHASH;
    }

    public String getORDERID() {
        return ORDERID;
    }

    public void setORDERID(String ORDERID) {
        this.ORDERID = ORDERID;
    }

    public String getMERCHANTID() {
        return MERCHANTID;
    }

    public void setMERCHANTID(String MERCHANTID) {
        this.MERCHANTID = MERCHANTID;
    }

    public String getCHANNELID() {
        return CHANNELID;
    }

    public void setCHANNELID(String CHANNELID) {
        this.CHANNELID = CHANNELID;
    }

    public String getWEBSITE() {
        return WEBSITE;
    }

    public void setWEBSITE(String WEBSITE) {
        this.WEBSITE = WEBSITE;
    }

    public String getCALLBACKURL() {
        return CALLBACKURL;
    }

    public void setCALLBACKURL(String CALLBACKURL) {
        this.CALLBACKURL = CALLBACKURL;
    }

    public String getINDUSTRYTYPEID() {
        return INDUSTRYTYPEID;
    }

    public void setINDUSTRYTYPEID(String INDUSTRYTYPEID) {
        this.INDUSTRYTYPEID = INDUSTRYTYPEID;
    }
}
