package com.kouchan.dyutpassenger.other;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;

import androidx.annotation.Nullable;

import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by KOUCHAN-ADMIN on 1/20/2018.
 */

public class CustomDialogClass extends Dialog implements
        android.view.View.OnClickListener, OnRequestListener {

    public String latlongtype;
    public Activity c;
    public Dialog d;
    public TextView yes, no;
    public EditText customeFavoritEditText;
    public TextView addressFavorit;
    public RadioGroup book_a_ride_fevorit_radiogroup;
    public String type = "";
    public String mobile;
    public String tolatitude;
    public String tolongitude;
    String address;
    RadioButton homeFevorit;
    AsyncInteractor asyncInteractor;
    private String favoritStoreApi = Url.PASSENGER_API + "favorites.php";
    private String languageCode;
    private Resources resources;

    public CustomDialogClass(Activity a, String address, String tolatitude, String tolongitude, String mobile, String latlongtype) {
        super(a);

        this.c = a;
        this.address = address;
        this.mobile = mobile;
        this.tolatitude = tolatitude;
        this.tolongitude = tolongitude;
        this.latlongtype = latlongtype;
        this.asyncInteractor = new AsyncInteractor(a);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favourite_dialog_box);

        yes = (TextView) findViewById(R.id.btn_yes);
        no = (TextView) findViewById(R.id.btn_no);
        book_a_ride_fevorit_radiogroup = (RadioGroup) findViewById(R.id.book_a_ride_fevorit_radiogroup);
        customeFavoritEditText = (EditText) findViewById(R.id.customeFavoritEditText);
        addressFavorit = (TextView) findViewById(R.id.addressFavorit);

        addressFavorit.setText(address);

        yes.setOnClickListener(this);
        no.setOnClickListener(this);

        homeFevorit = (RadioButton) findViewById(R.id.homeFevorit);
        homeFevorit.setChecked(true);


        if (Utils.appCode != null) {
            languageCode = Utils.appCode.toString();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(c, languageCode);
        resources = context.getResources();

        customeFavoritEditText.setHint(resources.getString(R.string.name_your_favourite_ex_gym));
        yes.setText(resources.getString(R.string.ok));
        no.setText(resources.getString(R.string.cancel));
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_yes:
                sendFavoritsToServer();
                break;
            case R.id.btn_no:
                dismiss();
                break;


            default:
                break;
        }
        /*dismiss();*/
    }

    private void sendFavoritsToServer() {

        if (addressFavorit.getText().toString().isEmpty()) {
            Toast.makeText(c, "Selct address to save", Toast.LENGTH_SHORT).show();
        } else if (customeFavoritEditText.getText().toString().isEmpty()) {
            Toast.makeText(c, "Name your favourite", Toast.LENGTH_SHORT).show();
        } else {
            Utils.showProgress(c);

            Map<String, String> params = new HashMap<String, String>();

            params.put("mobile", mobile);
            params.put("address", address);
            params.put("addresstype", customeFavoritEditText.getText().toString());
            params.put("tolatitude", tolatitude);
            params.put("tolongitude", tolongitude);
            params.put("latlongtype", latlongtype);

            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_ADD_Favourite, Url.PASSENGER_API + ServerApiNames.Add_Favourite, new JSONObject(params));

            /*StringRequest stringRequest = new StringRequest(Request.Method.POST, favoritStoreApi,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {

                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {

                                    dismiss();
                                    Utils.stopProgress(c);

                                    Toast.makeText(c, "Favourite added successfully", Toast.LENGTH_SHORT).show();
                                } else {
                                    String errorMsg = jObj.getString("error_msg");
                                    Toast.makeText(c, errorMsg, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Utils.stopProgress(c);
                            Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();

                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {

                    Map<String, String> params = new HashMap<String, String>();

                    params.put("mobile", mobile);
                    params.put("address", address);
                    params.put("addresstype", customeFavoritEditText.getText().toString());
                    params.put("tolatitude", tolatitude);
                    params.put("tolongitude", tolongitude);
                    params.put("latlongtype", latlongtype);

                    return params;

                }
            };

            VolleySingleton.getInstance(c).addToRequestQueue(stringRequest);*/
        }
    }


    @Override
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> data, @Nullable Menu menu, int deviceId) {

    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if (pid == AppConstants.TAG_ID_ADD_Favourite)
            dismiss();
        Utils.stopProgress(c);
        Toast.makeText(c, "Favourite added successfully", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        dismiss();
        Utils.stopProgress(c);
        Toast.makeText(c, error, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}