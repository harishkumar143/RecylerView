package com.kouchan.dyutpassenger.models;

import com.google.gson.annotations.SerializedName;

public class PassengerModel {


    /**
     * name : Ghyanmitra Jiblapnor
     * email : nsbilgi@kouchanindia.com
     * mobile : 9870738322
     * emergency_contact_name : raju
     * emergency_contact_mobile : 9022288980
     */

    @SerializedName("name")
    private String mName;
    @SerializedName("email")
    private String mEmail;
    @SerializedName("mobile")
    private String mMobile;
    @SerializedName("emergency_contact_name")
    private String mEmergencyContactName;
    @SerializedName("emergency_contact_mobile")
    private String mEmergencyContactMobile;

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public String getMobile() {
        return mMobile;
    }

    public void setMobile(String mobile) {
        mMobile = mobile;
    }

    public String getEmergencyContactName() {
        return mEmergencyContactName;
    }

    public void setEmergencyContactName(String emergencyContactName) {
        mEmergencyContactName = emergencyContactName;
    }

    public String getEmergencyContactMobile() {
        return mEmergencyContactMobile;
    }

    public void setEmergencyContactMobile(String emergencyContactMobile) {
        mEmergencyContactMobile = emergencyContactMobile;
    }
}
