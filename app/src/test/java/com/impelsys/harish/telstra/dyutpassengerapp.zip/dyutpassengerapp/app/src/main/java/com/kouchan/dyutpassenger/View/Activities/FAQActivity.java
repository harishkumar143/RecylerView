package com.kouchan.dyutpassenger.View.Activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.kouchan.dyutpassenger.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class FAQActivity extends AppCompatActivity {

    ArrayList<String> listdata,listdataans;
    ListView listfaq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq);
        listfaq = (ListView) findViewById(R.id.listfaq);
        String response = getIntent().getStringExtra("FAQ");
        try {
            JSONObject jObj = new JSONObject(response);
            listdata = new ArrayList<String>();
            JSONArray jArray = jObj.getJSONArray("comments");
            JSONArray jArrayans = jObj.getJSONArray("discription");
            if (jArray != null) {
                for (int i = 0; i < jArray.length(); i++) {
                    listdata.add(jArray.getString(i));
                    listdata.add(jArrayans.getString(i));
                }
            }
        } catch (JSONException e) {

        }
        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                R.layout.listitem, listdata);
        listfaq.setAdapter(adapter);

    }
}
