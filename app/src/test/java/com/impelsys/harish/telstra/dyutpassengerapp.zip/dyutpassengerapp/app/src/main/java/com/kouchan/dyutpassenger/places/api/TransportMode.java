package com.kouchan.dyutpassenger.places.api;


public class TransportMode {
    public static final String DRIVING = "driving";
    public static final String WALKING = "walking";
    public static final String BICYCLING = "bicycling";
    public static final String TRANSIT = "transit";
}
