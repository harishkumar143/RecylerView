package com.kouchan.dyutpassenger.Interface.m3withbookarideregistration;

public interface IRegisterView {

    void onRegisterSuccess(int pid, String registerModel);
    void onRegisterError(int pid, String regModel);
    void onRegisterServerError(int pid, String error);
}
