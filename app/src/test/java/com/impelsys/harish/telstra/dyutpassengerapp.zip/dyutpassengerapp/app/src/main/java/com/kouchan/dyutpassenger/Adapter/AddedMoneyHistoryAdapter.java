package com.kouchan.dyutpassenger.Adapter;

import android.content.Context;
import android.graphics.Color;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.holders.AddedMoneyHistoryHolder;
import com.kouchan.dyutpassenger.models.AddedMoneyHistoryModel;

import java.util.ArrayList;
import java.util.List;

public class AddedMoneyHistoryAdapter extends RecyclerView.Adapter<AddedMoneyHistoryHolder> {

    Context context;
    List<AddedMoneyHistoryModel.TXNRECORDSBean> list=new ArrayList<>();
    LayoutInflater layoutInflater;

    public AddedMoneyHistoryAdapter(Context context, List<AddedMoneyHistoryModel.TXNRECORDSBean> list) {
        this.context = context;
        this.list = list;
        layoutInflater=LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public AddedMoneyHistoryHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView =layoutInflater.inflate(R.layout.added_money_history_item, viewGroup, false);
        AddedMoneyHistoryHolder holder=new AddedMoneyHistoryHolder(itemView);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull AddedMoneyHistoryHolder holder, int i) {
        holder.amount.setText("₹ "+list.get(i).getTxnAmount());
        holder.dateTime.setText("Date: "+list.get(i).getCreatedAt());
        holder.txnId.setText("Txn Id: "+list.get(i).getTransactionId());

        String trnsType=list.get(i).getTxnType();

        if(trnsType.equalsIgnoreCase("DEBITED")){
            holder.trnsType.setText("Amount Debited");
            holder.amount.setTextColor(Color.RED);
        }
        else if(trnsType.equalsIgnoreCase("credited")){
            holder.trnsType.setText("Amount Credited");
            holder.amount.setTextColor(ContextCompat.getColor(context, R.color.bookARidecolorPrimaryDark));
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
