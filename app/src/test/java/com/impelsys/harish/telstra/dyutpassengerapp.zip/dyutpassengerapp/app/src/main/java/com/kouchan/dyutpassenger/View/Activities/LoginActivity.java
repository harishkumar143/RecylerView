package com.kouchan.dyutpassenger.View.Activities;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.dynamiclinks.DynamicLink;
import com.google.firebase.dynamiclinks.FirebaseDynamicLinks;
import com.google.firebase.dynamiclinks.ShortDynamicLink;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.gson.Gson;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.PrefManager;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.functions.Functions;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.login.LoginModelClass;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;
import static com.paytm.pgsdk.easypay.manager.PaytmAssist.getContext;


public class LoginActivity extends AppCompatActivity implements OnRequestListener {

    private static final String requestForOTP = Url.PASSENGER_API + "forgotPassword.php";
    public static String id, email, vehicleType;

    static final String TAG = "login";
    TextView activity_passenger_login;
    TextView forgotPassword, newToDyut;
    TextView registration_text_passenger, registration_text_passenger1;
    ProgressDialog loading;
    EditText mobile;
    EditText password;
    SessionManager sessionManager;
    Sharedpreferences sharedpreferences;
    PrefManager prefManager;
    String stringPassword, stringMobile;
    Button login;
    Toolbar mToolbar;
    String languageCode;
    Resources resources;
    String mobile_no_session;
    HashMap<String, String> user = new HashMap<String, String>();
    AlertDialog alertDialog1;
    CharSequence[] values = {"Current Mobile Number", "Alternate Mobile Number"};
    String selectedOption;
    AsyncInteractor asyncInteractor;
    LoginModelClass loginModelClass;
    //private String loginUrl = ApiClient.PASSENGER_STAG_URL+ServerApiNames.LOGIN;
    private String LOGIN_URL = Url.PASSENGER_API + ServerApiNames.LOGIN;
    private SharedPreferences preferences;
    private TelephonyManager telephonyManager;
    private String imeiNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sessionManager = new SessionManager(getApplicationContext());
        sharedpreferences = Sharedpreferences.getUserDataObj(this);
        prefManager = new PrefManager(getApplicationContext());
        asyncInteractor = new AsyncInteractor(this);

          Log.e("Login","is login="+sessionManager.isLoggedIn()+", sms="+prefManager.isWaitingForSms());
        if (sessionManager.isLoggedIn() && !prefManager.isWaitingForSms()) {
            startActivity(new Intent(getApplicationContext(), NavHome.class));
            finish();
        } else {

            selectedOption = "passenger";
            sessionManager.createType(selectedOption);

            mobile = (EditText) findViewById(R.id.login_mobile);
// Request focus and show soft keyboard automatically
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            user = sessionManager.getUserDetails();
            mobile_no_session = user.get(SessionManager.KEY_MOBILE);
            password = (EditText) findViewById(R.id.login_password);
            login = (Button) findViewById(R.id.login_button);
            forgotPassword = (TextView) findViewById(R.id.forgotPasswordPassenger);
            newToDyut = (TextView) findViewById(R.id.newToDyut);
            registration_text_passenger = (TextView) findViewById(R.id.registration_text_passenger);
            registration_text_passenger1 = (TextView) findViewById(R.id.registration_text_passenger1);
            activity_passenger_login = (TextView) findViewById(R.id.activity_passenger_login);

            if (Utils.appCode != null) {
                languageCode = Utils.appCode.toString();
                updateViews(languageCode);
            }

            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isValid(mobile, password)) {

                        stringMobile = mobile.getText().toString();
                        stringPassword = password.getText().toString();

                        sendValues();
                    }
                }
            });


            forgotPassword.setOnClickListener(new View.OnClickListener() {
                                                  @Override
                                                  public void onClick(View v) {

                                                      stringMobile = mobile.getText().toString();
                                                      if (!(Functions.isMobileValid(mobile.getText().toString()))) {

                                                          Toast.makeText(LoginActivity.this, "Please enter valid mobile number", Toast.LENGTH_SHORT).show();
                                                      } else {
                                                          CreateAlertDialogWithRadioButtonGroup();
                                                      }
                                                  }
                                              }
            );


            registration_text_passenger.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(LoginActivity.this, Registration.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                    finish();
                }
            });

            registration_text_passenger1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(LoginActivity.this, Registration.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                    finish();
                }
            });

            sessionManager = new SessionManager(this);
            if (sessionManager.getLanguageCode() != null) {
                languageCode = sessionManager.getLanguageCode();
                updateViews(languageCode);
            }

        }

        permission();
        getDeviceId();

        /*newToDyut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DynamicLink dynamicLink = FirebaseDynamicLinks.getInstance().createDynamicLink()
                        .setLink(Uri.parse("https://www.bookarideworldwide.com/"))
                        .setDomainUriPrefix("https://dyutpassenger.page.link")
                        // Open links with this app on Android
                        .setAndroidParameters(new DynamicLink.AndroidParameters.Builder().build())
                        // Open links with com.example.ios on iOS
                        .setIosParameters(new DynamicLink.IosParameters.Builder("com.example.ios").build())
                        .buildDynamicLink();

                Uri dynamicLinkUri = dynamicLink.getUri();

                Log.d("main","link:"+dynamicLink.getUri());

              //  createReferlink("kouchan123", "prod456");
            }
        });*/
    }


    private void getDeviceId() {
        telephonyManager = (TelephonyManager) getSystemService(this.TELEPHONY_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 101);
            return;
        }
    }

    private boolean isValid(EditText mobile, EditText password) {

        if (mobile.getText().toString().trim().length() == 0) {
            Utils.showToast(this, "Please enter mobile number");
           // mobile.setError("Please enter mobile number");
            mobile.requestFocus();
            return false;
        }

        if (mobile.getText().toString().trim().length() < 10) {
            Utils.showToast(this, "Mobile number should be 10 digits");
           // mobile.setError("Mobile number should be 10 digits");
            mobile.requestFocus();
            return false;
        }

        if (password.getText().toString().trim().length() == 0) {
            Utils.showToast(this, "Please enter password");
           // password.setError("Password is empty");
            password.requestFocus();
            return false;
        }

        if (password.getText().toString().trim().length() < 6) {
            Utils.showToast(this, "Password to be more than 6 characters");
           // password.setError("Password to be more than 6 characters");
            password.requestFocus();
            return false;
        }

        if (password.getText().toString().trim().length() > 8) {
            Utils.showToast(this, "Password to be less than 8 characters");
          //  password.setError("Password to be less than 8 characters");
            password.requestFocus();
            return false;
        }

        return true;
    }


    /*----------------------------------------------------------------------*/

    public void CreateAlertDialogWithRadioButtonGroup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
        builder.setTitle("Did you forget your password?")
                .setPositiveButton(resources.getString(R.string.yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        sendPasswordForOTP();
                    }
                })
                .setNegativeButton(resources.getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing
                        alertDialog1.dismiss();
                    }
                }).setIcon(android.R.drawable.ic_dialog_alert)
                .show();

        alertDialog1 = builder.create();
        alertDialog1.show();
    }

    /*-----------------------------------------------------------------------*/

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        activity_passenger_login.setText(resources.getString(R.string.login));
        mobile.setHint(resources.getString(R.string.mobile_no));
        password.setHint(resources.getString(R.string.loginPassword));
        login.setText(resources.getString(R.string.login));
        forgotPassword.setText(resources.getString(R.string.forgot_password));
        newToDyut.setText(resources.getString(R.string.new_to_dyut_rides));
    }


    private void sendPasswordForOTP() {

        if (Utils.isInternetAvailable(LoginActivity.this)) {

            Utils.showProgress(LoginActivity.this);

            Map<String, String> params = new HashMap<String, String>();

            params.put("mobile", stringMobile);
            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_FORGOT_PASSWORD, Url.PASSENGER_API + ServerApiNames.FORGOT_PASSWORD, new JSONObject(params),"");

        } else {

            Utils.showToast(LoginActivity.this, "please connect to the internate");

        }
    }


    private void sendValues() {

            if (Utils.isInternetAvailable(LoginActivity.this)) {

            Utils.showProgress(LoginActivity.this);

            HashMap<String, String> params = new HashMap<>();
            params.put("mobile", stringMobile);
            params.put("password", stringPassword);

            if(sharedpreferences.getFcmToken()==null || sharedpreferences.getFcmToken().isEmpty()){
              String token = getFcmTokenAgain();
                params.put("token", token);
            }else{
                params.put("token", sharedpreferences.getFcmToken());
            }

            params.put("login_number","NA");
                if(sharedpreferences.getTagDeviceId()==null || sharedpreferences.getTagDeviceId().isEmpty()){
                    String android_id = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
                    params.put("device_id",android_id);
                }
                else{
                    params.put("device_id",sharedpreferences.getTagDeviceId());
                }
            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_LOGIN, LOGIN_URL, new JSONObject(params),"");

        } else {
            Utils.showToast(LoginActivity.this, "Please connect to the internet");
        }
    }

    private String getFcmTokenAgain() {

        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w(TAG, "getInstanceId failed", task.getException());
                            return;
                        }

                        // Get new Instance ID token

                        if (task.getResult()!= null) {
                            String token = task.getResult().getToken();
                            sharedpreferences = Sharedpreferences.getUserDataObj(getApplicationContext());
                            sharedpreferences.setFcmToken(token);
                        }
                    }
                });

        return sharedpreferences.getFcmToken();
    }

    private void sendValuesWithExtraKey() {

        if (Utils.isInternetAvailable(LoginActivity.this)) {

            Utils.showProgress(LoginActivity.this);

            HashMap<String, String> params = new HashMap<>();
            params.put("mobile", stringMobile);
            params.put("password", stringPassword);
            if(sharedpreferences.getFcmToken()==null || sharedpreferences.getFcmToken().isEmpty()){
                String token = getFcmTokenAgain();
                params.put("token", token);
            }else{
                params.put("token", sharedpreferences.getFcmToken());
            }
            params.put("login_number","YES");

            if(sharedpreferences.getTagDeviceId()==null || sharedpreferences.getTagDeviceId().isEmpty()){

                String android_id = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
                params.put("device_id",android_id);
            }
            else{
                params.put("device_id",sharedpreferences.getTagDeviceId());
            }

            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_LOGIN, LOGIN_URL, new JSONObject(params),"");
        } else {
            Utils.showToast(LoginActivity.this, "Please connect to the internet");
        }
    }


    private void permission() {

        Dexter.withActivity(this)
                .withPermissions(
                        android.Manifest.permission.CAMERA,
                        android.Manifest.permission.READ_CONTACTS,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION,
                        android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.GET_ACCOUNTS
                ).withListener(new MultiplePermissionsListener() {
            @Override
            public void onPermissionsChecked(MultiplePermissionsReport report) {
            }

            @Override
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {/* ... */}
        }).check();

    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        if (pid == AppConstants.TAG_ID_LOGIN) {
            if (responseJson != null) {

                Utils.stopProgress(LoginActivity.this);
                Gson gson = new Gson();
                loginModelClass = gson.fromJson("" + responseJson, LoginModelClass.class);

                if (!loginModelClass.isError()) {
                    sessionManager.setIsLogin(true);
                    sessionManager.createLoginSession(loginModelClass.getUser().getName(), loginModelClass.getUser().getMobile());
                    sessionManager.createId("" + loginModelClass.getId());
                    sessionManager.createEmail(email);
                    sessionManager.setUniqueId(loginModelClass.getUser().getUniqueId());
                    sharedpreferences.setOauthToken(loginModelClass.getAccessToken());
                   // sharedpreferences.setRefreshTokenToken(loginModelClass.getRefreshToken());
                    sharedpreferences.setOauthTokenExpiryTime(loginModelClass.getExpiresIn());
                    sharedpreferences.setEncriptedPassword(loginModelClass.getUser().getEncryptedPassword());
                    sharedpreferences.setUserName(loginModelClass.getUser().getName());
                    sharedpreferences.setUserMobile(loginModelClass.getUser().getMobile());
                    sharedpreferences.setUserId(loginModelClass.getUser().getUniqueId());
                    sessionManager.createEmail(loginModelClass.getUser().getEmail());
                    sessionManager.setBlockstatus(loginModelClass.getUser().getBlockStatus());

                    preferences = getSharedPreferences(AppConstants.PREF_AUTO_BOOK, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean(AppConstants.PREF_AUTO_LESS_DISTANCE, false);
                    editor.putBoolean(AppConstants.PREF_AUTO_LESS_PRICE, true);
                    editor.putBoolean(AppConstants.NONE,false);
                    editor.commit();

                    Utils.showToast(this, "Lowset fare updated");
                    startActivity(new Intent(LoginActivity.this, NavHome.class));
                    finish();
                } else {

                    if(loginModelClass.getLogin_device().equalsIgnoreCase("DEVICE_ERROR")){

                        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
                        builder.setMessage(resources.getString(R.string.deviceLoggedIn))
                                .setCancelable(false)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        Thread.interrupted();

                                        sendValuesWithExtraKey();
                                    }
                                })
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });
                        androidx.appcompat.app.AlertDialog alert = builder.create();
                        alert.show();
                    }
                    else{
                        Utils.showToast(this, loginModelClass.getError_msg());
                    }

                }
            }
        }

        if (pid == AppConstants.TAG_ID_FORGOT_PASSWORD) {

            if (responseJson != null) {
                try {
                    Utils.stopProgress(LoginActivity.this);
                    JSONObject jObj = new JSONObject(responseJson);
                    boolean error = jObj.getBoolean("error");
                    if (!error) {

                        Intent i = new Intent(LoginActivity.this, ForgotPassword.class);
                        i.putExtra("mobile", stringMobile);
                        startActivity(i);
                        finish();


                    } else {

                        String errorMsg = jObj.getString("error_msg");
                        Toast.makeText(LoginActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {

        Utils.showToast(LoginActivity.this,error);
        Utils.stopProgress(LoginActivity.this);

    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        switch (requestCode) {
            case 101:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 101);
                        return;
                    }
                    imeiNumber = telephonyManager.getDeviceId();

                    if(imeiNumber!=null)
                        sharedpreferences.setTagDeviceId(imeiNumber);
                   // Toast.makeText(LoginActivity.this,imeiNumber,Toast.LENGTH_LONG).show();
                } else {

                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 101);
                   // Toast.makeText(LoginActivity.this,"Permission is required",Toast.LENGTH_LONG).show();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


}
