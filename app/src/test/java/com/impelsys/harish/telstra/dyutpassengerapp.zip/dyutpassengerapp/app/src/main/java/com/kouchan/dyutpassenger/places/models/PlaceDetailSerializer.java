package com.kouchan.dyutpassenger.places.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PlaceDetailSerializer {
    /**
     * html_attributions : []
     * result : {"address_components":[{"long_name":"27th Main Road","short_name":"27th Main Rd","types":["route"]},{"long_name":"1st Sector","short_name":"1st Sector","types":["sublocality_level_2","sublocality","political"]},{"long_name":"HSR Layout","short_name":"HSR Layout","types":["sublocality_level_1","sublocality","political"]},{"long_name":"Bengaluru","short_name":"Bengaluru","types":["locality","political"]},{"long_name":"Bangalore Urban","short_name":"Bangalore Urban","types":["administrative_area_level_2","political"]},{"long_name":"Karnataka","short_name":"KA","types":["administrative_area_level_1","political"]},{"long_name":"India","short_name":"IN","types":["country","political"]},{"long_name":"560102","short_name":"560102","types":["postal_code"]}],"adr_address":"<span class=\"street-address\">27th Main Rd<\/span>, <span class=\"extended-address\">1st Sector, HSR Layout<\/span>, <span class=\"locality\">Bengaluru<\/span>, <span class=\"region\">Karnataka<\/span> <span class=\"postal-code\">560102<\/span>, <span class=\"country-name\">India<\/span>","formatted_address":"27th Main Rd, 1st Sector, HSR Layout, Bengaluru, Karnataka 560102, India","formatted_phone_number":"080 2294 3467","geometry":{"location":{"lat":12.9201596,"lng":77.6512411},"viewport":{"northeast":{"lat":12.9215125802915,"lng":77.6527734802915},"southwest":{"lat":12.9188146197085,"lng":77.6500755197085}}},"icon":"https://maps.gstatic.com/mapfiles/place_api/icons/police-71.png","id":"8a9527172a151cd5855bbbc8cbdf4e8bd7db74f7","international_phone_number":"+91 80 2294 3467","name":"HSR Layout Police Station","photos":[{"height":3264,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/102208463240140501143/photos\">Gopinath M S<\/a>"],"photo_reference":"CmRaAAAAL9eqoCYudUTQl6NvTNp9h3JrCmHic05vfaXd-8nlKtH2DQzg7h63jE8riTXS3P_gmcETlB6K8DL6GGBraCpaHI3GhEdIS_ReAOJiXrq7qMiGntZag9dD-v1KACJY8cJxEhBAnoFZsXKN-bSr-Xf2dneBGhQEExdmr5ClScGZe48c1gxbJ06LCg","width":2448},{"height":2448,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/102420848847182194943/photos\">Swopendro Gurumayum<\/a>"],"photo_reference":"CmRaAAAAg1K4wSWdma9BGKDyAhgz0m1kgyDcpCB2wBQWJa6pxMgW1ENhmv2Px_Jg7IFKBUTll8tliaDyrl3VMXnjYe_ruMFfAAzR1ntwmn5ahivmJ7N6N9PdSR_hTIb4_eK4pnT9EhApVxsRONpd76wO1D0KTZCWGhTrgbz7t97S-rT07d5eg1QnXXk_wA","width":3264},{"height":2322,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/106964971603056060622/photos\">durjoy ghose<\/a>"],"photo_reference":"CmRaAAAAQVWpfnRovGBGO1cA0MeKuOtZTgqfMZGXDU2EVnRUUvx6DM8JL3Frce1yiSpRBDiEyFqAJBbEk5NtDY1sZ6fplIbMLZzVMqy5bizQZKhcUkSdrStzzunA6uWC6pOaqs8sEhAiZhxbitxajBHLE2Qwk7dAGhRvEZBsUX5Td1LFU1QuMTydYdcKRg","width":4128},{"height":4608,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/106778014447839219402/photos\">subbaraju s.v<\/a>"],"photo_reference":"CmRaAAAA1yfIFd_iuRVodVRBykWsd4g4CTv2w9O-OHK50jvyVkUMa9bI2lk8f7ieEiTceJo_zpe3rwJUS1EhZYMHUNRw6ajccxj1YRZ6uLE8V01SzpOp8EudXjiiS7v71Rw81kntEhCEWAL5_Ak9ZeplCl21gwZ8GhT_Yv2T7Rr17kz_cobUHaSa0e4NKw","width":3456},{"height":4608,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/111658097148460339535/photos\">Rex recca<\/a>"],"photo_reference":"CmRaAAAA9CqmUSYtW1DC6AxfIaDx6F9p74rZca_s5HHnrmkca3XklGdHuDrM2zThVQ9rffzFqQ8eAQ8RxnXQFzC9sdt-bFtSHXoR1VHGsuR-6pmdBrFPCrFKLHyfYbhOJ116eVX_EhBCCIpToGbwc_g5dTmmXLdhGhQA5oWX-7mb25U8LyxxxUOr-E7O0Q","width":2592},{"height":2322,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/106964971603056060622/photos\">durjoy ghose<\/a>"],"photo_reference":"CmRaAAAAoPNQp0MvqqqzHW7VDDCi7cnTP_Gm2Wmug1OGQA0jyMTNdSnrsNeoXyHDSIfgcExGuOkuj9qKX1Q2RLKrNfntPPtiuMcs5Ri6RCHuSxXiMh4RGRhLcRlQW5xZVCy_dTUoEhCalW05lXNeBwcKz3yLNK5GGhRSWVn0FZ8Dq1ZBzvN2DnWivXeZwA","width":4128},{"height":2448,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/102208463240140501143/photos\">Gopinath M S<\/a>"],"photo_reference":"CmRaAAAA1V34tJ84-a4A8YBkHP8Kue3cacIxPk6Aen780o9GBYNH74akfFAI-eH16YyolowMjevFXv7IztxlLy5l59zNixamkpDq6Y5xIjMy9_xAckYXGaRWA9P7ZScHTWE06UZdEhDM4COXYr9sJZgtbD4xl50tGhRKmX42sq552CtemOUQ5IGMEOoRmw","width":3264},{"height":2022,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/109584871912834040366/photos\">Driver Ontravel<\/a>"],"photo_reference":"CmRaAAAADe9NSOUZqAb-s-zwvjaHACZaq7tP-SEFVYApUo_igYu44IUASGOAhHExjA4KAOqOfF1pQTobRumGfjwAX_FSrHFGIy0t9W6-HkA5_US0_x6T7vq4XWAbZa81arLkmWtlEhCxFZfSqhQq_LxO5jsDBTK1GhSHtysyZU2yQq56OzWaX8gJV6zL3w","width":3822}],"place_id":"ChIJw_Ujl4EUrjsRXuGsfv_xkwI","plus_code":{"compound_code":"WMC2+3F Bengaluru, Karnataka, India","global_code":"7J4VWMC2+3F"},"rating":3.5,"reference":"ChIJw_Ujl4EUrjsRXuGsfv_xkwI","reviews":[{"author_name":"Nawab Dilaweez Hasan","author_url":"https://www.google.com/maps/contrib/110040233580378259920/reviews","language":"en","profile_photo_url":"https://lh3.googleusercontent.com/-vhBAd2XYn-4/AAAAAAAAAAI/AAAAAAAABBw/3OFPZuIAUqs/s128-c0x00000000-cc-rp-mo/photo.jpg","rating":5,"relative_time_description":"2 weeks ago","text":"Unbelievable! My first experience with a police station in Bangalore and I was floored! Did not expect policemen and a police station to be so warm, helpful and welcoming....hats off to the station in charge and the commissioner! Everyone, right from the lady at the help desk to the two policemen and women I met for my work were so courteous and non government type employees!!! \nThis is definitely new India in the making!!!","time":1564830830},{"author_name":"PANKAJ KULI","author_url":"https://www.google.com/maps/contrib/101511729419457764885/reviews","language":"en","profile_photo_url":"https://lh5.googleusercontent.com/-IaRIbKIKQS8/AAAAAAAAAAI/AAAAAAAABws/vw9MNJTDvHU/s128-c0x00000000-cc-rp-mo/photo.jpg","rating":4,"relative_time_description":"3 months ago","text":"Staff were very polite when arresting me. Car was very clean and quite comfortable. The room was a very basic, not much decoration going on, but still got a great sleep in those comfy mattresses. Checking out in the morning was very exceedingly pleasant. Would highly recommend and will be back again for sure.","time":1556936592},{"author_name":"Nikhil P","author_url":"https://www.google.com/maps/contrib/113500452627714202169/reviews","language":"en","profile_photo_url":"https://lh4.googleusercontent.com/-FnPHCgSFnVA/AAAAAAAAAAI/AAAAAAAAAAA/ACHi3rcJxoD1nVG6-M1KMPtfyE2-qJ-PhA/s128-c0x00000000-cc-rp-mo-ba3/photo.jpg","rating":1,"relative_time_description":"in the last week","text":"Be careful while you're signing here they might use your signature to make you a witness to a crime that you've never seen , horrible experience , I had gone ther to file a complaint about my lost car on 8.3.2016 and 2 years later I find my signature and address being used as a witness for another crime which I was totally unaware about! \nWhen I told that I have not signed on the said paper and my signature was only on the complaint that I had written , they forced me and coherced me into giving false statements , which I did not agree too ! Please be careful with the cops here , they treat only the passport verification nicely , and I see a lot of positive reviews only because of that , try filing an FIR over here you'll know what I mean ! Unethical policemen who harass innocent citizens.","time":1565794254},{"author_name":"Sudhakar Sudhi","author_url":"https://www.google.com/maps/contrib/117381165735802236011/reviews","language":"en","profile_photo_url":"https://lh6.googleusercontent.com/-7K2Fnb6x3Mg/AAAAAAAAAAI/AAAAAAAASfg/uFqQcTihMkA/s128-c0x00000000-cc-rp-mo/photo.jpg","rating":1,"relative_time_description":"6 months ago","text":"Today hsr park hathira waking madutha edhe   policemen car alle bandu nanna magane ille yenu kelasa yendu keluthare alva avru public ge help madake edhara athava rowdy behaviour madake edhara avana name yenoo gothila nange but  ava nan maganige chai nale vadayabeku lofar Nan maga","time":1549812492},{"author_name":"sai thanush","author_url":"https://www.google.com/maps/contrib/106875102077190905267/reviews","language":"en","profile_photo_url":"https://lh6.googleusercontent.com/-7GItmzX5nyY/AAAAAAAAAAI/AAAAAAAAABY/YtqMyCzoPO0/s128-c0x00000000-cc-rp-mo/photo.jpg","rating":1,"relative_time_description":"8 months ago","text":"Worst experience  ,most of them not deserve that dress theft has happened in my apartment I lost my phone laptop.. Etc I filled fit that to online and till no no respons from them  even I have given the thief CCTV footage but still they didint bro any investigation and they are saying some reason every time and I feel so thief's r more passionated to work comparing to this guy's","time":1544247669}],"scope":"GOOGLE","types":["police","point_of_interest","establishment"],"url":"https://maps.google.com/?cid=185758089296535902","user_ratings_total":90,"utc_offset":330,"vicinity":"27th Main Road, 1st Sector, HSR Layout, Bengaluru"}
     * status : OK
     */

    @SerializedName("result")
    private ResultBean result;
    @SerializedName("status")
    private String status;
    @SerializedName("html_attributions")
    private List<?> htmlAttributions;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<?> getHtmlAttributions() {
        return htmlAttributions;
    }

    public void setHtmlAttributions(List<?> htmlAttributions) {
        this.htmlAttributions = htmlAttributions;
    }

    public static class ResultBean {
        /**
         * address_components : [{"long_name":"27th Main Road","short_name":"27th Main Rd","types":["route"]},{"long_name":"1st Sector","short_name":"1st Sector","types":["sublocality_level_2","sublocality","political"]},{"long_name":"HSR Layout","short_name":"HSR Layout","types":["sublocality_level_1","sublocality","political"]},{"long_name":"Bengaluru","short_name":"Bengaluru","types":["locality","political"]},{"long_name":"Bangalore Urban","short_name":"Bangalore Urban","types":["administrative_area_level_2","political"]},{"long_name":"Karnataka","short_name":"KA","types":["administrative_area_level_1","political"]},{"long_name":"India","short_name":"IN","types":["country","political"]},{"long_name":"560102","short_name":"560102","types":["postal_code"]}]
         * adr_address : <span class="street-address">27th Main Rd</span>, <span class="extended-address">1st Sector, HSR Layout</span>, <span class="locality">Bengaluru</span>, <span class="region">Karnataka</span> <span class="postal-code">560102</span>, <span class="country-name">India</span>
         * formatted_address : 27th Main Rd, 1st Sector, HSR Layout, Bengaluru, Karnataka 560102, India
         * formatted_phone_number : 080 2294 3467
         * geometry : {"location":{"lat":12.9201596,"lng":77.6512411},"viewport":{"northeast":{"lat":12.9215125802915,"lng":77.6527734802915},"southwest":{"lat":12.9188146197085,"lng":77.6500755197085}}}
         * icon : https://maps.gstatic.com/mapfiles/place_api/icons/police-71.png
         * id : 8a9527172a151cd5855bbbc8cbdf4e8bd7db74f7
         * international_phone_number : +91 80 2294 3467
         * name : HSR Layout Police Station
         * photos : [{"height":3264,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/102208463240140501143/photos\">Gopinath M S<\/a>"],"photo_reference":"CmRaAAAAL9eqoCYudUTQl6NvTNp9h3JrCmHic05vfaXd-8nlKtH2DQzg7h63jE8riTXS3P_gmcETlB6K8DL6GGBraCpaHI3GhEdIS_ReAOJiXrq7qMiGntZag9dD-v1KACJY8cJxEhBAnoFZsXKN-bSr-Xf2dneBGhQEExdmr5ClScGZe48c1gxbJ06LCg","width":2448},{"height":2448,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/102420848847182194943/photos\">Swopendro Gurumayum<\/a>"],"photo_reference":"CmRaAAAAg1K4wSWdma9BGKDyAhgz0m1kgyDcpCB2wBQWJa6pxMgW1ENhmv2Px_Jg7IFKBUTll8tliaDyrl3VMXnjYe_ruMFfAAzR1ntwmn5ahivmJ7N6N9PdSR_hTIb4_eK4pnT9EhApVxsRONpd76wO1D0KTZCWGhTrgbz7t97S-rT07d5eg1QnXXk_wA","width":3264},{"height":2322,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/106964971603056060622/photos\">durjoy ghose<\/a>"],"photo_reference":"CmRaAAAAQVWpfnRovGBGO1cA0MeKuOtZTgqfMZGXDU2EVnRUUvx6DM8JL3Frce1yiSpRBDiEyFqAJBbEk5NtDY1sZ6fplIbMLZzVMqy5bizQZKhcUkSdrStzzunA6uWC6pOaqs8sEhAiZhxbitxajBHLE2Qwk7dAGhRvEZBsUX5Td1LFU1QuMTydYdcKRg","width":4128},{"height":4608,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/106778014447839219402/photos\">subbaraju s.v<\/a>"],"photo_reference":"CmRaAAAA1yfIFd_iuRVodVRBykWsd4g4CTv2w9O-OHK50jvyVkUMa9bI2lk8f7ieEiTceJo_zpe3rwJUS1EhZYMHUNRw6ajccxj1YRZ6uLE8V01SzpOp8EudXjiiS7v71Rw81kntEhCEWAL5_Ak9ZeplCl21gwZ8GhT_Yv2T7Rr17kz_cobUHaSa0e4NKw","width":3456},{"height":4608,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/111658097148460339535/photos\">Rex recca<\/a>"],"photo_reference":"CmRaAAAA9CqmUSYtW1DC6AxfIaDx6F9p74rZca_s5HHnrmkca3XklGdHuDrM2zThVQ9rffzFqQ8eAQ8RxnXQFzC9sdt-bFtSHXoR1VHGsuR-6pmdBrFPCrFKLHyfYbhOJ116eVX_EhBCCIpToGbwc_g5dTmmXLdhGhQA5oWX-7mb25U8LyxxxUOr-E7O0Q","width":2592},{"height":2322,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/106964971603056060622/photos\">durjoy ghose<\/a>"],"photo_reference":"CmRaAAAAoPNQp0MvqqqzHW7VDDCi7cnTP_Gm2Wmug1OGQA0jyMTNdSnrsNeoXyHDSIfgcExGuOkuj9qKX1Q2RLKrNfntPPtiuMcs5Ri6RCHuSxXiMh4RGRhLcRlQW5xZVCy_dTUoEhCalW05lXNeBwcKz3yLNK5GGhRSWVn0FZ8Dq1ZBzvN2DnWivXeZwA","width":4128},{"height":2448,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/102208463240140501143/photos\">Gopinath M S<\/a>"],"photo_reference":"CmRaAAAA1V34tJ84-a4A8YBkHP8Kue3cacIxPk6Aen780o9GBYNH74akfFAI-eH16YyolowMjevFXv7IztxlLy5l59zNixamkpDq6Y5xIjMy9_xAckYXGaRWA9P7ZScHTWE06UZdEhDM4COXYr9sJZgtbD4xl50tGhRKmX42sq552CtemOUQ5IGMEOoRmw","width":3264},{"height":2022,"html_attributions":["<a href=\"https://maps.google.com/maps/contrib/109584871912834040366/photos\">Driver Ontravel<\/a>"],"photo_reference":"CmRaAAAADe9NSOUZqAb-s-zwvjaHACZaq7tP-SEFVYApUo_igYu44IUASGOAhHExjA4KAOqOfF1pQTobRumGfjwAX_FSrHFGIy0t9W6-HkA5_US0_x6T7vq4XWAbZa81arLkmWtlEhCxFZfSqhQq_LxO5jsDBTK1GhSHtysyZU2yQq56OzWaX8gJV6zL3w","width":3822}]
         * place_id : ChIJw_Ujl4EUrjsRXuGsfv_xkwI
         * plus_code : {"compound_code":"WMC2+3F Bengaluru, Karnataka, India","global_code":"7J4VWMC2+3F"}
         * rating : 3.5
         * reference : ChIJw_Ujl4EUrjsRXuGsfv_xkwI
         * reviews : [{"author_name":"Nawab Dilaweez Hasan","author_url":"https://www.google.com/maps/contrib/110040233580378259920/reviews","language":"en","profile_photo_url":"https://lh3.googleusercontent.com/-vhBAd2XYn-4/AAAAAAAAAAI/AAAAAAAABBw/3OFPZuIAUqs/s128-c0x00000000-cc-rp-mo/photo.jpg","rating":5,"relative_time_description":"2 weeks ago","text":"Unbelievable! My first experience with a police station in Bangalore and I was floored! Did not expect policemen and a police station to be so warm, helpful and welcoming....hats off to the station in charge and the commissioner! Everyone, right from the lady at the help desk to the two policemen and women I met for my work were so courteous and non government type employees!!! \nThis is definitely new India in the making!!!","time":1564830830},{"author_name":"PANKAJ KULI","author_url":"https://www.google.com/maps/contrib/101511729419457764885/reviews","language":"en","profile_photo_url":"https://lh5.googleusercontent.com/-IaRIbKIKQS8/AAAAAAAAAAI/AAAAAAAABws/vw9MNJTDvHU/s128-c0x00000000-cc-rp-mo/photo.jpg","rating":4,"relative_time_description":"3 months ago","text":"Staff were very polite when arresting me. Car was very clean and quite comfortable. The room was a very basic, not much decoration going on, but still got a great sleep in those comfy mattresses. Checking out in the morning was very exceedingly pleasant. Would highly recommend and will be back again for sure.","time":1556936592},{"author_name":"Nikhil P","author_url":"https://www.google.com/maps/contrib/113500452627714202169/reviews","language":"en","profile_photo_url":"https://lh4.googleusercontent.com/-FnPHCgSFnVA/AAAAAAAAAAI/AAAAAAAAAAA/ACHi3rcJxoD1nVG6-M1KMPtfyE2-qJ-PhA/s128-c0x00000000-cc-rp-mo-ba3/photo.jpg","rating":1,"relative_time_description":"in the last week","text":"Be careful while you're signing here they might use your signature to make you a witness to a crime that you've never seen , horrible experience , I had gone ther to file a complaint about my lost car on 8.3.2016 and 2 years later I find my signature and address being used as a witness for another crime which I was totally unaware about! \nWhen I told that I have not signed on the said paper and my signature was only on the complaint that I had written , they forced me and coherced me into giving false statements , which I did not agree too ! Please be careful with the cops here , they treat only the passport verification nicely , and I see a lot of positive reviews only because of that , try filing an FIR over here you'll know what I mean ! Unethical policemen who harass innocent citizens.","time":1565794254},{"author_name":"Sudhakar Sudhi","author_url":"https://www.google.com/maps/contrib/117381165735802236011/reviews","language":"en","profile_photo_url":"https://lh6.googleusercontent.com/-7K2Fnb6x3Mg/AAAAAAAAAAI/AAAAAAAASfg/uFqQcTihMkA/s128-c0x00000000-cc-rp-mo/photo.jpg","rating":1,"relative_time_description":"6 months ago","text":"Today hsr park hathira waking madutha edhe   policemen car alle bandu nanna magane ille yenu kelasa yendu keluthare alva avru public ge help madake edhara athava rowdy behaviour madake edhara avana name yenoo gothila nange but  ava nan maganige chai nale vadayabeku lofar Nan maga","time":1549812492},{"author_name":"sai thanush","author_url":"https://www.google.com/maps/contrib/106875102077190905267/reviews","language":"en","profile_photo_url":"https://lh6.googleusercontent.com/-7GItmzX5nyY/AAAAAAAAAAI/AAAAAAAAABY/YtqMyCzoPO0/s128-c0x00000000-cc-rp-mo/photo.jpg","rating":1,"relative_time_description":"8 months ago","text":"Worst experience  ,most of them not deserve that dress theft has happened in my apartment I lost my phone laptop.. Etc I filled fit that to online and till no no respons from them  even I have given the thief CCTV footage but still they didint bro any investigation and they are saying some reason every time and I feel so thief's r more passionated to work comparing to this guy's","time":1544247669}]
         * scope : GOOGLE
         * types : ["police","point_of_interest","establishment"]
         * url : https://maps.google.com/?cid=185758089296535902
         * user_ratings_total : 90
         * utc_offset : 330
         * vicinity : 27th Main Road, 1st Sector, HSR Layout, Bengaluru
         */

        @SerializedName("adr_address")
        private String adrAddress;
        @SerializedName("formatted_address")
        private String formattedAddress;
        @SerializedName("formatted_phone_number")
        private String formattedPhoneNumber;
        @SerializedName("geometry")
        private GeometryBean geometry;
        @SerializedName("icon")
        private String icon;
        @SerializedName("id")
        private String id;
        @SerializedName("international_phone_number")
        private String internationalPhoneNumber;
        @SerializedName("name")
        private String name;
        @SerializedName("place_id")
        private String placeId;
        @SerializedName("plus_code")
        private PlusCodeBean plusCode;
        @SerializedName("rating")
        private double rating;
        @SerializedName("reference")
        private String reference;
        @SerializedName("scope")
        private String scope;
        @SerializedName("url")
        private String url;
        @SerializedName("user_ratings_total")
        private int userRatingsTotal;
        @SerializedName("utc_offset")
        private int utcOffset;
        @SerializedName("vicinity")
        private String vicinity;
        @SerializedName("address_components")
        private List<AddressComponentsBean> addressComponents;
        @SerializedName("photos")
        private List<PhotosBean> photos;
        @SerializedName("reviews")
        private List<ReviewsBean> reviews;
        @SerializedName("types")
        private List<String> types;

        public String getAdrAddress() {
            return adrAddress;
        }

        public void setAdrAddress(String adrAddress) {
            this.adrAddress = adrAddress;
        }

        public String getFormattedAddress() {
            return formattedAddress;
        }

        public void setFormattedAddress(String formattedAddress) {
            this.formattedAddress = formattedAddress;
        }

        public String getFormattedPhoneNumber() {
            return formattedPhoneNumber;
        }

        public void setFormattedPhoneNumber(String formattedPhoneNumber) {
            this.formattedPhoneNumber = formattedPhoneNumber;
        }

        public GeometryBean getGeometry() {
            return geometry;
        }

        public void setGeometry(GeometryBean geometry) {
            this.geometry = geometry;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getInternationalPhoneNumber() {
            return internationalPhoneNumber;
        }

        public void setInternationalPhoneNumber(String internationalPhoneNumber) {
            this.internationalPhoneNumber = internationalPhoneNumber;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPlaceId() {
            return placeId;
        }

        public void setPlaceId(String placeId) {
            this.placeId = placeId;
        }

        public PlusCodeBean getPlusCode() {
            return plusCode;
        }

        public void setPlusCode(PlusCodeBean plusCode) {
            this.plusCode = plusCode;
        }

        public double getRating() {
            return rating;
        }

        public void setRating(double rating) {
            this.rating = rating;
        }

        public String getReference() {
            return reference;
        }

        public void setReference(String reference) {
            this.reference = reference;
        }

        public String getScope() {
            return scope;
        }

        public void setScope(String scope) {
            this.scope = scope;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public int getUserRatingsTotal() {
            return userRatingsTotal;
        }

        public void setUserRatingsTotal(int userRatingsTotal) {
            this.userRatingsTotal = userRatingsTotal;
        }

        public int getUtcOffset() {
            return utcOffset;
        }

        public void setUtcOffset(int utcOffset) {
            this.utcOffset = utcOffset;
        }

        public String getVicinity() {
            return vicinity;
        }

        public void setVicinity(String vicinity) {
            this.vicinity = vicinity;
        }

        public List<AddressComponentsBean> getAddressComponents() {
            return addressComponents;
        }

        public void setAddressComponents(List<AddressComponentsBean> addressComponents) {
            this.addressComponents = addressComponents;
        }

        public List<PhotosBean> getPhotos() {
            return photos;
        }

        public void setPhotos(List<PhotosBean> photos) {
            this.photos = photos;
        }

        public List<ReviewsBean> getReviews() {
            return reviews;
        }

        public void setReviews(List<ReviewsBean> reviews) {
            this.reviews = reviews;
        }

        public List<String> getTypes() {
            return types;
        }

        public void setTypes(List<String> types) {
            this.types = types;
        }

        public static class GeometryBean {
            /**
             * location : {"lat":12.9201596,"lng":77.6512411}
             * viewport : {"northeast":{"lat":12.9215125802915,"lng":77.6527734802915},"southwest":{"lat":12.9188146197085,"lng":77.6500755197085}}
             */

            @SerializedName("location")
            private LocationBean location;
            @SerializedName("viewport")
            private ViewportBean viewport;

            public LocationBean getLocation() {
                return location;
            }

            public void setLocation(LocationBean location) {
                this.location = location;
            }

            public ViewportBean getViewport() {
                return viewport;
            }

            public void setViewport(ViewportBean viewport) {
                this.viewport = viewport;
            }

            public static class LocationBean {
                /**
                 * lat : 12.9201596
                 * lng : 77.6512411
                 */

                @SerializedName("lat")
                private double lat;
                @SerializedName("lng")
                private double lng;

                public double getLat() {
                    return lat;
                }

                public void setLat(double lat) {
                    this.lat = lat;
                }

                public double getLng() {
                    return lng;
                }

                public void setLng(double lng) {
                    this.lng = lng;
                }
            }

            public static class ViewportBean {
                /**
                 * northeast : {"lat":12.9215125802915,"lng":77.6527734802915}
                 * southwest : {"lat":12.9188146197085,"lng":77.6500755197085}
                 */

                @SerializedName("northeast")
                private NortheastBean northeast;
                @SerializedName("southwest")
                private SouthwestBean southwest;

                public NortheastBean getNortheast() {
                    return northeast;
                }

                public void setNortheast(NortheastBean northeast) {
                    this.northeast = northeast;
                }

                public SouthwestBean getSouthwest() {
                    return southwest;
                }

                public void setSouthwest(SouthwestBean southwest) {
                    this.southwest = southwest;
                }

                public static class NortheastBean {
                    /**
                     * lat : 12.9215125802915
                     * lng : 77.6527734802915
                     */

                    @SerializedName("lat")
                    private double lat;
                    @SerializedName("lng")
                    private double lng;

                    public double getLat() {
                        return lat;
                    }

                    public void setLat(double lat) {
                        this.lat = lat;
                    }

                    public double getLng() {
                        return lng;
                    }

                    public void setLng(double lng) {
                        this.lng = lng;
                    }
                }

                public static class SouthwestBean {
                    /**
                     * lat : 12.9188146197085
                     * lng : 77.6500755197085
                     */

                    @SerializedName("lat")
                    private double lat;
                    @SerializedName("lng")
                    private double lng;

                    public double getLat() {
                        return lat;
                    }

                    public void setLat(double lat) {
                        this.lat = lat;
                    }

                    public double getLng() {
                        return lng;
                    }

                    public void setLng(double lng) {
                        this.lng = lng;
                    }
                }
            }
        }

        public static class PlusCodeBean {
            /**
             * compound_code : WMC2+3F Bengaluru, Karnataka, India
             * global_code : 7J4VWMC2+3F
             */

            @SerializedName("compound_code")
            private String compoundCode;
            @SerializedName("global_code")
            private String globalCode;

            public String getCompoundCode() {
                return compoundCode;
            }

            public void setCompoundCode(String compoundCode) {
                this.compoundCode = compoundCode;
            }

            public String getGlobalCode() {
                return globalCode;
            }

            public void setGlobalCode(String globalCode) {
                this.globalCode = globalCode;
            }
        }

        public static class AddressComponentsBean {
            /**
             * long_name : 27th Main Road
             * short_name : 27th Main Rd
             * types : ["route"]
             */

            @SerializedName("long_name")
            private String longName;
            @SerializedName("short_name")
            private String shortName;
            @SerializedName("types")
            private List<String> types;

            public String getLongName() {
                return longName;
            }

            public void setLongName(String longName) {
                this.longName = longName;
            }

            public String getShortName() {
                return shortName;
            }

            public void setShortName(String shortName) {
                this.shortName = shortName;
            }

            public List<String> getTypes() {
                return types;
            }

            public void setTypes(List<String> types) {
                this.types = types;
            }
        }

        public static class PhotosBean {
            /**
             * height : 3264
             * html_attributions : ["<a href=\"https://maps.google.com/maps/contrib/102208463240140501143/photos\">Gopinath M S<\/a>"]
             * photo_reference : CmRaAAAAL9eqoCYudUTQl6NvTNp9h3JrCmHic05vfaXd-8nlKtH2DQzg7h63jE8riTXS3P_gmcETlB6K8DL6GGBraCpaHI3GhEdIS_ReAOJiXrq7qMiGntZag9dD-v1KACJY8cJxEhBAnoFZsXKN-bSr-Xf2dneBGhQEExdmr5ClScGZe48c1gxbJ06LCg
             * width : 2448
             */

            @SerializedName("height")
            private int height;
            @SerializedName("photo_reference")
            private String photoReference;
            @SerializedName("width")
            private int width;
            @SerializedName("html_attributions")
            private List<String> htmlAttributions;

            public int getHeight() {
                return height;
            }

            public void setHeight(int height) {
                this.height = height;
            }

            public String getPhotoReference() {
                return photoReference;
            }

            public void setPhotoReference(String photoReference) {
                this.photoReference = photoReference;
            }

            public int getWidth() {
                return width;
            }

            public void setWidth(int width) {
                this.width = width;
            }

            public List<String> getHtmlAttributions() {
                return htmlAttributions;
            }

            public void setHtmlAttributions(List<String> htmlAttributions) {
                this.htmlAttributions = htmlAttributions;
            }
        }

        public static class ReviewsBean {
            /**
             * author_name : Nawab Dilaweez Hasan
             * author_url : https://www.google.com/maps/contrib/110040233580378259920/reviews
             * language : en
             * profile_photo_url : https://lh3.googleusercontent.com/-vhBAd2XYn-4/AAAAAAAAAAI/AAAAAAAABBw/3OFPZuIAUqs/s128-c0x00000000-cc-rp-mo/photo.jpg
             * rating : 5
             * relative_time_description : 2 weeks ago
             * text : Unbelievable! My first experience with a police station in Bangalore and I was floored! Did not expect policemen and a police station to be so warm, helpful and welcoming....hats off to the station in charge and the commissioner! Everyone, right from the lady at the help desk to the two policemen and women I met for my work were so courteous and non government type employees!!!
             This is definitely new India in the making!!!
             * time : 1564830830
             */

            @SerializedName("author_name")
            private String authorName;
            @SerializedName("author_url")
            private String authorUrl;
            @SerializedName("language")
            private String language;
            @SerializedName("profile_photo_url")
            private String profilePhotoUrl;
            @SerializedName("rating")
            private int rating;
            @SerializedName("relative_time_description")
            private String relativeTimeDescription;
            @SerializedName("text")
            private String text;
            @SerializedName("time")
            private int time;

            public String getAuthorName() {
                return authorName;
            }

            public void setAuthorName(String authorName) {
                this.authorName = authorName;
            }

            public String getAuthorUrl() {
                return authorUrl;
            }

            public void setAuthorUrl(String authorUrl) {
                this.authorUrl = authorUrl;
            }

            public String getLanguage() {
                return language;
            }

            public void setLanguage(String language) {
                this.language = language;
            }

            public String getProfilePhotoUrl() {
                return profilePhotoUrl;
            }

            public void setProfilePhotoUrl(String profilePhotoUrl) {
                this.profilePhotoUrl = profilePhotoUrl;
            }

            public int getRating() {
                return rating;
            }

            public void setRating(int rating) {
                this.rating = rating;
            }

            public String getRelativeTimeDescription() {
                return relativeTimeDescription;
            }

            public void setRelativeTimeDescription(String relativeTimeDescription) {
                this.relativeTimeDescription = relativeTimeDescription;
            }

            public String getText() {
                return text;
            }

            public void setText(String text) {
                this.text = text;
            }

            public int getTime() {
                return time;
            }

            public void setTime(int time) {
                this.time = time;
            }
        }
    }



    /*public class Geometry {
        public class Location {
            Double lat;
            Double lng;
        }
        Location location;
    }

    public class AddressComponent {
        String long_name;
        String short_name;
        String[] types;
    }

    public class Photo {
        int height;
        int width;
        String photo_reference;
    }

    public class Place {
        @SerializedName("place_id")
        private String place_id;

        @SerializedName("name")
        private String name;

        @SerializedName("address_components")
        private List<AddressComponent> address_components;

        @SerializedName("formatted_address")
        private String formatted_address;

        @SerializedName("international_phone_number")
        private String phone_number;

        @SerializedName("photos")
        private List<Photo> photos;

        @SerializedName("geometry")
        private Geometry geometry;

        @SerializedName("icon")
        private String icon;

        @SerializedName("rating")
        Double rating;

        @SerializedName("types")
        private String[] types;

        @SerializedName("url")
        private String url;

        @SerializedName("vicinity")
        private String vicinity;

        @SerializedName("website")
        private String website;

        public String getID() {
            return place_id;
        }

        public String getName() {
            return name;
        }

        public String getAddress() {
            return formatted_address;
        }

        public List<Photo> getPhotos() {
            return photos;
        }

        public String getPhotoURL(int maxwidth) {
            if (!photos.isEmpty()) {
                String key = PlaceAutocompleteAPI.KEY;
                Photo photo = photos.get(0);
                String ref = photo.photo_reference;
                String url = String.format("https://maps.googleapis.com/maps/api/place/photo?maxwidth=%d&photoreference=%s&key=%s", maxwidth, ref, key);
                return url;
            }
            return null;
        }

        @Override
        public String toString() {
            return "Place{" +
                    "name='" + name + '\'' +
                    '}';
        }
    }

    @SerializedName("result")
    private Place result;

    @SerializedName("status")
    private String status;


    public Place getPlace() {
        return result;
    }*/
}
