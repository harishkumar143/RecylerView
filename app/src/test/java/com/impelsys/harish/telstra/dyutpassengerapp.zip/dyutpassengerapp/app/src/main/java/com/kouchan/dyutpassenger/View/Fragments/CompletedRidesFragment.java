package com.kouchan.dyutpassenger.View.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Adapter.HistoryAdapter;
import com.kouchan.dyutpassenger.Adapter.RecyclerTouchListener;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.MonthExpandActivity;
import com.kouchan.dyutpassenger.View.Activities.SplashActivity;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.History;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class CompletedRidesFragment extends Fragment implements OnRequestListener {

    String languageCode;
    Resources resources;
    AsyncInteractor asyncInteractor;
    HashMap<String, String> user;
    String passengermobile, type;
    SessionManager sessionManager;
    View view;
    private List<History> historyList = new ArrayList<>();
    private String TAG = SplashActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private RecyclerView recyclerView;
    private HistoryAdapter mAdapter;
    private TextView takeFirstTv;

    public CompletedRidesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflate the layout for this fragment

        view = inflater.inflate(R.layout.fragment_two, container, false);


        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view_history);
        takeFirstTv = (TextView) view.findViewById(R.id.no_records_found_text);

       /* mAdapter = new HistoryAdapter(historyList, getActivity());
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);

        recyclerView.setAdapter(mAdapter);*/

        sessionManager = new SessionManager(getActivity());
        asyncInteractor = new AsyncInteractor(getActivity());

        user = new HashMap<String, String>();
        user = sessionManager.getUserDetails();

        passengermobile = user.get("mobile");

        type = sessionManager.getType();

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                History history = historyList.get(position);


                Intent i = new Intent(getActivity(), MonthExpandActivity.class);

                i.putExtra("month", history.getMonth());
                i.putExtra("year", history.getYear());

                startActivity(i);


            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));


        displayHistoy();

        sessionManager = new SessionManager(getActivity());
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        return view;
    }


    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(getActivity(), languageCode);
        resources = context.getResources();

        /*forgot_password_tv.setText(resources.getString(R.string.forgot_password));*/

    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("Ride History");

    }

    public void displayHistoy() {

        //Utils.showProgress(getActivity());
        Map<String, String> params = new HashMap<String, String>();
        params.put("mobile", passengermobile);

        asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_PassengerHistoryByMonth, Url.PASSENGER_API + ServerApiNames.passengerHistoryByMonth, new JSONObject(params));
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        historyList.clear();
        // mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        //Utils.stopProgress(getActivity());

        if (pid == AppConstants.TAG_ID_PassengerHistoryByMonth)
            try {

                Utils.stopProgress(getActivity());
                JSONObject jsonObj = new JSONObject(responseJson);
                boolean error = jsonObj.getBoolean("error");
                if (!error) {

                    JSONArray contacts = jsonObj.getJSONArray("user");

                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        String month = c.getString("month");
                        String year = c.getString("year");
                        String total_no_of_rides = c.getString("total_no_of_rides");
                        String total_fare = c.getString("total_fare");


                        History history = new History(month, year, total_no_of_rides, total_fare);
                        historyList.add(history);
                        // mAdapter.notifyDataSetChanged();


                        if (historyList.isEmpty()) {
                            takeFirstTv.setVisibility(View.VISIBLE);
                            recyclerView.setVisibility(View.GONE);
                        } else {
                            //historyList.clear();
                            mAdapter = new HistoryAdapter(historyList, getActivity());
                            recyclerView.setHasFixedSize(true);
                            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                            recyclerView.setLayoutManager(mLayoutManager);
                            recyclerView.setAdapter(mAdapter);
                        }

                    }
                } else {
                    String errorMsg = jsonObj.getString("error_msg");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(getActivity(),error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
