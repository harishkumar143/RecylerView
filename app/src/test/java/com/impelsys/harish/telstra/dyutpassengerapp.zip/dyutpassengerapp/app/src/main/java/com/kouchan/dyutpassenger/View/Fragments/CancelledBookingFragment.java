package com.kouchan.dyutpassenger.View.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Adapter.CancelAdapter;
import com.kouchan.dyutpassenger.Adapter.RecyclerTouchListener;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.SplashActivity;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.Cancel;
import com.kouchan.dyutpassenger.other.DividerItemDecoration;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class CancelledBookingFragment extends Fragment implements OnRequestListener {

    View view;
    private List<Cancel> cancelList = new ArrayList<>();
    private String TAG = SplashActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private RecyclerView recyclerView;
    private CancelAdapter mAdapter;
    HashMap<String, String> user;
    String passengermobile,type;
    String historyUrl= "";
    SessionManager sessionManager;
    AsyncInteractor asyncInteractor;

    String languageCode;
    Resources resources;
    private TextView takeFirstTv;

    public CancelledBookingFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflate the layout for this fragment

        view= inflater.inflate(R.layout.fragment_three, container, false);
      //  cancelList.clear();
        recyclerView = (RecyclerView)view. findViewById(R.id.recycler_view_cancel);
        takeFirstTv = (TextView) view.findViewById(R.id.no_records_found_text);


        sessionManager=new SessionManager(getActivity());
        asyncInteractor=new AsyncInteractor(getActivity());

        user = new HashMap<String, String>();
        user=sessionManager.getUserDetails();

        passengermobile=user.get("mobile");

        type=sessionManager.getType();

        historyUrl= Url.PASSENGER_API+ServerApiNames.CANCELLLED_HISTORY_OFPASSENGER;

        displayHistoyCancel();


        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        return view;
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(getActivity(), languageCode);
        resources = context.getResources();
        /*forgot_password_tv.setText(resources.getString(R.string.forgot_password));*/
    }



    public void displayHistoyCancel(){

        Map<String,String> params=new HashMap<String, String>();
        params.put("mobile",passengermobile);
        asyncInteractor.validateCredentialsAsync(this,AppConstants.CANCELLLED_HISTORY_OFPASSENGER,historyUrl,new JSONObject(params));

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        cancelList.clear();
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        Utils.stopProgress(getActivity());
        if(pid==AppConstants.CANCELLLED_HISTORY_OFPASSENGER){
            try {
                //loading.dismiss();
                JSONObject jsonObj = new JSONObject(responseJson);
                boolean error = jsonObj.getBoolean("error");
                if (!error) {


                    JSONArray contacts = jsonObj.getJSONArray("user");

                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        String id = c.getString("booking_id");
                        String vehicle = c.getString("vehicle");
                        String paymenttype = c.getString("paymenttype");
                        String bookingtime = c.getString("bookingtime");
                        String ridestatus = c.getString("ridestatus");
                        String fromplace = c.getString("fromplace");
                        String toplace = c.getString("toplace");
                        String price = c.getString("actualprice");

                        Cancel cancel=new Cancel(id,paymenttype,bookingtime,vehicle,ridestatus,fromplace,toplace,price);
                        cancelList.add(cancel);
                       // mAdapter.notifyDataSetChanged();

                        if(cancelList.isEmpty()){
                            takeFirstTv.setVisibility(View.VISIBLE);
                            recyclerView.setVisibility(View.GONE);
                        }
                        else{
                            takeFirstTv.setVisibility(View.GONE);
                            mAdapter = new CancelAdapter(cancelList,getActivity());
                            recyclerView.setHasFixedSize(true);

                            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
                            recyclerView.setLayoutManager(mLayoutManager);
                            recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
                            recyclerView.setItemAnimator(new DefaultItemAnimator());
                            recyclerView.setAdapter(mAdapter);

                        }

                    }
                }else {
                    String errorMsg = jsonObj.getString("error_msg");
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(getActivity(),error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
