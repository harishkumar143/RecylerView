package com.kouchan.dyutpassenger.View.Fragments;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.google.gson.Gson;
import com.kouchan.dyutpassenger.Adapter.AddedMoneyHistoryAdapter;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.models.AddedMoneyHistoryModel;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AddedMoneyHistoryFragment extends Fragment implements OnRequestListener {

    @BindView(R.id.addedMoneyRecyclerView)
    RecyclerView addedMoneyHistoryRecyclerView;

    AsyncInteractor asyncInteractor;

    AddedMoneyHistoryModel addedMoneyHistoryModel;
    String url= Url.BASE_URL+"paytmlib/transactionhistory.php?unique_id=";
    SessionManager sessionManager;
    AddedMoneyHistoryAdapter moneyHistoryAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.added_money_history,container,false);
        ButterKnife.bind(this, view);
        sessionManager=new SessionManager(getActivity());
        asyncInteractor=new AsyncInteractor(getActivity());
        intializeViews();

        return view;
    }



    private void intializeViews() {

       // Utils.showProgress(getActivity());
        asyncInteractor.validateCredentialsAsync(this,AppConstants.add_money_transaction_history,url+sessionManager.getUniqueId(),null);

    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        if(pid==AppConstants.add_money_transaction_history){
            try {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    Gson gson=new Gson();
                    addedMoneyHistoryModel=   gson.fromJson(responseJson.toString(),AddedMoneyHistoryModel.class);

                    if(getActivity()!=null){

                        moneyHistoryAdapter=new AddedMoneyHistoryAdapter(getActivity(),addedMoneyHistoryModel.getTXNRECORDS());
                        addedMoneyHistoryRecyclerView.setHasFixedSize(true);
                        addedMoneyHistoryRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                        addedMoneyHistoryRecyclerView.setNestedScrollingEnabled(false);
                        addedMoneyHistoryRecyclerView.setItemAnimator(new DefaultItemAnimator());
                        addedMoneyHistoryRecyclerView.setAdapter(moneyHistoryAdapter);
                    }

                } else {
                    String errorMsg = jObj.getString("error_msg");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(getActivity());
        Utils.showToast(getActivity(),error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
