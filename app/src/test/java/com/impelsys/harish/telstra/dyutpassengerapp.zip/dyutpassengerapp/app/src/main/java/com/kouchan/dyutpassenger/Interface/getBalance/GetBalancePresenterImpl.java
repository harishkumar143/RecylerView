package com.kouchan.dyutpassenger.Interface.getBalance;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.VolleyJsonObjectRequest;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class GetBalancePresenterImpl implements IGetBalancePresnter,OnRequestListener {


    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IGetBalanceView getBalanceView;
    SessionManager sessionManager;
    Context context;

    String url= Url.BASE_URL+"paytmlib/getdyutbalance.php";


    public GetBalancePresenterImpl(IGetBalanceView getBalanceView, Context context) {

        this.sharedpreferences = Sharedpreferences.getUserDataObj(context);
        this.asyncInteractor = new AsyncInteractor(context);
        this.getBalanceView = getBalanceView;
        this.context=context;
        sessionManager=new SessionManager(context);
    }

    @Override
    public void getBalance(String mobileNo) {
        if(NetworkStatus.checkNetworkStatus(context)){


            Map<String, String> params = new HashMap<String, String>();

            params.put("mobile", mobileNo);
            params.put("user_type","PASSENGER");

            asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_GETBALANCE,url,new JSONObject(params));

        }
        else {
            Utils.showToast(context, "Please connect to internet");
        }
    }


    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if(pid==AppConstants.TAG_ID_GETBALANCE){
        //    Utils.stopProgress(navHome);
            if(responseJson!=null){
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if(!error) {
                    getBalanceView.getBalanceSuccess(pid,jObj.getString("dyut_account_balance"));
                }
                else {
                    getBalanceView.getBalanceError(pid,jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(context);
        getBalanceView.getBalanceError(pid,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        Utils.stopProgress(context);
        getBalanceView.getBalanceError(pid,error);
    }
}
