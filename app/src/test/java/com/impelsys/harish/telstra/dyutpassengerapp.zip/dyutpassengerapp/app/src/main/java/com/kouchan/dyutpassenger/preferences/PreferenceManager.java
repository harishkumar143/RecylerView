package com.kouchan.dyutpassenger.preferences;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by basavaraj on 5/3/17.
 */

public class PreferenceManager {
  private SharedPreferences mSharedPreferences;
  private SharedPreferences.Editor mEditor;
  private static PreferenceManager preferenceManager;
  private Context mContext;


  public static PreferenceManager getInstance(Context context) {
    if (preferenceManager == null) {
      preferenceManager = new PreferenceManager(context);
    }
    return preferenceManager;
  }

  private PreferenceManager() {

  }

  private PreferenceManager(Context context) {
    mSharedPreferences = android.preference.PreferenceManager.getDefaultSharedPreferences(context);
    mEditor = mSharedPreferences.edit();
  }


  public void saveFCMToken(String token) {
    mEditor.putString(KeyConstants.KEY_FCM_TOKEN, token);
    mEditor.commit();
  }
  public String getFcmToken() {
    return mSharedPreferences.getString(KeyConstants.KEY_FCM_TOKEN, "");
  }


  public String getAadharNum() {
    return mSharedPreferences.getString(KeyConstants.AADHAR_NUM, "");
  }


  public void saveAadharNum(String aadhar) {
    mEditor.putString(KeyConstants.AADHAR_NUM, aadhar);
    mEditor.commit();
  }

  public String getAlternateNum() {
    return mSharedPreferences.getString(KeyConstants.USER_ALTERNATE_NUM, "");
  }

  public String getOAuthToken() {
    return mSharedPreferences.getString(KeyConstants.OAUTH_TOKEN, "");
  }

public  void saveOAuthToken(String token){
  mEditor.putString(KeyConstants.OAUTH_TOKEN, token);
  mEditor.commit();
}


  public String getForgotPasswordOauthToken() {
    return mSharedPreferences.getString(KeyConstants.FORGOT_PASSWORD_OAUTH_TOKEN, "");
  }

  public  void saveForgotPasswordOauthToken(String token){
    mEditor.putString(KeyConstants.FORGOT_PASSWORD_OAUTH_TOKEN, token);
    mEditor.commit();

  }

  public String getRefreshToken() {
    return mSharedPreferences.getString(KeyConstants.REFRESH_TOKEN, "");

  }

  public  void saveRefreshToken(String refreshToken){
    mEditor.putString(KeyConstants.REFRESH_TOKEN, refreshToken);
    mEditor.commit();

  }
  public void saveAlternateNum(String alternateNum) {
    mEditor.putString(KeyConstants.USER_ALTERNATE_NUM, alternateNum);
    mEditor.commit();
  }



  public String getUserDetails() {
    return mSharedPreferences.getString(KeyConstants.USER_DETAILS, ""); // TODO: 18-01-2018 storing all user related data here. 
  }


  public void saveUserProfilePicture(String userDetails) {
    mEditor.putString(KeyConstants.USER_PHOTO, userDetails);
    mEditor.commit();
  }

  public String getUserProfilePicture() {
    return mSharedPreferences.getString(KeyConstants.USER_PHOTO, "");
  }


  public void saveUserDetailsData(String userDetails) {
    mEditor.putString(KeyConstants.KYC_STATUS, userDetails);
    mEditor.commit();
  }


  public String getTransactionBetweenPeriodData() {
    return mSharedPreferences.getString(KeyConstants.TRANSACTION_BETWEEN_PERIOD, "");
  }

  public void saveTransactionBetweenPeriodData(String userDetails) {
    mEditor.putString(KeyConstants.TRANSACTION_BETWEEN_PERIOD, userDetails);
    mEditor.commit();
  }


  public String getUserDetailsData() {
    return mSharedPreferences.getString(KeyConstants.KYC_STATUS, "");
  }

  public void saveUserDetails(String userDetails) {
    mEditor.putString(KeyConstants.USER_DETAILS, userDetails);
    mEditor.commit();
  }

  public boolean isOtpVerified() {
    return mSharedPreferences.getBoolean(KeyConstants.IS_OTP_VERIFIED, false);
  }


  public boolean setOtpVerified(boolean password) {
    mEditor.putBoolean(KeyConstants.IS_OTP_VERIFIED, password);
    mEditor.commit();
    return password;
  }

  public boolean isDailogShow() {
    return mSharedPreferences.getBoolean(KeyConstants.CLOSE_DAILOG, false);
  }


  public boolean setDailogShow(boolean close) {
    mEditor.putBoolean(KeyConstants.CLOSE_DAILOG, close);
    mEditor.commit();
    return close;
  }
}
