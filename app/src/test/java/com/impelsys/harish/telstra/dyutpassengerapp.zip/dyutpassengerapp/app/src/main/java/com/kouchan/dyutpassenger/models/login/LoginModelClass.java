package com.kouchan.dyutpassenger.models.login;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

public class LoginModelClass {

    /**
     * error : false
     * access_token : e68cdaa7756588ca23ba27ab918dff6ff0dd10a35d06195218
     * expires_in : 300
     * token_type : Bearer
     * refresh_token : 95795f495b4f809c9bb1bcc93e5103239ffbc5612692cff832
     * scope : BOOKARIDE
     * id : 3
     * user : {"unique_id":"BRP5003","name":"Ghyanmitra Jiblapnor","mobile":"9870738322","email":"ghyanmitra@kouchanindia.com","block_status":"0","dyut_account_balance":"566.34","created_at":"2019-05-03 12:26:49","ride_cancel_count":"0","encrypted_password":"vrKKOZNG5pIOJ+Tpw8XWOmDem4BiNTNjNWQxZGYz"}
     */

    @SerializedName("error")
    private boolean error;

    @SerializedName("error_msg")
    private String error_msg;

    @SerializedName("login_device")
    private String login_device;

    @SerializedName("access_token")
    private String accessToken;
    @SerializedName("expires_in")
    private String expiresIn;
    @SerializedName("token_type")
    private String tokenType;
    @SerializedName("refresh_token")
    private String refreshToken;
    @SerializedName("scope")
    private String scope;
    @SerializedName("id")
    private int id;
    @SerializedName("user")
    private UserBean user;

    public static LoginModelClass objectFromData(String str) {

        return new Gson().fromJson(str, LoginModelClass.class);
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }

    public String getLogin_device() {
        return login_device;
    }

    public void setLogin_device(String login_device) {
        this.login_device = login_device;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(String expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public UserBean getUser() {
        return user;
    }

    public void setUser(UserBean user) {
        this.user = user;
    }

    public static class UserBean {
        /**
         * unique_id : BRP5003
         * name : Ghyanmitra Jiblapnor
         * mobile : 9870738322
         * email : ghyanmitra@kouchanindia.com
         * block_status : 0
         * dyut_account_balance : 566.34
         * created_at : 2019-05-03 12:26:49
         * ride_cancel_count : 0
         * encrypted_password : vrKKOZNG5pIOJ+Tpw8XWOmDem4BiNTNjNWQxZGYz
         */

        @SerializedName("unique_id")
        private String uniqueId;

        @SerializedName("name")
        private String name;
        @SerializedName("mobile")
        private String mobile;
        @SerializedName("email")
        private String email;
        @SerializedName("block_status")
        private String blockStatus;
        @SerializedName("dyut_account_balance")
        private String dyutAccountBalance;
        @SerializedName("created_at")
        private String createdAt;
        @SerializedName("ride_cancel_count")
        private String rideCancelCount;
        @SerializedName("encrypted_password")
        private String encryptedPassword;

        public static UserBean objectFromData(String str) {

            return new Gson().fromJson(str, UserBean.class);
        }

        public String getUniqueId() {
            return uniqueId;
        }

        public void setUniqueId(String uniqueId) {
            this.uniqueId = uniqueId;
        }


        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getBlockStatus() {
            return blockStatus;
        }

        public void setBlockStatus(String blockStatus) {
            this.blockStatus = blockStatus;
        }

        public String getDyutAccountBalance() {
            return dyutAccountBalance;
        }

        public void setDyutAccountBalance(String dyutAccountBalance) {
            this.dyutAccountBalance = dyutAccountBalance;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public String getRideCancelCount() {
            return rideCancelCount;
        }

        public void setRideCancelCount(String rideCancelCount) {
            this.rideCancelCount = rideCancelCount;
        }

        public String getEncryptedPassword() {
            return encryptedPassword;
        }

        public void setEncryptedPassword(String encryptedPassword) {
            this.encryptedPassword = encryptedPassword;
        }
    }


}
