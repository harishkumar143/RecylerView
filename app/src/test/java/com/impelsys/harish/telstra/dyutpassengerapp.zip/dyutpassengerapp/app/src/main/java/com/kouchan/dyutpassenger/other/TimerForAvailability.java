package com.kouchan.dyutpassenger.other;

import android.content.Context;
import android.os.CountDownTimer;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by KOUCHAN-ADMIN on 8/24/2017.
 */

public class TimerForAvailability {

    Context context;
    String isAvailable,mobile;
    SessionManager sessionManager;
    String availabilityUpdateURL= Url.COMUNICATE_API+"driverStatus.php";
    CountDownTimer countDownTimer;


    public TimerForAvailability(Context context){
        this.context=context;
    }

    public void starTimer(){

       /* this.isAvailable=isAvailable;*/
        setCountDownTimer();
        countDownTimer.start();
      //  updateAvailability();

    }

    public void setCountDownTimer(){
        countDownTimer = new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {

                /*sessionManager=new SessionManager(context);
                sessionManager.setUpdateButton("waiting");*/

              /*  menuDriver.updateButton();*/

             /*   Intent i1 = new Intent (context, NavHome.class);
                context.startActivity(i1);*/
         /*       if(sessionManager.getTimer()!="1")
                {

                isAvailable="AVAILABLE";
                }
                updateAvailability();*/
            }
        };
    }

    public void stopTimer(String isAvailable){
        this.isAvailable=isAvailable;
        if(countDownTimer != null) {
            countDownTimer.cancel();
            countDownTimer = null;
        }
      //  updateAvailability();

    }


    public void updateAvailability() {

        sessionManager=new SessionManager(context);
        HashMap<String, String> user = new HashMap<String, String>();
        user=sessionManager.getUserDetails();
        mobile=user.get("mobile");
        StringRequest updateDriverLocation = new StringRequest(Request.Method.POST, availabilityUpdateURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {



                            } else {

                                // Error occurred in registration. Get the error
                                // message
                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("drivermobile", mobile);
                params.put("status", isAvailable);

                return params;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(updateDriverLocation);
    }

}
