package com.kouchan.dyutpassenger.places.api;

public interface ApiListener<T, E> {
    void onSuccess(T data);

    void onFailure(E error);
}
