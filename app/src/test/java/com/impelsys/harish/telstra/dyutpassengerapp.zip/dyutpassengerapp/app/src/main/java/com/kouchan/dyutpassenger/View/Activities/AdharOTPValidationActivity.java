package com.kouchan.dyutpassenger.View.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kouchan.dyutpassenger.Database.PrefManager;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Interface.aadharotpvalidate.AadharOtpValidatePresenterImpl;
import com.kouchan.dyutpassenger.Interface.aadharotpvalidate.IAadharValidateOtpPresnter;
import com.kouchan.dyutpassenger.Interface.aadharotpvalidate.IAadharValidateOtpView;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AdharOTPValidationActivity extends AppCompatActivity implements IAadharValidateOtpView {

    private TextView phoneNoView;
    private EditText phoneCodeView;
    private Button phoneVerifyButton;
    //private TextView phoneTimer;
    private TextView resendOtpButton;
    private TextView resendOtpDesc;


    IAadharValidateOtpPresnter iAadharValidateOtpPresnter;

    TextView verify_otp_textView,phone_verify_desc;
    String languageCode;
    Resources resources;

    String mobile, otpmsg;



    SessionManager sessionManager;
    PrefManager prefManager;
    HashMap<String, String> user = new HashMap<String, String>();

    /*  Bus eventBus;*/

    String VERIFY_OTP_URL = "";

    String RESEND_OTP_URL = "";

    private final int COUNT_DOWN_TIME = 60 * 1000; // 60 sec
    private final int COUNT_DOWN_INTERVAL = 1000;  // 1 sec
    private boolean isCodeFetchDone = false;
    Sharedpreferences sharedpreferences;

    Toolbar mToolbar;
    ImageView verifyOTPBackImageView;

    String otpFromServer;
    String otpEntered;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adhar_otpvalidation);
        prefManager = new PrefManager(getApplicationContext());
        prefManager.setIsWaitingForSms(true);
        iAadharValidateOtpPresnter = new AadharOtpValidatePresenterImpl(this);
        sharedpreferences = Sharedpreferences.getUserDataObj(this);
        sessionManager = new SessionManager(getApplicationContext());
        user = sessionManager.getUserDetails();
        mobile = user.get("mobile");

        VERIFY_OTP_URL = Url.DRIVER_API + "register.php";
        RESEND_OTP_URL = Url.DRIVER_API + "sendotpforregistration.php";



        EventBusManager.getInstance().getEventBus().register(this);

        phoneNoView = (TextView) findViewById(R.id.phone_verify_number_tv);
        phoneCodeView = (EditText) findViewById(R.id.phone_verify_code);
        // phoneTimer = (TextView) findViewById(R.id.phone_verify_timer);
        phoneVerifyButton = (Button) findViewById(R.id.phone_verification_submit);/*
        resendOtpDesc = (TextView) findViewById(R.id.phone_verify_resend_otp_description);*/
        resendOtpButton = (TextView) findViewById(R.id.phone_verification_resend_otp_button);
/*
        phone_verify_desc = (TextView) findViewById(R.id.phone_verify_desc);*/
        verify_otp_textView = (TextView) findViewById(R.id.verify_otp_textView);

        resendOtpButton.setVisibility(View.GONE);/*
        resendOtpDesc.setVisibility(View.GONE);*/
        phoneNoView.setText(getIntent().getStringExtra("mobile"));
        phoneVerifyButton.setEnabled(true);

        phoneCodeView.setInputType(InputType.TYPE_CLASS_NUMBER);


        phoneVerifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                otpEntered = phoneCodeView.getText().toString();

                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(phoneCodeView.getWindowToken(),
                        InputMethodManager.RESULT_UNCHANGED_SHOWN);

                if (!otpEntered.isEmpty()) {
                    //otpFromServer=Integer.toString(getIntent().getIntExtra("otp",0));
                    iAadharValidateOtpPresnter.validateAadhatOtp(getIntent().getStringExtra("mobile"),getIntent().getStringExtra("password"),otpEntered);
                } else {
                    Toast.makeText(AdharOTPValidationActivity.this, resources.getString(R.string.otp_empty), Toast.LENGTH_LONG).show();
                }
            }
        });

        resendOtpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                resendOtpButton.setVisibility(View.GONE);
                resendOtpDesc.setVisibility(View.GONE);
                sendOtpRequest();
//                sendValues();
                // countDownTimer.start();
            }
        });
        // mDialog.show();
        //  countDownTimer.start();

        initializeViews();

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        verify_otp_textView.setText(resources.getString(R.string.verify_otp));
        phoneCodeView.setHint(resources.getString(R.string.enter_otp));
        phoneVerifyButton.setText(resources.getString(R.string.verify));
        resendOtpButton.setText(resources.getString(R.string.resend_otp));
    }


    @Override
    protected void onResume() {
        super.onResume();
    }

    /*@Subscribe //todo remvoing because sms permision changed in android
    public void onOTPReceivedFromSMS(SMSOtpMessage smsOtpMessage) {
        isCodeFetchDone = true;
        otpmsg = smsOtpMessage.getOtp();
        phoneCodeView.setText(otpmsg);
    }*/


    public void sendValues() {

        final ProgressDialog loading = ProgressDialog.show(this, resources.getString(R.string.logging), resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, VERIFY_OTP_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {


                                prefManager.setIsWaitingForSms(false);
                                sessionManager.setIsLogin(true);

                                String id = jObj.getString("id");

                                JSONObject user = jObj.getJSONObject("user");
                                String stringName = user.getString("name");
                                String stringMobile = user.getString("mobile");
                                String email = user.getString("email");
                                String created_at = user.getString("created_at");

                                sessionManager.createLoginSession(stringName, stringMobile);
                                sessionManager.createId(id);
                                sessionManager.createEmail(email);

                                startActivity(new Intent(AdharOTPValidationActivity.this, NavHome.class));
                                finish();


                            } else {

                                // Error occurred in registration. Get the error
                                // message
                                String errorMsg = jObj.getString("message");
                                Toast.makeText(getApplicationContext(),
                                        errorMsg, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                        Toast.makeText(AdharOTPValidationActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                params.put("email",getIntent().getStringExtra("email"));
                params.put("mobile",getIntent().getStringExtra("mobile"));
                params.put("password",getIntent().getStringExtra("password"));
                params.put("name",getIntent().getStringExtra("name"));
                params.put("bdate",getIntent().getStringExtra("bdate"));
                params.put("gender",getIntent().getStringExtra("gender"));
                params.put("alternateName",getIntent().getStringExtra("alternateName"));
                params.put("alternateMobile",getIntent().getStringExtra("alternateMobile"));
                params.put("messagingid",getIntent().getStringExtra("messagingid"));
                params.put("pin",getIntent().getStringExtra("pin"));
                params.put("adharno",getIntent().getStringExtra("adharno"));
                params.put("otp",otpEntered);

                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public void sendValuesDriver() {

        final ProgressDialog loading = ProgressDialog.show(this, resources.getString(R.string.logging), resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, VERIFY_OTP_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {


                                prefManager.setIsWaitingForSms(false);
                                sessionManager.setIsLogin(true);

                                String id = jObj.getString("id");

                                JSONObject user = jObj.getJSONObject("user");
                                String stringName = user.getString("name");
                                String stringMobile = user.getString("mobile");
                                String email = user.getString("email");
                                String created_at = user.getString("created_at");

                                sessionManager.createLoginSession(stringName, stringMobile);
                                sessionManager.createId(id);
                                sessionManager.createEmail(email);


                                startActivity(new Intent(AdharOTPValidationActivity.this, NavHome.class));
                                finish();


                            } else {

                                // Error occurred in registration. Get the error
                                // message
                                String errorMsg = jObj.getString("message");
                                Toast.makeText(getApplicationContext(),
                                        errorMsg, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                        Toast.makeText(AdharOTPValidationActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                params.put("email",getIntent().getStringExtra("email"));
                params.put("mobile",getIntent().getStringExtra("mobile"));
                params.put("password",getIntent().getStringExtra("password"));
                params.put("name",getIntent().getStringExtra("name"));
                params.put("bdate",getIntent().getStringExtra("bdate"));
                params.put("gender",getIntent().getStringExtra("gender"));
                params.put("alternateName",getIntent().getStringExtra("alternateName"));
                params.put("alternateMobile",getIntent().getStringExtra("alternateMobile"));
                params.put("vehicleno",getIntent().getStringExtra("vehicleno"));
                params.put("vehicletype",getIntent().getStringExtra("vehicletype"));
                params.put("driverlicence",getIntent().getStringExtra("driverlicence"));
                params.put("driverphoto",getIntent().getStringExtra("driverphoto"));
                params.put("messagingid",getIntent().getStringExtra("messagingid"));
                params.put("vehicleColor",getIntent().getStringExtra("vehicleColor"));
                params.put("vehicleModel",getIntent().getStringExtra("vehicleModel"));
                params.put("pin",getIntent().getStringExtra("pin"));
                params.put("adharno",getIntent().getStringExtra("adharno"));
                params.put("driver_licence_expiry",getIntent().getStringExtra("driver_licence_expiry"));
                params.put("otp", otpEntered);

                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public void sendOtpRequest() {
        final ProgressDialog loading = ProgressDialog.show(this, resources.getString(R.string.logging), resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, RESEND_OTP_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                PrefManager prefManager = new PrefManager(getApplicationContext());
                                prefManager.setIsWaitingForSms(true);

                                otpFromServer=Integer.toString(jObj.getInt("otp"));


                            } else {

                                // Error occurred in registration. Get the error
                                // message
                                String errorMsg = jObj.getString("message");
                                Toast.makeText(getApplicationContext(),
                                        errorMsg, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                        Toast.makeText(AdharOTPValidationActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                params.put("email",getIntent().getStringExtra("email"));
                params.put("mobile",getIntent().getStringExtra("mobile"));
                params.put("password",getIntent().getStringExtra("password"));
                params.put("name",getIntent().getStringExtra("name"));
                params.put("bdate",getIntent().getStringExtra("bdate"));
                params.put("gender",getIntent().getStringExtra("gender"));
                params.put("alternateName",getIntent().getStringExtra("alternateName"));
                params.put("alternateMobile",getIntent().getStringExtra("alternateMobile"));
                params.put("messagingid",getIntent().getStringExtra("messagingid"));
                params.put("pin",getIntent().getStringExtra("pin"));
                params.put("adharno",getIntent().getStringExtra("adharno"));

                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();

        Intent intent = new Intent(AdharOTPValidationActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();


    }

    private void initializeViews() {
        setSupportActionBar(mToolbar);
        verifyOTPBackImageView = (ImageView) findViewById(R.id.verifyOTPBackImageView);

        verifyOTPBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(AdharOTPValidationActivity.this, LoginActivity.class);
                startActivity(intent);


            }
        });
    }

    @Override
    public void aadharOtpSuccess(int pid, String bookARideResponseModel) {
        Utils.stopProgress(this);

        /*sessionManager.setUniqueId(bookARideResponseModel.getUser().getUnique_id());
        sessionManager.createEmail(bookARideResponseModel.getUser().getEmail());
        sessionManager.createLoginSession(bookARideResponseModel.getUser().getName(),bookARideResponseModel.getUser().getMobile());
        sessionManager.setBlockstatus(bookARideResponseModel.getUser().getBlock_status());
        sessionManager.createId(String.valueOf(bookARideResponseModel.getUser_id()));*/
        Intent intent = new Intent(AdharOTPValidationActivity.this, NavHome.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void aadharOtpError(int pid, String error) {
        Utils.stopProgress(this);
        Toast.makeText(getApplicationContext(),error,Toast.LENGTH_LONG).show();
        Intent intent = new Intent(AdharOTPValidationActivity.this, NavHome.class);
        startActivity(intent);
        finish();
    }
}
