package com.kouchan.dyutpassenger.Interface.getBalance;

public interface IGetBalancePresnter {

    void getBalance(String mobileNumber);

}
