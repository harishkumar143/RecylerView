package com.kouchan.dyutpassenger.View.Activities;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.CurrentRide;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class PaymentStatusActivity extends AppCompatActivity implements OnRequestListener {

    TextView amountPaid, mode, paymentStatusText, transId, date,thanks,referenceId;
    Button okButton;
    AsyncInteractor asyncInteractor;
    ImageView shareImage;
    String drivermobile, booking_id, amount, payment_mode, comingFrom;
    private String transIdString;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_status);

        asyncInteractor = new AsyncInteractor(this);
        amountPaid = (TextView) findViewById(R.id.amountPaid);
        paymentStatusText = (TextView) findViewById(R.id.paymentStatusText);
        transId = (TextView) findViewById(R.id.transId);
        date = (TextView) findViewById(R.id.date);
        thanks = (TextView) findViewById(R.id.thanks);
        referenceId = (TextView) findViewById(R.id.referenceId);
        mode = (TextView) findViewById(R.id.mode);
        okButton = (Button) findViewById(R.id.okButton);
        shareImage = (ImageView) findViewById(R.id.shareImage);

        Intent i = getIntent();

        if (i != null) {

            if (getIntent().getStringExtra("comingFrom") != null) {
                comingFrom = getIntent().getStringExtra("comingFrom");
            }

            if (comingFrom != null) {
                if (getIntent().getStringExtra("comingFrom").equalsIgnoreCase("CancelRide")) {
                    booking_id = getIntent().getStringExtra("booking_id");
                    transIdString = getIntent().getStringExtra("transaction_id");
                    amount = getIntent().getStringExtra("amount");
                    payment_mode = getIntent().getStringExtra("payment_mode");
                    transId.setText("TXN Id : " + transIdString);
                    referenceId.setText("Reference Id : " + booking_id);
                }
                else if (getIntent().getStringExtra("comingFrom").equalsIgnoreCase("HDFC")) {
                    comingFrom="hdfc";
                    booking_id = getIntent().getStringExtra("txnId");
                    amount = getIntent().getStringExtra("amount");
                    payment_mode = getIntent().getStringExtra("mode");

                    transId.setText("TXN Id : " + booking_id);
                    referenceId.setVisibility(View.GONE);
                }

                else {
                    drivermobile = getIntent().getStringExtra("drivermobile");
                    booking_id = getIntent().getStringExtra("booking_id");
                    amount = getIntent().getStringExtra("amount");
                    payment_mode = getIntent().getStringExtra("payment_mode");
                    transIdString = getIntent().getStringExtra("transaction_id");
                    transId.setText("TXN Id : " + transIdString);
                    referenceId.setText("Reference Id : " + booking_id);
                }


                amountPaid.setText("₹ " + amount);


                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                date.setText("Date :"+formatter.format(new Date())); //todo need to take from server
            }


        }


        if (payment_mode.equalsIgnoreCase("CASH")) {
            mode.setText(getString(R.string.paymentModeCash));
            paymentStatusText.setText(getString(R.string.payToDriver));
        }
        else if (payment_mode.equalsIgnoreCase("CC")) {
            mode.setText(getString(R.string.payment_successfully));
            paymentStatusText.setVisibility(View.GONE);
            thanks.setVisibility(View.GONE);

        }
        else {
            mode.setText(getString(R.string.paymentModeDYUT));
            paymentStatusText.setText(R.string.payment_successfully);
        }


        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (comingFrom.equalsIgnoreCase("CancelRide")) {
                    Intent intent3 = new Intent(getApplicationContext(), NavHome.class);
                    CurrentRide currentRide = new CurrentRide(getApplicationContext());
                    currentRide.setIsRideStarted("ended");
                    startActivity(intent3);
                    finish();
                }
                else if(comingFrom.equalsIgnoreCase("hdfc")){

                    startActivity(new Intent(PaymentStatusActivity.this,NavHome.class));
                    finish();
                }else {
                    apiCall();
                    Intent intent3 = new Intent(getApplicationContext(), FeedbackActivity.class);
                    CurrentRide currentRide = new CurrentRide(getApplicationContext());
                    currentRide.setIsRideStarted("ended");
                    intent3.putExtra("drivermobile", drivermobile);
                    intent3.putExtra("booking_id", booking_id);
                    startActivity(intent3);
                    finish();
                }

            }
        });

        shareImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, "My app name");
                String strShareMessage = "Amount paid to driver :" + amount + "\nPayment mode :" + payment_mode;
                //  Uri screenshotUri = Uri.parse("android.resource://packagename/drawable/image_name");
                // i.setType("image/png");
                //  i.putExtra(Intent.EXTRA_STREAM, screenshotUri);
                i.putExtra(Intent.EXTRA_TEXT, strShareMessage);
                startActivity(Intent.createChooser(i, "Share Vai"));

            }
        });
    }

    private void apiCall() {
        String emailUrl = Url.BASE_URL+"PHPMailer-master/email.php?booking_id=" + booking_id;
        asyncInteractor.onPostMethodServerCall(this, AppConstants.RIDE_SUCCESS_MAIL, emailUrl, null);

    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
