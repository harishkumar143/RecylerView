package com.kouchan.dyutpassenger.Interface.changedestination;

public interface IChangeDestinationPresnter {

    void changeDestination(String bookingid,String current_place,String new_destination_name,
                           String current_placelatitude,String current_placelongitude
            ,String new_destinationlatitude,String new_destinationlongitude);

}
