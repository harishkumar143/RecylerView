package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ChangePasswordActivity extends AppCompatActivity implements OnRequestListener {


    EditText currentPassword, newPassword, confirmNewPassword;
    Button submit_button;
    AsyncInteractor asyncInteractor;
    String stringCurrentPassword, stringNewPassword, stringConfirmNewPassword, passengermobile, type;
    SessionManager sessionManager;
    HashMap<String, String> user;
    String driURL = "";
    Toolbar mToolbar;
    ImageView changepasswordBackImageView, changepasswordHomeImageView;

    TextView change_password_textView, changePasswordLabel;
    TextInputLayout currentPassword_TextInput, newPassword_TextInput, confirmNewPassword_TextInput;
    String languageCode;
    Resources resources;

    public AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);


        initializeWidget();
        /*sendValue();*/
        selection();

        change_password_textView = (TextView) findViewById(R.id.change_password_textView);
        changePasswordLabel = (TextView) findViewById(R.id.changePasswordLabel);
        currentPassword_TextInput = (TextInputLayout) findViewById(R.id.currentPassword_TextInput);
        newPassword_TextInput = (TextInputLayout) findViewById(R.id.newPassword_TextInput);
        confirmNewPassword_TextInput = (TextInputLayout) findViewById(R.id.confirmNewPassword_TextInput);

        submit_button = (Button) findViewById(R.id.changePasswordButton);
        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendValue();
                sendNotification();
            }
        });

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        change_password_textView.setText(resources.getString(R.string.change_password));
        changePasswordLabel.setText(resources.getString(R.string.change_password));

        currentPassword_TextInput.setHint(resources.getString(R.string.enter_current_password));
        newPassword_TextInput.setHint(resources.getString(R.string.enter_new_password));
        confirmNewPassword_TextInput.setHint(resources.getString(R.string.confirm_password));
        submit_button.setHint(resources.getString(R.string.submit));
    }

    private void selection() {
        driURL = Url.PASSENGER_API + "changePassword.php";

    }

    private void initializeWidget() {

        sessionManager = new SessionManager(getApplicationContext());
        asyncInteractor=new AsyncInteractor(this);

        currentPassword = (EditText) findViewById(R.id.currentPasswordId);
        newPassword = (EditText) findViewById(R.id.newPasswordId);
        confirmNewPassword = (EditText) findViewById(R.id.confirmNewPasswordId);

        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        changepasswordBackImageView = (ImageView) findViewById(R.id.changepasswordBackImageView);

        changepasswordBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ChangePasswordActivity.this, SecurityAndSettingsActivity.class);
                startActivity(intent);
                finish();
            }
        });

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        /*String regexPassword = ".{8,}";*/
        String regexPassword = ".{6,8}";
        awesomeValidation.addValidation(this, R.id.newPassword, regexPassword, R.string.passworderror);
       /* awesomeValidation.addValidation(this, R.id.currentPasswordId, regexPassword, R.string.passworderrorold);*/
        awesomeValidation.addValidation(this, R.id.confirmNewPasswordId, R.id.newPasswordId, R.string.invalid_confirm_password);

    }


    private void sendValue() {

        user = new HashMap<String, String>();
        user = sessionManager.getUserDetails();
        passengermobile = user.get("mobile");
        stringCurrentPassword = currentPassword.getText().toString();
        stringNewPassword = newPassword.getText().toString();
        stringConfirmNewPassword = confirmNewPassword.getText().toString();

    }

    public void sendNotification() {
        if (!(awesomeValidation.validate())) {

            //process the data further
        } else {

            Utils.showProgress(this);

            Map<String, String> params = new HashMap<String, String>();

            params.put("mobile", passengermobile);
            params.put("oldpassword", stringCurrentPassword);
            params.put("newpassword", stringNewPassword);

            asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_CHANGE_PASSWORD,Url.PASSENGER_API+ServerApiNames.CHANGE_PASSWORD,new JSONObject(params));


          /*  StringRequest stringRequestNotification = new StringRequest(Request.Method.POST, driURL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {

                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {

                                    String error_msg = jObj.getString("message");
                                    Toast.makeText(ChangePasswordActivity.this, error_msg, Toast.LENGTH_SHORT).show();
                                    Intent i=new Intent(ChangePasswordActivity.this,LoginActivity.class);
                                    startActivity(i);
                                    finish();

                                } else {

                                    String errorMsg = jObj.getString("error_msg");
                                    Toast.makeText(ChangePasswordActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                         }
                    }) {

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String, String> params = new HashMap<String, String>();

                    params.put("mobile", passengermobile);
                    params.put("oldpassword", stringCurrentPassword);
                    params.put("newpassword", stringNewPassword);

                    return params;
                }
            };
            VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequestNotification);*/
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {


        if(pid==AppConstants.TAG_ID_CHANGE_PASSWORD){
            Utils.stopProgress(this);
            try {

                Utils.stopProgress(this);
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    String error_msg = jObj.getString("message");
                    Toast.makeText(ChangePasswordActivity.this, error_msg, Toast.LENGTH_SHORT).show();

                    sessionManager.logoutUser(ChangePasswordActivity.this);
                    finish();

                } else {

                    String errorMsg = jObj.getString("error_msg");
                    Toast.makeText(ChangePasswordActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(this);
        Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
