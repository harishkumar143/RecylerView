
package com.kouchan.dyutpassenger.BroadcastReceivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.Status;
import com.kouchan.dyutpassenger.Interface.SMSConstants;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.models.SMSOtpMessage;


public class BookARideSMSReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        Log.e("onReceive:","onReceive"+"Called"+intent.getAction());

        if (SmsRetriever.SMS_RETRIEVED_ACTION.equals(intent.getAction())) {
            Bundle extras = intent.getExtras();
            Status status = (Status) extras.get(SmsRetriever.EXTRA_STATUS);
            Log.e("messageStringTimeout:","Response:"+status);
            switch(status.getStatusCode()) {
                case CommonStatusCodes.SUCCESS:
                    // Get SMS message contents
                    String message = (String) extras.get(SmsRetriever.EXTRA_SMS_MESSAGE);

                    Log.e("messageString:","messageString"+message);
                    onOtpReceived(message);

                    // Extract one-time code from the message and complete verifica
                    //
                    //tion
                    // by sending the code back to your server.
                    break;
                case CommonStatusCodes.TIMEOUT:
                    // Waiting for SMS timed out (5 minutes)
                    // Handle the error ...
                    onOtpReceived("timeout");
                    Log.e("messageStringTimeout:","timeout");
                    break;
            }


        }
    }

 /*   private final static String SMS_PDU_IDENTIFIER = "pdus";
    private static final String TAG = BookARideSMSReceiver.class.getName();


    @Override
    public void onReceive(Context context, Intent intent) {

            final Bundle bundle = intent.getExtras();

        try {
            if (bundle != null) {
                final Object[] pdusObj = (Object[]) bundle.get(SMS_PDU_IDENTIFIER);
                SmsMessage currentMessage;
                for (int i = 0; i < pdusObj.length; i++) {

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        String format = bundle.getString("format");
                        currentMessage = SmsMessage.createFromPdu((byte[]) pdusObj[i], format);
                    } else {
                        currentMessage = SmsMessage.createFromPdu((byte[]) pdusObj[i]);
                    }
                    String senderNum = currentMessage.getDisplayOriginatingAddress();
                    String message = currentMessage.getDisplayMessageBody();
                    //check if message is a M3 OTP Message
                    if (message.endsWith(SMSConstants.OTP_SMS_END_STRING)) {
                        String otp = message.substring(0, 4);
                        onOtpReceived(otp);
                    }
                }
            }
        } catch (Exception e) {

            Log.e(TAG, "Exception smsReceiver" + e.toString());

        }
    }

    private void onOtpReceived(String otp) {

        SMSOtpMessage SMSOtpMessage = new SMSOtpMessage(otp);
        EventBusManager.getInstance().getEventBus().post(SMSOtpMessage);

    }*/

    private void onOtpReceived(String otp) {

        SMSOtpMessage SMSOtpMessage = new SMSOtpMessage(otp);
        EventBusManager.getInstance().getEventBus().post(SMSOtpMessage);

    }
}

