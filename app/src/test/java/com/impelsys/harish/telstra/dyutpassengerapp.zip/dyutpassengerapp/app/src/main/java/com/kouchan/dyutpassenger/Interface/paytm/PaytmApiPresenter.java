package com.kouchan.dyutpassenger.Interface.paytm;

public interface PaytmApiPresenter {
    void paytmGenerateChecksum(String orderId, String custId,String txnAmount);
}
