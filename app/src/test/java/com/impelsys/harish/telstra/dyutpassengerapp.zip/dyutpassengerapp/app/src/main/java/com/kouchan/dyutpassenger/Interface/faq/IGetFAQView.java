package com.kouchan.dyutpassenger.Interface.faq;

public interface IGetFAQView {

    void getFAQSuccess(int pid, String response);

    void getFAQError(int pid, String error);

}
