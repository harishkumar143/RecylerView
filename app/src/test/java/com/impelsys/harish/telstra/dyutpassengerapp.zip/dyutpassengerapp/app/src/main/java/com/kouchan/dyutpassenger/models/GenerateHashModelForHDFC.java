package com.kouchan.dyutpassenger.models;

import com.google.gson.annotations.SerializedName;

public class GenerateHashModelForHDFC {


    /**
     * error : false
     * txnid : 4bd24ee0ea7c015ab73d
     * user_credentials : 7rnFly:ghyan@gmail.com
     * MERCHANT_KEY : 7rnFly
     * SALT : pjVQAWpA
     * payment_hash : b1afdcff4f8f2a12283c3f7227947721e7af88a7fcafc80f2893d21fdf3e0b335203feabf003984074e50400a1424015ab4f38c25742414b4951e31ce4e86f16
     * get_merchant_ibibo_codes_hash : eb58593c0090b426cdeed6ef2536337ea4da6a907b29a27313b22b77586f54637abc4183c340181c28da2ed5fde60f11215adda70e739c42f6799c848037aa38
     * vas_for_mobile_sdk_hash : ca4f689de7db52e3bab5c9be0109bb4dcb361a5795795dd6b29d577917bb73e515c5038d5c4563798fce416fb7fa0a53b3cc9b11530a3a7979dc2f360e56d239
     * emi_hash : 4d95dd11e7a56b37652449c5a785d8cf659ad9c781ee4ae3e0a79b13ff13283cef0698813ca7e2a541448b5ffa64697281b2c02ff78da10d48036e3d9d26a384
     * payment_related_details_for_mobile_sdk_hash : 65ea16c8f539e9b198b8b681a09a7a5b92cc9805269eff077609af8a498943c3d21b2ec306eb21a4a615f3279b9fd972ac8dae6a9ab1b20ebbe7195126912012
     * verify_payment_hash : 9769879d0bb879b3fd24317fc594d92349c67da86912dc9ad4634b573a8187a6d6afd762843d3d59a43edc9c9ca3f94d37d1dc3919e269bca2123122afaa2e3d
     * delete_user_card_hash : ca562a728c3f441e638a5be9808085b9d6cad15ecc5df5480cc2a75af402b58bdd5959d330947b23b0250b028fdc581c4fcc80f8c6fe1c52702edb67c7f91f27
     * get_user_cards_hash : fd94be9672e44d716ea342f1d566948c1aad7e434aa06f3cdfb02790d88a1c7b132de0eb6481ed6590079135a0f1b57dec416b1f690873956d4736a16ed91b32
     * edit_user_card_hash : a94a45efc86fe715fdc8da53afe3b152efb05d8a2d471ac9f1ed59063c2418e2972f8ad53ade17d41c3967cb1140105d209014acec9dc83b471d79096274526c
     * save_user_card_hash : 95ea7eee8abe4f28fe1dfece37026b5c553d8fc6271475ed4ba7f7c3d3688f9e0f7905cd3e035ed91f1d12820f016a79c7616619d58e79e9da6d9f44097ac38c
     * send_sms_hash : 78aeba07d9cd0d9d9ef48e94ee629235fdc035edd916e7cb1122d9818a80e654c51d6ae96ecd375a736bcabf015e78d795c87f0cc2367d6cf80ca5207fbaee72
     */

    @SerializedName("error")
    private boolean mError;
    @SerializedName("txnid")
    private String mTxnid;
    @SerializedName("user_credentials")
    private String mUserCredentials;
    @SerializedName("MERCHANT_KEY")
    private String mMERCHANTKEY;
    @SerializedName("SALT")
    private String mSALT;
    @SerializedName("payment_hash")
    private String mPaymentHash;
    @SerializedName("get_merchant_ibibo_codes_hash")
    private String mGetMerchantIbiboCodesHash;
    @SerializedName("vas_for_mobile_sdk_hash")
    private String mVasForMobileSdkHash;
    @SerializedName("emi_hash")
    private String mEmiHash;
    @SerializedName("payment_related_details_for_mobile_sdk_hash")
    private String mPaymentRelatedDetailsForMobileSdkHash;
    @SerializedName("verify_payment_hash")
    private String mVerifyPaymentHash;
    @SerializedName("delete_user_card_hash")
    private String mDeleteUserCardHash;
    @SerializedName("get_user_cards_hash")
    private String mGetUserCardsHash;
    @SerializedName("edit_user_card_hash")
    private String mEditUserCardHash;
    @SerializedName("save_user_card_hash")
    private String mSaveUserCardHash;
    @SerializedName("send_sms_hash")
    private String mSendSmsHash;

    public boolean isError() {
        return mError;
    }

    public void setError(boolean error) {
        mError = error;
    }

    public String getTxnid() {
        return mTxnid;
    }

    public void setTxnid(String txnid) {
        mTxnid = txnid;
    }

    public String getUserCredentials() {
        return mUserCredentials;
    }

    public void setUserCredentials(String userCredentials) {
        mUserCredentials = userCredentials;
    }

    public String getMERCHANTKEY() {
        return mMERCHANTKEY;
    }

    public void setMERCHANTKEY(String mERCHANTKEY) {
        mMERCHANTKEY = mERCHANTKEY;
    }

    public String getSALT() {
        return mSALT;
    }

    public void setSALT(String sALT) {
        mSALT = sALT;
    }

    public String getPaymentHash() {
        return mPaymentHash;
    }

    public void setPaymentHash(String paymentHash) {
        mPaymentHash = paymentHash;
    }

    public String getGetMerchantIbiboCodesHash() {
        return mGetMerchantIbiboCodesHash;
    }

    public void setGetMerchantIbiboCodesHash(String getMerchantIbiboCodesHash) {
        mGetMerchantIbiboCodesHash = getMerchantIbiboCodesHash;
    }

    public String getVasForMobileSdkHash() {
        return mVasForMobileSdkHash;
    }

    public void setVasForMobileSdkHash(String vasForMobileSdkHash) {
        mVasForMobileSdkHash = vasForMobileSdkHash;
    }

    public String getEmiHash() {
        return mEmiHash;
    }

    public void setEmiHash(String emiHash) {
        mEmiHash = emiHash;
    }

    public String getPaymentRelatedDetailsForMobileSdkHash() {
        return mPaymentRelatedDetailsForMobileSdkHash;
    }

    public void setPaymentRelatedDetailsForMobileSdkHash(String paymentRelatedDetailsForMobileSdkHash) {
        mPaymentRelatedDetailsForMobileSdkHash = paymentRelatedDetailsForMobileSdkHash;
    }

    public String getVerifyPaymentHash() {
        return mVerifyPaymentHash;
    }

    public void setVerifyPaymentHash(String verifyPaymentHash) {
        mVerifyPaymentHash = verifyPaymentHash;
    }

    public String getDeleteUserCardHash() {
        return mDeleteUserCardHash;
    }

    public void setDeleteUserCardHash(String deleteUserCardHash) {
        mDeleteUserCardHash = deleteUserCardHash;
    }

    public String getGetUserCardsHash() {
        return mGetUserCardsHash;
    }

    public void setGetUserCardsHash(String getUserCardsHash) {
        mGetUserCardsHash = getUserCardsHash;
    }

    public String getEditUserCardHash() {
        return mEditUserCardHash;
    }

    public void setEditUserCardHash(String editUserCardHash) {
        mEditUserCardHash = editUserCardHash;
    }

    public String getSaveUserCardHash() {
        return mSaveUserCardHash;
    }

    public void setSaveUserCardHash(String saveUserCardHash) {
        mSaveUserCardHash = saveUserCardHash;
    }

    public String getSendSmsHash() {
        return mSendSmsHash;
    }

    public void setSendSmsHash(String sendSmsHash) {
        mSendSmsHash = sendSmsHash;
    }
}
