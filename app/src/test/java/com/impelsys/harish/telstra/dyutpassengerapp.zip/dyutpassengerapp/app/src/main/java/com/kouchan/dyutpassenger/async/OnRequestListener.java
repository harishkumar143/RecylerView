package com.kouchan.dyutpassenger.async;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public interface OnRequestListener {
    void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray);

    void onRequestCompletion(int pid, String responseJson) throws JSONException;

    void onRequestCompletionError(int pid, String error);

    void onRequestCompletionHomeError(int pid, String error);
}
