package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;


public class CancellationActivity extends AppCompatActivity {

    Button gotoHome;
    String stringReason,type;
    TextView reason,your_ride_has_been_cancelled_textView,reason_textView;

    SessionManager sessionManager;
    String languageCode;
    Resources resources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancellation);

        sessionManager=new SessionManager(getApplicationContext());

        reason= (TextView)findViewById(R.id.cancelation_reason);

        your_ride_has_been_cancelled_textView= (TextView)findViewById(R.id.your_ride_has_been_cancelled_textView);
        reason_textView= (TextView)findViewById(R.id.reason_textView);

        gotoHome=(Button)findViewById(R.id.goToHome);

        stringReason=getIntent().getStringExtra("reason");
        type=getIntent().getStringExtra("type");

        reason.setText(stringReason);


        gotoHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(type.equals("immediate")) {

                sessionManager.setUpdateButton("started");
                Intent i=new Intent(getApplicationContext(),NavHome.class);
                startActivity(i);

                }
                finish();
            }
        });

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {

            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
            your_ride_has_been_cancelled_textView.setText(resources.getString(R.string.your_ride_has_been_cancelled));
            reason_textView.setText(resources.getString(R.string.reason));
            gotoHome.setText(resources.getString(R.string.ok));

        }
    }

    private void updateViews(String languageCode) {

        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        your_ride_has_been_cancelled_textView.setText(resources.getString(R.string.your_ride_has_been_cancelled));
        reason_textView.setText(resources.getString(R.string.reason));
        gotoHome.setText(resources.getString(R.string.ok));
    }
}
