package com.kouchan.dyutpassenger.View.Activities;

import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.CurrentRide;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.VolleyJsonObjectRequest;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class FeedbackActivity extends AppCompatActivity implements OnRequestListener {


    RatingBar ratingBar;
    Button button14;
    EditText editText2,bonusAmount;
    ProgressDialog loading;
    TextView good_will_textView;
    SessionManager sessionManager;
    String name, passengermobile, rating, comment="", drivermobile,bonusAmt;
    HashMap<String, String> user = new HashMap<String, String>();

    float rating_float;

    TextView feedback_textView, thanks_for_riding_bookaride_textView,
            give_rating_textView, what_didnt_worked_textView;

    String languageCode;
    Resources resources;

    AsyncInteractor asyncInteractor;
    String Feedback, sendEmail;
    Toolbar mToolbar;
    ImageView feedbackBackImageView, feedbackHomeImageView;

    String type, booking_id;

    CurrentRide currentRide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        addListenerOnButtonClick();

        NotificationManager notificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
        notificationManager.cancelAll();

        asyncInteractor=new AsyncInteractor(this);
        sessionManager = new SessionManager(getApplicationContext());
        currentRide = new CurrentRide(getApplicationContext());

        user = sessionManager.getUserDetails();

        feedback_textView = (TextView) findViewById(R.id.feedback_textView);
        thanks_for_riding_bookaride_textView = (TextView) findViewById(R.id.thanks_for_riding_bookaride_textView);
        give_rating_textView = (TextView) findViewById(R.id.give_rating_textView);
        what_didnt_worked_textView = (TextView) findViewById(R.id.what_didnt_worked_textView);

        initializeViews();

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        type = sessionManager.getType();
        switch (type) {
            case "passenger":

                Feedback = Url.PASSENGER_API + ServerApiNames.RATING;

                passengermobile = user.get("mobile");
                drivermobile = getIntent().getStringExtra("drivermobile");
                booking_id = getIntent().getStringExtra("booking_id");

                currentRide.setDrivermobile(getIntent().getStringExtra("drivermobile"));
                currentRide.setFeedbackStatus("notgiven");
                currentRide.setRideid(getIntent().getStringExtra("booking_id"));

                currentRide.setSosStatus("off");

                break;

            case "driver":

                Feedback = Url.DRIVER_API + "driverRatingtoPassenger.php";

                drivermobile = user.get("mobile");
                passengermobile = getIntent().getStringExtra("passengermobile");

              //  sendEmailToPassenger();

                currentRide.setFeedbackStatus("notgiven");
                break;

            case "both":

                Feedback = Url.PASSENGER_API + "driverRating.php";
                break;
        }


    }
    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        editText2.setHint(resources.getString(R.string.any_suggistion));

        feedback_textView.setText(resources.getString(R.string.feedback));
        thanks_for_riding_bookaride_textView.setText(resources.getString(R.string.thanks_for_riding_bookaride));
        give_rating_textView.setText(resources.getString(R.string.give_rating));
        what_didnt_worked_textView.setText(resources.getString(R.string.what_didnt_worked));
        good_will_textView.setText(resources.getString(R.string.YouMayGiveGoodwillBonus));
        bonusAmount.setHint(resources.getString(R.string.amountWithRupee));
        editText2.setHint(resources.getString(R.string.any_suggistion));
        button14.setText(resources.getString(R.string.submit));
    }


    public void addListenerOnButtonClick() {
        ratingBar = (RatingBar) findViewById(R.id.ratingBar);

        button14 = (Button) findViewById(R.id.button14);


        editText2 = (EditText) findViewById(R.id.editText2);
        bonusAmount = (EditText) findViewById(R.id.bonusAmount);
        good_will_textView = (TextView) findViewById(R.id.good_will_textView);

        //Performing action on Button Click
        button14.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                rating = String.valueOf(ratingBar.getRating());

                rating_float = ratingBar.getRating();

                comment = editText2.getText().toString();
                bonusAmt=bonusAmount.getText().toString();

                if (rating_float <= 2) {
                    if (comment.equals("")) {
                        Toast.makeText(FeedbackActivity.this, "Please tell us what goes wrong", Toast.LENGTH_SHORT).show();
                    } else {
                        driverComment();
                    }
                } else {
                    driverComment();
                }

                /*driverComment();*/
            }

        });

    }


    private void driverComment() {

        comment = editText2.getText().toString();

        Utils.showProgress(this);

        Map<String, String> params = new HashMap<String, String>();
        params.put("passengerMobile", passengermobile);
        params.put("driverMobile", drivermobile);
        params.put("rating", rating);
        params.put("comment", comment);
        params.put("bookingid",booking_id);

        if(bonusAmt==null || bonusAmt.equalsIgnoreCase("")){
            params.put("bonus_amount","NA");
        }
        else{
            params.put("bonus_amount",bonusAmt);
        }


        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_RATING, Url.PASSENGER_API+ServerApiNames.RATING,new JSONObject(params));
    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(FeedbackActivity.this, NavHome.class);
        startActivity(intent);
        finish();
    }

    private void initializeViews() {
        setSupportActionBar(mToolbar);

        feedbackBackImageView = (ImageView) findViewById(R.id.feedbackBackImageView);
        feedbackHomeImageView = (ImageView) findViewById(R.id.feedbackHomeImageView);

        feedbackBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FeedbackActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });

        feedbackHomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FeedbackActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        Utils.stopProgress(this);
        if(pid==AppConstants.TAG_ID_RATING)

            try {

                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    if (type.equals("driver")) {

                        SessionManager sessionManager = new SessionManager(getApplicationContext());
                        sessionManager.setUpdateButton("started");

                        Intent i = new Intent(FeedbackActivity.this, NavHome.class);
                        startActivity(i);

                        currentRide.setIsRideStarted("end");
                        currentRide.setFeedbackStatus("given");

                        finish();
                    } else {
                        Intent i = new Intent(FeedbackActivity.this, ThankYouPassengerActivity.class);
                        i.putExtra("booking_id", booking_id);
                        startActivity(i);
                        currentRide.setFeedbackStatus("given");
                        finish();
                    }

                } else {

                    String errorMsg = jObj.getString("error_msg");
                    Toast.makeText(FeedbackActivity.this, errorMsg, Toast.LENGTH_SHORT).show();

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
