package com.kouchan.dyutpassenger.Interface.getprofile;

import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.View.Activities.EditProfileActivity;
import com.kouchan.dyutpassenger.View.Activities.NavHome;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class GetProfilePresenterImpl implements IGetProfilePresnter, OnRequestListener {

    NavHome navHome;
   // EditProfileActivity editProfileActivity;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IGetProfileView getProfileView;

    public GetProfilePresenterImpl(IGetProfileView getProfileView) {
        this.navHome = (NavHome) getProfileView;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(navHome);
        this.asyncInteractor = new AsyncInteractor(navHome);
        this.getProfileView = getProfileView;
    }

    @Override
    public void getProfile(String mobileNo,String password) {
        if (NetworkStatus.checkNetworkStatus(navHome)) {

            Map<String,String> map=new HashMap();

            map.put("mobile",mobileNo);
            map.put("password",password);

            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_GETPROFILE, Url.PASSENGER_API +"getPassengerProfile.php",new JSONObject(map));
        } else {
            Utils.showToast(navHome, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if (pid == AppConstants.TAG_ID_GETPROFILE) {
            if (responseJson != null) {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    getProfileView.getProfileSuccess(pid, responseJson);
                } else {
                    getProfileView.getProfileError(pid, jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        getProfileView.getProfileError(pid, error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        getProfileView.getProfileError(pid, error);
    }
}
