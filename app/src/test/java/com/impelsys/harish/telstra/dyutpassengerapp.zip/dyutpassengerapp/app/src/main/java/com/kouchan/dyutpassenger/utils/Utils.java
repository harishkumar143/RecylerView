package com.kouchan.dyutpassenger.utils;

import android.Manifest;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {


    /*
     *  For Language
     * */

    public static String appCode = "";


    public static Context context;
    public static String updatedValues;
    public static int pet_position;
    public static String petImageUrl;
    public static String veterinarianId;
    public static String groomerId;
    public static String unreadNotificationCount;

    static String FILE_NAME = "TailTales";
    static final int DEFAULT_ICON = R.mipmap.ic_launcher;
    public static String currentUserWalletBalance;
  //  public static TransactionBetweenAGivenPeriodModel transactionBetweenAGivenPeriodModel = new TransactionBetweenAGivenPeriodModel();

    public static void selectAadharImage(Context menuItemsAdapter) {
        final CharSequence[] items = {"Take Photo", "Choose from Gallery", "Cancel"};

        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(menuItemsAdapter);
        builder.setTitle("Upload Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                // boolean result = Utils.checkPermission(CameraActivity.this);
                //  boolean resultCamera = Utils.checkCameraPermission(CameraActivity.this);

                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    if (true)
                        cameraIntentAadhar(activity);

                } else if (items[item].equals("Choose from Gallery")) {
                    userChoosenTask = "Choose from Gallery";
                    if (true)
                        galleryIntentAadhar(activity);

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    public interface dialogInterface {
        public void dialogClick();
    }




    /* add tail 1 screen params data*/

    public static HashMap<String, String> params = new HashMap<String, String>();


    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;
    public static final int MY_PERMISSIONS_REQUEST_CAMERA = 987;
    public static final int MY_PERMISSIONS_REQUEST_READ_PHONE = 456;


    static Activity activity;
    public static ProgressDialog progress;
    public static Bitmap bitmap = null;
    public static AlertDialog mAlertDialog;
    public static AlertDialog.Builder malertBuilder;
    public static TextView mAlertDialogOkTV, mAAlertDialogCancelTV;
    public static ArrayList<String> imageList = new ArrayList<>();

    public static String veterinarianName = "";
    public static String groomerName = "";


    public static int speciesArraySize = 0;
    public static String selectedBreedOfSpecies = "";
    public static String selectedRecords = "";

    public static int species_id = 0;

    public static ArrayList<String> latitudeList = new ArrayList<>();
    public static String selectedServices = "";


    public static ArrayList<String> bDFaqsQusForDog = new ArrayList<>();
    public static ArrayList<String> bDFaqsAnsForDog = new ArrayList<>();


    public static ArrayList<String> bDFaqsQusForCat = new ArrayList<>();
    public static ArrayList<String> bDFaqsAnsForCat = new ArrayList<>();


    public static String refreshedFirebaseTokenValue = "";

        public static void showProgress(Context context) {
            progress = new ProgressDialog(context);
            progress.setMessage("Please Wait");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.setCancelable(true);

            // if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            Drawable drawable = new ProgressBar(context).getIndeterminateDrawable().mutate();
            drawable.setColorFilter(ContextCompat.getColor(context, R.color.colorAccent),
                    PorterDuff.Mode.SRC_IN);
            progress.setIndeterminateDrawable(drawable);
            //  }

            progress.show();
        }

        public static void showProgress(Context context, String message) {
            progress = new ProgressDialog(context);
            progress.setMessage(message);
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.setCancelable(false);
            progress.show();
        }

        public static void stopProgress(Context context) {
            if(progress!=null)
            progress.dismiss();
        }

    /*
     * Encodes the form the url using namevaluepair & base url
     */
/*    public static String getEncodedUrl(String baseurl, List<BasicNameValuePair> nameValuePairs) {

        if (nameValuePairs != null) {
            String paramString = URLEncodedUtils.format(nameValuePairs,
                    "utf-8");
            baseurl += "?" + paramString;
            Log.e("--Encoded URL--", "-->>" + baseurl.toString());
        }
        return baseurl;
    }*/



    public static BigDecimal roundTo(BigDecimal amount, int digits) {
        return amount.setScale(digits, RoundingMode.DOWN);
    }

    public static void showToast(Context context, String str) {
        if(context!=null){
            Toast toast = Toast.makeText(context,str, Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
    }

    public static void makeSnackBar(View view, String message) {
        Snackbar customSnackbar =
                Snackbar.make(view, "" + message, Snackbar.LENGTH_LONG);
        customSnackbar.show();
    }

    /*
     *Check Internet availability
     */
    public static boolean isInternetAvailable(Context context) {
        boolean isInternetAvailable = false;
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager
                    .getActiveNetworkInfo();
            isInternetAvailable = networkInfo != null && networkInfo.isAvailable()
                    && networkInfo.isConnectedOrConnecting();


        } catch (Exception e) {
            e.printStackTrace();
        }
        return isInternetAvailable;
    }

    public static boolean isStatusTrue(JSONObject jsonObject) {
        Boolean aStatus = false;
        if (jsonObject != null) {
            try {
                if (jsonObject.has(/*AppConstants.TAGNAME.STATUS.getValue()*/"status")) {
                    aStatus = jsonObject.getBoolean(/*AppConstants.TAGNAME.STATUS.getValue()
                    */"status");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return aStatus;
    }

    /**
     * Check particular node is array.
     *
     * @param jsonObject
     * @return true if particular node is Array.
     */
    public static boolean isJsonArray(JSONObject jsonObject, String key) {

        if (!jsonObject.isNull(key)) {

            try {
                jsonObject.getJSONArray(key);
                return true;
            } catch (JSONException e) {
                return false;
            }

        }
        return false;
    }

    /**
     * Check particular node is object.
     *
     * @param jsonObject
     * @return true if particular node is Object.
     */
    public static boolean isJsonObject(JSONObject jsonObject, String key) {

        if (!jsonObject.isNull(key)) {

            try {
                jsonObject.getJSONObject(key);
                return true;
            } catch (JSONException e) {
                return false;
            }

        }
        return false;
    }

    /**
     * Check particular node is having particular key.
     *
     * @param jsonObject
     * @return true if particular node is having key.
     */
    public static boolean isJsonKeyAvailable(JSONObject jsonObject, String key) {

        return jsonObject.has(key);

    }

    public static void putStringinPrefs(Context mContext, String mKey,
                                        String mVal) {
        SharedPreferences.Editor prefsEditorr = PreferenceManager
                .getDefaultSharedPreferences(mContext).edit();
        try {

            prefsEditorr.putString(mKey, mVal.toString());
            prefsEditorr.commit();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    /*
     * Create image and save in file system.
     */
    public static File createImage(Context context, int height, int width,
                                   View view, String fileName) {
        Bitmap bitmapCategory = getBitmapFromView(view, height, width);
        return createFile(context, bitmapCategory, fileName);
    }

    /*
     * save bitmap image in phone memory
     */
    public static File createFile(Context context, Bitmap bitmap,
                                  String fileName) {

        File externalStorage = Environment.getExternalStorageDirectory();
        String sdcardPath = externalStorage.getAbsolutePath();
        File reportImageFile = new File(sdcardPath + "/YourFolderName"
                + fileName + ".jpg");
        try {
            if (reportImageFile.isFile()) {
                reportImageFile.delete();
            }
            if (reportImageFile.createNewFile()) {
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                FileOutputStream fo = new FileOutputStream(reportImageFile);
                fo.write(bytes.toByteArray());
                bytes.close();
                fo.close();
                return reportImageFile;
            }
        } catch (Exception e) {
        }
        return null;
    }

    /*
     * Take view screen shots
     */
    public static Bitmap getBitmapFromView(View view, int totalHeight,
                                           int totalWidth) {

        Bitmap returnedBitmap = Bitmap.createBitmap(totalWidth, totalHeight,
                Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(returnedBitmap);
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null)
            bgDrawable.draw(canvas);
        else
            canvas.drawColor(Color.WHITE);

        view.measure(
                MeasureSpec.makeMeasureSpec(totalWidth, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(totalHeight, MeasureSpec.EXACTLY));
        view.layout(0, 0, totalWidth, totalHeight);
        view.draw(canvas);
        return returnedBitmap;
    }

/*    public static boolean isLocationEnabled(Context context) {

        final LocationManager manager = (LocationManager) context
                .getSystemService(Context.LOCATION_SERVICE);

        return manager != null
               && manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    public static String getDeviceIMEINo(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyManager.getDeviceId();
    }*/

    /*
     * This function copy InputStream bytes to OutputStream bytes
     *
     * @param InputStream
     *
     * @param OutputStream
     */
    public static void CopyStream(InputStream is, OutputStream os) {
        final int buffer_size = 1024;
        try {
            byte[] bytes = new byte[buffer_size];
            for (; ; ) {
                int count = is.read(bytes, 0, buffer_size);
                if (count == -1)
                    break;
                os.write(bytes, 0, count);
            }
        } catch (Exception ex) {
        }
    }

    /**
     * this method is used to navigate the user to the native sharing apps on
     * the device so that user can shared the data on the various social sites
     * success : opens the sharing apps list on the device
     */

    public static void navigateToSharedScreen(Context context, String title,
                                              String shareText, String link, Uri url) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("*/*");
//		intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, title + " " + shareText + " " + link);
        intent.putExtra(Intent.EXTRA_STREAM, url);
        context.startActivity(Intent.createChooser(intent, "Share"));
    }

    public static void hideKeyboard(Context context) {
        try {
            InputMethodManager imm = (InputMethodManager) context
                    .getSystemService(Context.INPUT_METHOD_SERVICE);

            if (imm != null) {
                imm.hideSoftInputFromWindow(((Activity) context)
                        .getCurrentFocus().getWindowToken(), 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Convert dp to px and vice-versa
     */
    public static int dpToPx(int dp) {
        return (int) (dp * Resources.getSystem().getDisplayMetrics().density);
    }

    public static int pxToDp(int px) {
        return (int) (px / Resources.getSystem().getDisplayMetrics().density);
    }

    /**
     * This method is used to convert the image into blurred bitmap image
     */
    public static Bitmap getBlurImage(Context context, Bitmap image) {
       /* Bitmap Icon = BitmapFactory.decodeResource(getResources(), R.mipmap.home_info);
        * Bitmap blurredBitmap = Utils.getBlurImage(this, Icon);
        * mLogoImg.setBackgroundDrawable(new BitmapDrawable(getResources(), blurredBitmap));
        */

        float BITMAP_SCALE = 0.25f;
        float BLUR_RADIUS = 9.5f;

        int width = Math.round(image.getWidth() * BITMAP_SCALE);
        int height = Math.round(image.getHeight() * BITMAP_SCALE);

        Bitmap inputBitmap = Bitmap.createScaledBitmap(image, width, height, false);
        Bitmap outputBitmap = Bitmap.createBitmap(inputBitmap);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                RenderScript rs = RenderScript.create(context);
                ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
                Allocation tmpIn = Allocation.createFromBitmap(rs, inputBitmap);
                Allocation tmpOut = Allocation.createFromBitmap(rs, outputBitmap);
                theIntrinsic.setRadius(BLUR_RADIUS);
                theIntrinsic.setInput(tmpIn);
                theIntrinsic.forEach(tmpOut);
                tmpOut.copyTo(outputBitmap);
            }
        } catch (Exception e) {

        }

        return outputBitmap;
    }

    public static void expand(final View v, int duration, int targetHeight) {

        int prevHeight = v.getHeight();
        v.setVisibility(View.VISIBLE);
        ValueAnimator valueAnimator = ValueAnimator.ofInt(prevHeight, targetHeight);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                v.getLayoutParams().height = (int) animation.getAnimatedValue();
                v.requestLayout();
            }
        });
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.setDuration(duration);
        valueAnimator.start();
    }

    public static void collapse(final View v, int duration, int targetHeight) {
        int prevHeight = v.getHeight();
        ValueAnimator valueAnimator = ValueAnimator.ofInt(prevHeight, targetHeight);
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                v.getLayoutParams().height = (int) animation.getAnimatedValue();
                v.requestLayout();
            }
        });
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.setDuration(duration);
        valueAnimator.start();
    }


    public static Bitmap getBitmap() {

        return bitmap;
    }

    public static void setBitMap(Bitmap bitmap) {

        Utils.bitmap = bitmap;
    }

    public static void setFont(TextView textView, String fontName) {
        textView.setTypeface(Typeface.createFromAsset(textView.getContext().getAssets(), "fonts/" + fontName));
    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static int getScreenHeight() {
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }


    /*Convert a Drawable object to a Bitmap object*/
    public static Bitmap convertToBitmap(Drawable drawable, int widthPixels, int heightPixels) {
        Bitmap mutableBitmap = Bitmap.createBitmap(widthPixels, heightPixels, Bitmap.Config
                .ARGB_8888);
        Canvas canvas = new Canvas(mutableBitmap);
        drawable.setBounds(0, 0, widthPixels, heightPixels);
        drawable.draw(canvas);
        return mutableBitmap;
    }

    /* convert between real pixel (px) and device indipenden pixel (dp, dip)*/
    private float px2Dp(float px, Context ctx) {
        return px / ctx.getResources().getDisplayMetrics().density;
    }

    private float dp2Px(float dp, Context ctx) {
        return dp * ctx.getResources().getDisplayMetrics().density;
    }

    /*
     * API 23 default component permissions
     */
    public static boolean checkPermission(Context context, String callPhone) {
        int result = ContextCompat.checkSelfPermission(context, callPhone);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }


    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public static boolean checkCameraPermission(final Context context) {
        int currentAPIVersion = Build.VERSION.SDK_INT;
        if (currentAPIVersion >= Build.VERSION_CODES.LOLLIPOP) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) !=
                    PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest
                        .permission.CAMERA)) {
                    AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
                    alertBuilder.setCancelable(true);
                    alertBuilder.setTitle("Permission necessary");
                    alertBuilder.setMessage("External storage permission is necessary");
                    alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface
                            .OnClickListener() {
                        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest
                                            .permission.CAMERA},
                                    MY_PERMISSIONS_REQUEST_CAMERA);
                        }
                    });
                    AlertDialog alert = alertBuilder.create();
                    alert.show();

                } else {
                    ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission
                            .CAMERA}, MY_PERMISSIONS_REQUEST_CAMERA);
                }
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }


    public static void hideStatusBar(Activity activity) {
        activity.requestWindowFeature(Window.FEATURE_NO_TITLE);
        activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


    }

    /*create and set Typeface to a textview*/

    public static void setTypeface(Activity activity, TextView view/*, String type*/) {
        Typeface typeface = null;
        typeface = Typeface.createFromAsset(activity.getAssets(), "fonts/GeorgiaRegularfont.ttf");

//        if (type.contains("bold")) {
//            typeface = Typeface.createFromAsset(activity.getAssets(), "fonts/GeorgiaRegularfont.ttf");
//        } else if (type.contains("regular")) {
//            typeface = Typeface.createFromAsset(activity.getAssets(), "fonts/AGENCYR.TTF");
//
//        }
        view.setTypeface(typeface);
    }


    /* select image*/


    public static String userChoosenTask;


    public static int REQUEST_CAMERA = 121, SELECT_FILE = 1;
    public static int RESULT_LOAD_IMAGE = 11;
    public static int REQUEST_CAMERA_RECTANGLE= 122;
    public static int RESULT_LOAD_IMAGE_Rectangle = 12;
    public static int REQUEST_CAMERA_AADHAR_PIC= 13;
    public static int RESULT_LOAD_AADHAR_PIC = 124;

    public static void selectImage(final Activity activity) {
        final CharSequence[] items = {"Take Photo", "Choose from Gallery",
                "Cancel"};

        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(activity);
        builder.setTitle("Upload Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                // boolean result = Utils.checkPermission(CameraActivity.this);
                //  boolean resultCamera = Utils.checkCameraPermission(CameraActivity.this);

                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    if (true)
                        cameraIntent(activity);

                } else if (items[item].equals("Choose from Gallery")) {
                    userChoosenTask = "Choose from Gallery";
                    if (true)
                        galleryIntent(activity);

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    public static void selectImageRectangle(final Activity activity) {
        final CharSequence[] items = {"Take Photo", "Choose from Gallery",
                "Cancel"};

        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(activity);
        builder.setTitle("Upload Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                // boolean result = Utils.checkPermission(CameraActivity.this);
                //  boolean resultCamera = Utils.checkCameraPermission(CameraActivity.this);

                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    if (true)
                        cameraIntentRectangle(activity);

                } else if (items[item].equals("Choose from Gallery")) {
                    userChoosenTask = "Choose from Gallery";
                    if (true)
                        galleryIntentRectangle(activity);

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private static void cameraIntentRectangle(Activity activity) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        activity.startActivityForResult(intent, REQUEST_CAMERA_RECTANGLE);
    }

    private static void galleryIntentRectangle(Activity activity) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        activity.startActivityForResult(Intent.createChooser(intent, "Select File"), RESULT_LOAD_IMAGE_Rectangle);
    }


    public static void galleryIntent(Activity activity) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        activity.startActivityForResult(Intent.createChooser(intent, "Select File"), RESULT_LOAD_IMAGE);
    }

    public static void cameraIntent(Activity activity) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        activity.startActivityForResult(intent, REQUEST_CAMERA);
    }

    public static void galleryIntentAadhar(Activity activity) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        activity.startActivityForResult(Intent.createChooser(intent, "Select File"), RESULT_LOAD_AADHAR_PIC);
    }

    public static void cameraIntentAadhar(Activity activity) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        activity.startActivityForResult(intent, REQUEST_CAMERA_AADHAR_PIC);
    }


    public static String onCaptureImageResult(Intent data, ImageView mImageView, TextView mTextView) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        //setting image captured through camera
        mImageView.setImageBitmap(thumbnail);
        mTextView.setVisibility(View.GONE);

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 60, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.PNG, 60, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();

              /*
               *to encode base64 from byte array use following method
               */

        String base64Image = Base64.encodeToString(byteArray, Base64.DEFAULT);
        return base64Image;
    }

    public static String onCaptureImageResultRectangle(Intent data, ImageView mImageView, TextView mTextView) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        //setting image captured through camera
        mImageView.setImageBitmap(thumbnail);
        mTextView.setVisibility(View.GONE);

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 60, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.PNG, 60, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();

              /*
               *to encode base64 from byte array use following method
               */

        String myRectangle = Base64.encodeToString(byteArray, Base64.DEFAULT);
        return myRectangle;
    }


    public static String onGalleryImageResult(Intent data, ImageView mImageView, TextView mTextView, Activity contextOfActivity) {
        Uri filePath = data.getData();
        String base64Image = null;
        Bitmap compressedBitmap;
        try {
            //Getting the Bitmap from Gallery
            bitmap = MediaStore.Images.Media.getBitmap(contextOfActivity.getContentResolver(), filePath);


            //Setting the Bitmap to ImageView
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 10, bytes);

            byte[] byteArray = bytes.toByteArray();
            compressedBitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
            //setting image picked from gallery
            mImageView.setImageBitmap(compressedBitmap);
            mTextView.setVisibility(View.GONE);
            base64Image = Base64.encodeToString(byteArray, Base64.DEFAULT);


        } catch (IOException e) {
            e.printStackTrace();
        }

        return base64Image;
    }

    public static String onGalleryImageResultRectangle(Intent data, ImageView mImageView, TextView mTextView, Activity contextOfActivity) {
        Uri filePath = data.getData();
        String myRectangle = null;
        Bitmap compressedBitmap;
        try {
            //Getting the Bitmap from Gallery
            bitmap = MediaStore.Images.Media.getBitmap(contextOfActivity.getContentResolver(), filePath);


            //Setting the Bitmap to ImageView
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 10, bytes);

            byte[] byteArray = bytes.toByteArray();
            compressedBitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
            //setting image picked from gallery
            mImageView.setImageBitmap(compressedBitmap);
            mTextView.setVisibility(View.GONE);
            myRectangle = Base64.encodeToString(byteArray, Base64.DEFAULT);


        } catch (IOException e) {
            e.printStackTrace();
        }

        return myRectangle;
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) activity.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(
                activity.getCurrentFocus().getWindowToken(), 0);
    }


    public static boolean isEmailValid(String email) {
        boolean isValid = false;

        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }

    public final static boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }




/*
    public static void settingViewsOnBasisOfInternetAvailability(Activity currentActivity, LinearLayout parentRoot, ImageView noInternetRootImg) {
        if (NetworkStatus.checkNetworkStatus(currentActivity)) {
            parentRoot.setVisibility(View.VISIBLE);
            noInternetRootImg.setVisibility(View.GONE);
        } else {
            noInternetRootImg.setVisibility(View.VISIBLE);
            parentRoot.setVisibility(View.GONE);

        }
    }*/

    //Remove all Special character from phone numbers
    public static String removeSpecialCharsFromPhoneNumber(String mobileNumber) {
      //  boolean startedWithPlus = false;

        //remove unknown characters, remove everything except numbers and plus
        //some phone numbers had unicode characters before + too
         mobileNumber = mobileNumber.replaceAll("[\\D]", "");
        mobileNumber.substring(mobileNumber.length()-10);

        //check if begins with plus
        /*if (updatedNumber.trim().startsWith("+")) {
            startedWithPlus = true;
        }*/

        //remove any trailing plus example: 938290384+932
        //updatedNumber = mobileNumber.replaceAll("[-+.^:,]", "");
        /*if (startedWithPlus) {
            updatedNumber = "" + updatedNumber;
        }*/

        return mobileNumber;
    }


    public static void sendDriverReadREceiptNetworkCall(final String id, final String passengerMobile, final String drivermobile, final Context context
    , String sendReadReceiptUrl) {

        if (Utils.isInternetAvailable(context)) {

            Utils.showProgress(context);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, sendReadReceiptUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                Utils.stopProgress(context);
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {




                                } else {


                                    String errorMsg = jObj.getString("error_msg");
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Utils.stopProgress(context);
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("bookingid", id);
                    params.put("passengermobile", passengerMobile);
                    params.put("drivermobile", drivermobile);
                    params.put("timestamp", String.valueOf(Calendar.getInstance().getTime()));
                    params.put("status", "1");

                    return params;
                }
            };

            VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);

        } else {

            Utils.showToast(context, "please connect to the internate");
        }
    }

    public static String getSHA256Hash(String data) {
        String result = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes("UTF-8"));
            return bytesToHex(hash); // make it printable
        }catch(Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }

    private final static char[] hexArray = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for ( int j = 0; j < bytes.length; j++ ) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    private static final AtomicLong LAST_TIME_MS = new AtomicLong();
    public static long uniqIdWithTimeStamp() {
        long now = System.currentTimeMillis();
        while(true) {
            long lastTime = LAST_TIME_MS.get();
            if (lastTime >= now)
                now = lastTime+1;
            if (LAST_TIME_MS.compareAndSet(lastTime, now))
                return now;
        }
    }

    public static Marker addMarker(LatLng latLng, GoogleMap map, BitmapDescriptor descriptor,String distance) {
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.flat(true);
        markerOptions.position(latLng);
        markerOptions.title(distance);
        markerOptions.icon(descriptor);
        map.addMarker(markerOptions);
        map.animateCamera(CameraUpdateFactory.zoomTo(13f));
        return map.addMarker(markerOptions);
    }

    public static void fixDirectionToScreen(Context context, Marker sourceMaker, Marker destinationMarker, GoogleMap map) {
        LatLngBounds.Builder builder = new LatLngBounds.Builder();
//the include method will calculate the min and max bound.
        builder.include(sourceMaker.getPosition());
        builder.include(destinationMarker.getPosition());
        LatLngBounds bounds = builder.build();

        int width = context.getResources().getDisplayMetrics().widthPixels;
        int height = context.getResources().getDisplayMetrics().heightPixels;
        int padding = (int) (width * 0.40); // offset from edges of the map 20% of screen

        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding);
        map.animateCamera(cu);
    }
}
