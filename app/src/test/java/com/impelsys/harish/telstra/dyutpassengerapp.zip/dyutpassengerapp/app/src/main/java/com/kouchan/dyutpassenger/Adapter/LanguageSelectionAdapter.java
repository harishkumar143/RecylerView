package com.kouchan.dyutpassenger.Adapter;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.LoginActivity;
import com.kouchan.dyutpassenger.View.Activities.NavHome;
import com.kouchan.dyutpassenger.View.Activities.SplashActivity;
import com.kouchan.dyutpassenger.holders.LanguageSelectionViewHolder;
import com.kouchan.dyutpassenger.utils.Utils;

import java.util.ArrayList;


/**
 * Created by kouchan on 22-12-2016.
 */

public class LanguageSelectionAdapter extends RecyclerView.Adapter<LanguageSelectionViewHolder> {

    private String comingFrom;
    private ArrayList<String> chooseYourLanguageForM3 = new ArrayList<>();
    private ArrayList<String> chooseYourLanguageForM3ArrayListInRespectiveLanguage = new ArrayList<>();

    SessionManager sessionManager;

    Context context;
    LayoutInflater layoutInflater;


    public LanguageSelectionAdapter(Context context, ArrayList<String> chooseYourLanguageForM3, ArrayList<String> chooseYourLanguageForM3ArrayListInRespectiveLanguage,String comingFrom) {
        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
        this.chooseYourLanguageForM3 = chooseYourLanguageForM3;
        this.chooseYourLanguageForM3ArrayListInRespectiveLanguage = chooseYourLanguageForM3ArrayListInRespectiveLanguage;
        this.comingFrom=comingFrom;
        sessionManager = new SessionManager(context);

    }


    @Override
    public LanguageSelectionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        Log.d("onCreateViewHolder", "onCreateViewHolder");
        View v = layoutInflater.inflate(R.layout.item_select_language_list, parent, false);
        LanguageSelectionViewHolder viewHolder = new LanguageSelectionViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(LanguageSelectionViewHolder holder, final int position) {

        //  holder.mLanguageNameInRespectiveTextView.setTypeface(Typeface.createFromAsset(context.getAssets(), "fonts/hindi.ttf"));
        holder.mLanguageNameInRespectiveTextView.setText(chooseYourLanguageForM3ArrayListInRespectiveLanguage.get(position));
        holder.mLanguageNameTextView.setText(chooseYourLanguageForM3.get(position));
        holder.selectLangRB.setChecked(position == sessionManager.getTAG_lang_code());


        holder.mItemRowOfLanguageSelectionLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sessionManager.setTAG_lang_code(holder.getAdapterPosition());

                if (position == 0) {

                    Utils.appCode = "en";

                    if(comingFrom.equalsIgnoreCase("SplashScreen")){
                        Intent intent = new Intent(context, SplashActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("en");

                    }
                    else{
                        Intent intent = new Intent(context, NavHome.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("en");

                    }

                } else if (position == 1) {

                    Utils.appCode = "hi";

                    if(comingFrom.equalsIgnoreCase("SplashScreen")){
                        Intent intent = new Intent(context, SplashActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("hi");


                    }
                    else{
                        Intent intent = new Intent(context, NavHome.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("hi");

                    }

                } else if (position == 2) {

                    Utils.appCode = "kn";

                    if (comingFrom.equalsIgnoreCase("SplashScreen")) {
                        Intent intent = new Intent(context, SplashActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("kn");

                    } else {
                        Intent intent = new Intent(context, NavHome.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("kn");

                    }
                } else if (position == 3) {

                    Utils.appCode = "te";

                    if (comingFrom.equalsIgnoreCase("SplashScreen")) {

                        Intent intent = new Intent(context, SplashActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("te");

                    } else {

                        Intent intent = new Intent(context, NavHome.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("te");
                    }

                } else if (position == 4) {

                    Utils.appCode = "ta";

                    if (comingFrom.equalsIgnoreCase("SplashScreen")) {

                        Intent intent = new Intent(context, SplashActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("ta");

                    } else {

                        Intent intent = new Intent(context, NavHome.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("ta");
                    }

                } else if (position == 5) {

                    Utils.appCode = "ml";

                    if (comingFrom.equalsIgnoreCase("SplashScreen")) {

                        Intent intent = new Intent(context, SplashActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("ml");

                    } else {

                        Intent intent = new Intent(context, NavHome.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("ml");
                    }

                } else if (position == 6) {
                    Utils.appCode = "mr";

                    if (comingFrom.equalsIgnoreCase("SplashScreen")) {

                        Intent intent = new Intent(context, SplashActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("mr");

                    } else {

                        Intent intent = new Intent(context, NavHome.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("mr");
                    }

                } else if (position == 7) {
                    Utils.appCode = "gu";

                    if (comingFrom.equalsIgnoreCase("SplashScreen")) {

                        Intent intent = new Intent(context, SplashActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("gu");

                    } else {

                        Intent intent = new Intent(context, NavHome.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("gu");
                    }

                } else if (position == 8) {
                    Utils.appCode = "bn";

                    if (comingFrom.equalsIgnoreCase("SplashScreen")) {

                        Intent intent = new Intent(context, SplashActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("bn");

                    } else {

                        Intent intent = new Intent(context, NavHome.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        context.startActivity(intent);
                        sessionManager.setKeyLanguageCode("bn");
                    }

                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return chooseYourLanguageForM3.size();
    }
}
