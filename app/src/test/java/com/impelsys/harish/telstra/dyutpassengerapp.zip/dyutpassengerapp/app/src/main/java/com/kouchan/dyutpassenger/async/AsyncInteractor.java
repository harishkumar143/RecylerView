package com.kouchan.dyutpassenger.async;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.DyutPassengerApplication;
import com.kouchan.dyutpassenger.GenerateOAuthToken;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.LoginActivity;
import com.kouchan.dyutpassenger.VolleyJsonObjectRequest;
import com.kouchan.dyutpassenger.models.OAuthToken;
import com.kouchan.dyutpassenger.models.tokenRegeneration.TokenReganeratedModel;
import com.kouchan.dyutpassenger.preferences.PreferenceManager;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AsyncInteractor {

    /******************************************************************************************
     * An Interactor helps models cross application boundaries such as networks or serialization
     * This LoginInteractor knows nothing about a UI or the LoginPresenter
     * Because this is an asynchronous call it will call back on the OnRequestListener when complete
     * ******************************************************************************************
     */

    Context context;
    boolean isTokenExpired = false;
    int count = 0;
    Sharedpreferences sharedpreferences;
    SessionManager sessionManager;
    private RequestQueue requestQueueForLocation;
    private static String TAG = "Asyc";

    public static final int DEFAULT_MAX_RETRIES = 0;
    public static final int TIME_OUT_TIME = 10000;

    public AsyncInteractor(Context context) {
        this.context = context;
        sharedpreferences = Sharedpreferences.getUserDataObj(context);
        sessionManager = new SessionManager(context);
    }

    public void validateCredentialsAsync(final OnRequestListener listener, final int pid, final
    String url, final JSONObject paramsMap, String s) {
        // creating a handler to delay the answer a couple of seconds
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                onPostMethodServerCall(listener, pid, url, paramsMap, "");
            }
        }, 500);
    }


    public void validateCredentialsAsync(final OnRequestListener listener, final int pid, final
    String url, final JSONObject paramsMap) {

        if (tokenExpiryCheck()) {
            Log.e("tokenExpiryCheck","tokenExpiryCheck token is expired-------------");
            regenrateAccessToken(listener, pid, url, paramsMap);
        } else {
            onPostMethodServerCall(listener, pid, url, paramsMap);
        }

    }

    private boolean tokenExpiryCheck() {
        String token_time = sharedpreferences.getOauthTokenExpiryTime();
        Log.e("tokenExpiryCheck", "token_time -------- " + token_time);
        if (token_time.equals("0")) {
            Log.e("tokenExpiryCheck", "Token is expired -------- 0 ");
            return true;
        } else {
            long token_expiry_time = Long.parseLong(token_time);
            long current_time = System.currentTimeMillis() / 1000;
            Log.e("tokenExpiryCheck", "current_time -------- " + current_time);
            if (current_time < token_expiry_time) {
                // token is not expired
                Log.e("tokenExpiryCheck", "Token is not expired -------- ");
                return false;
            } else {
                // token is expired.
                Log.e("tokenExpiryCheck", "Token is expired -------- ");
                return true;
            }


        }

    }

    private void onPostMethodServerCall(OnRequestListener listener, int pid, String url, JSONObject jsonObject, String s) {

        if (pid == AppConstants.TAG_ID_LOGIN) {
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });

            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_VALIDATE_AADHAR_OTP) {
            // JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {


                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }


                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_AADHAR_OTP) {
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {

                                listener.onRequestCompletionError(pid, error.toString());
                                // }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });


            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_REGISTER) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_VERIFY_OTP) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_OTP) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                listener.onRequestCompletion(pid, response.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GENERATE_TOKEN) {
            GenerateOAuthToken oAuthToken = new GenerateOAuthToken(Request.Method.POST, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        listener.onRequestCompletion(pid, response.toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    try {
                        String errorMsg = volleyErrorHandler(error);
                        listener.onRequestCompletionError(pid, errorMsg);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(oAuthToken);
        } else if (pid == AppConstants.TAG_ID_PAYMENT) {

            RequestQueue requestQueue;

            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_BOOKRIDERESENDOTP) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });

            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_PASSENGER_REGISTER) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_UPDATE_PASSWORD) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_FORGOT_PASSWORD) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        }
    }


    public void onPostMethodServerCall(final OnRequestListener listener, final int pid,
                                       final String url, final JSONObject jsonObject) {

        if (pid == AppConstants.TAG_ID_PAYTM_CHECKSUM) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.addmoneytodyut) {

            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.Add_To_Dyut_Wallet_From_HDFC) {

            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.HDFC_PAYMENT_HASH) {

            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GETBALANCE) {

            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.DRIVER_ARRIVAL_TIME) {

            RequestQueue requestQueue = null;
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            requestQueueForLocation = DyutPassengerApplication.getInstance().getRequestQueue();
            if (requestQueueForLocation != null) {
                Log.e("requestQueueForLocation", "requestQueueForLocation----- " + requestQueueForLocation.hashCode());
                requestQueueForLocation.add(stringRequest);
            }

        } else if (pid == AppConstants.RIDE_SUCCESS_MAIL) {

            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GETPROFILE) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_passengerHistoryByDateDetails) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };
            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_PassengerHistoryByMonth) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_PpassengerHistoryByMonthDetails) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_RATING) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_VehiclesDistanceAndTime) {

            RequestQueue requestQueue = null;
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            if (requestQueue == null) {
                requestQueue = Volley.newRequestQueue(this.context);
                requestQueue.add(stringRequest);
            }

        } else if (pid == AppConstants.TAG_ID_PassengerHistoryByBookingId) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GET_NEAR_BY_DRIVERS) {

            RequestQueue requestQueue = null;
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            requestQueueForLocation = DyutPassengerApplication.getInstance().getRequestQueue();
            if (requestQueueForLocation != null) {
                Log.e("requestQueueForLocation", "requestQueueForLocation----- " + requestQueueForLocation.hashCode());
                requestQueueForLocation.add(stringRequest);
            }
        } else if (pid == AppConstants.TAG_ID_GET_FAVOURITE) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GET_EMERGANCY_DETAILS) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_ADD_Favourite) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_LOGOUT) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_ADAVANCE_BOOKING_PASSENGER) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };
            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_ADAVANCE_BOOKING_BY_ID) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_bookingCancellationOfDriver) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_driverOfferToCustomer) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_driverResponseTimeOut) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.endRideFromDriver) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GET_COMMENTS_SUBJECT) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GET_COMMENTS_BEFORE_RIDE_START_CANCELLATION) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.passengerCancel) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.passengerSelectionOfDriver) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.paymentReceipt) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.removePassengerFromDriverOfferList) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.rideRequest) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.rideStart) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.distanceCalculateByLatLongNew) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.CANCELLLED_HISTORY_OFPASSENGER) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.emergancy_contact_update) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.PUT, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.cancelRideComments) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.GET_DRIVER_LOCATION) {


            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            requestQueueForLocation = DyutPassengerApplication.getInstance().getRequestQueue();
            if (requestQueueForLocation != null) {
                Log.e("requestQueueForLocation", "requestQueueForLocation----- " + requestQueueForLocation.hashCode());
                requestQueueForLocation.add(stringRequest);
            }

        } else if (pid == AppConstants.ADVANCE_BOOKING_OF_PASSENGER) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.add_money_transaction_history) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.updateLatLong) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.sosbuttton) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_driverDetailAfterBooking) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_CANCELLED_BYDRIVER) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_bookingCancellationOfPassenger) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_APK_VERSION) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e("TAG_ID_APK_VERSION","TAG_ID_APK_VERSION---"+response.toString());
                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_CHANGE_PASSWORD) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_COMPLAINT_REGISTER) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_EDITPROFILE) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.PUT, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_AFTERCANCEL) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_BEFORECANCEL) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_FAQ) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_CHANGEDESTINATION) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_DELETEFAVOURITE) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        } else if (pid == AppConstants.TAG_ID_GET_COMPLAINTS) {
            //JSONObject object = new JSONObject(stringMap);
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, url, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            isTokenExpered(response, listener, pid, url, jsonObject);
                            // listener.onRequestCompletion(pid, response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                String errorMsg = volleyErrorHandler(error);
                                listener.onRequestCompletionError(pid, errorMsg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }) {

                /** Passing some request headers* */
                @Override

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Accesstoken", sharedpreferences.getOauthToken());
                    return headers;
                }
            };

            // Adding request to volley request queue
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(TIME_OUT_TIME,
                    DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this.context);
            requestQueue.add(stringRequest);

        }
    }

    private boolean isTokenExpered(JSONObject object, OnRequestListener listener, int pid, String url, JSONObject jsonObject) {

        JSONObject jObj = null;
        try {
            jObj = new JSONObject(object.toString());
            boolean error = jObj.getBoolean("error");
            if (!error) {
                listener.onRequestCompletion(pid, object.toString());

                if(jObj!=null){
                    Log.e("Success", object.toString() + " URL:" + url +" Response :" + jObj);
                }
            } else {
                String errorMsg = jObj.getString("error_msg");

                if (errorMsg.equalsIgnoreCase("Access Token Expired") || errorMsg.equalsIgnoreCase("Invalid Access Token")) {
                    Log.e("errorMsg", "ErrorMsg=" + errorMsg + " URL:" + url);
                    regenrateAccessToken(listener, pid, url, jsonObject);
                } else {

                    if(jsonObject!=null){
                        Log.e("errorMsg", "ErrorMsg=" + errorMsg + " URL:" + url+" Req :" + jsonObject);
                    }
                    Utils.stopProgress(context);
                    listener.onRequestCompletionError(pid, errorMsg);
                    // Utils.showToast(context,errorMsg);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return isTokenExpired;
    }

    public void regenrateAccessToken(final OnRequestListener listener, final int pid,
                                     final String url, final JSONObject jsonObject) {

        String genarateTokenUrl = Url.OAUTH_URL +"secret&username=" + sharedpreferences.getUserId() + "&password=" + sharedpreferences.getEncriptedPassword() + "&device_id=" + sharedpreferences.getTagDeviceId() + "&scope";

        VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, genarateTokenUrl, new JSONObject(),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        TokenReganeratedModel authToken = new Gson().fromJson(response.toString(), TokenReganeratedModel.class);

                        if (!authToken.isError()) {

                            sharedpreferences.setOauthToken(authToken.getAccessToken());
                            // sharedpreferences.setRefreshTokenToken(authToken.getRefreshToken());
                            sharedpreferences.setOauthTokenExpiryTime(authToken.getExpiresIn());

                            Log.d("accessToken", authToken.getAccessToken());

                            validateCredentialsAsync(listener, pid, url, jsonObject);
                        } else {

                            try {

                                JSONObject jObj = new JSONObject(response.toString());
                                String errorMsg = jObj.getString("login_device");

                                if (errorMsg.equalsIgnoreCase("DEVICE_ERROR")) {
                                    logout();
                                }

                                Log.d("Token Response: ", "Token res : " + response.toString());

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        try {
                            logout();
                            //Utils.showToast(context,error.toString());

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

        // Adding request to volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this.context); // todo once got: java.lang.OutOfMemoryError: Could not allocate JNI Env
        requestQueue.add(stringRequest);

    }

    private void logout() {

        try {

            logoutOperation();
           /* if (!((Activity) context).isFinishing()) {
                sessionFinish();
                //show dialog
            }*/
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void sessionFinish() {
        final Dialog dialog = new Dialog(context);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setContentView(R.layout.verify_password_dialog);
        //dialog.setTitle("Password verification");
        ImageView close = (ImageView) dialog.findViewById(R.id.closeContactUsRootImageView);
        final EditText mPassword = (EditText) dialog.findViewById(R.id.password);
        mPassword.setVisibility(View.GONE);
        close.setVisibility(View.GONE);
        final TextView mText = (TextView) dialog.findViewById(R.id.text);
        mText.setText("Session time out You need to logout now.");
        Button mSubmit = (Button) dialog.findViewById(R.id.submit);
        mSubmit.setText("Ok");

        mSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logoutOperation();
            }
        });

        dialog.show(); //todo android.view.WindowManager$BadTokenException: Unable to add window
    }

    private void logoutOperation() {
        PreferenceManager.getInstance(context).setOtpVerified(false);
        PreferenceManager.getInstance(context).saveOAuthToken("");
        PreferenceManager.getInstance(context).saveRefreshToken("");
        sharedpreferences.setOauthToken("");
        // sharedpreferences.setRefreshTokenToken("");
        sharedpreferences.setOauthTokenExpiryTime("");

        sessionManager.clearAll(context);

        Intent intent = new Intent(context, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
    }

    private String volleyErrorHandler(VolleyError error) {

        Log.e(TAG, "VolleyError: " + error);

        if (error instanceof NetworkError) {
            return "Something went wrong, Try again";
        } else if (error instanceof ServerError) {
            return "Something went wrong, Try again";
        } else if (error instanceof AuthFailureError) {
            return "Something went wrong, Try again";
        } else if (error instanceof ParseError) {
            return "Something went wrong, Try again";
        } else if (error instanceof NoConnectionError) {
            return "Something went wrong, Try again";
        } else if (error instanceof TimeoutError) {
            return "Time out error, Try again";
        } else {
            return "Something went wrong, Try again";
        }
    }
}