package com.kouchan.dyutpassenger.FCM;

import com.google.firebase.iid.FirebaseInstanceId;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;

/**
 * Created by KOUCHAN-ADMIN on 2/7/2017.
 */

public class PassengerIDInstance {

}/*extends FirebaseInstanceIdService
{
    Sharedpreferences sharedpreferences;

    @Override
    public void onTokenRefresh()
    {
        super.onTokenRefresh();

        storePassengerToken(FirebaseInstanceId.getInstance().getToken());
    }

    public String storePassengerToken(String token) {
        //we will save the token in sharedpreferences later

        sharedpreferences=Sharedpreferences.getUserDataObj(getApplicationContext());
        sharedpreferences.setFcmToken(token);

        return token;
    }

}
*/