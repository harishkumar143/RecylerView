package com.kouchan.dyutpassenger.utils;

public class AppConstants {

    public static int TAG_ID_REGISTER = 1;
    public static int TAG_ID_OTP = 2;
    public static int TAG_ID_AADHAR_OTP = 3;
    public static int TAG_ID_VALIDATE_AADHAR_OTP = 4;
    public static int TAG_ID_VERIFY_OTP = 5;
    public static int TAG_ID_GENERATE_TOKEN = 6;
    public static int TAG_ID_PAYMENT = 7;
    public static int TAG_ID_VERIFY_BOOKRIDE_OTP = 8;
    public static int TAG_ID_GETBALANCE = 9;
    public static int TAG_ID_BOOKRIDERESENDOTP = 10;
    public static int TAG_ID_EDITPROFILE = 11;
    public static int TAG_ID_GETPROFILE = 12;
    public static int TAG_ID_AFTERCANCEL = 13;
    public static int TAG_ID_BEFORECANCEL = 14;
    public static int TAG_ID_FAQ = 15;
    public static int TAG_ID_DELETEFAVOURITE = 16;
    public static int TAG_ID_CHANGEDESTINATION = 17;
    public static int TAG_ID_PAYTM_CHECKSUM = 18;

    public static int TAG_ID_LOGIN = 19;
    public static int TAG_ID_CHANGE_PASSWORD = 20;
    public static int TAG_ID_COMPLAINT_REGISTER = 21;
    public static int TAG_ID_ADD_Favourite = 22;
    public static int TAG_ID_FORGOT_PASSWORD = 23;
    public static int TAG_ID_GET_COMPLAINTS = 24;
    public static int TAG_ID_GET_EMERGANCY_DETAILS = 25;
    public static int TAG_ID_GET_FAVOURITE = 26;
    public static int TAG_ID_GET_NEAR_BY_DRIVERS = 27;
    public static int TAG_ID_LOGOUT = 28;
    public static int TAG_ID_PassengerHistoryByBookingId = 29;
    public static int TAG_ID_passengerHistoryByDateDetails = 30;
    public static int TAG_ID_PassengerHistoryByMonth = 31;
    public static int TAG_ID_PpassengerHistoryByMonthDetails = 32;
    public static int TAG_ID_RATING = 33;
    public static int TAG_ID_PASSENGER_REGISTER = 34;
    public static int TAG_ID_UPDATE_PASSWORD = 35;
    public static int TAG_ID_VehiclesDistanceAndTime = 36;

    public static int TAG_ID_ADAVANCE_BOOKING_PASSENGER = 37;
    public static int TAG_ID_ADAVANCE_BOOKING_BY_ID = 38;
    public static int TAG_ID_APK_VERSION = 39;
    public static int TAG_ID_bookingCancellationOfDriver = 40;
    public static int TAG_ID_bookingCancellationOfPassenger = 41;
    public static int TAG_ID_CANCELLED_BYDRIVER = 42;
    public static int TAG_ID_driverDetailAfterBooking= 43;
    public static int TAG_ID_driverOfferToCustomer= 44;
    public static int TAG_ID_driverResponseTimeOut= 45;
    public static int endRideFromDriver = 46;
    public static int TAG_ID_GET_COMMENTS_SUBJECT = 47;
    public static int TAG_ID_GET_COMMENTS_BEFORE_RIDE_START_CANCELLATION = 48;
    public static int passengerCancel = 49;
    public static int passengerSelectionOfDriver = 50;
    public static int paymentReceipt = 51;
    public static int removePassengerFromDriverOfferList = 52;
    public static int rideRequest = 53;
    public static int rideStart = 54;
    public static int sosbuttton = 55;
    public static int updateLatLong = 56;
    public static int add_money_transaction_history = 57;
    public static int distanceCalculateByLatLongNew = 58;
    public static int CANCELLLED_HISTORY_OFPASSENGER = 59;
    public static int ADVANCE_BOOKING_OF_PASSENGER = 60;
    public static int GET_DRIVER_LOCATION = 61;
    public static int cancelRideComments = 62;
    public static int emergancy_contact_update = 63;
    public static int RIDE_SUCCESS_MAIL = 64;
    public static int DRIVER_ARRIVAL_TIME = 65;
    public static int addmoneytodyut = 66;
    public static int HDFC_PAYMENT_HASH = 67;
    public static int Add_To_Dyut_Wallet_From_HDFC = 68;

    public static boolean IS_LIVE_BUILD = false;


    private static String BASE_URL;
    public static String WEBSERVICE_HOST;


    static {
        if (IS_LIVE_BUILD) {
            WEBSERVICE_HOST = "http://www.kouchan.in/M3app/";
        } else {
            WEBSERVICE_HOST = "http://www.kouchan.in/M3app/";

        }
        BASE_URL = WEBSERVICE_HOST;
    }


    public static String PREF_AUTO_BOOK="autobooking";
    public static String PREF_AUTO_LESS_PRICE="lessprice";
    public static String PREF_AUTO_LESS_DISTANCE="lessdistance";
    public static String NONE="noneValue";

}
