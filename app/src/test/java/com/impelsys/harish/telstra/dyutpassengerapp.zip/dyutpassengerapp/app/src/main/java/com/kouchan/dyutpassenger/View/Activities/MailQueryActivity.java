package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fr.ganfra.materialspinner.MaterialSpinner;


public class MailQueryActivity extends AppCompatActivity implements OnRequestListener {

    MaterialSpinner subjectSpinner;
    EditText qyeryEditText;
    TextView contactUsRefNumber;
    Button submitButton;
    TextView about_us_textView,contactUsSubjectTextView,querySubjectTextView;
    ImageView nav_about_usBackImageView;
    List spinnerItems = new ArrayList();
    ArrayAdapter spinnerAdaper;
    String bookingId;
    AsyncInteractor asyncInteractor;
    SessionManager sessionManager;
    private String subjectType;
    private String languageCode;
    private Resources resources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mail_query);
        sessionManager = new SessionManager(this);
        asyncInteractor=new AsyncInteractor(this);
        intializeViews();
        spinnerOperation();
        subjectApiCall();

        if (Utils.appCode != null) {
            languageCode = Utils.appCode.toString();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        about_us_textView.setText(resources.getString(R.string.mail_your_query));
        contactUsSubjectTextView.setText(resources.getString(R.string.subject));
        querySubjectTextView.setText(resources.getString(R.string.write_your_query));
        submitButton.setText(resources.getString(R.string.submit));


    }

    private void intializeViews() {
        subjectSpinner = (MaterialSpinner) findViewById(R.id.subjectSpinner);
        about_us_textView = (TextView) findViewById(R.id.about_us_textView);
        contactUsSubjectTextView = (TextView) findViewById(R.id.contactUsSubjectTextView);
        querySubjectTextView = (TextView) findViewById(R.id.querySubjectTextView);
        qyeryEditText = (EditText) findViewById(R.id.qyeryEditText);
        submitButton = (Button) findViewById(R.id.submitButton);
        nav_about_usBackImageView = (ImageView) findViewById(R.id.nav_about_usBackImageView);
        contactUsRefNumber = (TextView) findViewById(R.id.contactUsRefNumber);

        Intent i = getIntent();
        if (i != null) {
            bookingId = i.getStringExtra("bookingId");
        }
        contactUsRefNumber.setText(bookingId);


        spinnerAdaper = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, spinnerItems);
        spinnerAdaper.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subjectSpinner.setAdapter(spinnerAdaper);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(subjectType.equalsIgnoreCase("Select subject")){
                    Toast.makeText(MailQueryActivity.this, "Select a subject", Toast.LENGTH_SHORT).show();
                }
                else if(qyeryEditText.getText().toString().trim().isEmpty()){
                    Toast.makeText(MailQueryActivity.this, "Write query", Toast.LENGTH_SHORT).show();
                }
                else{
                    submitQueryApiCall();
                }
            }
        });

        nav_about_usBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    private void spinnerOperation() {
        subjectSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                subjectType = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void submitQueryApiCall() {

        Map<String, String> params = new HashMap<String, String>();
        params.put("booking_id", bookingId);
        params.put("user_id", sessionManager.getId());
        params.put("complaint_type", subjectSpinner.getSelectedItem().toString());
        params.put("comments", qyeryEditText.getText().toString());
        params.put("user_type", sessionManager.getType());

        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_COMPLAINT_REGISTER,Url.PASSENGER_API+ServerApiNames.COMPLAINT_REGISTER,new JSONObject(params));
        // final ProgressDialog loading = ProgressDialog.show(getApplicationContext(),resources.getString(R.string.processing),resources.getString(R.string.please_wait),false,false);
    }

    private void subjectApiCall() {

        Utils.showProgress(this);

        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_GET_COMMENTS_SUBJECT, Url.COMUNICATE_API+"get_comments.php?user_type=PASSENGER&comment_type=HELP&language="+sessionManager.getLanguageCode(),null);
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {



        if(pid==AppConstants.TAG_ID_COMPLAINT_REGISTER) {

            Utils.stopProgress(this);
            try {
                JSONObject jsonObj = new JSONObject(responseJson);
                boolean error = jsonObj.getBoolean("error");
                if (!error) {
                    Toast.makeText(MailQueryActivity.this, jsonObj.getString("message"), Toast.LENGTH_SHORT).show();
                    finish();
                    Intent i = new Intent(MailQueryActivity.this, TrackComplentActivity.class);
                    startActivity(i);
                } else {
                    String errorMsg = jsonObj.getString("error_msg");
                    Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_LONG).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


        if(pid==AppConstants.TAG_ID_GET_COMMENTS_SUBJECT){
            Utils.stopProgress(this);
            try {
                //                   loading.dismiss();
                JSONObject jsonObj = new JSONObject(responseJson);
                boolean error = jsonObj.getBoolean("error");
                if (!error) {
                    JSONArray contacts = jsonObj.getJSONArray("comments");

                    for (int i = 0; i < contacts.length(); i++) {
                        String s = contacts.getString(i);
                        spinnerItems.add(s);
                    }
                } else {
                    String errorMsg = jsonObj.getString("error_msg");
                    Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_LONG).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
