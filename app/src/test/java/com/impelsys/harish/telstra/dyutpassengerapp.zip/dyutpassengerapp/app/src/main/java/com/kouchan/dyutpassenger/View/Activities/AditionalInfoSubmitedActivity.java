package com.kouchan.dyutpassenger.View.Activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.kouchan.dyutpassenger.R;


public class AditionalInfoSubmitedActivity extends AppCompatActivity {

    Button thanks_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        thanks_button=(Button)findViewById(R.id.thanks_button);

        thanks_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AditionalInfoSubmitedActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed()
    {
        // code here to show dialog
        super.onBackPressed();
        Intent intent= new Intent(getApplicationContext(), NavHome.class);
        startActivity(intent);
        finish();
    }
}
