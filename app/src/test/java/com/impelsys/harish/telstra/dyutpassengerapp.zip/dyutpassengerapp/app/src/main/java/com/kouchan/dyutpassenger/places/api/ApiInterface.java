package com.kouchan.dyutpassenger.places.api;

import com.kouchan.dyutpassenger.places.models.DirectionResponseModel;
import com.kouchan.dyutpassenger.places.models.PlaceDetailSerializer;
import com.kouchan.dyutpassenger.places.models.PlaceSerializer;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET(DirectionUrl.PLACE_AUTOCOMPLETE_API_URL)
    Call<PlaceSerializer> getPredictions(
            @Query("key") String key,
            @Query("input") String input
    );

    @GET(DirectionUrl.PLACE_DETAILS_API_URL)
    Call<PlaceDetailSerializer> getPlace(
            @Query("key") String key,
            @Query("placeid") String placeid
    );

    @GET(DirectionUrl.DIRECTION_API_URL)
    public Call<DirectionResponseModel> getRouteJson(
            @Query("origin") String origin,
            @Query("destination") String destination,
            @Query("sensor") boolean sensor,
            @Query("mode") String mode,
            @Query("avoid") String avoid,
            @Query("alternatives") boolean alternatives,
            @Query("key") String key
    );

    @GET(DirectionUrl.PLACE_AUTOCOMPLETE_API_URL)
    Call<PlaceSerializer> getPredictionsByLocality(
            @Query("key") String key,
            @Query("input") String input,
            @Query("location") String location,
            @Query("radius") String radius
    );
}
