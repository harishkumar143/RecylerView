package com.kouchan.dyutpassenger.Interface.aftercancel;

import com.kouchan.dyutpassenger.View.Activities.NavHome;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;



public class GetAfterCancelPresenterImpl implements IGetAfterCancelPresnter,OnRequestListener {

    NavHome navHome;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IGetAfterCancelView getAfterCancelView;

    public GetAfterCancelPresenterImpl(IGetAfterCancelView navHome) {
        this.navHome = (NavHome) navHome ;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(this.navHome);
        this.asyncInteractor = new AsyncInteractor(this.navHome);
        this.getAfterCancelView = navHome;
    }

    @Override
    public void getAfterCancel() { //todo no usage
        if(NetworkStatus.checkNetworkStatus(navHome)){
            //Utils.showProgress(navHome);
        } else {
            Utils.showToast(navHome, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if(pid==AppConstants.TAG_ID_AFTERCANCEL){
           // Utils.stopProgress(navHome);
            if(responseJson!=null){
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if(!error) {
                    ArrayList<String> listdata = new ArrayList<String>();
                    JSONArray jArray = jObj.getJSONArray("comments");
                    if (jArray != null) {
                        for (int i=0;i<jArray.length();i++){
                            listdata.add(jArray.getString(i));
                        }
                    }
                    getAfterCancelView.getAfterCancelSuccess(pid,listdata);
                }
                else {
                    getAfterCancelView.getAfterCancelError(pid,jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
     //   Utils.stopProgress(navHome);
        getAfterCancelView.getAfterCancelError(pid,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
       // Utils.stopProgress(navHome);
        getAfterCancelView.getAfterCancelError(pid,error);
    }
}
