package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.kouchan.dyutpassenger.Adapter.CustomItemClickListener;
import com.kouchan.dyutpassenger.Adapter.FavouriteAdapter;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.deletefavourite.DeleteFavouritePresenterImpl;
import com.kouchan.dyutpassenger.Interface.deletefavourite.IDeleteFavouritePresnter;
import com.kouchan.dyutpassenger.Interface.deletefavourite.IDeleteFavouriteView;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Fragments.PassengerHomeFragment;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.FavoriteModel;
import com.kouchan.dyutpassenger.places.api.ApiClient;
import com.kouchan.dyutpassenger.places.api.ApiInterface;
import com.kouchan.dyutpassenger.places.models.PlaceDetailSerializer;
import com.kouchan.dyutpassenger.places.models.PlaceSerializer;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchPlaceActivity extends AppCompatActivity implements AdapterView.OnItemClickListener, IDeleteFavouriteView, OnRequestListener {
    String TAG = "PLACE";
    ApiInterface api;
    List<PlaceSerializer.PredictionsBean> places = new ArrayList<>();
    TextView tvPlace;
    ImageView ivPhoto,searchActivityBackImageView;
    RecyclerView recyclerView;
    FavouriteAdapter favouriteAdapter;
    IDeleteFavouritePresnter deleteFavouritePresnter;
    ArrayList<FavoriteModel> favoriteModels;
    AsyncInteractor asyncInteractor;
    SessionManager sessionManager;
    LinearLayoutManager llm;
    Resources resources;
    String comingFrom,languageCode;
    String latitude, longitude;
    private View view;
    final String LOCALITY_RADIUS="500";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_place);

        api = ApiClient.getApiInterface();
        view = new View(this);
        tvPlace = (TextView) findViewById(R.id.tvPlace);
        ivPhoto = (ImageView) findViewById(R.id.ivPhoto);
        searchActivityBackImageView = (ImageView) findViewById(R.id.searchActivityBackImageView);
        recyclerView = (RecyclerView) findViewById(R.id.favlist);
        favoriteModels = new ArrayList<>();
        asyncInteractor=new AsyncInteractor(this);
        sessionManager=new SessionManager(this);
        favRecyclerViews();
        Intent intent=getIntent();
        if(intent!=null){
            comingFrom=intent.getStringExtra("Source");

            try{
                latitude=intent.getStringExtra("latitude");
                longitude=intent.getStringExtra("longitude");
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        AutoCompleteTextView autoCompView = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
        autoCompView.setAdapter(new GooglePlacesAutocompleteAdapter(this, R.layout.autocomplete_list_item));
        autoCompView.setOnItemClickListener(this);

        if (Utils.appCode != null) {
            languageCode = Utils.appCode;
            updateViews(languageCode);
        }
        searchActivityBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PassengerHomeFragment.cursorStatus=1;

                onBackPressed();
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(autoCompView.getWindowToken(), 0);
            }
        });

        if(comingFrom.equalsIgnoreCase("from")){
            autoCompView.setHint(resources.getString(R.string.enterYourPickupLocation));
        }
        else if(comingFrom.equalsIgnoreCase("to")){
            autoCompView.setHint(resources.getString(R.string.enterYourDropLocation));
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        PassengerHomeFragment.cursorStatus=1;
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();



    }

    private void favRecyclerViews() {

        Map<String,String> params=new HashMap<String, String>();

        params.put("mobile",sessionManager.getUserDetails().get("mobile"));
        asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_GET_FAVOURITE, Url.PASSENGER_API+ ServerApiNames.GET_FAVOURITE,new JSONObject(params));


        favouriteAdapter = new FavouriteAdapter(this, R.layout.view_favourite,
                getIntent().getStringExtra("Source"), favoriteModels,new CustomItemClickListener() {
            @Override
            public void onItemClick(View v, String position) {
                deleteFavouritePresnter = new DeleteFavouritePresenterImpl(SearchPlaceActivity.this);
                deleteFavouritePresnter.deleteFavourite(position);
            }
        });
        llm = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(llm);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(favouriteAdapter);
    }

    public void onItemClick(AdapterView adapterView, View view, int position, long id) {
        String key = getResources().getString(R.string.google_direction_api);
        PlaceSerializer.PredictionsBean place = places.get(position);

        Call<PlaceDetailSerializer> callPlace = api.getPlace(key, place.getPlaceId());
        Log.d(TAG, "On Item select "+callPlace.request().url().toString());
        callPlace.enqueue(new Callback<PlaceDetailSerializer>() {
            @Override
            public void onResponse(Call<PlaceDetailSerializer> call, Response<PlaceDetailSerializer> response) {
                Log.e(TAG, "onResponse"+new Gson().toJson(response.body()));

                if (response.isSuccessful() ) {
                    PlaceDetailSerializer data = response.body();
                    PlaceDetailSerializer.ResultBean placeDetail = data.getResult();
                    if (placeDetail.getName()!= null)
                    tvPlace.setText(placeDetail.getName() + "\n" + placeDetail.getAdrAddress());
                    Log.d(TAG,"lat: "+placeDetail.getGeometry().getLocation().getLat());
                    Log.d(TAG,"lat: "+placeDetail.getGeometry().getLocation().getLng());

                    Intent intent=new Intent();
                    if(comingFrom.equalsIgnoreCase("from")){
                        intent.putExtra("fromAddress", (String) adapterView.getItemAtPosition(position));
                        intent.putExtra("fromLat",""+placeDetail.getGeometry().getLocation().getLat());
                        intent.putExtra("fromLong",""+placeDetail.getGeometry().getLocation().getLng());
                        Log.e("fromAddress","fromAddress search=="+(String) adapterView.getItemAtPosition(position));
                        setResult(RESULT_OK,intent);
                        finish();
                    }
                    else if(comingFrom.equalsIgnoreCase("to")){
                        //intent.putExtra("toAddress", (String) adapterView.getItemAtPosition(position));

                        if(tvPlace.getText().toString()!=null)
                        intent.putExtra("toAddress", (String) adapterView.getItemAtPosition(position));
                        intent.putExtra("toLat",""+placeDetail.getGeometry().getLocation().getLat());
                        intent.putExtra("toLong",""+placeDetail.getGeometry().getLocation().getLng());
                        setResult(RESULT_OK,intent);
                        finish();

                    }
                }
            }

            @Override
            public void onFailure(Call<PlaceDetailSerializer> call, Throwable t) {
                Log.e(TAG, "onFailure");
                Log.e(TAG, t.toString());
            }
        });

/*        String str = (String) adapterView.getItemAtPosition(position);
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();*/
        InputMethodManager in = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        in.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
    }


    @Override
    public void deleteFavouriteSuccess(int pid, String response) {
        Toast.makeText(this, "Deleted successfully", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void deleteFavouriteError(int pid, String error) {
        Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if(pid == AppConstants.TAG_ID_GET_FAVOURITE){
            try {

                JSONObject jsonObj = new JSONObject(responseJson);
                boolean error = jsonObj.getBoolean("error");
                if (!error) {

                    JSONArray contacts = jsonObj.getJSONArray("user");

                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        int id=c.getInt("id");
                        String type = c.getString("addresstype");
                        String address = c.getString("address");
                        String tolatitude = c.getString("latitude");
                        String tolongitude = c.getString("longitude");
                        String latlongtype="source";

                        FavoriteModel favorite=new FavoriteModel(String.valueOf(id),type,address,tolatitude,tolongitude);

                        favoriteModels.add(favorite);


                    }
                }else {
                    String errorMsg = jsonObj.getString("error_msg");

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }

    public class GooglePlacesAutocompleteAdapter extends ArrayAdapter implements Filterable {
        private ArrayList<String> resultList = new ArrayList<>();

        public GooglePlacesAutocompleteAdapter(Context context, int textViewResourceId) {
            super(context, textViewResourceId);
        }

        @Override
        public int getCount() {
            return resultList.size();
        }

        @Override
        public String getItem(int index) {
            return resultList.get(index);
        }

        @Override
        public Filter getFilter() {
            Log.d(TAG, "getFilter");
            Filter filter = new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    FilterResults filterResults = new FilterResults();
                    if (constraint != null) {
                        // Retrieve the autocomplete results.
                        if (constraint.length() > 2)
                            resultList = getItems(constraint.toString());

                        // Assign the data to the FilterResults
                        filterResults.values = resultList;
                        filterResults.count = resultList.size();
                    }
                    return filterResults;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    if (results != null && results.count > 0) {
                        notifyDataSetChanged();
                    } else {
                        notifyDataSetInvalidated();
                    }
                }
            };
            return filter;
        }

        public ArrayList<String> getItems(String input) {
            ArrayList<String> resultList = new ArrayList<String>();
            String key = getResources().getString(R.string.google_direction_api);
             //input=input+"&location=12.987813,77.733676&radius=500";
            // Log.e("Input","input="+input);
              String location="";
                if(latitude!=null && longitude !=null){
                    location=latitude+","+longitude;
                }
            Call<PlaceSerializer> callPlaces = api.getPredictionsByLocality(key, input,location,LOCALITY_RADIUS);

            // show url
            Log.d(TAG, callPlaces.request().url().toString());

            try {
                PlaceSerializer predictions = callPlaces.execute().body();
                Log.e(TAG, "onResponse"+new Gson().toJson(predictions));
                places = predictions.getPredictions();
                if (!places.isEmpty()) {
                    resultList = new ArrayList<>();
                    for (PlaceSerializer.PredictionsBean place : places) {
                        resultList.add(place.getDescription());
                        Log.d(TAG, place.getDescription());
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "Error connecting to Places API", e);
                return resultList;
            }

            return resultList;
        }
    }
}