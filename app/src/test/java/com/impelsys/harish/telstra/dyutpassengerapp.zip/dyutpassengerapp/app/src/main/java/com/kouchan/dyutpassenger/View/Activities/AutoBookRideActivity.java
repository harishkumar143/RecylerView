package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

public class AutoBookRideActivity extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    RadioGroup radioGroup;
    RadioButton rb_lessprice, rb_lessdistance, none;
    ImageView auto_book_image_view;
    TextView auto_book_text;
    Button submitButton;
    private String languageCode;
    private Resources resources;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto_book_ride);
        sharedPreferences = getSharedPreferences(AppConstants.PREF_AUTO_BOOK, Context.MODE_PRIVATE);
        radioGroup = (RadioGroup) findViewById(R.id.radiogroup);
        auto_book_image_view = (ImageView) findViewById(R.id.auto_book_image_view);
        auto_book_text = (TextView) findViewById(R.id.auto_book_text);
        submitButton = (Button) findViewById(R.id.submitButton);
        rb_lessdistance = findViewById(R.id.rb_less_distance);
        rb_lessprice = findViewById(R.id.rb_less_price);
        none = findViewById(R.id.none);
        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        boolean lessprice = sharedPreferences.getBoolean(AppConstants.PREF_AUTO_LESS_PRICE, false);
        boolean lessdistance = sharedPreferences.getBoolean(AppConstants.PREF_AUTO_LESS_DISTANCE, false);
        boolean noneValue = sharedPreferences.getBoolean(AppConstants.NONE, false);

        auto_book_image_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        rb_lessprice.setChecked(lessprice);
        rb_lessdistance.setChecked(lessdistance);
        none.setChecked(noneValue);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == rb_lessdistance.getId()) {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean(AppConstants.PREF_AUTO_LESS_DISTANCE, true);
                    editor.putBoolean(AppConstants.PREF_AUTO_LESS_PRICE, false);
                    editor.putBoolean(AppConstants.NONE, false);
                    editor.commit();
                    Log.d("Mode","Ride mode: Nearest");
                    Utils.showToast(AutoBookRideActivity.this,"Nearest vehicle updated");
                } else if (checkedId == rb_lessprice.getId()) {

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean(AppConstants.PREF_AUTO_LESS_PRICE, true);
                    editor.putBoolean(AppConstants.PREF_AUTO_LESS_DISTANCE, false);
                    editor.putBoolean(AppConstants.NONE, false);
                    editor.commit();
                    Log.d("Mode","Ride mode: Less price");
                    Utils.showToast(AutoBookRideActivity.this,"Lowset fare updated");

                } else if (checkedId == none.getId()) {

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean(AppConstants.PREF_AUTO_LESS_PRICE, false);
                    editor.putBoolean(AppConstants.PREF_AUTO_LESS_DISTANCE, false);
                    editor.putBoolean(AppConstants.NONE, true);
                    editor.commit();
                    Log.d("Mode","Ride mode: none");
                    Utils.showToast(AutoBookRideActivity.this,"Manual selection of ride updated");
                }
            }
        });

    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        rb_lessprice.setText(resources.getString(R.string.auto_book_lessprice));
        rb_lessdistance.setText(resources.getString(R.string.auto_book_lessdistance));
        none.setText(resources.getString(R.string.none));
        auto_book_text.setText(resources.getString(R.string.auto_book));
        submitButton.setText(resources.getString(R.string.submit));
    }


}
