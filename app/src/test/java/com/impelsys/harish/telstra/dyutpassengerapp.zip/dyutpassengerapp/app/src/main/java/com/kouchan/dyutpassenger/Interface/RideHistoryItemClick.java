package com.kouchan.dyutpassenger.Interface;

public interface RideHistoryItemClick {

    void onItemClick(int position);
}
