package com.kouchan.dyutpassenger.View.Activities;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.dynamiclinks.DynamicLink;
import com.google.firebase.dynamiclinks.FirebaseDynamicLinks;
import com.google.firebase.dynamiclinks.ShortDynamicLink;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.BroadcastReceivers.NetworkChangeReceiver;
import com.kouchan.dyutpassenger.BuildConfig;
import com.kouchan.dyutpassenger.Database.PrefManager;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Interface.faq.IGetFAQView;
import com.kouchan.dyutpassenger.Interface.getBalance.IGetBalanceView;
import com.kouchan.dyutpassenger.Interface.getprofile.GetProfilePresenterImpl;
import com.kouchan.dyutpassenger.Interface.getprofile.IGetProfilePresnter;
import com.kouchan.dyutpassenger.Interface.getprofile.IGetProfileView;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Fragments.PassengerHomeFragment;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.forceupdate.ForceUpdateActivity;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.OttoEventActivityFinish;
import com.kouchan.dyutpassenger.models.PassengerModel;
import com.kouchan.dyutpassenger.other.CustomeDialogGeneric;
import com.kouchan.dyutpassenger.other.OttoDialogGeneric;
import com.kouchan.dyutpassenger.paytm.AddMoneyToDyutAccActivity;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;
import com.squareup.otto.Subscribe;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class NavHome extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, IGetBalanceView, IGetFAQView,OnRequestListener, IGetProfileView {


    private View navHeader;
    TextView txtName, txtWebsite, txtId, txtEmail;
    SessionManager sessionManager;
    Sharedpreferences sharedPreferences;
    HashMap<String, String> user = new HashMap<String, String>();
    String name, mobile;

    AsyncInteractor asyncInteractor;
    NavigationView navigationView;

    String type, id, email,faqresponse;

    NetworkChangeReceiver receiver;

    private PrefManager prefManager;

    AlertDialog.Builder builder;

    MenuItem nav_walletBalance;

    ProgressDialog loading;

    String tokenUpdateUrl = Url.PASSENGER_API + "firebaseTokenUpdate.php";
    String URL_FAQ = Url.WEB_URL + "p_faq.html";

    String languageCode;
    Resources resources;
    String from,to,fromlatitude,fromlongitude,tolatitude,tolongitude,vehicalType;

    CustomeDialogGeneric cdd;
    private ImageView imgProfile;
    private SharedPreferences preferences;
    IGetProfilePresnter getProfilePresnter;
    private PassengerModel passengerModel;

    @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        EventBusManager.getInstance().getEventBus().register(this);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        sessionManager = new SessionManager(this);
        asyncInteractor=new AsyncInteractor(this);
        sharedPreferences= Sharedpreferences.getUserDataObj(this);

        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);

        navHeader = navigationView.getHeaderView(0);
        txtName = (TextView) navHeader.findViewById(R.id.name);
        txtWebsite = (TextView) navHeader.findViewById(R.id.website);
        txtEmail = (TextView) navHeader.findViewById(R.id.email);
        txtId = (TextView) navHeader.findViewById(R.id.textViewId);
        imgProfile = (ImageView) navHeader.findViewById(R.id.img_profile);

        sessionManager = new SessionManager(getApplicationContext());
        prefManager = new PrefManager(NavHome.this);

        user = sessionManager.getUserDetails();
        name = user.get("name");
        mobile = user.get("mobile");

        id = sharedPreferences.getUserId();
        email = sessionManager.getKeyEmail();



        getProfilePresnter = new GetProfilePresenterImpl(this);


        Intent i=getIntent();
        if(i!=null){
            from=i.getStringExtra("from");
            to=i.getStringExtra("to");
            fromlatitude=i.getStringExtra("fromlatitude");
            fromlongitude=i.getStringExtra("fromlongitude");
            tolatitude=i.getStringExtra("tolatitude");
            tolongitude=i.getStringExtra("tolongitude");
            vehicalType=i.getStringExtra("vehicle_type");

        }
        /*-----------------------------------------------------------------------------------*/

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);

        // get menu from navigationView
        Menu menu = navigationView.getMenu();

        // do the same for other MenuItems
        MenuItem nav_home = menu.findItem(R.id.nav_home);
        nav_home.setTitle(resources.getString(R.string.nav_home));

        MenuItem nav_m3account = menu.findItem(R.id.nav_m3account);
        nav_m3account.setTitle(resources.getString(R.string.nav_m3account));

        MenuItem nav_booking_history = menu.findItem(R.id.nav_booking_history);
        nav_booking_history.setTitle(resources.getString(R.string.nav_booking_history));

        MenuItem nav_security_settings = menu.findItem(R.id.nav_security_settings);
        nav_security_settings.setTitle(resources.getString(R.string.nav_security_settings));

        MenuItem nav_invite_friends = menu.findItem(R.id.nav_invite_friends);
        nav_invite_friends.setTitle(resources.getString(R.string.nav_invite_friends));

        MenuItem nav_faqs = menu.findItem(R.id.nav_faqs);
        nav_faqs.setTitle(resources.getString(R.string.nav_faqs));

        MenuItem autoBooking = menu.findItem(R.id.autoBooking);
        autoBooking.setTitle(resources.getString(R.string.auto_book_text));

        MenuItem edit_profile = menu.findItem(R.id.edit_profile);
        edit_profile.setTitle(resources.getString(R.string.edit_profile));

        MenuItem emergencyContact = menu.findItem(R.id.emergencyContact);
        emergencyContact.setTitle(resources.getString(R.string.emergancyContact));

        MenuItem nav_about_us = menu.findItem(R.id.nav_contact_us);
        nav_about_us.setTitle(resources.getString(R.string.nav_contact_us));

        MenuItem nav_logout = menu.findItem(R.id.nav_logout);
        nav_logout.setTitle(resources.getString(R.string.nav_logout));


        MenuItem nav_favorit = menu.findItem(R.id.nav_favorit);
        nav_favorit.setTitle(resources.getString(R.string.nav_favorit));

        nav_walletBalance = menu.findItem(R.id.get_balance);

        navigationView.setNavigationItemSelectedListener(this);

        /*-----------------------------------------------------------------------------------*/


        loadNavHeader();
        //add this line to display menu1 when the activity is loaded
        receiver = new NetworkChangeReceiver();
        registerReceiver(receiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)); //todo that was originally registered here. Are you missing a call to unregisterReceiver()?

        type = sessionManager.getType();
        Menu nav_Menu = navigationView.getMenu();

        displaySelectedScreen(R.id.nav_home);
        txtId.setText("User Id-P " + id);
        //firebaseTokenUpdate();
        txtEmail.setText(email);

        versionUpdate();


    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        /*forgot_password_tv.setText(resources.getString(R.string.forgot_password));*/
    }

    private void firebaseTokenUpdate() {


        user = sessionManager.getUserDetails();
        loading = ProgressDialog.show(this, resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, tokenUpdateUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {
                                // User sRIuccessfully stored in MySQL


                            } else {

                                // Error occurred in registration. Get the error
                                // message
                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("mobile", user.get("mobile"));
                params.put("token", sharedPreferences.getFcmToken());
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    private void loadNavHeader() {

        txtName.setText(name);
        txtWebsite.setText("+91 " + mobile);

    }

    @Override
    public void onBackPressed() {

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        FragmentManager manager = getSupportFragmentManager();


        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {

            /*super.onBackPressed();*/
            if (manager.getBackStackEntryCount() > 0) {
                // If there are back-stack entries, leave the FragmentActivity
                // implementation take care of them.
                manager.popBackStack();

            } else {
                new AlertDialog.Builder(this)
                        .setMessage(resources.getString(R.string.are_you_sure_you_want_to_exit))
                        .setNegativeButton(resources.getString(R.string.no), null)
                        .setPositiveButton(resources.getString(R.string.yes), new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface arg0, int arg1) {

                                NavHome.super.onBackPressed();

                            }
                        }).create().show();
            }
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        /*getMenuInflater().inflate(R.menu.main, menu);*/
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the AditionalInfoSubmitedActivity/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
       /* if (id == R.id.action_settings) {
            return true;
        }*/

        return super.onOptionsItemSelected(item);
    }

    private void displaySelectedScreen(int itemId) {

        //creating fragment object
        Fragment fragment = null;

        //initializing the fragment object which is selected
        switch (itemId) {
            case R.id.nav_home:
                fragment = new PassengerHomeFragment();

                Bundle bundle=new Bundle();
                bundle.putString("from", from);
                bundle.putString("to", to);
                bundle.putString("fromlatitude", fromlatitude);
                bundle.putString("fromlongitude", fromlongitude);
                bundle.putString("tolatitude", tolatitude);
                bundle.putString("tolongitude", tolongitude);
                bundle.putString("vehicle_type", vehicalType);

                if(from!=null){
                    fragment.setArguments(bundle);
                }
                break;
            case R.id.nav_favorit:
                // fragment = new Menu2();
                break;

            case R.id.nav_invite_friends:

                DynamicLink dynamicLink = FirebaseDynamicLinks.getInstance().createDynamicLink()
                        .setLink(Uri.parse("https://www.bookarideworldwide.com/"))
                        .setDomainUriPrefix("https://dyutpassenger.page.link")
                        // Open links with this app on Android
                        .setAndroidParameters(new DynamicLink.AndroidParameters.Builder().build())
                        // Open links with com.example.ios on iOS
                        .setIosParameters(new DynamicLink.IosParameters.Builder("com.example.ios").build())
                        .buildDynamicLink();

                Uri dynamicLinkUri = dynamicLink.getUri();

                Log.d("main","link:"+dynamicLink.getUri());

                createReferlink(sessionManager.getUniqueId(), "prod456",resources.getString(R.string.passengerMsg));

                break;

            case R.id.nav_contact_us:
                Intent au = new Intent(getApplicationContext(), ContactUsActivity.class);
                startActivity(au);
                break;

            case R.id.nav_faqs:
                Intent faq = new Intent(getApplicationContext(), WebViewActivity.class);
                faq.putExtra("url", URL_FAQ);
                String faqs_titel = "FAQs";
                faq.putExtra("action_bar_name", faqs_titel);
                startActivity(faq);

                break;

            case R.id.edit_profile:

                final Dialog dialog = new Dialog(NavHome.this);
                // mDialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setCanceledOnTouchOutside(false);
                dialog.setContentView(R.layout.verify_password_dialog);
                dialog.setTitle("Password verification");
                ImageView close = (ImageView) dialog.findViewById(R.id.closeContactUsRootImageView);
                final EditText mPassword = (EditText) dialog.findViewById(R.id.password);
                final TextView mText = (TextView) dialog.findViewById(R.id.text);
                mText.setVisibility(View.GONE);
                Button mSubmit = (Button) dialog.findViewById(R.id.submit);
                mSubmit.setText(resources.getString(R.string.submit));
                mPassword.setHint(resources.getString(R.string.enter_password));

                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });


                mSubmit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!mPassword.getText().toString().isEmpty()) {

                            String password = mPassword.getText().toString();
                            dialog.dismiss();
                            getProfilePresnter.getProfile(sharedPreferences.getUserMobile(),password);

                        } else {
                            Utils.showToast(NavHome.this, "Enter password");
                        }
                    }
                });

                dialog.show();


                //finish();
                break;

            case R.id.autoBooking:
                Intent autoBook = new Intent(getApplicationContext(), AutoBookRideActivity.class);
                startActivity(autoBook);
                //finish();
                break;

            case R.id.emergencyContact:
                Intent intent1 = new Intent(getApplicationContext(), EmergancyContactDeatilsActivity.class);
                startActivity(intent1);
                //finish();
                break;


            case R.id.nav_security_settings:
                Intent intent = new Intent(getApplicationContext(), SecurityAndSettingsActivity.class);
                startActivity(intent);
                break;

            case R.id.nav_booking_history:
                Intent history = new Intent(getApplicationContext(), RideHistoryActivity.class);
                startActivity(history);
                break;


            case R.id.nav_m3account:
                Intent m3account = new Intent(getApplicationContext(), AddMoneyToDyutAccActivity.class);
                startActivity(m3account);
                break;

            case R.id.nav_booking:
                Intent booking = new Intent(getApplicationContext(), AdvanceBooking.class);
                startActivity(booking);
                finish();
                break;

            case R.id.nav_logout:

             /*   cdd = new CustomeDialogGeneric(NavHome.this, resources.getString(R.string.nav_logout), resources.getString(R.string.nav_would_you_like_to_logout), resources.getString(R.string.yes), resources.getString(R.string.no), "logout", receiver);
                cdd.setCancelable(false);
                cdd.show();
                Window window = cdd.getWindow();
                assert window != null;
                window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);*/

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage(resources.getString(R.string.nav_would_you_like_to_logout))
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                              //  Thread.interrupted();
                                logoutApi();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();

                break;
        }

        //replacing the fragment
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.content_frame, fragment);
            ft.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    public void createReferlink(String custid, String prodid,String msg){
        // manuall link
        String sharelinktext  = "https://dyutpassenger.page.link?"+
                "link=https://www.bookarideworldwide.com/myrefer.php?custid="+custid +"-"+prodid+
                "&apn="+ getPackageName()+
                "&st="+"My Refer Link"+
                "&sd="+"Dyut Passenger"+
                "&si="+"https://bookarideworldwide.com/CAB2.V.1/dyut_passenger.png";

        Log.e("mainactivity", "sharelink - "+sharelinktext);
        // shorten the link
        Task<ShortDynamicLink> shortLinkTask = FirebaseDynamicLinks.getInstance().createDynamicLink()
                //.setLongLink(dynamicLink.getUri())    // enable it if using firebase method dynamicLink
                .setLongLink(Uri.parse(sharelinktext))  // manually
                .buildShortDynamicLink()
                .addOnCompleteListener(this, new OnCompleteListener<ShortDynamicLink>() {
                    @Override
                    public void onComplete(@NonNull Task<ShortDynamicLink> task) {
                        if (task.isSuccessful()) {
                            // Short link created
                            Uri shortLink = task.getResult().getShortLink();
                            Uri flowchartLink = task.getResult().getPreviewLink();
                            Log.e("main ", "short link "+ shortLink.toString());
                            // share app dialog
                            Intent intent = new Intent();
                            intent.setAction(Intent.ACTION_SEND);
                            intent.putExtra(Intent.EXTRA_TEXT, msg + shortLink.toString());
                            intent.setType("text/plain");
                            startActivity(intent);


                        } else {
                            // Error
                            // ...
                            Log.e("main", " error "+task.getException() );

                        }
                    }
                });
    }

    private void logoutApi() {

        Map<String, String> params = new HashMap<String, String>();
        params.put("mobile", mobile);
        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_LOGOUT,Url.PASSENGER_API+ServerApiNames.GET_LOGOUT,new JSONObject(params));
    }

    private void launchHomeScreen() {
        startActivity(new Intent(NavHome.this, AditionalInfoSubmitedActivity.class));
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        //calling the method displayselectedscreen and passing the id of selected menu
        displaySelectedScreen(item.getItemId());
        //make this method blank
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (!sessionManager.isLoggedIn()) {
            startActivity(new Intent(NavHome.this, LoginActivity.class));
            Log.e("OnResume","OnResume------------- inside");
            finish();
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        try  {
            unregisterReceiver(receiver);
        }
        catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Subscribe
    public void ottoEventActivityFinish(OttoEventActivityFinish finish) {
        if (finish.getFinishActivity().equals("navhome")) {
            finish();
        }
    }


    private void versionUpdate() {

        final int versionCode =  BuildConfig.VERSION_CODE;

        Map<String, String> params = new HashMap<String, String>();

        params.put("mobile", mobile);
        params.put("name", name);
        params.put("version", versionCode+"");
        params.put("type", type);

        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_APK_VERSION,Url.COMUNICATE_API+ServerApiNames.apk_version,new JSONObject(params));

    }

    /*@Subscribe
        public void ottoDialogBoxLogout(OttoDialogGeneric ottoDialogGeneric) {

        if (ottoDialogGeneric.getType().equals("logout")) {

            if (ottoDialogGeneric.getValue().equals("yes")) {

                //  cdd.dismiss();
                Thread.interrupted();

                sessionManager.logoutUser(NavHome.this);

            }
        }

    }*/

    @Override
    public void getBalanceSuccess(int pid, String balance) {

        nav_walletBalance.setTitle(balance);
        sessionManager.setWalletBal(balance);
    }

    @Override
    public void getBalanceError(int pid, String error) {
        Utils.showToast(this,error);
    }


    @Override
    public void getFAQSuccess(int pid, String response) {
        this.faqresponse = response;
    }

    @Override
    public void getFAQError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        if(pid==AppConstants.TAG_ID_LOGOUT){
            sessionManager.logoutUser(NavHome.this);
        }

        else if(pid==AppConstants.TAG_ID_APK_VERSION){
            //-{"error":false,"message":"updated","version":"7"}
            if(responseJson!=null){
                JSONObject jsonObject=new JSONObject(responseJson);
                if(!jsonObject.getBoolean("error")){
                    String version=jsonObject.getString("play_store_version");
                    int updatedVersion=-1;
                    try{

                         if(version!=null) {
                             String temp[] = version.split("\\.");
                             updatedVersion = Integer.parseInt(temp[0]);
                         }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    int appVersionCode = BuildConfig.VERSION_CODE;
                    if(appVersionCode==updatedVersion){
                        // if it is equal no need to do anything
                        Log.e("Forceupdate","Forceupdate current version="+appVersionCode+" Play store version="+updatedVersion);
                    }else if(appVersionCode<updatedVersion) {
                        // if current version is lessthan updated version then will ask user to do force update.
                        Log.e("Forceupdate","Forceupdate current version="+appVersionCode+" Play store version"+updatedVersion);
                        launchforceupdate();
                    }else{
                        Log.e("Forceupdate","Forceupdate current version="+appVersionCode+" Play store version"+updatedVersion);
                    }
                }
            }


        }
    }
/*Show the force update alert to the user*/
    private void showUpdateAlert(){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle(R.string.force_update_title);
        builder.setMessage(R.string.force_update_message);
        builder.setPositiveButton(R.string.update, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
                Log.e("appPackageName","appPackageName----"+appPackageName);
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                }
            }
        });
        builder.setNegativeButton(R.string.later, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog alertDialog=builder.create();
        alertDialog.show();

    }

    /*Launch the ForceUpdate activity after setting the manual update mandatory*/
    private void launchforceupdate(){
        Intent intent=new Intent(this, ForceUpdateActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }

    @Override
    public void getProfileSuccess(int pid, String response) {

        Intent intent=new Intent(NavHome.this,EditProfileActivity.class);
        intent.putExtra("profileResponse",response);
        startActivity(intent);
    }

    @Override
    public void getProfileError(int pid, String error) {
        Utils.showToast(this,error);
    }
}
