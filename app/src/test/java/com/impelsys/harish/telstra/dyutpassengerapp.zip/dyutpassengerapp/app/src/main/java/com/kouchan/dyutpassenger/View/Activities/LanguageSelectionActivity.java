package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Adapter.LanguageSelectionAdapter;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LanguageSelectionActivity extends AppCompatActivity {

    @BindView(R.id.selectLanguageRecyclerView)
    RecyclerView mSelectLanguageRecyclerView;

    @BindView(R.id.language_selection_BackImageView)
    ImageView language_selection_BackImageView;


    ArrayList<String> chooseYourLanguageForM3ArrayList = new ArrayList<>();
    ArrayList<String> chooseYourLanguageForM3ArrayListInRespectiveLanguage = new ArrayList<>();

    LanguageSelectionAdapter mLanguageSelectionAdapter;

    Toolbar mToolbar;
    TextView language_selection__textView;
    private SessionManager sessionManager;
    private String languageCode;
    private Resources resources;
    private String comingFrom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_selection);
        ButterKnife.bind(this);

        Intent intent = getIntent();
        if (intent != null) {
            comingFrom = intent.getStringExtra("comingfrom");
            if (comingFrom.equalsIgnoreCase("SplashScreen")) {
                language_selection_BackImageView.setVisibility(View.GONE);
            }
        } else {
            comingFrom = "Home";
        }

        language_selection__textView = (TextView) findViewById(R.id.language_selection__textView);

        setSupportActionBar(mToolbar);


        language_selection_BackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        initializeViews();

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        language_selection__textView.setText(resources.getString(R.string.select_language));
    }

    private void initializeViews() {

        preparingListOfOtherTransactionsWithM3();
        settingUpLanguageWithM3RecyclerViews();

    }


    private void preparingListOfOtherTransactionsWithM3() {

        chooseYourLanguageForM3ArrayList.add("English");
        chooseYourLanguageForM3ArrayList.add("Hindi");
        chooseYourLanguageForM3ArrayList.add("Kannada");
        chooseYourLanguageForM3ArrayList.add("Telugu");
        chooseYourLanguageForM3ArrayList.add("Tamil");
        chooseYourLanguageForM3ArrayList.add("Malayalam");
        chooseYourLanguageForM3ArrayList.add("Marathi");
        chooseYourLanguageForM3ArrayList.add("Gujarati");


        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("हिंदी");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("ಕನ್ನಡ");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("తెలుగు");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("தமிழ்");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("മലയാളം");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("मराठी");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("ગુજરાતી");
    }

    private void settingUpLanguageWithM3RecyclerViews() {

        mLanguageSelectionAdapter = new LanguageSelectionAdapter(LanguageSelectionActivity.this, chooseYourLanguageForM3ArrayList, chooseYourLanguageForM3ArrayListInRespectiveLanguage,comingFrom);
        mSelectLanguageRecyclerView.setHasFixedSize(true);

        mSelectLanguageRecyclerView.setLayoutManager(new LinearLayoutManager(LanguageSelectionActivity.this));
        /*for animation*/
        mSelectLanguageRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mSelectLanguageRecyclerView.setAdapter(mLanguageSelectionAdapter);
        //  }
    }

}
