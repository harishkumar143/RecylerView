package com.kouchan.dyutpassenger.Interface.verifyOtp;

public interface VerifyOtpPresenter {

    void verifyOtp(String userOtp, String mobile, String password);

}
