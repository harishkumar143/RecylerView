package com.kouchan.dyutpassenger.View.Activities;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.android.volley.DefaultRetryPolicy;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.auth.api.credentials.HintRequest;
import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;

import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.provider.Settings;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.gson.Gson;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.SmsVerificationApp;
import com.kouchan.dyutpassenger.VolleyJsonObjectRequest;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.AdhaarModel;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import fr.arnaudguyon.xmltojsonlib.XmlToJson;


public class Registration extends AppCompatActivity implements com.google.android.gms.location.LocationListener, OnMapReadyCallback,GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {

    static final int PICK_CONTACT = 4;
    private static final String TAG = "Registration";
    private static final long INTERVAL = 1000 * 10;
    private static final long FASTEST_INTERVAL = 1000 * 5;
    private static final int TAG_RESULT_PICK__CONTACT = 1001;
    private static final String REGISTER_URL = Url.PASSENGER_API + "sendotpforregistration.php";
    private static final int REQUEST_CODE = 1;
    private static final int TAG_RESULT_PICK_ALTERNATIVE_CONTACT = 1001;
    private static final int REQUEST_CODE_PERMISSION = 89;
    public AwesomeValidation awesomeValidation;
    EditText email_id, mobile_no, first_name, contactPersonMobile, contactPersonName,register_password_passenger;
    LocationRequest mLocationRequest;
    Location mCurrentLocation;
    String state, address, pin;
    TextView registerAcivityLoginTextView, loginInSignUp, registration_text_passenger, byClick, termsAndConditionText, already_have_dyut_account;
    String languageCode;
    Resources resources;
    ImageView contactPersonPhoneBookImage;
    String stringEmail, stringMobile, stringPassword, stringFirstName, stringMessagingID, contacName, contactMobile;
    Button submit_button;
    String stringName, id;
    AlertDialog.Builder ab;
    Toolbar mToolbar;
    Cursor cursor = null;
    int phonePosIndex, namePosIndex;
    String userNameValue, userPhoneNumberValue = null;
    SessionManager sessionManager;
    Sharedpreferences sharedpreferences;
    String mPermission = Manifest.permission.GET_ACCOUNTS;
    private int RESOLVE_HINT=1234;
    private GoogleApiClient mGoogleApiClient;
    private String refinedNumber;
    private SharedPreferences preferences;

    static String getEmail(Context context) {
        AccountManager accountManager = AccountManager.get(context);
        Account account = getAccount(accountManager);

        if (account == null) {
            return null;
        } else {
            return account.name;
        }
    }

    private static Account getAccount(AccountManager accountManager) {
        Account[] accounts = accountManager.getAccountsByType("com.google");
        Account account;
        if (accounts.length > 0) {
            account = accounts[0];
        } else {
            account = null;
        }
        return account;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_registration);
        ab = new AlertDialog.Builder(Registration.this);
        sessionManager = new SessionManager(getApplicationContext());

        // iRegisterPresenter = new RegisterPresenterImp(this);
        sharedpreferences = Sharedpreferences.getUserDataObj(this);
        // iAadharOtpPresnter = new AadharOtpPresenterImpl(this);

        initializeWidgets();
        initializeViews();

        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setValuesForSubmisssion();
                startSmsRetrieverClient();
                sendValues();
            }

        });

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
            Context context = LocaleHelper.setLocale(this, languageCode);
            resources = context.getResources();
            getMailId();
        }

        SpannableString content = new SpannableString(resources.getString(R.string.ssTerms));
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        termsAndConditionText.setText(content);

        termsAndConditionText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = Url.WEB_URL+"p_tnc.html";
                String webview_titel = resources.getString(R.string.terms_and_conditions);
                Intent intent = new Intent(Registration.this, WebViewActivity.class);
                intent.putExtra("url", url);
                intent.putExtra("action_bar_name", webview_titel);
                startActivity(intent);
            }
        });

        //set google api client for hint request
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .enableAutoManage(this, this)
                .addApi(Auth.CREDENTIALS_API)
                .build();

        getHintPhoneNumber();
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        registration_text_passenger.setText(resources.getString(R.string.registration));
        mobile_no.setHint(resources.getString(R.string.mobile_no));
        first_name.setHint(resources.getString(R.string.name_as_per_the_aadhar));
        email_id.setHint(resources.getString(R.string.email_id));
        contactPersonMobile.setHint(resources.getString(R.string.emergancyContact));
        contactPersonName.setHint(resources.getString(R.string.emergancy_contact_name));
        register_password_passenger.setHint(resources.getString(R.string.passenger_password));
        byClick.setText(resources.getString(R.string.byClicking));
        termsAndConditionText.setText(resources.getString(R.string.ssTerms));
        already_have_dyut_account.setText(resources.getString(R.string.already_have_dyut_account));
        loginInSignUp.setText(resources.getString(R.string.login));

    }

    private void initializeWidgets() {

        email_id = (EditText) findViewById(R.id.register_emailid);
        mobile_no = (EditText) findViewById(R.id.register_mobile);
        contactPersonMobile = (EditText) findViewById(R.id.contactPersonMobile);
        contactPersonName = (EditText) findViewById(R.id.contactPersonName);
        register_password_passenger = (EditText) findViewById(R.id.register_password_passenger);
        first_name = (EditText) findViewById(R.id.register_firstname);
        contactPersonPhoneBookImage = (ImageView) findViewById(R.id.contactPersonPhoneBookImage);

        loginInSignUp = (TextView) findViewById(R.id.loginInSignUp);
        registration_text_passenger = (TextView) findViewById(R.id.registration_text_passenger);
        termsAndConditionText = (TextView) findViewById(R.id.termsAndConditionText);
        byClick = (TextView) findViewById(R.id.byClick);
        already_have_dyut_account = (TextView) findViewById(R.id.already_have_dyut_account);

        //loginInSignUp.setPaintFlags(loginInSignUp.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        loginInSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Registration.this, LoginActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
                finish();
            }
        });
        registerAcivityLoginTextView = (TextView) findViewById(R.id.registerAcivityLoginTextView);
        //registerAcivityLoginTextView.setPaintFlags(registerAcivityLoginTextView.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        registerAcivityLoginTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Registration.this, LoginActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
                finish();
            }
        });


        contactPersonPhoneBookImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickContact(TAG_RESULT_PICK_ALTERNATIVE_CONTACT);
            }
        });

        submit_button = (Button) findViewById(R.id.submit_button);

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);


        awesomeValidation.addValidation(this, R.id.register_emailid, Patterns.EMAIL_ADDRESS, R.string.emailerror);
        awesomeValidation.addValidation(this, R.id.register_mobile, "^[7-9]{1}[0-9]{9}$", R.string.mobileerror);
        awesomeValidation.addValidation(this, R.id.register_firstname, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.nameerror);

        String regexPassword = ".{6,8}";
        awesomeValidation.addValidation(this, R.id.register_password_passenger, regexPassword, R.string.passworderror);

    }

    private void setValuesForSubmisssion() {
        stringEmail = email_id.getText().toString();
        stringMobile = mobile_no.getText().toString();
        stringPassword = register_password_passenger.getText().toString();
        contacName = contactPersonName.getText().toString();
        contactMobile = contactPersonMobile.getText().toString();
        stringFirstName = first_name.getText().toString();
        stringMessagingID = sharedpreferences.getFcmToken();
    }

    public void sendValues() {
        try {
            Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude(), 1);
            address = addresses.get(0).getAddressLine(0);
            // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
            String city = addresses.get(0).getLocality();
            state = addresses.get(0).getAdminArea();
            String country = addresses.get(0).getCountryName();
            pin = addresses.get(0).getPostalCode();
            String knownName = addresses.get(0).getFeatureName();
        } catch (Exception e) {
            Log.d("Location", "Not Updated");
        }


        if (Utils.isInternetAvailable(Registration.this)) {

            Utils.showProgress(Registration.this);

            Map<String, String> params = new HashMap<String, String>();

            params.put("email", stringEmail);
            params.put("mobile", stringMobile);
            params.put("password", stringPassword);
            params.put("name", stringFirstName);
            //params.put("device_id", sharedpreferences.getTagDeviceId());
            params.put("messagingid", stringMessagingID);
            params.put("emergency_contact_name", contacName);
            params.put("emergency_contact_mobile", contactMobile);

            if(sharedpreferences.getTagDeviceId()==null || sharedpreferences.getTagDeviceId().isEmpty()){
                String android_id = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
                params.put("device_id",android_id);
            }
            else{
                params.put("device_id",sharedpreferences.getTagDeviceId());
            }

            if(sessionManager.getKeyReferenceId()!=null){
                params.put("referenced_id", sessionManager.getKeyReferenceId());
                Log.e(TAG, " referenced_id "+ sessionManager.getKeyReferenceId());
            }else{
                params.put("referenced_id", "");
            }

            JSONObject json = new JSONObject(params);

            /* if (!requiredm3.isChecked()) {*/
            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, REGISTER_URL, json,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e("reg","reg json----"+response.toString());
                            try {
                                Utils.stopProgress(Registration.this);
                                JSONObject jObj = new JSONObject(response.toString());
                                boolean error = jObj.getBoolean("error");
                                if (!error) {

                                    //if (!requiredm3.isChecked()) {
                                    Intent intent = new Intent(Registration.this, VerifyOTP.class);

                                    intent.putExtra("email", stringEmail);
                                    intent.putExtra("mobile", stringMobile);
                                    intent.putExtra("password", stringPassword);
                                    intent.putExtra("name", stringFirstName);
                                    intent.putExtra("messagingid", stringMessagingID);

                                    if (contacName == null && contacName.equalsIgnoreCase("")) {
                                        intent.putExtra("emergency_contact_name", "NA");
                                    } else {
                                        intent.putExtra("emergency_contact_name", contacName);
                                    }

                                    if (contactMobile == null && contactMobile.equalsIgnoreCase("")) {
                                        intent.putExtra("emergency_contact_name", "NA");
                                    } else {
                                        intent.putExtra("emergency_contact_mobile", contactMobile);
                                    }

                                    preferences = getSharedPreferences(AppConstants.PREF_AUTO_BOOK, Context.MODE_PRIVATE);
                                    SharedPreferences.Editor editor = preferences.edit();
                                    editor.putBoolean(AppConstants.PREF_AUTO_LESS_DISTANCE, false);
                                    editor.putBoolean(AppConstants.PREF_AUTO_LESS_PRICE, true);
                                    editor.putBoolean(AppConstants.NONE,false);
                                    editor.commit();
                                    // intent.putExtra("otp", jObj.getInt("otp"));

/*                                    SmsVerificationApp smsVerificationApp=new SmsVerificationApp();
                                    smsVerificationApp.onCreate();*/

                                    startActivity(intent);

                                } else {
                                    String errorMsg = jObj.getString("error_msg");
                                    Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_SHORT).show();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Utils.stopProgress(Registration.this);
                            Log.e("Reg","VolleyError---"+error.getMessage());
                        }
                    });

            stringRequest.setRetryPolicy(new DefaultRetryPolicy(10000,0,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);

        } else {

            Utils.showToast(Registration.this, "please connect to the internate");
        }


    }

    private void startSmsRetrieverClient() {
        // Get an instance of SmsRetrieverClient, used to start listening for a matching
       // SMS message.
        SmsRetrieverClient client = SmsRetriever.getClient(this /* context */);

// Starts SmsRetriever, which waits for ONE matching SMS message until timeout
// (5 minutes). The matching SMS message will be sent via a Broadcast Intent with
// action SmsRetriever#SMS_RETRIEVED_ACTION.
        Task<Void> task = client.startSmsRetriever();

// Listen for success/failure of the start Task. If in a background thread, this
// can be made blocking using Tasks.await(task, [timeout]);
        task.addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {

                Log.e("SmsRetrieverClient","SmsRetrieverClient Started");
                // Successfully started retriever, expect broadcast intent
                // ...
            }
        });

        task.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // Failed to start retriever, inspect Exception for more details
                // ...

                Log.e("SmsRetrieverClient","SmsRetrieverClient Failed");
            }
        });
    }

    private void pickContact(int type) {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(intent, type);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            // Check for the request code, we might be usign multiple startActivityForReslut
            switch (requestCode) {
                case (TAG_RESULT_PICK_ALTERNATIVE_CONTACT):

                    if (resultCode == Activity.RESULT_OK) {

                        pickedContact(data, requestCode);
                    }
                    break;

            }
        }
        if (requestCode == RESOLVE_HINT) {
            if (resultCode == RESULT_OK) {
                Credential credential = data.getParcelableExtra(Credential.EXTRA_KEY);

                Log.e("credentials", credential.getId());

                refinedNumber=credential.getId();
                if (refinedNumber.length() == 10) {
                    mobile_no.setText(refinedNumber);
                } else if (refinedNumber.length() > 10) {
                    refinedNumber = refinedNumber.replaceAll("[^0-9]+", "");
                    refinedNumber = refinedNumber.substring(refinedNumber.length() - 10);
                    mobile_no.setText(refinedNumber);
                    //
                } else {
                    // whatever is appropriate in this case
                    throw new IllegalArgumentException(resources.getString(R.string.please_enter_the_valid_mobile_number));
                }
            }
        }

        else {
            Log.e("MainActivity", "Failed to pick contact");
        }
    }

    private void pickedContact(Intent data, int requestCode) {

        try {

            // getData() method will have the Content Uri of the selected contact
            Uri uri = data.getData();

            //Query the content uri
            cursor = getContentResolver().query(uri, null, null, null, null);
            cursor.moveToFirst();
            // sendToParentLinearLayout.setVisibility(GONE);
            //pickedContactDetailsLinearLayout.setVisibility(View.VISIBLE);
            // column index of the phone number
            phonePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            // column index of the contact name
            namePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

            userPhoneNumberValue = cursor.getString(phonePosIndex);
            userNameValue = cursor.getString(namePosIndex);


            Log.d("pickedPhoneNum", ":" + cursor.getString(phonePosIndex));
            String[] splitStrPhoneNumber = cursor.getString(phonePosIndex).split("\\s+");

            String refinedNumber = "";

            for (int i = 0; i < splitStrPhoneNumber.length; i++) {

                StringBuilder sb = new StringBuilder();

                Log.d("splitted", "Values" + i + "   " + splitStrPhoneNumber[i]);
                sb.append(refinedNumber).append(splitStrPhoneNumber[i]);

                Log.d("data", ":data came" + sb.toString());

                refinedNumber = sb.toString();
                Log.d("data", ":data came" + refinedNumber);


            }


            if (userPhoneNumberValue != null && userNameValue != null) {


                Log.d("data", ":Length" + refinedNumber.length());

                Log.d("data123", ":data came" + refinedNumber);


                if (refinedNumber.length() == 10) {
                    refinedNumber = refinedNumber;
                } else if (refinedNumber.length() > 10) {
                    refinedNumber = refinedNumber.replaceAll("[^0-9]+", "");
                    refinedNumber = refinedNumber.substring(refinedNumber.length() - 10);
                    //
                } else {
                    // whatever is appropriate in this case
                    throw new IllegalArgumentException(resources.getString(R.string.please_enter_the_valid_mobile_number));
                }

                Log.d("data123", ":data came" + refinedNumber);
                if (requestCode == TAG_RESULT_PICK_ALTERNATIVE_CONTACT) {
                    contactPersonName.setText(userNameValue);
                    contactPersonMobile.setText(refinedNumber);
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getMailId() {

        if (Build.VERSION.SDK_INT >= 23) {

            if (checkSelfPermission(mPermission) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(Registration.this, new String[]{mPermission}, REQUEST_CODE_PERMISSION);
                return;
            } else {
                String email = getEmail(this);
                if (email != null) {
                    email_id.setText(email);
                } else {
                    email_id.setText("");
                }
            }

        } else {
            String email = getEmail(this);
            if (email != null) {
                email_id.setText(email);
            } else {
                email_id.setText("");
            }
        }
    }

/*    public void parseXml(String stringXml) {

        String json = convertXmlToJson(stringXml);
        *//* if (json != null && json.toString().isEmpty()) {*//*
        AdhaarModel model = new Gson().fromJson(json.toString(), AdhaarModel.class);

        Log.d("adhaar", "Name " + model.getPrintLetterBarcodeData().getName());
        Log.d("adhaar", "gender " + model.getPrintLetterBarcodeData().getGender());
        Log.d("adhaar", "co  " + model.getPrintLetterBarcodeData().getCo());
        Log.d("adhaar", "pc " + model.getPrintLetterBarcodeData().getPc());
        Log.d("adhaar", "DOB " + model.getPrintLetterBarcodeData().getDob());
        Log.d("adhaar", "dist " + model.getPrintLetterBarcodeData().getDist());
        Log.d("adhaar", "PO " + model.getPrintLetterBarcodeData().getPo());
        Log.d("adhaar", "VTC " + model.getPrintLetterBarcodeData().getVtc());
        Log.d("adhaar", "uid " + model.getPrintLetterBarcodeData().getUid());
        Log.d("adhaar", "state " + model.getPrintLetterBarcodeData().getState());

        if (model.getPrintLetterBarcodeData().getUid() != null) {
            String myString = model.getPrintLetterBarcodeData().getUid();
            String newString = myString.replaceAll("\\s+", "");*//*replaceAll("(.{4})(?!$)", "$1 ");*//*
            // aadhar_card_number.setText(newString);
        }
        if (model.getPrintLetterBarcodeData().getName() != null) {
            first_name.setText(model.getPrintLetterBarcodeData().getName());
        }
        if (model.getPrintLetterBarcodeData().getDob() != null) {
            //      dob.setText(model.getPrintLetterBarcodeData().getDob());
        } else {
            //     dob.setError("");
        }
        //  pin_code.setText(model.getPrintLetterBarcodeData().getPc());
    }*/


 /*   public String convertXmlToJson(String xml) {
        XmlToJson xmlToJson = new XmlToJson.Builder(xml)
                .build();
        return xmlToJson.toString();
    }
*/

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(Registration.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void initializeViews() {

        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    @Override
    public void onLocationChanged(Location location) {
        mCurrentLocation = location;
    }

    @SuppressLint("RestrictedApi")
    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(INTERVAL);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

    }


    // Construct a request for phone numbers and show the picker
    public void getHintPhoneNumber() {
        HintRequest hintRequest =
                new HintRequest.Builder()
                        .setPhoneNumberIdentifierSupported(true)
                        .build();
        PendingIntent mIntent = Auth.CredentialsApi.getHintPickerIntent(mGoogleApiClient, hintRequest);
        try {
            startIntentSenderForResult(mIntent.getIntentSender(), RESOLVE_HINT, null, 0, 0, 0);
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
