package com.kouchan.dyutpassenger.holders;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.kouchan.dyutpassenger.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class TrackCOmplentHolder extends RecyclerView.ViewHolder {
    @BindView(R.id.complentId)
    public TextView complentId;

    @BindView(R.id.bookingId)
    public TextView bookingId;

    @BindView(R.id.complentType)
    public TextView complentType;

    @BindView(R.id.comments)
    public TextView comments;

    @BindView(R.id.status)
    public TextView status;

    public TrackCOmplentHolder(@NonNull View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }
}
