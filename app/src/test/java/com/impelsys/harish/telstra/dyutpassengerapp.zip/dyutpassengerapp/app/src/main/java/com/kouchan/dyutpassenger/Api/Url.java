package com.kouchan.dyutpassenger.Api;

/**
 * Created by KOUCHAN-ADMIN on 8/5/2017.
 */

public interface Url {

    /*
            Digital ocean server
     */
   /* String PASSENGER_API = "https://bookarideworldwideapi.com/CAB2.V.1/passenger_api/";
    String DRIVER_API = "https://bookarideworldwideapi.com/CAB2.V.1/driver_api/";
    String COMUNICATE_API = "https://bookarideworldwideapi.com/CAB2.V.1/comunicate_api/";
    String PAYTM_Generate_Checksum_URL = "https://bookarideworldwide.com/CAB2.V.1/paytmlib/generateChecksum.php";

    String WEB_URL = "https://bookarideworldwideapi.com/CAB2.V.1/web/";
    String BASE_URL = "https://bookarideworldwideapi.com/CAB2.V.1/";

*/

   /*
    Big Rock Server

    */
   String BASE_URL = "https://www.bookarideworldwide.com/CAB2.V.1/"; // for base url at the end we need add the slash.its mandatory.
    String PASSENGER_API = BASE_URL+"passenger_api/";
    String DRIVER_API = BASE_URL+"driver_api/";
    String COMUNICATE_API = BASE_URL+"comunicate_api/";
    String PAYTM_Generate_Checksum_URL = BASE_URL+"paytmlib/generateChecksum.php";

    String WEB_URL = BASE_URL+"web/";

    String  OAUTH_URL=BASE_URL+"oauth/gettoken.php/?grant_type=password&client_id=DYUT_ANDROID_CLIENT&client_secret=android-dyut-kouchan-";
}
