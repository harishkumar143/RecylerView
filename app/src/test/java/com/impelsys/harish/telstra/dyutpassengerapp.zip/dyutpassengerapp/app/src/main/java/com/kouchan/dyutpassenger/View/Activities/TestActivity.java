/*
package kouchan.siddhesh.com.BookARideAndroid.View.Activities;


import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;

public class TestActivity{

    StringRequest StringRequest= new StringRequest(Request.Method.POST,)
}*/
