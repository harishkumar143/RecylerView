package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 12/29/2017.
 */

public class OttoRideStarted {

    private String rideStatus;

    public OttoRideStarted(String rideStatus) {
        this.rideStatus = rideStatus;

    }

    public String getRidestatus() {

        return rideStatus;
    }
}
