package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 11/4/2017.
 */

public class Cancel {

    private String booking_id, vehicle, paymenttype, ridestatus, bookingtime, fromplace, toplace, price;

    public Cancel(String booking_id, String paymenttype
            , String bookingtime, String vehicle, String ridestatus, String fromplace, String toplace, String price) {

        this.booking_id = booking_id;
        this.vehicle = vehicle;
        this.paymenttype = paymenttype;
        this.ridestatus = ridestatus;
        this.bookingtime = bookingtime;
        this.fromplace = fromplace;
        this.toplace = toplace;
        this.price = price;

    }

    public String getPaymenttype() {
        return paymenttype;
    }

    public String getBookingtime() {
        return bookingtime;
    }

    public String getRidestatus() {
        return ridestatus;
    }

    public String getFromplace() {
        return fromplace;
    }

    public String getToplace() {
        return toplace;
    }

    public String getVehicle() {
        return vehicle;
    }

    public String getId() {
        return booking_id;
    }

    public String getPrice() {
        return price;
    }
}
