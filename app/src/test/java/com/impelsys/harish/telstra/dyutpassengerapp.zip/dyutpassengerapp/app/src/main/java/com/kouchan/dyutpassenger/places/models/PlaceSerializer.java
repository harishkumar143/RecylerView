package com.kouchan.dyutpassenger.places.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PlaceSerializer {
    /**
     * predictions : [{"description":"HSR Layout, Bengaluru, Karnataka, India","id":"cfeef42cd5db5d4c2a55fc842fcdd712fb1092ad","matched_substrings":[{"length":3,"offset":0}],"place_id":"ChIJzW7cv5EUrjsRecj7OYRxMvI","reference":"ChIJzW7cv5EUrjsRecj7OYRxMvI","structured_formatting":{"main_text":"HSR Layout","main_text_matched_substrings":[{"length":3,"offset":0}],"secondary_text":"Bengaluru, Karnataka, India"},"terms":[{"offset":0,"value":"HSR Layout"},{"offset":12,"value":"Bengaluru"},{"offset":23,"value":"Karnataka"},{"offset":34,"value":"India"}],"types":["sublocality_level_1","sublocality","political","geocode"]},{"description":"HSR Layout Police Station, 27th Main Road, 1st Sector, HSR Layout, Bengaluru, Karnataka, India","id":"8a9527172a151cd5855bbbc8cbdf4e8bd7db74f7","matched_substrings":[{"length":3,"offset":0}],"place_id":"ChIJw_Ujl4EUrjsRXuGsfv_xkwI","reference":"ChIJw_Ujl4EUrjsRXuGsfv_xkwI","structured_formatting":{"main_text":"HSR Layout Police Station","main_text_matched_substrings":[{"length":3,"offset":0}],"secondary_text":"27th Main Road, 1st Sector, HSR Layout, Bengaluru, Karnataka, India"},"terms":[{"offset":0,"value":"HSR Layout Police Station"},{"offset":27,"value":"27th Main Road"},{"offset":43,"value":"1st Sector"},{"offset":55,"value":"HSR Layout"},{"offset":67,"value":"Bengaluru"},{"offset":78,"value":"Karnataka"},{"offset":89,"value":"India"}],"types":["police","point_of_interest","establishment"]},{"description":"HSR Layout 5th Sector, Bengaluru, Karnataka, India","id":"88c744e9a71f84d0515bd026cbb7baa42b3701a2","matched_substrings":[{"length":3,"offset":0}],"place_id":"ChIJM3CiL4sUrjsRdzek2j-ZyLM","reference":"ChIJM3CiL4sUrjsRdzek2j-ZyLM","structured_formatting":{"main_text":"HSR Layout 5th Sector","main_text_matched_substrings":[{"length":3,"offset":0}],"secondary_text":"Bengaluru, Karnataka, India"},"terms":[{"offset":0,"value":"HSR Layout 5th Sector"},{"offset":23,"value":"Bengaluru"},{"offset":34,"value":"Karnataka"},{"offset":45,"value":"India"}],"types":["sublocality_level_1","sublocality","political","geocode"]},{"description":"HSR layout Sector 2, 1st Stage, BTM Layout, Bengaluru, Karnataka, India","id":"1fd7897950a04d0607f071c172e3234db480f093","matched_substrings":[{"length":3,"offset":0}],"place_id":"ChIJ1fVhq1cUrjsRPSz9FSV7NFQ","reference":"ChIJ1fVhq1cUrjsRPSz9FSV7NFQ","structured_formatting":{"main_text":"HSR layout Sector 2, 1st Stage, BTM Layout","main_text_matched_substrings":[{"length":3,"offset":0}],"secondary_text":"Bengaluru, Karnataka, India"},"terms":[{"offset":0,"value":"HSR layout Sector 2"},{"offset":21,"value":"1st Stage"},{"offset":32,"value":"BTM Layout"},{"offset":44,"value":"Bengaluru"},{"offset":55,"value":"Karnataka"},{"offset":66,"value":"India"}],"types":["sublocality_level_3","sublocality","political","geocode"]},{"description":"HSR Trinity Appartments, Bandepalya, Muneshwara Nagar, Bengaluru, Karnataka, India","id":"dbe76e718b09d74cf58a38270106d92673c9ec39","matched_substrings":[{"length":3,"offset":0}],"place_id":"ChIJRWUzTLwUrjsR_byswj7xhFE","reference":"ChIJRWUzTLwUrjsR_byswj7xhFE","structured_formatting":{"main_text":"HSR Trinity Appartments","main_text_matched_substrings":[{"length":3,"offset":0}],"secondary_text":"Bandepalya, Muneshwara Nagar, Bengaluru, Karnataka, India"},"terms":[{"offset":0,"value":"HSR Trinity Appartments"},{"offset":25,"value":"Bandepalya"},{"offset":37,"value":"Muneshwara Nagar"},{"offset":55,"value":"Bengaluru"},{"offset":66,"value":"Karnataka"},{"offset":77,"value":"India"}],"types":["premise","establishment"]}]
     * status : OK
     */

    @SerializedName("status")
    private String status;
    @SerializedName("predictions")
    private List<PredictionsBean> predictions;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<PredictionsBean> getPredictions() {
        return predictions;
    }

    public void setPredictions(List<PredictionsBean> predictions) {
        this.predictions = predictions;
    }

    public static class PredictionsBean {
        /**
         * description : HSR Layout, Bengaluru, Karnataka, India
         * id : cfeef42cd5db5d4c2a55fc842fcdd712fb1092ad
         * matched_substrings : [{"length":3,"offset":0}]
         * place_id : ChIJzW7cv5EUrjsRecj7OYRxMvI
         * reference : ChIJzW7cv5EUrjsRecj7OYRxMvI
         * structured_formatting : {"main_text":"HSR Layout","main_text_matched_substrings":[{"length":3,"offset":0}],"secondary_text":"Bengaluru, Karnataka, India"}
         * terms : [{"offset":0,"value":"HSR Layout"},{"offset":12,"value":"Bengaluru"},{"offset":23,"value":"Karnataka"},{"offset":34,"value":"India"}]
         * types : ["sublocality_level_1","sublocality","political","geocode"]
         */

        @SerializedName("description")
        private String description;
        @SerializedName("id")
        private String id;
        @SerializedName("place_id")
        private String placeId;
        @SerializedName("reference")
        private String reference;
        @SerializedName("structured_formatting")
        private StructuredFormattingBean structuredFormatting;
        @SerializedName("matched_substrings")
        private List<MatchedSubstringsBean> matchedSubstrings;
        @SerializedName("terms")
        private List<TermsBean> terms;
        @SerializedName("types")
        private List<String> types;

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPlaceId() {
            return placeId;
        }

        public void setPlaceId(String placeId) {
            this.placeId = placeId;
        }

        public String getReference() {
            return reference;
        }

        public void setReference(String reference) {
            this.reference = reference;
        }

        public StructuredFormattingBean getStructuredFormatting() {
            return structuredFormatting;
        }

        public void setStructuredFormatting(StructuredFormattingBean structuredFormatting) {
            this.structuredFormatting = structuredFormatting;
        }

        public List<MatchedSubstringsBean> getMatchedSubstrings() {
            return matchedSubstrings;
        }

        public void setMatchedSubstrings(List<MatchedSubstringsBean> matchedSubstrings) {
            this.matchedSubstrings = matchedSubstrings;
        }

        public List<TermsBean> getTerms() {
            return terms;
        }

        public void setTerms(List<TermsBean> terms) {
            this.terms = terms;
        }

        public List<String> getTypes() {
            return types;
        }

        public void setTypes(List<String> types) {
            this.types = types;
        }

        public static class StructuredFormattingBean {
            /**
             * main_text : HSR Layout
             * main_text_matched_substrings : [{"length":3,"offset":0}]
             * secondary_text : Bengaluru, Karnataka, India
             */

            @SerializedName("main_text")
            private String mainText;
            @SerializedName("secondary_text")
            private String secondaryText;
            @SerializedName("main_text_matched_substrings")
            private List<MainTextMatchedSubstringsBean> mainTextMatchedSubstrings;

            public String getMainText() {
                return mainText;
            }

            public void setMainText(String mainText) {
                this.mainText = mainText;
            }

            public String getSecondaryText() {
                return secondaryText;
            }

            public void setSecondaryText(String secondaryText) {
                this.secondaryText = secondaryText;
            }

            public List<MainTextMatchedSubstringsBean> getMainTextMatchedSubstrings() {
                return mainTextMatchedSubstrings;
            }

            public void setMainTextMatchedSubstrings(List<MainTextMatchedSubstringsBean> mainTextMatchedSubstrings) {
                this.mainTextMatchedSubstrings = mainTextMatchedSubstrings;
            }

            public static class MainTextMatchedSubstringsBean {
                /**
                 * length : 3
                 * offset : 0
                 */

                @SerializedName("length")
                private int length;
                @SerializedName("offset")
                private int offset;

                public int getLength() {
                    return length;
                }

                public void setLength(int length) {
                    this.length = length;
                }

                public int getOffset() {
                    return offset;
                }

                public void setOffset(int offset) {
                    this.offset = offset;
                }
            }
        }

        public static class MatchedSubstringsBean {
            /**
             * length : 3
             * offset : 0
             */

            @SerializedName("length")
            private int length;
            @SerializedName("offset")
            private int offset;

            public int getLength() {
                return length;
            }

            public void setLength(int length) {
                this.length = length;
            }

            public int getOffset() {
                return offset;
            }

            public void setOffset(int offset) {
                this.offset = offset;
            }
        }

        public static class TermsBean {
            /**
             * offset : 0
             * value : HSR Layout
             */

            @SerializedName("offset")
            private int offset;
            @SerializedName("value")
            private String value;

            public int getOffset() {
                return offset;
            }

            public void setOffset(int offset) {
                this.offset = offset;
            }

            public String getValue() {
                return value;
            }

            public void setValue(String value) {
                this.value = value;
            }
        }
    }




    /*public class Place {
        @SerializedName("place_id")
        private String placeID;

        @SerializedName("description")
        private String description;

        @SerializedName("types")
        private String[] types;

        public Place(String placeID, String description, String[] types) {
            this.placeID = placeID;
            this.description = description;
            this.types = types;
        }

        public String getPlaceID() {
            return placeID;
        }

        public String getDescription() {
            return description;
        }

        public String[] getTypes() {
            return types;
        }

        @Override
        public String toString() {
            return "Place{" +
                    "description='" + description + '\'' +
                    '}';
        }
    }

    @SerializedName("predictions")
    private List<Place> predictions;

    @SerializedName("status")
    private String status;

    public List<Place> getPlaces() {
        return predictions;
    }

    public String getStatus() {
        return status;
    }*/
}
