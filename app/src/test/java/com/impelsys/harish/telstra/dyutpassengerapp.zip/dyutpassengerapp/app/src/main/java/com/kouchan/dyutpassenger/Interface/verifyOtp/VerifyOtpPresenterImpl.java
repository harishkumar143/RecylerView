package com.kouchan.dyutpassenger.Interface.verifyOtp;


import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.View.Activities.AadharRegistrationActivity;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class VerifyOtpPresenterImpl implements OnRequestListener, VerifyOtpPresenter {
    VerifyOtpView verifyOtpView;
    AsyncInteractor mAsyncInteractor;
    AadharRegistrationActivity registrationPassengerDriverActivity;
    Sharedpreferences prefs;

    public VerifyOtpPresenterImpl(VerifyOtpView verifyOtpView) {
        this.verifyOtpView = verifyOtpView;
        this.registrationPassengerDriverActivity = (AadharRegistrationActivity) verifyOtpView;
        this.mAsyncInteractor = new AsyncInteractor(registrationPassengerDriverActivity);
        this.prefs = Sharedpreferences.getUserDataObj(registrationPassengerDriverActivity);
    }


    @Override
    public void verifyOtp(String userOtp, String mobile, String password) {
        if (NetworkStatus.checkNetworkStatus(registrationPassengerDriverActivity)) {
            Map<String, String> params = new HashMap<String, String>();
            params.put("mobile", mobile);
            params.put("password", password);
            params.put("otp", userOtp);

            mAsyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_VERIFY_OTP, Url.PASSENGER_API+"m3otpverifyofpassenger.php", new JSONObject(params),"");
        } else {
            Utils.showToast(registrationPassengerDriverActivity, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if (pid == AppConstants.TAG_ID_VERIFY_OTP) {
            if (responseJson != null) {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    verifyOtpView.verifyOtpSuccess(pid, jObj.getString("next_step"));
                } else {
                    verifyOtpView.verifyOtpError(pid, jObj.getString("error_msg"));
                }
            }
        }

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        verifyOtpView.verifyOtpError(pid, error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
