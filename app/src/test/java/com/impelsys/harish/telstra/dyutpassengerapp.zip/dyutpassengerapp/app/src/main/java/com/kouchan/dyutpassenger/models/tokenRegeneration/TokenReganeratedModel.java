package com.kouchan.dyutpassenger.models.tokenRegeneration;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

public class TokenReganeratedModel {

    /**
     * error : false
     * access_token : 201ca06f5ffcf47b3ad05ace1c0ad50b7076b5fdefcaf6fd1a35db”
     * expires_in : 60
     * token_type : Bearer
     * refresh_token : 2080da9f3471a1cd32fa55be22984895556782f8526dd9aed9
     * scope : BOOKARIDE
     * user_id : BRP5002
     */

    @SerializedName("error")
    private boolean error;
    @SerializedName("access_token")
    private String accessToken;
    @SerializedName("expires_in")
    private String expiresIn;
    @SerializedName("token_type")
    private String tokenType;
    @SerializedName("refresh_token")
    private String refreshToken;
    @SerializedName("scope")
    private String scope;
    @SerializedName("user_id")
    private String userId;

    public static TokenReganeratedModel objectFromData(String str) {

        return new Gson().fromJson(str, TokenReganeratedModel.class);
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(String expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
