package com.kouchan.dyutpassenger.Api;

public interface ServerApiNames {

  String PAYMENT = "paymentintegration.php";
  String LOGIN = "login.php";
  String CANCELLLED_HISTORY_OFPASSENGER = "cancellledHistoryOfPassenger.php";
  String CHANGE_PASSWORD = "changePassword.php";
  String COMPLAINT_REGISTER = "complaintregister.php";
  String Add_Favourite = "favorites.php";
  String FORGOT_PASSWORD = "forgotPassword.php";
  String GET_FAVOURITE ="getfavorites.php";
  String GET_NEAR_BY_DRIVERS ="getNearByDrivers.php";
  String GET_LOGOUT ="logout_of_passenger.php";
  String PassengerHistoryByBookingId = "passengerHistoryByBookingId.php";

  String passengerHistoryByDateDetails = "passengerHistoryByDateDetails.php";
  String passengerHistoryByMonth = "passengerHistoryByMonth.php";
  String passengerHistoryByMonthDetails = "passengerHistoryByMonthDetails.php";
  String RATING = "rating.php";
  String PASSENGER_REGISTER = "register.php";
  String UPDATE_PASSWORD = "updatePassword.php";
  String vehiclesDistanceAndTime = "vehiclesDistanceAndTime.php";
  String ADAVANCE_BOOKING_PASSENGER = "advanceBookingOfPassenger.php";
  String ADAVANCE_BOOKING_ID = "advanceBookingOfPassengerById.php";
  String apk_version = "apkversion.php";
  String bookingCancellationOfDriver = "bookingCancellationOfDriver.php";
  String bookingCancellationOfPassenger = "bookingCancellationOfPassenger.php";
  String cancelledbydriver = "cancelledbydriver.php";
  String driverDetailAfterBooking = "driverDetailAfterBooking.php";
  String driverOfferToCustomer= "driverOfferToCustomer.php";
  String driverResponseTimeOut="driverResponseTimeOut.php";
  String endRideFromDriver = "endRideFromDriver.php";
  String passengerCancel="passengerCancel.php";
  String passengerSelectionOfDriver="passengerSelectionOfDriver.php";

  String paymentReceipt="paymentReceipt.php";
  String removePassengerFromDriverOfferList="removePassengerFromDriverOfferList.php";
  String rideRequest="rideRequest1.php";
  String rideStart = "rideStart.php";
  String sosbuttton = "sosbuttton.php";
  String updateLatLong="updateLatLong.php";
  String distanceCalculateByLatLongNew="distanceCalculateByLatLongNew.php";

}
