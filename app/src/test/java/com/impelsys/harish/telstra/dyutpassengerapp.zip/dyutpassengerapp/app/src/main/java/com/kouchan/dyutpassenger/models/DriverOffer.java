package com.kouchan.dyutpassenger.models;

/**
 * Created by Lincoln on 15/01/16.
 */
public class DriverOffer {
    private String drivername;
    private String drivermobile;
    private String price;
    private String bookingid;
    private String vehicle;
    private String rating;

    private String typeofmeter;
    private String extraLessValue;
    private String metervalue;
    private String whenrequiredtype;
    private String myoffer;
    private String service_tax_val;
    private String service_charge_val;
    private String final_amount_val;
    private String myoffer_service_charge;
    private String myoffer_gst;
    private String vehicle_model;
    private String vehicle_sub_type;
    public long timeRemaining=60000;

    public DriverOffer() {
    }

    public DriverOffer(String drivername, String drivermobile, String price, String bookingid, String vehicle, String rating,
                       String metervalue, String extraLessValue, String typeofmeter, String whenrequiredtype, String myoffer
            , String service_tax_val, String service_charge_val, String final_amount_val,String myoffer_service_charge,String myoffer_gst,String vehicle_model,String vehicle_sub_type) {
        this.drivername = drivername;
        this.drivermobile = drivermobile;
        this.price = price;
        this.bookingid = bookingid;
        this.vehicle = vehicle;
        this.rating = rating;

        this.metervalue = metervalue;
        this.typeofmeter = typeofmeter;
        this.extraLessValue = extraLessValue;
        this.whenrequiredtype = whenrequiredtype;
        this.myoffer = myoffer;

        this.service_tax_val = service_tax_val;
        this.service_charge_val = service_charge_val;
        this.final_amount_val = final_amount_val;
        this.myoffer_service_charge=myoffer_service_charge;
        this.myoffer_gst=myoffer_gst;
        this.vehicle_model=vehicle_model;
        this.vehicle_sub_type=vehicle_sub_type;

    }

    public String getDrivername() {
        return drivername;
    }

    public void setDrivername(String drivername) {
        this.drivername = drivername;
    }

    public String getPrice() {
        return price;
    }

    public void setYear(String year) {
        this.price = year;
    }

    public String getDrivermobile() {
        return drivermobile;
    }

    public void setGenre(String genre) {
        this.drivermobile = genre;
    }

    public String getBookingid() {
        return bookingid;
    }

    public String getVehicle() {
        return vehicle;
    }

    public String getRating() {
        return rating;
    }


    public String getTypeofmeter() {
        return typeofmeter;
    }

    public String getExtraLessValue() {
        return extraLessValue;
    }

    public String getMetervalue() {
        return metervalue;
    }

    public String getWhenrequiredtype() {
        return whenrequiredtype;
    }

    public String getMyoffer() {
        return myoffer;
    }

    public String getService_tax_val() {
        return service_tax_val;
    }

    public void setService_tax_val(String service_tax_val) {
        this.service_tax_val = service_tax_val;
    }

    public String getService_charge_val() {
        return service_charge_val;
    }

    public void setService_charge_val(String service_charge_val) {
        this.service_charge_val = service_charge_val;
    }

    public String getFinal_amount_val() {
        return final_amount_val;
    }

    public void setFinal_amount_val(String final_amount_val) {
        this.final_amount_val = final_amount_val;
    }

    public String getMyoffer_service_charge() {
        return myoffer_service_charge;
    }

    public void setMyoffer_service_charge(String myoffer_service_charge) {
        this.myoffer_service_charge = myoffer_service_charge;
    }

    public String getMyoffer_gst() {
        return myoffer_gst;
    }

    public void setMyoffer_gst(String myoffer_gst) {
        this.myoffer_gst = myoffer_gst;
    }

    public String getVehicle_model() {
        return vehicle_model;
    }

    public void setVehicle_model(String vehicle_model) {
        this.vehicle_model = vehicle_model;
    }


    public String getVehicle_sub_type() {
        return vehicle_sub_type;
    }

    public void setVehicle_sub_type(String vehicle_sub_type) {
        this.vehicle_sub_type = vehicle_sub_type;
    }

}
