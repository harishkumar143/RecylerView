package com.kouchan.dyutpassenger.models;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by KOUCHAN-ADMIN on 12/1/2017.
 */

public class OttoPassengerOffer {

    private String message;
    private String stage;
    private String bookingid;
    private String passengername;
    private String passengermobile;
    private String vehicle;
    private String whenrequired;
    private String whenrequiredtyp;
    private String val;
    private String typeofrate;
    private String rate;
    private String metervalue;
    private String from;
    private String to;
    private String fromlatitude;
    private String fromlongitude;
    private String tolatitude;
    private String tolongitude;
    private String distance;

    private String finalPriceForSortingOfPassenger;
    private String expiry_time;

    public OttoPassengerOffer(String message, String stage, String bookingid, String passengername,
                              String passengermobile, String vehicle, String whenrequired, String whenrequiredtyp,
                              String typeofrate, String rate, String metervalue, String from, String to,
                              String fromlatitude, String fromlongitude, String tolatitude, String tolongitude,
                              String distance, String finalPriceForSortingOfPassenger, String expiry_time) {
        this.message = message;
        this.stage = stage;
        this.bookingid = bookingid;
        this.passengername = passengername;
        this.passengermobile = passengermobile;
        this.vehicle = vehicle;
        this.whenrequired = whenrequired;
        this.whenrequiredtyp = whenrequiredtyp;
        this.typeofrate = typeofrate;
        this.rate = rate;
        this.metervalue = metervalue;
        this.from = from;
        this.to = to;
        this.fromlatitude = fromlatitude;
        this.fromlongitude = fromlongitude;
        this.tolatitude = tolatitude;
        this.tolongitude = tolongitude;
        this.distance = distance;
        this.finalPriceForSortingOfPassenger = finalPriceForSortingOfPassenger;
        this.expiry_time = expiry_time;
    }

    public List getPassengerOffer() {
        List<String> list = new ArrayList<String>();
        list.add(message);
        list.add(stage);
        list.add(bookingid);
        list.add(passengername);
        list.add(passengermobile);
        list.add(vehicle);
        list.add(whenrequired);
        list.add(whenrequiredtyp);
        list.add(typeofrate);
        list.add(rate);
        list.add(metervalue);
        list.add(from);
        list.add(to);
        list.add(fromlatitude);
        list.add(fromlongitude);
        list.add(tolatitude);
        list.add(tolongitude);
        list.add(distance);
        list.add(finalPriceForSortingOfPassenger);
        list.add(expiry_time);

        return list;
    }


}
