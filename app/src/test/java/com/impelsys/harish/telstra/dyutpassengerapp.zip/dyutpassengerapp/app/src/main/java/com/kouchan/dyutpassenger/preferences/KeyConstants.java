package com.kouchan.dyutpassenger.preferences;

/**
 * Created by basavaraj on 5/3/17.
 */

public interface KeyConstants {
  String USER_DETAILS="user_details";
  String KEY_FCM_TOKEN = "fcm_token";
  String USER_PASSWORD = "password";
  String IS_OTP_VERIFIED = "otp";
  String CLOSE_DAILOG = "close";
  String USER_ALTERNATE_NUM = "alternate_num";
  String USER_PHOTO = "userPhoto";
  String KYC_STATUS = "kyc_status";
  String OAUTH_TOKEN = "oauth_token";
  String REFRESH_TOKEN ="refresh_token";
  String FORGOT_PASSWORD_OAUTH_TOKEN="forgot_password_oauth_token";
//<<<<<<< HEAD
  String AADHAR_NUM="aadhar_num";
//=======
  String TRANSACTION_BETWEEN_PERIOD = "between_period";
//>>>>>>> ee44df68c318908b26c4b5e71f988b441ca7c7d7
}
