package com.kouchan.dyutpassenger.async;

public interface IAsyncInteractor {
    void validateCredentialsAsync(OnRequestListener listener, int pid, String url);

}
