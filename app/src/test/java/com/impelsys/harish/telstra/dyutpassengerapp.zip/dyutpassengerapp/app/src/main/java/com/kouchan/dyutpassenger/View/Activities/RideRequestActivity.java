package com.kouchan.dyutpassenger.View.Activities;

import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.location.Location;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.OttoEventFinishedPassengerOffer;
import com.kouchan.dyutpassenger.models.RemovePassengerRequest;
import com.kouchan.dyutpassenger.other.TimerForAvailability;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;
import com.squareup.otto.Subscribe;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class RideRequestActivity extends AppCompatActivity implements OnRequestListener {

    RadioGroup choose_vehicle, when_required, type_of_rate;
    RadioButton taxi, auto, bike, any;
    RadioButton immediate, later;
    RadioButton fixed_amount, ride_per_meter, meter_plus_extra, meter_minus_extra;
    TextView time, whenrequiretpe;
    TextView passengergreeting;
    EditText edit_fixed_amount, edit_per_meter, edit_meter_plus, edit_meter_less;
    EditText bookaridefrom, bookarideto;
    TextView date;

    TextView ride_request_textView, choose_your_ride_textView, when_require_textView,
            distance_textView, meter_price_textView, type_of_meter_textView,
            from_textView, to_textView;

    String languageCode;
    Resources resources;

    AsyncInteractor asyncInteractor;
    SessionManager sessionManager;
    TimerForAvailability timerForAvailability;
    ProgressDialog loading;

    String tolatitude, tolongitude, fromlatitude, fromlongitude, bookingid;

    HashMap<String, String> user;

    Button submit_button, cancel;

    String choose_vehicle_value;
    String type_of_rate_value, meter_value;

    String string_type_of_rate;

    TextView distance, meterPrice;

    String countOfferURL = Url.COMUNICATE_API + "driverOfferToCustomer.php";
    String driverStatus = Url.COMUNICATE_API + "removeDriverFromTokenList.php";

    private static final int PLACE_PICKER_REQUEST_FROM = 1000;
    private static final int PLACE_PICKER_REQUEST_TO = 2000;
    private GoogleApiClient mClient;

    private LocationRequest mLocationRequest;

    Location mLastLocation;

    double lat = 19.0760;
    double longi = 72.8777;

    public LatLngBounds latLngBounds = new LatLngBounds(
            new LatLng(lat, longi), new LatLng(lat, longi));

    Toolbar mToolbar;
    ImageView rideRequestBackImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride_request);

        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//----------------------------------------------------------------------------------------------------------------------
//----------------------Initialize the values for widgets in activity_book_aride.xml-------------------------------------
//-----------------------------------------------------------------------------------------------------------------------
        // ((TextView) findViewById(R.id.textView5)).setText(route.distance.text);
       /*timerForAvailability=new TimerForAvailability(getApplicationContext());
       timerForAvailability.starTimer("NOTAVAILABLE");*/


        NotificationManager notificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
        notificationManager.cancelAll();

        initializeWidget();

        setValueBasedOnRequest();
//----------------------------------------------------------------------------------------------------------------------
//-----------------------------Set values based on options selected---------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------

        setValuesBasedOnOptions();

       /* time.setEnabled(true);*/

     /*   time.setOnClickListener(
                new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(RideRequestActivity.this, new TimePickerDialog.OnTimeSetListener()
                {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute)
                    {
                        String AM_PM;
                        if(selectedHour<12)
                        {
                            AM_PM="AM";
                        }
                        else
                        {
                            AM_PM="PM";
                            selectedHour-=12;
                        }

                        time.setText(selectedHour%12 + ":" + selectedMinute+" "+AM_PM);
                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();
            }
        });*/

        initializeViews();

        EventBusManager.getInstance().getEventBus().register(this);

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        fixed_amount.setText(resources.getString(R.string.fixed_amount));
        ride_per_meter.setText(resources.getString(R.string.per_meter));
        meter_plus_extra.setText(resources.getString(R.string.meter_plus_extra));
        meter_minus_extra.setText(resources.getString(R.string.meter_less_extra));
        submit_button.setText(resources.getString(R.string.counter_offer));
        cancel.setText(resources.getString(R.string.back));

        ride_request_textView.setText(resources.getString(R.string.ride_request));
        choose_your_ride_textView.setText(resources.getString(R.string.choose_your_ride));
        when_require_textView.setText(resources.getString(R.string.when_require));
        distance_textView.setText(resources.getString(R.string.distance));
        meter_price_textView.setText(resources.getString(R.string.meter_price));
        type_of_meter_textView.setText(resources.getString(R.string.type_of_meter));
        from_textView.setText(resources.getString(R.string.from));
        to_textView.setText(resources.getString(R.string.to));

        edit_fixed_amount.setHint(resources.getString(R.string.fixed_amount));
        edit_per_meter.setHint(resources.getString(R.string.per_meter));
        edit_meter_plus.setHint(resources.getString(R.string.meter_plus_extra));
        edit_meter_less.setHint(resources.getString(R.string.meter_less_extra));
    }
   /* @Override
    public void onConnected(Bundle connectionHint) {


    }

    @Override
    public void onConnectionSuspended(int i) {


    }*/


    public void initializeWidget() {

        distance = (TextView) findViewById(R.id.textView20);
        meterPrice = (TextView) findViewById(R.id.textView15);

        choose_vehicle = (RadioGroup) findViewById(R.id.book_a_ride_choose_vehicle);

        taxi = (RadioButton) findViewById(R.id.book_a_ride_taxi);
        auto = (RadioButton) findViewById(R.id.book_a_ride_auto);
        bike = (RadioButton) findViewById(R.id.book_a_ride_bike);
        any = (RadioButton) findViewById(R.id.book_a_ride_any);

        time = (TextView) findViewById(R.id.book_a_ride_book_time);
        whenrequiretpe = (TextView) findViewById(R.id.whenrequiredtypetextbox);

        type_of_rate = (RadioGroup) findViewById(R.id.book_a_ride_type_of_rate);

        fixed_amount = (RadioButton) findViewById(R.id.book_a_ride_fixed_amount);
        ride_per_meter = (RadioButton) findViewById(R.id.book_a_ride_per_meter);
        meter_plus_extra = (RadioButton) findViewById(R.id.book_a_ride_meter_plus_extra);
        meter_minus_extra = (RadioButton) findViewById(R.id.book_a_ride_meter_minus_extra);

        edit_fixed_amount = (EditText) findViewById(R.id.edit_fixed_amount);
        edit_per_meter = (EditText) findViewById(R.id.edit_per_meter);
        edit_meter_plus = (EditText) findViewById(R.id.edit_meter_plus);
        edit_meter_less = (EditText) findViewById(R.id.edit_meter_less);

        bookaridefrom = (EditText) findViewById(R.id.book_a_ride_from);
        bookarideto = (EditText) findViewById(R.id.book_a_ride_to);

        submit_button = (Button) findViewById(R.id.book_a_ride_submit_button);
        cancel = (Button) findViewById(R.id.cancel_button);

        date = (TextView) findViewById(R.id.book_a_ride_date);
        passengergreeting = (TextView) findViewById(R.id.passengergreeting);

        ride_request_textView = (TextView) findViewById(R.id.ride_request_textView);
        choose_your_ride_textView = (TextView) findViewById(R.id.choose_your_ride_textView);
        when_require_textView = (TextView) findViewById(R.id.when_require_textView);
        distance_textView = (TextView) findViewById(R.id.distance_textView);
        meter_price_textView = (TextView) findViewById(R.id.meter_price_textView);
        type_of_meter_textView = (TextView) findViewById(R.id.type_of_meter_textView);
        from_textView = (TextView) findViewById(R.id.from_textView);
        to_textView = (TextView) findViewById(R.id.to_textView);

        sessionManager = new SessionManager(getApplicationContext());


        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        Date dates = cal.getTime();

        SimpleDateFormat dateformat = new SimpleDateFormat("dd-MM-yy");

        date.setText(dateformat.format(dates));

        edit_fixed_amount.setEnabled(false);
        edit_per_meter.setEnabled(false);
        edit_meter_plus.setEnabled(false);
        edit_meter_less.setEnabled(false);

      /*  mClient = new GoogleApiClient
                .Builder(this)
                .addApi(Places.GEO_DATA_API)
                .addApi(Places.PLACE_DETECTION_API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();*/
    }

    public void setValueBasedOnRequest() {
        distance.setText(getIntent().getStringExtra("distance"));
        edit_per_meter.setText(getIntent().getStringExtra("metervalue"));
        meterPrice.setText(getIntent().getStringExtra("metervalue"));

        passengergreeting.setText("Hello, I " + getIntent().getStringExtra("passengername") + " want a ride on the following terms , send counter offer or Your Acceptance.");

        if (getIntent().getStringExtra("vehicle").equals("Taxi")) {
            taxi.setChecked(true);
        } else if (getIntent().getStringExtra("vehicle").equals("Auto")) {
            auto.setChecked(true);
        } else if (getIntent().getStringExtra("vehicle").equals("Bike")) {
            bike.setChecked(true);
        } else {
            any.setChecked(true);
        }

        time.setText(getIntent().getStringExtra("whenrequired"));
        whenrequiretpe.setText(getIntent().getStringExtra("whenrequiredtype"));

        if (getIntent().getStringExtra("typeofrate").equals("Fixed Amount")) {
            fixed_amount.setChecked(true);

            edit_fixed_amount.setEnabled(true);
            edit_fixed_amount.setText(getIntent().getStringExtra("rate"));
            string_type_of_rate = "Fixed Amount";
            type_of_rate_value = getIntent().getStringExtra("rate");
        } else if (getIntent().getStringExtra("typeofrate").equals("Permeter")) {
            ride_per_meter.setChecked(true);

            edit_per_meter.setEnabled(false);
            /*edit_per_meter.setText(getIntent().getStringExtra("rate"));*/
            string_type_of_rate = "Permeter";
            type_of_rate_value = getIntent().getStringExtra("rate");
        } else if (getIntent().getStringExtra("typeofrate").equals("Meter Plus Extra")) {
            meter_plus_extra.setChecked(true);

            edit_meter_plus.setEnabled(true);
            edit_meter_plus.setText(getIntent().getStringExtra("rate"));
            string_type_of_rate = "Meter Plus Extra";
            type_of_rate_value = getIntent().getStringExtra("rate");
        } else if (getIntent().getStringExtra("typeofrate").equals("Meter Minus Extra")) {
            meter_minus_extra.setChecked(true);

            edit_meter_less.setEnabled(true);
            edit_meter_less.setText(getIntent().getStringExtra("rate"));
            string_type_of_rate = "Meter Minus Extra";
            type_of_rate_value = getIntent().getStringExtra("rate");
        }

        bookaridefrom.setText(getIntent().getStringExtra("from"));
        bookarideto.setText(getIntent().getStringExtra("to"));
        fromlatitude = getIntent().getStringExtra("fromlatitude");
        fromlongitude = getIntent().getStringExtra("fromlongitude");
        tolatitude = getIntent().getStringExtra("tolatitude");
        tolongitude = getIntent().getStringExtra("tolongitude");
        bookingid = getIntent().getStringExtra("bookingid");

    }

    public void sendCounterOffer() {

        meter_value = edit_per_meter.getText().toString();

        Utils.showProgress(this);
        Map<String, String> params = new HashMap<String, String>();
        params.put("drivername", user.get("name"));
        params.put("drivermobile", user.get("mobile"));
        params.put("passengername", getIntent().getStringExtra("passengername"));
        params.put("passengermobile", getIntent().getStringExtra("passengermobile"));
        params.put("vehicle", getIntent().getStringExtra("vehicle"));
        params.put("whenrequired", time.getText().toString());
        params.put("whenrequiredtype", whenrequiretpe.getText().toString());
        params.put("typeofrate", string_type_of_rate);
        params.put("rate", type_of_rate_value);
        params.put("metervalue", meter_value);
        params.put("from", bookaridefrom.getText().toString());
        params.put("to", bookarideto.getText().toString());
        params.put("fromlatitude", fromlatitude);
        params.put("fromlongitude", fromlongitude);
        params.put("tolatitude", tolatitude);
        params.put("tolongitude", tolongitude);
        params.put("bookingid", bookingid);
        params.put("final_amount_val",getIntent().getStringExtra("final_amount_val"));
        params.put("service_charge_val",getIntent().getStringExtra("service_charge_val"));
        params.put("service_tax_val",getIntent().getStringExtra("service_tax_val"));

        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_driverOfferToCustomer,Url.COMUNICATE_API+ServerApiNames.driverOfferToCustomer,new JSONObject(params));

        /*final ProgressDialog loading = ProgressDialog.show(this, resources.getString(R.string.processing),resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, countOfferURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                OttoEventFinishedPassengerOffer ottoEventFinishedPassengerOffer=new OttoEventFinishedPassengerOffer("finished");
                                EventBusManager.getInstance().getEventBus().post(ottoEventFinishedPassengerOffer);


                                timerForAvailability = new TimerForAvailability(getApplicationContext());
                                sessionManager.setUpdateButton("waiting");
                                timerForAvailability.starTimer();

                                Intent intent1 = new Intent(RideRequestActivity.this, NavHome.class);
                                intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent1);



                                finish();

                            } else {


                                String errorMsg = jObj.getString("error_msg");
                                //  startActivity(new Intent(RideRequestActivity.this,NavHome.class));
                            }
                        } catch (Exception e) {
                            Log.d("Error", e.toString());
                            loading.dismiss();
                            //    startActivity(new Intent(RideRequestActivity.this,NavHome.class));
                        }
                    }
                }
                ,
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.d("Error", error.toString());
                        //   startActivity(new Intent(RideRequestActivity.this,NavHome.class));
                        loading.dismiss();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                params.put("drivername", user.get("name"));
                params.put("drivermobile", user.get("mobile"));
                params.put("passengername", getIntent().getStringExtra("passengername"));
                params.put("passengermobile", getIntent().getStringExtra("passengermobile"));
                params.put("vehicle", getIntent().getStringExtra("vehicle"));
                params.put("whenrequired", time.getText().toString());
                params.put("whenrequiredtype", whenrequiretpe.getText().toString());
                params.put("typeofrate", string_type_of_rate);
                params.put("rate", type_of_rate_value);
                params.put("metervalue", meter_value);
                params.put("from", bookaridefrom.getText().toString());
                params.put("to", bookarideto.getText().toString());
                params.put("fromlatitude", fromlatitude);
                params.put("fromlongitude", fromlongitude);
                params.put("tolatitude", tolatitude);
                params.put("tolongitude", tolongitude);
                params.put("bookingid", bookingid);
                params.put("final_amount_val",getIntent().getStringExtra("final_amount_val"));
                params.put("service_charge_val",getIntent().getStringExtra("service_charge_val"));
                params.put("service_tax_val",getIntent().getStringExtra("service_tax_val"));
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(2500, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        VolleySingleton.getInstance(RideRequestActivity.this).addToRequestQueue(stringRequest);*/
    }


    public void setValuesBasedOnOptions() {

        user = new HashMap<String, String>();

        user = sessionManager.getUserDetails();
        //-------------------------------------------------------------------------------------------------------------------------
//--------------------------set the selected values for vehicle choice based choice of passenger---------------------------
//-------------------------------------------------------------------------------------------------------------------------

        choose_vehicle.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.book_a_ride_taxi:

                        choose_vehicle_value = taxi.getText().toString();
                        break;

                    case R.id.book_a_ride_auto:

                        choose_vehicle_value = auto.getText().toString();
                        break;

                    case R.id.book_a_ride_bike:

                        choose_vehicle_value = bike.getText().toString();
                        break;

                    case R.id.book_a_ride_any:

                        choose_vehicle_value = any.getText().toString();
                        break;
                }
            }
        });
//----------------------------------------------------------------------------------------------------------------
//-----------------------------set the when required values based choice of passenger-----------------------------
//----------------------------------------------------------------------------------------------------------------

        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);

                time.setText(hour + " : " + minute);

                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(RideRequestActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        String AM_PM;
                        if (selectedHour < 12) {
                            AM_PM = "AM";
                        } else {
                            AM_PM = "PM";
                            selectedHour -= 12;
                        }
                        time.setText(selectedHour + " : " + selectedMinute);
                    }
                }, hour, minute, false);//Yes 24 hour time
                mTimePicker.setTitle(resources.getString(R.string.select_time));
                mTimePicker.show();
            }
        });

//        when_required.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
//        {
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId)
//            {
//                switch (checkedId)
//                {
//                    //-------------------------------------------------------------------
//                    //-----sets the current time because immediate option is selected----
//                    //-------------------------------------------------------------------
//                    case R.id.book_a_ride_immediate:
//
//                        later_time.setEnabled(false);
//
//                        Calendar mcurrentTime = Calendar.getInstance();
//                        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
//                        int minute = mcurrentTime.get(Calendar.MINUTE);
//
//                       when_required_value=immediate.getText().toString();
//
//                        break;
//                    //--------------------------------------------------------------------------------------------
//                    //----gives the choice to select time by a dialog of clock when cloice "later is selected"----
//                    //--------------------------------------------------------------------------------------------
//                    case R.id.book_a_ride_later:
//
//                        later_time.setEnabled(true);
//
//                        later_time.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View v) {
//                                Calendar mcurrentTime = Calendar.getInstance();
//                                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
//                                int minute = mcurrentTime.get(Calendar.MINUTE);
//                                TimePickerDialog mTimePicker;
//                                mTimePicker = new TimePickerDialog(RideRequestActivity.this, new TimePickerDialog.OnTimeSetListener()
//                                {
//                                    @Override
//                                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
//                                        later_time.setText(selectedHour%12 + ":" + selectedMinute);
//                                    }
//                                }, hour, minute, false);//Yes 24 hour time
//                                mTimePicker.setDrivername("Select Time");
//                                mTimePicker.show();
//                            }
//                        });
//
//                        when_required_value=later_time.getText().toString();
//
//                        break;
//                }
//            }
//        });

        edit_fixed_amount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                type_of_rate_value = edit_fixed_amount.getText().toString();
                string_type_of_rate = "Fixed Amount";
            }
        });

        edit_per_meter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                type_of_rate_value = "0";
                string_type_of_rate = "Permeter";
                meter_value = edit_per_meter.getText().toString();
            }
        });

        edit_meter_plus.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                type_of_rate_value = edit_meter_plus.getText().toString();
                string_type_of_rate = "Meter Plus Extra";
            }
        });

        edit_meter_less.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                type_of_rate_value = edit_meter_less.getText().toString();
                string_type_of_rate = "Meter Minus Extra";
            }
        });

//----------------------------------------------------------------------------------------------------------------
//-----------------------------Selection of type of rate and the value--------------------------------------------
//----------------------------------------------------------------------------------------------------------------

        type_of_rate.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.book_a_ride_fixed_amount:

                        edit_fixed_amount.setEnabled(true);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(false);

                        edit_fixed_amount.requestFocus();
                        edit_fixed_amount.setFocusableInTouchMode(true);

                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.showSoftInput(edit_fixed_amount, InputMethodManager.SHOW_FORCED);

                        /*edit_per_meter.setText("");*/
                        edit_meter_plus.setText("");
                        edit_meter_less.setText("");

                        edit_fixed_amount.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                type_of_rate_value = edit_fixed_amount.getText().toString();
                                string_type_of_rate = "Fixed Amount";
                            }
                        });

                        break;

                    case R.id.book_a_ride_per_meter:

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(false);

                        edit_fixed_amount.setText("");
                        edit_meter_plus.setText("");
                        edit_meter_less.setText("");


                        type_of_rate_value = edit_per_meter.getText().toString();
                        string_type_of_rate = "Permeter";

                        edit_per_meter.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                /*type_of_rate_value=edit_per_meter.getText().toString();
                                string_type_of_rate="permeter";*/
                            }
                        });

                        break;

                    case R.id.book_a_ride_meter_plus_extra:

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(true);
                        edit_meter_less.setEnabled(false);

                        edit_meter_plus.requestFocus();
                        edit_meter_plus.setFocusableInTouchMode(true);

                        InputMethodManager imm2 = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm2.showSoftInput(edit_meter_plus, InputMethodManager.SHOW_FORCED);

                        edit_fixed_amount.setText("");
                       /* edit_per_meter.setText("");*/
                        edit_meter_less.setText("");

                        edit_meter_plus.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                type_of_rate_value = edit_meter_plus.getText().toString();
                                string_type_of_rate = "Meter Plus Extra";
                            }
                        });

                        break;

                    case R.id.book_a_ride_meter_minus_extra:

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(true);

                        edit_meter_less.requestFocus();
                        edit_meter_less.setFocusableInTouchMode(true);

                        InputMethodManager imm3 = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm3.showSoftInput(edit_meter_less, InputMethodManager.SHOW_FORCED);

                        edit_fixed_amount.setText("");
                        edit_meter_plus.setText("");

                        edit_meter_less.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                type_of_rate_value = edit_meter_less.getText().toString();
                                string_type_of_rate = "Meter Minus Extra";
                            }
                        });

                        break;
                }
            }
        });

   /*     bookaridefrom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();

                builder.setLatLngBounds(latLngBounds);
                try {
                    startActivityForResult(builder.build(RideRequestActivity.this), PLACE_PICKER_REQUEST_FROM);
                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }

            }
        });*/

 /*       bookarideto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                builder.setLatLngBounds(latLngBounds);
                try {
                    startActivityForResult(builder.build(RideRequestActivity.this), PLACE_PICKER_REQUEST_TO);
                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }

            }
        });*/

        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
                sendCounterOffer();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
                //sendAvaibility();

            }
        });

    }

   /* @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }*/

    @Override
    protected void onStart() {
        super.onStart();

        /*mClient.connect();*/
    }

    @Override
    protected void onStop() {
      /*  mClient.disconnect();*/
        super.onStop();
      /*  EventBusManager.getInstance().getEventBus().unregister(this);*/
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBusManager.getInstance().getEventBus().unregister(this);
    }

/*    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == PLACE_PICKER_REQUEST_FROM) {
            if (resultCode == RESULT_OK) {
                Place place = PlacePicker.getPlace(data, this);
                StringBuilder stBuilder = new StringBuilder();
                String placename = String.format("%s", place.getName());
                String latitude = String.valueOf(place.getLatLng().latitude);
                String longitude = String.valueOf(place.getLatLng().longitude);

                fromlatitude = String.valueOf(place.getLatLng().latitude);
                fromlongitude = String.valueOf(place.getLatLng().longitude);
                String address = String.format("%s", place.getAddress());

                String locale = String.format("%s", place.getLocale());

                stBuilder.append("Name: ");
                stBuilder.append(placename);
                stBuilder.append("\n");
                stBuilder.append("Latitude: ");
                stBuilder.append(latitude);
                stBuilder.append("\n");
                stBuilder.append("Logitude: ");
                stBuilder.append(longitude);
                stBuilder.append("\n");
                stBuilder.append("Address: ");
                stBuilder.append(address);

                stBuilder.append("Locale: ");
                stBuilder.append(locale);
                bookaridefrom.setText(place.getName()+" , "+place.getAddress());

                latLngBounds = new LatLngBounds(
                        new LatLng(place.getLatLng().latitude,place.getLatLng().longitude), new LatLng(place.getLatLng().latitude,place.getLatLng().longitude));
            }
        }

        else if (requestCode == PLACE_PICKER_REQUEST_TO) {
            if (resultCode == RESULT_OK) {
                Place place = PlacePicker.getPlace(data, this);
                StringBuilder stBuilder = new StringBuilder();
                String placename = String.format("%s", place.getName());
                String latitude = String.valueOf(place.getLatLng().latitude);
                String longitude = String.valueOf(place.getLatLng().longitude);

                tolatitude = String.valueOf(place.getLatLng().latitude);
                tolongitude = String.valueOf(place.getLatLng().longitude);

                String address = String.format("%s", place.getAddress());
                stBuilder.append("Name: ");
                stBuilder.append(placename);
                stBuilder.append("\n");
                stBuilder.append("Latitude: ");
                stBuilder.append(latitude);
                stBuilder.append("\n");
                stBuilder.append("Logitude: ");
                stBuilder.append(longitude);
                stBuilder.append("\n");
                stBuilder.append("Address: ");
                stBuilder.append(address);
                bookarideto.setText(place.getName()+" "+place.getAddress());

                latLngBounds = new LatLngBounds(
                        new LatLng(place.getLatLng().latitude,place.getLatLng().longitude), new LatLng(place.getLatLng().latitude,place.getLatLng().longitude));
            }
        }
    }*/

    private void sendAvaibility() {
        {
            user = sessionManager.getUserDetails();
            loading = ProgressDialog.show(this, resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);

            StringRequest stringRequest = new StringRequest(Request.Method.POST, driverStatus,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                loading.dismiss();
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {

                                    // User successfully stored in MySQL
                                    sessionManager.setUpdateButton("started");

                                    Intent intent1 = new Intent(RideRequestActivity.this, NavHome.class);
                                    intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent1);
                                    finish();

                                } else {

                                    // Error occurred in registration. Get the error
                                    // message
                                    String errorMsg = jObj.getString("error_msg");
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            loading.dismiss();
                            finish();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("drivermobile", user.get("mobile"));
                    params.put("bookingid", bookingid);
                    params.put("passengermobile", getIntent().getStringExtra("passengermobile"));

                    return params;
                }

            };
            // remove caching
            stringRequest.setShouldCache(false);
            // Wait 30 seconds and don't retry more than once
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(0, 0,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }


    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        finish();
    }

    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        rideRequestBackImageView = (ImageView) findViewById(R.id.rideRequestBackImageView);

        rideRequestBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    @Subscribe
    public void getButtonStatus(RemovePassengerRequest data) {
        Log.i("Activity", data.getBookingid());
        if (data.getBookingid().equals(bookingid)) {

      /*  Intent intent1=new Intent(RideRequestActivity.this,NavHome.class);
        intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | IntentCompat.FLAG_ACTIVITY_CLEAR_TASK);*/
      /*  startActivity(intent1);*/


            finish();

        }

    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        Utils.stopProgress(this);
        if(pid==AppConstants.TAG_ID_driverOfferToCustomer)
            try {
                loading.dismiss();
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    OttoEventFinishedPassengerOffer ottoEventFinishedPassengerOffer=new OttoEventFinishedPassengerOffer("finished");
                    EventBusManager.getInstance().getEventBus().post(ottoEventFinishedPassengerOffer);


                    timerForAvailability = new TimerForAvailability(getApplicationContext());
                    sessionManager.setUpdateButton("waiting");
                    timerForAvailability.starTimer();

                    Intent intent1 = new Intent(RideRequestActivity.this, NavHome.class);
                    intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent1);



                    finish();

                } else {


                    String errorMsg = jObj.getString("error_msg");
                    //  startActivity(new Intent(RideRequestActivity.this,NavHome.class));
                }
            } catch (Exception e) {
                Log.d("Error", e.toString());
                loading.dismiss();
                //    startActivity(new Intent(RideRequestActivity.this,NavHome.class));
            }

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
