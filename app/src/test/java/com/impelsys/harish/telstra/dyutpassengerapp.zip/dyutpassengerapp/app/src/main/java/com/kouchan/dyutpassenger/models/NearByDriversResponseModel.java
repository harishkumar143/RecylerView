package com.kouchan.dyutpassenger.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class NearByDriversResponseModel {


    /**
     * user : [{"time":"2 min","lat":"12.974676","lng":"77.6053325","distance":"0.3 km","vehicle_type":"Taxi(4+1)","vehicle_type_id":5},{"time":"2 min","lat":"12.97450090519","lng":"77.605271568554","distance":"0.2 km","vehicle_type":"Taxi(4+1)","vehicle_type_id":7},{"time":"2 min","lat":"12.974488012647","lng":"77.605267919815","distance":"0.2 km","vehicle_type":"Taxi(7+1)","vehicle_type_id":9},{"time":"2 min","lat":"12.974448877946","lng":"77.605256844246","distance":"0.2 km","vehicle_type":"Auto","vehicle_type_id":10}]
     * error : false
     */

    @SerializedName("error")
    private boolean mError;
    @SerializedName("user")
    private List<UserBean> mUser;

    public boolean isError() {
        return mError;
    }

    public void setError(boolean error) {
        mError = error;
    }

    public List<UserBean> getUser() {
        return mUser;
    }

    public void setUser(List<UserBean> user) {
        mUser = user;
    }

    public static class UserBean {
        /**
         * time : 2 min
         * lat : 12.974676
         * lng : 77.6053325
         * distance : 0.3 km
         * vehicle_type : Taxi(4+1)
         * vehicle_type_id : 5
         */

        @SerializedName("time")
        private String mTime;
        @SerializedName("lat")
        private String mLat;
        @SerializedName("lng")
        private String mLng;
        @SerializedName("distance")
        private String mDistance;
        @SerializedName("vehicle_type")
        private String mVehicleType;
        @SerializedName("vehicle_type_id")
        private int mVehicleTypeId;

        public String getTime() {
            return mTime;
        }

        public void setTime(String time) {
            mTime = time;
        }

        public String getLat() {
            return mLat;
        }

        public void setLat(String lat) {
            mLat = lat;
        }

        public String getLng() {
            return mLng;
        }

        public void setLng(String lng) {
            mLng = lng;
        }

        public String getDistance() {
            return mDistance;
        }

        public void setDistance(String distance) {
            mDistance = distance;
        }

        public String getVehicleType() {
            return mVehicleType;
        }

        public void setVehicleType(String vehicleType) {
            mVehicleType = vehicleType;
        }

        public int getVehicleTypeId() {
            return mVehicleTypeId;
        }

        public void setVehicleTypeId(int vehicleTypeId) {
            mVehicleTypeId = vehicleTypeId;
        }
    }
}
