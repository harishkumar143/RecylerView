package com.kouchan.dyutpassenger;


import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.kouchan.dyutpassenger.Api.Retry;

import org.json.JSONObject;

/**
 * Created by Basavaraj on 11/16/17.
 * KaHa Technologies Pvt Ltd
 * basavaraj.navi@coveiot.com
 * M3APP
 */


public class VolleyJsonObjectRequest  extends JsonObjectRequest {
  private final String TAG = VolleyJsonObjectRequest.class.getSimpleName();
  String url;
  public VolleyJsonObjectRequest(int method, String url, JSONObject jsonRequest,
                                 Response.Listener<JSONObject> listener, Response.ErrorListener errorListener) {
    super(method, url, jsonRequest, listener, errorListener);

    this.url = url;
    Retry.method = method;
  }

  public VolleyJsonObjectRequest(String url, JSONObject jsonRequest,
                                 Response.Listener<JSONObject> listener, Response.ErrorListener errorListener) {
    super(url, null, listener, errorListener);
    this.url = url;
  }
  @Override
  protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
    if (response!=null){
      try {

      }catch (Exception e){
        e.printStackTrace();
      }

    }
    return super.parseNetworkResponse(response);
  }

  @Override
  protected VolleyError parseNetworkError(VolleyError volleyError) {
    String errorMessage = "";
    try {
      if (volleyError instanceof AuthFailureError){
        
      }else if(volleyError instanceof TimeoutError){
        Log.e("TimeoutError","TimeoutError error -------------");
      }
      /*errorMessage = new String(volleyError.networkResponse.data);
      Log.e("Error Reason: ", errorMessage);*/
      if (volleyError.networkResponse != null) {
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

    return super.parseNetworkError(volleyError);
  }
}
