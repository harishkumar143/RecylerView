package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 10/18/2017.
 */

public class OttoEventButton {

    String buttonStatus;

    String bookingId;
    String to;
    String prise;
    String typeOfRate;

    public OttoEventButton(String buttonStatus) {
        this.buttonStatus = buttonStatus;
    }

    public String getButtonStatus() {
        return buttonStatus;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getPrise() {
        return prise;
    }

    public void setPrise(String prise) {
        this.prise = prise;
    }

    public String getTypeOfRate() {
        return typeOfRate;
    }

    public void setTypeOfRate(String typeOfRate) {
        this.typeOfRate = typeOfRate;
    }


}
