package com.kouchan.dyutpassenger.places.api;

public interface DirectionUrl {
    String MAPS_API_URL = "https://maps.googleapis.com/maps/api/";
    String PLACE_AUTOCOMPLETE_API_URL = "place/autocomplete/json";
    String PLACE_DETAILS_API_URL = "place/details/json";
    String DIRECTION_API_URL = "directions/json";
}
