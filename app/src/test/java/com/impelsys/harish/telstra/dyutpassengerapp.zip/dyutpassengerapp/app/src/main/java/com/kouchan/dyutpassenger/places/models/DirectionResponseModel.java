package com.kouchan.dyutpassenger.places.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;


public class DirectionResponseModel {

    /**
     * geocoded_waypoints : [{"geocoder_status":"OK","place_id":"ChIJLYNyk60VrjsRH1iSTlsNwc4","types":["establishment","point_of_interest"]},{"geocoder_status":"OK","place_id":"ChIJqbPgMsM9rjsRy3gY5dJLSTw","types":["street_address"]}]
     * routes : [{"bounds":{"northeast":{"lat":12.9757275,"lng":77.6036985},"southwest":{"lat":12.9287006,"lng":77.53538549999999}},"copyrights":"Map data ©2019","legs":[{"distance":{"text":"13.6 km","value":13551},"duration":{"text":"43 mins","value":2556},"end_address":"20, 5th Main Rd, Govindaraja Nagar Ward, Govindarajanagar, Vijayanagar, Bengaluru, Karnataka 560040, India","end_location":{"lat":12.9756,"lng":77.53540000000001},"start_address":"4/1 Bannerghatta Main Road 9th Floor Tower D IBC Towers, Bhavani Nagar, S.G. Palya, Bengaluru, Karnataka 560029, India","start_location":{"lat":12.9330309,"lng":77.6036985},"steps":[{"distance":{"text":"0.3 km","value":286},"duration":{"text":"2 mins","value":131},"end_location":{"lat":12.933494,"lng":77.6011017},"html_instructions":"Head <b>west<\/b> on <b>IBC Internal Rd<\/b> towards <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Restricted-usage road<\/div><div style=\"font-size:0.9em\">Drive along Accenture Tower A and B (on the left for 130&nbsp;m)<\/div>","polyline":{"points":"m~|mAc~sxMc@lEw@xH"},"start_location":{"lat":12.9330309,"lng":77.6036985},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":366},"duration":{"text":"1 min","value":78},"end_location":{"lat":12.9302382,"lng":77.6006519},"html_instructions":"Turn <b>left<\/b> at IBC Pickup Point onto <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Pass by IBC Knowledge Park (on the left)<\/div>","maneuver":"turn-left","polyline":{"points":"ia}mA{msxMzFl@fDR`@DjADd@B|@DN?B@"},"start_location":{"lat":12.933494,"lng":77.6011017},"travel_mode":"DRIVING"},{"distance":{"text":"0.2 km","value":181},"duration":{"text":"1 min","value":56},"end_location":{"lat":12.9287032,"lng":77.6005893},"html_instructions":"Slight <b>left<\/b> to stay on <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Advaith Hyundai Service Center, BG Road - Bannerghatta Rd (on the left)<\/div>","maneuver":"turn-slight-left","polyline":{"points":"_m|mAaksxM^QHAJCF?@?BAr@BZ?fBBN@L@F@B@@@@@BFDH"},"start_location":{"lat":12.9302382,"lng":77.6006519},"travel_mode":"DRIVING"},{"distance":{"text":"0.8 km","value":795},"duration":{"text":"2 mins","value":139},"end_location":{"lat":12.9356869,"lng":77.6013626},"html_instructions":"Turn <b>right<\/b> at Smart Space Interiors to stay on <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Pass by S A Associates - Auditor &amp; Tax Consultant (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"kc|mAujsxM?TS?}@AcFMO?o@GO?UAc@Cc@CSAkDQg@EaAKc@Ec@Ga@GWCkDa@aAK_AKs@CSAoBM"},"start_location":{"lat":12.9287032,"lng":77.6005893},"travel_mode":"DRIVING"},{"distance":{"text":"0.2 km","value":152},"duration":{"text":"1 min","value":18},"end_location":{"lat":12.9370382,"lng":77.6015323},"html_instructions":"Slight <b>left<\/b> at Bengaluru Dairy Circle (Towards Jayadeva Hospital) onto <b>Bannerghatta-Marigowda Turn Rd<\/b><div style=\"font-size:0.9em\">Pass by Sushma Industries (on the left)<\/div>","maneuver":"turn-slight-left","polyline":{"points":"ao}mAoosxMWDSA_BOiAOw@E"},"start_location":{"lat":12.9356869,"lng":77.6013626},"travel_mode":"DRIVING"},{"distance":{"text":"2.9 km","value":2868},"duration":{"text":"9 mins","value":513},"end_location":{"lat":12.9541523,"lng":77.5849047},"html_instructions":"Turn <b>left<\/b> at Quality Management Service onto <b>Bannerghatta-Marigowda Turn Rd<\/b>/<b>Hosur Main Road<\/b>/<b>Marigowda Rd<\/b><div style=\"font-size:0.9em\">Pass by Bengaluru Dairy Circle (Towards Lakkasandra) (on the right)<\/div>","maneuver":"turn-left","polyline":{"points":"ow}mAqpsxMAZCT?LEd@GhAKhAOx@I^Ob@KVYj@MVOXKJKDq@p@[Vi@`@MHy@j@i@Xi@To@Zi@Ng@LYDmBLaCJkBJa@B{BJ_AHaAHSBu@JiAJu@Hi@H[F_@DYF_@RONOPUR{@|AQ\\g@`AcBpBc@n@u@r@QLk@^[NYNoAXcA\\}@b@u@d@UHUDe@NaBn@A?[LA@i@X[ZST[^QPk@l@a@b@STOXO^K\\]|@O`@I^ET@@?@@??@?@@@?@?DAB?BCDC@CBE@Oh@EJEBGDq@pCsBzIGT[lAEHEJGLGHCFOPMNOPg@n@q@x@w@|@G`@EZCV]t@G`@"},"start_location":{"lat":12.9370382,"lng":77.6015323},"travel_mode":"DRIVING"},{"distance":{"text":"0.5 km","value":539},"duration":{"text":"2 mins","value":109},"end_location":{"lat":12.9551566,"lng":77.5800685},"html_instructions":"Continue straight past CS-Lalbagh Main Gate onto <b>Lalbagh Fort Rd<\/b><div style=\"font-size:0.9em\">Pass by B.S Auto Engineering Work (on the left)<\/div>","maneuver":"straight","polyline":{"points":"mbanAshpxMk@lCUx@Ml@Mf@Ip@CNANAF?HCZGt@AZATAJAFEv@Ab@Cb@EhAI|AOdAAFKRCFCJCL"},"start_location":{"lat":12.9541523,"lng":77.5849047},"travel_mode":"DRIVING"},{"distance":{"text":"1.1 km","value":1078},"duration":{"text":"4 mins","value":262},"end_location":{"lat":12.9633264,"lng":77.5849798},"html_instructions":"Turn <b>right<\/b> at Mobile zone onto <b>JC Rd<\/b><div style=\"font-size:0.9em\">Pass by Sleepwell (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"whanAmjoxM?RMKa@_@oDmDIIkA_Ay@i@uCcB}Aq@sCmAUKm@U]OMEeAc@eB{@qEoBMGkCiAsB{@KEe@Me@KKAI?"},"start_location":{"lat":12.9551566,"lng":77.5800685},"travel_mode":"DRIVING"},{"distance":{"text":"3.3 km","value":3308},"duration":{"text":"6 mins","value":348},"end_location":{"lat":12.9595793,"lng":77.55595319999999},"html_instructions":"Turn <b>left<\/b> at global Industrial Traders onto <b>Mysore Rd<\/b>/<b>NR Rd<\/b><div style=\"font-size:0.9em\">Continue to follow Mysore Rd<\/div><div style=\"font-size:0.9em\">Pass by Chitradurga Ispat (Pvt) Ltd. (on the left)<\/div>","maneuver":"turn-left","polyline":{"points":"y{bnAcipxMg@Ha@PFtAHXDb@Ff@L|@Fn@FpB@n@A\\?D?~@Ap@InAO|BQxEApAB`A?J?R?b@Cf@Qz@k@rB_@lBAFCL?@ADKj@I\\IVCHO^GTEJMZADGRCLCJEVADA\\?D@^Bb@?@DNBj@@l@Bb@Bd@?HBX@b@Bd@Bb@@d@Bb@Bb@Bd@?@@`@Bb@@d@Bb@?@JfCLhC?^@V@RDTZxA?@?BDLFZXbAn@~Bj@hBZt@BHp@tClAjGDP?BDPH\\Nr@H\\l@rBl@xBZ`BT`BFt@@^Bp@@~A?VBjAJdAL`A\\nC@@\\nCFj@Jj@Rh@Tj@Zf@\\f@v@|ArA`Cf@j@"},"start_location":{"lat":12.9633264,"lng":77.5849798},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":443},"duration":{"text":"2 mins","value":108},"end_location":{"lat":12.9605065,"lng":77.5521033},"html_instructions":"Turn <b>right<\/b> at Design Impex onto <b>Old Guddadahalli Rd<\/b><div style=\"font-size:0.9em\">Go past the church (on the right in 350&nbsp;m)<\/div>","maneuver":"turn-right","polyline":{"points":"kdbnAusjxMKP[b@QTIJKPCFEJGNEJETKf@EXIbA?^?`@Fr@BPBN@Jm@nEIn@ABGb@"},"start_location":{"lat":12.9595793,"lng":77.55595319999999},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":449},"duration":{"text":"2 mins","value":133},"end_location":{"lat":12.964477,"lng":77.5527268},"html_instructions":"Turn <b>right<\/b> at National Defence Office (Old guddadahalli) onto <b>3rd Cross Rd<\/b><div style=\"font-size:0.9em\">Pass by Suhail Gas Point (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"ejbnAs{ixMyCA{@EsACs@E_@Aa@Gu@IaBWC?}E_A"},"start_location":{"lat":12.9605065,"lng":77.5521033},"travel_mode":"DRIVING"},{"distance":{"text":"1.0 km","value":991},"duration":{"text":"4 mins","value":247},"end_location":{"lat":12.9675165,"lng":77.5449993},"html_instructions":"Turn <b>left<\/b> at Ruby Footwear onto <b>Hosahalli Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Star Tele-Links (on the right)<\/div>","maneuver":"turn-left","polyline":{"points":"_ccnAq_jxMEzA?P?l@B\\?H@H@F@HDJHJ@@XRPRFHDFDJ@T@X@l@QjASx@KTSb@Q`@Wp@Qh@ELEFGLOPWVYRIFUL]T]R[T]T]Tk@d@WR_@b@IHEJKRSp@IPMf@q@vBkAlEEN"},"start_location":{"lat":12.964477,"lng":77.5527268},"travel_mode":"DRIVING"},{"distance":{"text":"0.6 km","value":568},"duration":{"text":"2 mins","value":106},"end_location":{"lat":12.9722304,"lng":77.54701969999999},"html_instructions":"Turn <b>right<\/b> at Paras Telecom onto <b>Krishnadevaraya Rd<\/b><div style=\"font-size:0.9em\">Pass by A-One Fruit Stall (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"_vcnAgohxMaA]{@UaAWaA]UIg@OaA_@OEk@Qu@YKC{@]eA_@gA[cA[mAe@qA]"},"start_location":{"lat":12.9675165,"lng":77.5449993},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":443},"duration":{"text":"1 min","value":86},"end_location":{"lat":12.9735257,"lng":77.5431542},"html_instructions":"Turn <b>left<\/b> at G K Seat Works onto <b>1st Main Rd<\/b><div style=\"font-size:0.9em\">Pass by BBMP Birth and Death Office (on the right)<\/div>","maneuver":"turn-left","polyline":{"points":"msdnA{{hxMUl@Qz@Qx@S|@St@mAtFsAvF"},"start_location":{"lat":12.9722304,"lng":77.54701969999999},"travel_mode":"DRIVING"},{"distance":{"text":"44 m","value":44},"duration":{"text":"1 min","value":10},"end_location":{"lat":12.9739108,"lng":77.5432344},"html_instructions":"Turn <b>right<\/b> at Milacron Ferromatik onto <b>4th Cross Rd<\/b><div style=\"font-size:0.9em\">Pass by Maya Fashions (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"q{dnAuchxMq@IYE"},"start_location":{"lat":12.9735257,"lng":77.5431542},"travel_mode":"DRIVING"},{"distance":{"text":"0.1 km","value":109},"duration":{"text":"1 min","value":17},"end_location":{"lat":12.9737105,"lng":77.54224549999999},"html_instructions":"Turn <b>left<\/b> onto <b>Chord Rd<\/b>","maneuver":"turn-left","polyline":{"points":"}}dnAedhxMLfAVtB@D"},"start_location":{"lat":12.9739108,"lng":77.5432344},"travel_mode":"DRIVING"},{"distance":{"text":"0.2 km","value":187},"duration":{"text":"1 min","value":41},"end_location":{"lat":12.9753676,"lng":77.5421671},"html_instructions":"Turn <b>right<\/b> at Sri shakthi stores onto <b>8th Cross Rd<\/b><div style=\"font-size:0.9em\">Pass by Karnataka State Coir Co-operative Federation Ltd. (on the right)<\/div>","maneuver":"turn-right","polyline":{"points":"u|dnAa~gxMk@D[BwBVkCQ"},"start_location":{"lat":12.9737105,"lng":77.54224549999999},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":395},"duration":{"text":"1 min","value":76},"end_location":{"lat":12.9757275,"lng":77.5385412},"html_instructions":"Turn <b>left<\/b> at Sri Raghavendraswamy Electronics onto <b>5th Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Mac Consultants (on the left)<\/div>","maneuver":"turn-left","polyline":{"points":"agenAq}gxMI`BIpAGxAGpAGvAGtAGzAKjB"},"start_location":{"lat":12.9753676,"lng":77.5421671},"travel_mode":"DRIVING"},{"distance":{"text":"0.3 km","value":343},"duration":{"text":"1 min","value":75},"end_location":{"lat":12.9755525,"lng":77.53538549999999},"html_instructions":"At Madhav Villa, continue onto <b>Nagarabhavi Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Sri Raghavendraswamy Electronic (on the left)<\/div>","polyline":{"points":"iienA{fgxM?V?rAF~@?@@l@JvBDr@FvBA|A@V"},"start_location":{"lat":12.9757275,"lng":77.5385412},"travel_mode":"DRIVING"},{"distance":{"text":"6 m","value":6},"duration":{"text":"1 min","value":3},"end_location":{"lat":12.9756,"lng":77.53540000000001},"html_instructions":"Turn <b>right<\/b> at Hubbanahalli Gobi Center","maneuver":"turn-right","polyline":{"points":"ehenAesfxMIA"},"start_location":{"lat":12.9755525,"lng":77.53538549999999},"travel_mode":"DRIVING"}],"traffic_speed_entry":[],"via_waypoint":[]}],"overview_polyline":{"points":"m~|mAc~sxM{AfOzFl@fDRlBJbBHR@h@SXEfEHZFDHD^qAAsFMyBMkG]qN_BgAEoBMWDsBQaCUKdBSrCYxA[z@g@bA[d@}@v@eAx@gAt@sAn@o@Zi@NaARoFXiId@uEd@{C`@YF_@R_@`@UR{@|Ay@~AcBpBc@n@gA`AgAn@YNoAXcA\\}@b@kAn@{@TcBn@]Ni@X[Zo@t@}@~@u@x@_@x@cA|CCX@B?LKNE@Oh@KNGDq@pC{BpJa@vAMXi@r@aDxDM|@CV]t@s@nDc@fBMf@Ip@E^MbBGdAQhEI|AOdAMZGRC`@iFcFkA_Ay@i@uCcB}Aq@iDyAkAe@sAi@eB{@qEoByCqA_CaAkAYUAg@Ha@PFtAHXLjATlBH`DAb@ApBYlEQxEApABlA?v@Cf@Qz@k@rB_@lBAFCNa@fBa@jA[bAIb@Cb@DhADPDxAJlBVbGJnCJhCLhDH`A`@lB`@~AzAhF^~@p@tClAjGDTNn@XpAzAlFp@bEHtAHtFXfC^pCd@zDJj@Rh@Tj@Zf@\\f@v@|ArA`Cf@j@g@t@[`@OXY|@Q`AIbBFtAF`@@Jm@nEKr@Gb@yCA{@EgCIaAIwCa@aF_AElBBjADd@NVZTX\\JRBn@@l@QjASx@KTe@dAu@pBW^q@j@{A~@cCfBw@v@OTw@~B}BdIENaA]}Bm@wAg@eDgAcE{AkCw@mAe@qA]Ul@Qz@e@vBaBjHsAvFq@IYELfAXzBgAHwBVkCQSrDOjDc@tJ?jBF`AZpI?tBIA"},"summary":"Mysore Rd","warnings":[],"waypoint_order":[]}]
     * status : OK
     */

    @SerializedName("status")
    private String status;
    @SerializedName("geocoded_waypoints")
    private List<GeocodedWaypointsBean> geocodedWaypoints;
    @SerializedName("routes")
    private List<RoutesBean> routes;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<GeocodedWaypointsBean> getGeocodedWaypoints() {
        return geocodedWaypoints;
    }

    public void setGeocodedWaypoints(List<GeocodedWaypointsBean> geocodedWaypoints) {
        this.geocodedWaypoints = geocodedWaypoints;
    }

    public List<RoutesBean> getRoutes() {
        return routes;
    }

    public void setRoutes(List<RoutesBean> routes) {
        this.routes = routes;
    }

    public static class GeocodedWaypointsBean {
        /**
         * geocoder_status : OK
         * place_id : ChIJLYNyk60VrjsRH1iSTlsNwc4
         * types : ["establishment","point_of_interest"]
         */

        @SerializedName("geocoder_status")
        private String geocoderStatus;
        @SerializedName("place_id")
        private String placeId;
        @SerializedName("types")
        private List<String> types;

        public String getGeocoderStatus() {
            return geocoderStatus;
        }

        public void setGeocoderStatus(String geocoderStatus) {
            this.geocoderStatus = geocoderStatus;
        }

        public String getPlaceId() {
            return placeId;
        }

        public void setPlaceId(String placeId) {
            this.placeId = placeId;
        }

        public List<String> getTypes() {
            return types;
        }

        public void setTypes(List<String> types) {
            this.types = types;
        }
    }

    public static class RoutesBean {
        /**
         * bounds : {"northeast":{"lat":12.9757275,"lng":77.6036985},"southwest":{"lat":12.9287006,"lng":77.53538549999999}}
         * copyrights : Map data ©2019
         * legs : [{"distance":{"text":"13.6 km","value":13551},"duration":{"text":"43 mins","value":2556},"end_address":"20, 5th Main Rd, Govindaraja Nagar Ward, Govindarajanagar, Vijayanagar, Bengaluru, Karnataka 560040, India","end_location":{"lat":12.9756,"lng":77.53540000000001},"start_address":"4/1 Bannerghatta Main Road 9th Floor Tower D IBC Towers, Bhavani Nagar, S.G. Palya, Bengaluru, Karnataka 560029, India","start_location":{"lat":12.9330309,"lng":77.6036985},"steps":[{"distance":{"text":"0.3 km","value":286},"duration":{"text":"2 mins","value":131},"end_location":{"lat":12.933494,"lng":77.6011017},"html_instructions":"Head <b>west<\/b> on <b>IBC Internal Rd<\/b> towards <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Restricted-usage road<\/div><div style=\"font-size:0.9em\">Drive along Accenture Tower A and B (on the left for 130&nbsp;m)<\/div>","polyline":{"points":"m~|mAc~sxMc@lEw@xH"},"start_location":{"lat":12.9330309,"lng":77.6036985},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":366},"duration":{"text":"1 min","value":78},"end_location":{"lat":12.9302382,"lng":77.6006519},"html_instructions":"Turn <b>left<\/b> at IBC Pickup Point onto <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Pass by IBC Knowledge Park (on the left)<\/div>","maneuver":"turn-left","polyline":{"points":"ia}mA{msxMzFl@fDR`@DjADd@B|@DN?B@"},"start_location":{"lat":12.933494,"lng":77.6011017},"travel_mode":"DRIVING"},{"distance":{"text":"0.2 km","value":181},"duration":{"text":"1 min","value":56},"end_location":{"lat":12.9287032,"lng":77.6005893},"html_instructions":"Slight <b>left<\/b> to stay on <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Advaith Hyundai Service Center, BG Road - Bannerghatta Rd (on the left)<\/div>","maneuver":"turn-slight-left","polyline":{"points":"_m|mAaksxM^QHAJCF?@?BAr@BZ?fBBN@L@F@B@@@@@BFDH"},"start_location":{"lat":12.9302382,"lng":77.6006519},"travel_mode":"DRIVING"},{"distance":{"text":"0.8 km","value":795},"duration":{"text":"2 mins","value":139},"end_location":{"lat":12.9356869,"lng":77.6013626},"html_instructions":"Turn <b>right<\/b> at Smart Space Interiors to stay on <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Pass by S A Associates - Auditor &amp; Tax Consultant (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"kc|mAujsxM?TS?}@AcFMO?o@GO?UAc@Cc@CSAkDQg@EaAKc@Ec@Ga@GWCkDa@aAK_AKs@CSAoBM"},"start_location":{"lat":12.9287032,"lng":77.6005893},"travel_mode":"DRIVING"},{"distance":{"text":"0.2 km","value":152},"duration":{"text":"1 min","value":18},"end_location":{"lat":12.9370382,"lng":77.6015323},"html_instructions":"Slight <b>left<\/b> at Bengaluru Dairy Circle (Towards Jayadeva Hospital) onto <b>Bannerghatta-Marigowda Turn Rd<\/b><div style=\"font-size:0.9em\">Pass by Sushma Industries (on the left)<\/div>","maneuver":"turn-slight-left","polyline":{"points":"ao}mAoosxMWDSA_BOiAOw@E"},"start_location":{"lat":12.9356869,"lng":77.6013626},"travel_mode":"DRIVING"},{"distance":{"text":"2.9 km","value":2868},"duration":{"text":"9 mins","value":513},"end_location":{"lat":12.9541523,"lng":77.5849047},"html_instructions":"Turn <b>left<\/b> at Quality Management Service onto <b>Bannerghatta-Marigowda Turn Rd<\/b>/<b>Hosur Main Road<\/b>/<b>Marigowda Rd<\/b><div style=\"font-size:0.9em\">Pass by Bengaluru Dairy Circle (Towards Lakkasandra) (on the right)<\/div>","maneuver":"turn-left","polyline":{"points":"ow}mAqpsxMAZCT?LEd@GhAKhAOx@I^Ob@KVYj@MVOXKJKDq@p@[Vi@`@MHy@j@i@Xi@To@Zi@Ng@LYDmBLaCJkBJa@B{BJ_AHaAHSBu@JiAJu@Hi@H[F_@DYF_@RONOPUR{@|AQ\\g@`AcBpBc@n@u@r@QLk@^[NYNoAXcA\\}@b@u@d@UHUDe@NaBn@A?[LA@i@X[ZST[^QPk@l@a@b@STOXO^K\\]|@O`@I^ET@@?@@??@?@@@?@?DAB?BCDC@CBE@Oh@EJEBGDq@pCsBzIGT[lAEHEJGLGHCFOPMNOPg@n@q@x@w@|@G`@EZCV]t@G`@"},"start_location":{"lat":12.9370382,"lng":77.6015323},"travel_mode":"DRIVING"},{"distance":{"text":"0.5 km","value":539},"duration":{"text":"2 mins","value":109},"end_location":{"lat":12.9551566,"lng":77.5800685},"html_instructions":"Continue straight past CS-Lalbagh Main Gate onto <b>Lalbagh Fort Rd<\/b><div style=\"font-size:0.9em\">Pass by B.S Auto Engineering Work (on the left)<\/div>","maneuver":"straight","polyline":{"points":"mbanAshpxMk@lCUx@Ml@Mf@Ip@CNANAF?HCZGt@AZATAJAFEv@Ab@Cb@EhAI|AOdAAFKRCFCJCL"},"start_location":{"lat":12.9541523,"lng":77.5849047},"travel_mode":"DRIVING"},{"distance":{"text":"1.1 km","value":1078},"duration":{"text":"4 mins","value":262},"end_location":{"lat":12.9633264,"lng":77.5849798},"html_instructions":"Turn <b>right<\/b> at Mobile zone onto <b>JC Rd<\/b><div style=\"font-size:0.9em\">Pass by Sleepwell (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"whanAmjoxM?RMKa@_@oDmDIIkA_Ay@i@uCcB}Aq@sCmAUKm@U]OMEeAc@eB{@qEoBMGkCiAsB{@KEe@Me@KKAI?"},"start_location":{"lat":12.9551566,"lng":77.5800685},"travel_mode":"DRIVING"},{"distance":{"text":"3.3 km","value":3308},"duration":{"text":"6 mins","value":348},"end_location":{"lat":12.9595793,"lng":77.55595319999999},"html_instructions":"Turn <b>left<\/b> at global Industrial Traders onto <b>Mysore Rd<\/b>/<b>NR Rd<\/b><div style=\"font-size:0.9em\">Continue to follow Mysore Rd<\/div><div style=\"font-size:0.9em\">Pass by Chitradurga Ispat (Pvt) Ltd. (on the left)<\/div>","maneuver":"turn-left","polyline":{"points":"y{bnAcipxMg@Ha@PFtAHXDb@Ff@L|@Fn@FpB@n@A\\?D?~@Ap@InAO|BQxEApAB`A?J?R?b@Cf@Qz@k@rB_@lBAFCL?@ADKj@I\\IVCHO^GTEJMZADGRCLCJEVADA\\?D@^Bb@?@DNBj@@l@Bb@Bd@?HBX@b@Bd@Bb@@d@Bb@Bb@Bd@?@@`@Bb@@d@Bb@?@JfCLhC?^@V@RDTZxA?@?BDLFZXbAn@~Bj@hBZt@BHp@tClAjGDP?BDPH\\Nr@H\\l@rBl@xBZ`BT`BFt@@^Bp@@~A?VBjAJdAL`A\\nC@@\\nCFj@Jj@Rh@Tj@Zf@\\f@v@|ArA`Cf@j@"},"start_location":{"lat":12.9633264,"lng":77.5849798},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":443},"duration":{"text":"2 mins","value":108},"end_location":{"lat":12.9605065,"lng":77.5521033},"html_instructions":"Turn <b>right<\/b> at Design Impex onto <b>Old Guddadahalli Rd<\/b><div style=\"font-size:0.9em\">Go past the church (on the right in 350&nbsp;m)<\/div>","maneuver":"turn-right","polyline":{"points":"kdbnAusjxMKP[b@QTIJKPCFEJGNEJETKf@EXIbA?^?`@Fr@BPBN@Jm@nEIn@ABGb@"},"start_location":{"lat":12.9595793,"lng":77.55595319999999},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":449},"duration":{"text":"2 mins","value":133},"end_location":{"lat":12.964477,"lng":77.5527268},"html_instructions":"Turn <b>right<\/b> at National Defence Office (Old guddadahalli) onto <b>3rd Cross Rd<\/b><div style=\"font-size:0.9em\">Pass by Suhail Gas Point (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"ejbnAs{ixMyCA{@EsACs@E_@Aa@Gu@IaBWC?}E_A"},"start_location":{"lat":12.9605065,"lng":77.5521033},"travel_mode":"DRIVING"},{"distance":{"text":"1.0 km","value":991},"duration":{"text":"4 mins","value":247},"end_location":{"lat":12.9675165,"lng":77.5449993},"html_instructions":"Turn <b>left<\/b> at Ruby Footwear onto <b>Hosahalli Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Star Tele-Links (on the right)<\/div>","maneuver":"turn-left","polyline":{"points":"_ccnAq_jxMEzA?P?l@B\\?H@H@F@HDJHJ@@XRPRFHDFDJ@T@X@l@QjASx@KTSb@Q`@Wp@Qh@ELEFGLOPWVYRIFUL]T]R[T]T]Tk@d@WR_@b@IHEJKRSp@IPMf@q@vBkAlEEN"},"start_location":{"lat":12.964477,"lng":77.5527268},"travel_mode":"DRIVING"},{"distance":{"text":"0.6 km","value":568},"duration":{"text":"2 mins","value":106},"end_location":{"lat":12.9722304,"lng":77.54701969999999},"html_instructions":"Turn <b>right<\/b> at Paras Telecom onto <b>Krishnadevaraya Rd<\/b><div style=\"font-size:0.9em\">Pass by A-One Fruit Stall (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"_vcnAgohxMaA]{@UaAWaA]UIg@OaA_@OEk@Qu@YKC{@]eA_@gA[cA[mAe@qA]"},"start_location":{"lat":12.9675165,"lng":77.5449993},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":443},"duration":{"text":"1 min","value":86},"end_location":{"lat":12.9735257,"lng":77.5431542},"html_instructions":"Turn <b>left<\/b> at G K Seat Works onto <b>1st Main Rd<\/b><div style=\"font-size:0.9em\">Pass by BBMP Birth and Death Office (on the right)<\/div>","maneuver":"turn-left","polyline":{"points":"msdnA{{hxMUl@Qz@Qx@S|@St@mAtFsAvF"},"start_location":{"lat":12.9722304,"lng":77.54701969999999},"travel_mode":"DRIVING"},{"distance":{"text":"44 m","value":44},"duration":{"text":"1 min","value":10},"end_location":{"lat":12.9739108,"lng":77.5432344},"html_instructions":"Turn <b>right<\/b> at Milacron Ferromatik onto <b>4th Cross Rd<\/b><div style=\"font-size:0.9em\">Pass by Maya Fashions (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"q{dnAuchxMq@IYE"},"start_location":{"lat":12.9735257,"lng":77.5431542},"travel_mode":"DRIVING"},{"distance":{"text":"0.1 km","value":109},"duration":{"text":"1 min","value":17},"end_location":{"lat":12.9737105,"lng":77.54224549999999},"html_instructions":"Turn <b>left<\/b> onto <b>Chord Rd<\/b>","maneuver":"turn-left","polyline":{"points":"}}dnAedhxMLfAVtB@D"},"start_location":{"lat":12.9739108,"lng":77.5432344},"travel_mode":"DRIVING"},{"distance":{"text":"0.2 km","value":187},"duration":{"text":"1 min","value":41},"end_location":{"lat":12.9753676,"lng":77.5421671},"html_instructions":"Turn <b>right<\/b> at Sri shakthi stores onto <b>8th Cross Rd<\/b><div style=\"font-size:0.9em\">Pass by Karnataka State Coir Co-operative Federation Ltd. (on the right)<\/div>","maneuver":"turn-right","polyline":{"points":"u|dnAa~gxMk@D[BwBVkCQ"},"start_location":{"lat":12.9737105,"lng":77.54224549999999},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":395},"duration":{"text":"1 min","value":76},"end_location":{"lat":12.9757275,"lng":77.5385412},"html_instructions":"Turn <b>left<\/b> at Sri Raghavendraswamy Electronics onto <b>5th Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Mac Consultants (on the left)<\/div>","maneuver":"turn-left","polyline":{"points":"agenAq}gxMI`BIpAGxAGpAGvAGtAGzAKjB"},"start_location":{"lat":12.9753676,"lng":77.5421671},"travel_mode":"DRIVING"},{"distance":{"text":"0.3 km","value":343},"duration":{"text":"1 min","value":75},"end_location":{"lat":12.9755525,"lng":77.53538549999999},"html_instructions":"At Madhav Villa, continue onto <b>Nagarabhavi Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Sri Raghavendraswamy Electronic (on the left)<\/div>","polyline":{"points":"iienA{fgxM?V?rAF~@?@@l@JvBDr@FvBA|A@V"},"start_location":{"lat":12.9757275,"lng":77.5385412},"travel_mode":"DRIVING"},{"distance":{"text":"6 m","value":6},"duration":{"text":"1 min","value":3},"end_location":{"lat":12.9756,"lng":77.53540000000001},"html_instructions":"Turn <b>right<\/b> at Hubbanahalli Gobi Center","maneuver":"turn-right","polyline":{"points":"ehenAesfxMIA"},"start_location":{"lat":12.9755525,"lng":77.53538549999999},"travel_mode":"DRIVING"}],"traffic_speed_entry":[],"via_waypoint":[]}]
         * overview_polyline : {"points":"m~|mAc~sxM{AfOzFl@fDRlBJbBHR@h@SXEfEHZFDHD^qAAsFMyBMkG]qN_BgAEoBMWDsBQaCUKdBSrCYxA[z@g@bA[d@}@v@eAx@gAt@sAn@o@Zi@NaARoFXiId@uEd@{C`@YF_@R_@`@UR{@|Ay@~AcBpBc@n@gA`AgAn@YNoAXcA\\}@b@kAn@{@TcBn@]Ni@X[Zo@t@}@~@u@x@_@x@cA|CCX@B?LKNE@Oh@KNGDq@pC{BpJa@vAMXi@r@aDxDM|@CV]t@s@nDc@fBMf@Ip@E^MbBGdAQhEI|AOdAMZGRC`@iFcFkA_Ay@i@uCcB}Aq@iDyAkAe@sAi@eB{@qEoByCqA_CaAkAYUAg@Ha@PFtAHXLjATlBH`DAb@ApBYlEQxEApABlA?v@Cf@Qz@k@rB_@lBAFCNa@fBa@jA[bAIb@Cb@DhADPDxAJlBVbGJnCJhCLhDH`A`@lB`@~AzAhF^~@p@tClAjGDTNn@XpAzAlFp@bEHtAHtFXfC^pCd@zDJj@Rh@Tj@Zf@\\f@v@|ArA`Cf@j@g@t@[`@OXY|@Q`AIbBFtAF`@@Jm@nEKr@Gb@yCA{@EgCIaAIwCa@aF_AElBBjADd@NVZTX\\JRBn@@l@QjASx@KTe@dAu@pBW^q@j@{A~@cCfBw@v@OTw@~B}BdIENaA]}Bm@wAg@eDgAcE{AkCw@mAe@qA]Ul@Qz@e@vBaBjHsAvFq@IYELfAXzBgAHwBVkCQSrDOjDc@tJ?jBF`AZpI?tBIA"}
         * summary : Mysore Rd
         * warnings : []
         * waypoint_order : []
         */

        @SerializedName("bounds")
        private BoundsBean bounds;
        @SerializedName("copyrights")
        private String copyrights;
        @SerializedName("overview_polyline")
        private OverviewPolylineBean overviewPolyline;
        @SerializedName("summary")
        private String summary;
        @SerializedName("legs")
        private List<LegsBean> legs;
        @SerializedName("warnings")
        private List<?> warnings;
        @SerializedName("waypoint_order")
        private List<?> waypointOrder;

        public BoundsBean getBounds() {
            return bounds;
        }

        public void setBounds(BoundsBean bounds) {
            this.bounds = bounds;
        }

        public String getCopyrights() {
            return copyrights;
        }

        public void setCopyrights(String copyrights) {
            this.copyrights = copyrights;
        }

        public OverviewPolylineBean getOverviewPolyline() {
            return overviewPolyline;
        }

        public void setOverviewPolyline(OverviewPolylineBean overviewPolyline) {
            this.overviewPolyline = overviewPolyline;
        }

        public String getSummary() {
            return summary;
        }

        public void setSummary(String summary) {
            this.summary = summary;
        }

        public List<LegsBean> getLegs() {
            return legs;
        }

        public void setLegs(List<LegsBean> legs) {
            this.legs = legs;
        }

        public List<?> getWarnings() {
            return warnings;
        }

        public void setWarnings(List<?> warnings) {
            this.warnings = warnings;
        }

        public List<?> getWaypointOrder() {
            return waypointOrder;
        }

        public void setWaypointOrder(List<?> waypointOrder) {
            this.waypointOrder = waypointOrder;
        }

        public static class BoundsBean {
            /**
             * northeast : {"lat":12.9757275,"lng":77.6036985}
             * southwest : {"lat":12.9287006,"lng":77.53538549999999}
             */

            @SerializedName("northeast")
            private NortheastBean northeast;
            @SerializedName("southwest")
            private SouthwestBean southwest;

            public NortheastBean getNortheast() {
                return northeast;
            }

            public void setNortheast(NortheastBean northeast) {
                this.northeast = northeast;
            }

            public SouthwestBean getSouthwest() {
                return southwest;
            }

            public void setSouthwest(SouthwestBean southwest) {
                this.southwest = southwest;
            }

            public static class NortheastBean {
                /**
                 * lat : 12.9757275
                 * lng : 77.6036985
                 */

                @SerializedName("lat")
                private double lat;
                @SerializedName("lng")
                private double lng;

                public double getLat() {
                    return lat;
                }

                public void setLat(double lat) {
                    this.lat = lat;
                }

                public double getLng() {
                    return lng;
                }

                public void setLng(double lng) {
                    this.lng = lng;
                }
            }

            public static class SouthwestBean {
                /**
                 * lat : 12.9287006
                 * lng : 77.53538549999999
                 */

                @SerializedName("lat")
                private double lat;
                @SerializedName("lng")
                private double lng;

                public double getLat() {
                    return lat;
                }

                public void setLat(double lat) {
                    this.lat = lat;
                }

                public double getLng() {
                    return lng;
                }

                public void setLng(double lng) {
                    this.lng = lng;
                }
            }
        }

        public static class OverviewPolylineBean {
            /**
             * points : m~|mAc~sxM{AfOzFl@fDRlBJbBHR@h@SXEfEHZFDHD^qAAsFMyBMkG]qN_BgAEoBMWDsBQaCUKdBSrCYxA[z@g@bA[d@}@v@eAx@gAt@sAn@o@Zi@NaARoFXiId@uEd@{C`@YF_@R_@`@UR{@|Ay@~AcBpBc@n@gA`AgAn@YNoAXcA\}@b@kAn@{@TcBn@]Ni@X[Zo@t@}@~@u@x@_@x@cA|CCX@B?LKNE@Oh@KNGDq@pC{BpJa@vAMXi@r@aDxDM|@CV]t@s@nDc@fBMf@Ip@E^MbBGdAQhEI|AOdAMZGRC`@iFcFkA_Ay@i@uCcB}Aq@iDyAkAe@sAi@eB{@qEoByCqA_CaAkAYUAg@Ha@PFtAHXLjATlBH`DAb@ApBYlEQxEApABlA?v@Cf@Qz@k@rB_@lBAFCNa@fBa@jA[bAIb@Cb@DhADPDxAJlBVbGJnCJhCLhDH`A`@lB`@~AzAhF^~@p@tClAjGDTNn@XpAzAlFp@bEHtAHtFXfC^pCd@zDJj@Rh@Tj@Zf@\f@v@|ArA`Cf@j@g@t@[`@OXY|@Q`AIbBFtAF`@@Jm@nEKr@Gb@yCA{@EgCIaAIwCa@aF_AElBBjADd@NVZTX\JRBn@@l@QjASx@KTe@dAu@pBW^q@j@{A~@cCfBw@v@OTw@~B}BdIENaA]}Bm@wAg@eDgAcE{AkCw@mAe@qA]Ul@Qz@e@vBaBjHsAvFq@IYELfAXzBgAHwBVkCQSrDOjDc@tJ?jBF`AZpI?tBIA
             */

            @SerializedName("points")
            private String points;

            public String getPoints() {
                return points;
            }

            public void setPoints(String points) {
                this.points = points;
            }
        }

        public static class LegsBean {
            /**
             * distance : {"text":"13.6 km","value":13551}
             * duration : {"text":"43 mins","value":2556}
             * end_address : 20, 5th Main Rd, Govindaraja Nagar Ward, Govindarajanagar, Vijayanagar, Bengaluru, Karnataka 560040, India
             * end_location : {"lat":12.9756,"lng":77.53540000000001}
             * start_address : 4/1 Bannerghatta Main Road 9th Floor Tower D IBC Towers, Bhavani Nagar, S.G. Palya, Bengaluru, Karnataka 560029, India
             * start_location : {"lat":12.9330309,"lng":77.6036985}
             * steps : [{"distance":{"text":"0.3 km","value":286},"duration":{"text":"2 mins","value":131},"end_location":{"lat":12.933494,"lng":77.6011017},"html_instructions":"Head <b>west<\/b> on <b>IBC Internal Rd<\/b> towards <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Restricted-usage road<\/div><div style=\"font-size:0.9em\">Drive along Accenture Tower A and B (on the left for 130&nbsp;m)<\/div>","polyline":{"points":"m~|mAc~sxMc@lEw@xH"},"start_location":{"lat":12.9330309,"lng":77.6036985},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":366},"duration":{"text":"1 min","value":78},"end_location":{"lat":12.9302382,"lng":77.6006519},"html_instructions":"Turn <b>left<\/b> at IBC Pickup Point onto <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Pass by IBC Knowledge Park (on the left)<\/div>","maneuver":"turn-left","polyline":{"points":"ia}mA{msxMzFl@fDR`@DjADd@B|@DN?B@"},"start_location":{"lat":12.933494,"lng":77.6011017},"travel_mode":"DRIVING"},{"distance":{"text":"0.2 km","value":181},"duration":{"text":"1 min","value":56},"end_location":{"lat":12.9287032,"lng":77.6005893},"html_instructions":"Slight <b>left<\/b> to stay on <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Advaith Hyundai Service Center, BG Road - Bannerghatta Rd (on the left)<\/div>","maneuver":"turn-slight-left","polyline":{"points":"_m|mAaksxM^QHAJCF?@?BAr@BZ?fBBN@L@F@B@@@@@BFDH"},"start_location":{"lat":12.9302382,"lng":77.6006519},"travel_mode":"DRIVING"},{"distance":{"text":"0.8 km","value":795},"duration":{"text":"2 mins","value":139},"end_location":{"lat":12.9356869,"lng":77.6013626},"html_instructions":"Turn <b>right<\/b> at Smart Space Interiors to stay on <b>Bannerghatta Main Rd<\/b><div style=\"font-size:0.9em\">Pass by S A Associates - Auditor &amp; Tax Consultant (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"kc|mAujsxM?TS?}@AcFMO?o@GO?UAc@Cc@CSAkDQg@EaAKc@Ec@Ga@GWCkDa@aAK_AKs@CSAoBM"},"start_location":{"lat":12.9287032,"lng":77.6005893},"travel_mode":"DRIVING"},{"distance":{"text":"0.2 km","value":152},"duration":{"text":"1 min","value":18},"end_location":{"lat":12.9370382,"lng":77.6015323},"html_instructions":"Slight <b>left<\/b> at Bengaluru Dairy Circle (Towards Jayadeva Hospital) onto <b>Bannerghatta-Marigowda Turn Rd<\/b><div style=\"font-size:0.9em\">Pass by Sushma Industries (on the left)<\/div>","maneuver":"turn-slight-left","polyline":{"points":"ao}mAoosxMWDSA_BOiAOw@E"},"start_location":{"lat":12.9356869,"lng":77.6013626},"travel_mode":"DRIVING"},{"distance":{"text":"2.9 km","value":2868},"duration":{"text":"9 mins","value":513},"end_location":{"lat":12.9541523,"lng":77.5849047},"html_instructions":"Turn <b>left<\/b> at Quality Management Service onto <b>Bannerghatta-Marigowda Turn Rd<\/b>/<b>Hosur Main Road<\/b>/<b>Marigowda Rd<\/b><div style=\"font-size:0.9em\">Pass by Bengaluru Dairy Circle (Towards Lakkasandra) (on the right)<\/div>","maneuver":"turn-left","polyline":{"points":"ow}mAqpsxMAZCT?LEd@GhAKhAOx@I^Ob@KVYj@MVOXKJKDq@p@[Vi@`@MHy@j@i@Xi@To@Zi@Ng@LYDmBLaCJkBJa@B{BJ_AHaAHSBu@JiAJu@Hi@H[F_@DYF_@RONOPUR{@|AQ\\g@`AcBpBc@n@u@r@QLk@^[NYNoAXcA\\}@b@u@d@UHUDe@NaBn@A?[LA@i@X[ZST[^QPk@l@a@b@STOXO^K\\]|@O`@I^ET@@?@@??@?@@@?@?DAB?BCDC@CBE@Oh@EJEBGDq@pCsBzIGT[lAEHEJGLGHCFOPMNOPg@n@q@x@w@|@G`@EZCV]t@G`@"},"start_location":{"lat":12.9370382,"lng":77.6015323},"travel_mode":"DRIVING"},{"distance":{"text":"0.5 km","value":539},"duration":{"text":"2 mins","value":109},"end_location":{"lat":12.9551566,"lng":77.5800685},"html_instructions":"Continue straight past CS-Lalbagh Main Gate onto <b>Lalbagh Fort Rd<\/b><div style=\"font-size:0.9em\">Pass by B.S Auto Engineering Work (on the left)<\/div>","maneuver":"straight","polyline":{"points":"mbanAshpxMk@lCUx@Ml@Mf@Ip@CNANAF?HCZGt@AZATAJAFEv@Ab@Cb@EhAI|AOdAAFKRCFCJCL"},"start_location":{"lat":12.9541523,"lng":77.5849047},"travel_mode":"DRIVING"},{"distance":{"text":"1.1 km","value":1078},"duration":{"text":"4 mins","value":262},"end_location":{"lat":12.9633264,"lng":77.5849798},"html_instructions":"Turn <b>right<\/b> at Mobile zone onto <b>JC Rd<\/b><div style=\"font-size:0.9em\">Pass by Sleepwell (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"whanAmjoxM?RMKa@_@oDmDIIkA_Ay@i@uCcB}Aq@sCmAUKm@U]OMEeAc@eB{@qEoBMGkCiAsB{@KEe@Me@KKAI?"},"start_location":{"lat":12.9551566,"lng":77.5800685},"travel_mode":"DRIVING"},{"distance":{"text":"3.3 km","value":3308},"duration":{"text":"6 mins","value":348},"end_location":{"lat":12.9595793,"lng":77.55595319999999},"html_instructions":"Turn <b>left<\/b> at global Industrial Traders onto <b>Mysore Rd<\/b>/<b>NR Rd<\/b><div style=\"font-size:0.9em\">Continue to follow Mysore Rd<\/div><div style=\"font-size:0.9em\">Pass by Chitradurga Ispat (Pvt) Ltd. (on the left)<\/div>","maneuver":"turn-left","polyline":{"points":"y{bnAcipxMg@Ha@PFtAHXDb@Ff@L|@Fn@FpB@n@A\\?D?~@Ap@InAO|BQxEApAB`A?J?R?b@Cf@Qz@k@rB_@lBAFCL?@ADKj@I\\IVCHO^GTEJMZADGRCLCJEVADA\\?D@^Bb@?@DNBj@@l@Bb@Bd@?HBX@b@Bd@Bb@@d@Bb@Bb@Bd@?@@`@Bb@@d@Bb@?@JfCLhC?^@V@RDTZxA?@?BDLFZXbAn@~Bj@hBZt@BHp@tClAjGDP?BDPH\\Nr@H\\l@rBl@xBZ`BT`BFt@@^Bp@@~A?VBjAJdAL`A\\nC@@\\nCFj@Jj@Rh@Tj@Zf@\\f@v@|ArA`Cf@j@"},"start_location":{"lat":12.9633264,"lng":77.5849798},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":443},"duration":{"text":"2 mins","value":108},"end_location":{"lat":12.9605065,"lng":77.5521033},"html_instructions":"Turn <b>right<\/b> at Design Impex onto <b>Old Guddadahalli Rd<\/b><div style=\"font-size:0.9em\">Go past the church (on the right in 350&nbsp;m)<\/div>","maneuver":"turn-right","polyline":{"points":"kdbnAusjxMKP[b@QTIJKPCFEJGNEJETKf@EXIbA?^?`@Fr@BPBN@Jm@nEIn@ABGb@"},"start_location":{"lat":12.9595793,"lng":77.55595319999999},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":449},"duration":{"text":"2 mins","value":133},"end_location":{"lat":12.964477,"lng":77.5527268},"html_instructions":"Turn <b>right<\/b> at National Defence Office (Old guddadahalli) onto <b>3rd Cross Rd<\/b><div style=\"font-size:0.9em\">Pass by Suhail Gas Point (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"ejbnAs{ixMyCA{@EsACs@E_@Aa@Gu@IaBWC?}E_A"},"start_location":{"lat":12.9605065,"lng":77.5521033},"travel_mode":"DRIVING"},{"distance":{"text":"1.0 km","value":991},"duration":{"text":"4 mins","value":247},"end_location":{"lat":12.9675165,"lng":77.5449993},"html_instructions":"Turn <b>left<\/b> at Ruby Footwear onto <b>Hosahalli Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Star Tele-Links (on the right)<\/div>","maneuver":"turn-left","polyline":{"points":"_ccnAq_jxMEzA?P?l@B\\?H@H@F@HDJHJ@@XRPRFHDFDJ@T@X@l@QjASx@KTSb@Q`@Wp@Qh@ELEFGLOPWVYRIFUL]T]R[T]T]Tk@d@WR_@b@IHEJKRSp@IPMf@q@vBkAlEEN"},"start_location":{"lat":12.964477,"lng":77.5527268},"travel_mode":"DRIVING"},{"distance":{"text":"0.6 km","value":568},"duration":{"text":"2 mins","value":106},"end_location":{"lat":12.9722304,"lng":77.54701969999999},"html_instructions":"Turn <b>right<\/b> at Paras Telecom onto <b>Krishnadevaraya Rd<\/b><div style=\"font-size:0.9em\">Pass by A-One Fruit Stall (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"_vcnAgohxMaA]{@UaAWaA]UIg@OaA_@OEk@Qu@YKC{@]eA_@gA[cA[mAe@qA]"},"start_location":{"lat":12.9675165,"lng":77.5449993},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":443},"duration":{"text":"1 min","value":86},"end_location":{"lat":12.9735257,"lng":77.5431542},"html_instructions":"Turn <b>left<\/b> at G K Seat Works onto <b>1st Main Rd<\/b><div style=\"font-size:0.9em\">Pass by BBMP Birth and Death Office (on the right)<\/div>","maneuver":"turn-left","polyline":{"points":"msdnA{{hxMUl@Qz@Qx@S|@St@mAtFsAvF"},"start_location":{"lat":12.9722304,"lng":77.54701969999999},"travel_mode":"DRIVING"},{"distance":{"text":"44 m","value":44},"duration":{"text":"1 min","value":10},"end_location":{"lat":12.9739108,"lng":77.5432344},"html_instructions":"Turn <b>right<\/b> at Milacron Ferromatik onto <b>4th Cross Rd<\/b><div style=\"font-size:0.9em\">Pass by Maya Fashions (on the left)<\/div>","maneuver":"turn-right","polyline":{"points":"q{dnAuchxMq@IYE"},"start_location":{"lat":12.9735257,"lng":77.5431542},"travel_mode":"DRIVING"},{"distance":{"text":"0.1 km","value":109},"duration":{"text":"1 min","value":17},"end_location":{"lat":12.9737105,"lng":77.54224549999999},"html_instructions":"Turn <b>left<\/b> onto <b>Chord Rd<\/b>","maneuver":"turn-left","polyline":{"points":"}}dnAedhxMLfAVtB@D"},"start_location":{"lat":12.9739108,"lng":77.5432344},"travel_mode":"DRIVING"},{"distance":{"text":"0.2 km","value":187},"duration":{"text":"1 min","value":41},"end_location":{"lat":12.9753676,"lng":77.5421671},"html_instructions":"Turn <b>right<\/b> at Sri shakthi stores onto <b>8th Cross Rd<\/b><div style=\"font-size:0.9em\">Pass by Karnataka State Coir Co-operative Federation Ltd. (on the right)<\/div>","maneuver":"turn-right","polyline":{"points":"u|dnAa~gxMk@D[BwBVkCQ"},"start_location":{"lat":12.9737105,"lng":77.54224549999999},"travel_mode":"DRIVING"},{"distance":{"text":"0.4 km","value":395},"duration":{"text":"1 min","value":76},"end_location":{"lat":12.9757275,"lng":77.5385412},"html_instructions":"Turn <b>left<\/b> at Sri Raghavendraswamy Electronics onto <b>5th Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Mac Consultants (on the left)<\/div>","maneuver":"turn-left","polyline":{"points":"agenAq}gxMI`BIpAGxAGpAGvAGtAGzAKjB"},"start_location":{"lat":12.9753676,"lng":77.5421671},"travel_mode":"DRIVING"},{"distance":{"text":"0.3 km","value":343},"duration":{"text":"1 min","value":75},"end_location":{"lat":12.9755525,"lng":77.53538549999999},"html_instructions":"At Madhav Villa, continue onto <b>Nagarabhavi Main Rd<\/b><div style=\"font-size:0.9em\">Pass by Sri Raghavendraswamy Electronic (on the left)<\/div>","polyline":{"points":"iienA{fgxM?V?rAF~@?@@l@JvBDr@FvBA|A@V"},"start_location":{"lat":12.9757275,"lng":77.5385412},"travel_mode":"DRIVING"},{"distance":{"text":"6 m","value":6},"duration":{"text":"1 min","value":3},"end_location":{"lat":12.9756,"lng":77.53540000000001},"html_instructions":"Turn <b>right<\/b> at Hubbanahalli Gobi Center","maneuver":"turn-right","polyline":{"points":"ehenAesfxMIA"},"start_location":{"lat":12.9755525,"lng":77.53538549999999},"travel_mode":"DRIVING"}]
             * traffic_speed_entry : []
             * via_waypoint : []
             */

            @SerializedName("distance")
            private DistanceBean distance;
            @SerializedName("duration")
            private DurationBean duration;
            @SerializedName("end_address")
            private String endAddress;
            @SerializedName("end_location")
            private EndLocationBean endLocation;
            @SerializedName("start_address")
            private String startAddress;
            @SerializedName("start_location")
            private StartLocationBean startLocation;
            @SerializedName("steps")
            private List<StepsBean> steps;
            @SerializedName("traffic_speed_entry")
            private List<?> trafficSpeedEntry;
            @SerializedName("via_waypoint")
            private List<?> viaWaypoint;

            public DistanceBean getDistance() {
                return distance;
            }

            public void setDistance(DistanceBean distance) {
                this.distance = distance;
            }

            public DurationBean getDuration() {
                return duration;
            }

            public void setDuration(DurationBean duration) {
                this.duration = duration;
            }

            public String getEndAddress() {
                return endAddress;
            }

            public void setEndAddress(String endAddress) {
                this.endAddress = endAddress;
            }

            public EndLocationBean getEndLocation() {
                return endLocation;
            }

            public void setEndLocation(EndLocationBean endLocation) {
                this.endLocation = endLocation;
            }

            public String getStartAddress() {
                return startAddress;
            }

            public void setStartAddress(String startAddress) {
                this.startAddress = startAddress;
            }

            public StartLocationBean getStartLocation() {
                return startLocation;
            }

            public void setStartLocation(StartLocationBean startLocation) {
                this.startLocation = startLocation;
            }

            public List<StepsBean> getSteps() {
                return steps;
            }

            public void setSteps(List<StepsBean> steps) {
                this.steps = steps;
            }

            public List<?> getTrafficSpeedEntry() {
                return trafficSpeedEntry;
            }

            public void setTrafficSpeedEntry(List<?> trafficSpeedEntry) {
                this.trafficSpeedEntry = trafficSpeedEntry;
            }

            public List<?> getViaWaypoint() {
                return viaWaypoint;
            }

            public void setViaWaypoint(List<?> viaWaypoint) {
                this.viaWaypoint = viaWaypoint;
            }

            public static class DistanceBean {
                /**
                 * text : 13.6 km
                 * value : 13551
                 */

                @SerializedName("text")
                private String text;
                @SerializedName("value")
                private int value;

                public String getText() {
                    return text;
                }

                public void setText(String text) {
                    this.text = text;
                }

                public int getValue() {
                    return value;
                }

                public void setValue(int value) {
                    this.value = value;
                }
            }

            public static class DurationBean {
                /**
                 * text : 43 mins
                 * value : 2556
                 */

                @SerializedName("text")
                private String text;
                @SerializedName("value")
                private int value;

                public String getText() {
                    return text;
                }

                public void setText(String text) {
                    this.text = text;
                }

                public int getValue() {
                    return value;
                }

                public void setValue(int value) {
                    this.value = value;
                }
            }

            public static class EndLocationBean {
                /**
                 * lat : 12.9756
                 * lng : 77.53540000000001
                 */

                @SerializedName("lat")
                private double lat;
                @SerializedName("lng")
                private double lng;

                public double getLat() {
                    return lat;
                }

                public void setLat(double lat) {
                    this.lat = lat;
                }

                public double getLng() {
                    return lng;
                }

                public void setLng(double lng) {
                    this.lng = lng;
                }
            }

            public static class StartLocationBean {
                /**
                 * lat : 12.9330309
                 * lng : 77.6036985
                 */

                @SerializedName("lat")
                private double lat;
                @SerializedName("lng")
                private double lng;

                public double getLat() {
                    return lat;
                }

                public void setLat(double lat) {
                    this.lat = lat;
                }

                public double getLng() {
                    return lng;
                }

                public void setLng(double lng) {
                    this.lng = lng;
                }
            }

            public static class StepsBean {
                /**
                 * distance : {"text":"0.3 km","value":286}
                 * duration : {"text":"2 mins","value":131}
                 * end_location : {"lat":12.933494,"lng":77.6011017}
                 * html_instructions : Head <b>west</b> on <b>IBC Internal Rd</b> towards <b>Bannerghatta Main Rd</b><div style="font-size:0.9em">Restricted-usage road</div><div style="font-size:0.9em">Drive along Accenture Tower A and B (on the left for 130&nbsp;m)</div>
                 * polyline : {"points":"m~|mAc~sxMc@lEw@xH"}
                 * start_location : {"lat":12.9330309,"lng":77.6036985}
                 * travel_mode : DRIVING
                 * maneuver : turn-left
                 */

                @SerializedName("distance")
                private DistanceBeanX distance;
                @SerializedName("duration")
                private DurationBeanX duration;
                @SerializedName("end_location")
                private EndLocationBeanX endLocation;
                @SerializedName("html_instructions")
                private String htmlInstructions;
                @SerializedName("polyline")
                private PolylineBean polyline;
                @SerializedName("start_location")
                private StartLocationBeanX startLocation;
                @SerializedName("travel_mode")
                private String travelMode;
                @SerializedName("maneuver")
                private String maneuver;

                public DistanceBeanX getDistance() {
                    return distance;
                }

                public void setDistance(DistanceBeanX distance) {
                    this.distance = distance;
                }

                public DurationBeanX getDuration() {
                    return duration;
                }

                public void setDuration(DurationBeanX duration) {
                    this.duration = duration;
                }

                public EndLocationBeanX getEndLocation() {
                    return endLocation;
                }

                public void setEndLocation(EndLocationBeanX endLocation) {
                    this.endLocation = endLocation;
                }

                public String getHtmlInstructions() {
                    return htmlInstructions;
                }

                public void setHtmlInstructions(String htmlInstructions) {
                    this.htmlInstructions = htmlInstructions;
                }

                public PolylineBean getPolyline() {
                    return polyline;
                }

                public void setPolyline(PolylineBean polyline) {
                    this.polyline = polyline;
                }

                public StartLocationBeanX getStartLocation() {
                    return startLocation;
                }

                public void setStartLocation(StartLocationBeanX startLocation) {
                    this.startLocation = startLocation;
                }

                public String getTravelMode() {
                    return travelMode;
                }

                public void setTravelMode(String travelMode) {
                    this.travelMode = travelMode;
                }

                public String getManeuver() {
                    return maneuver;
                }

                public void setManeuver(String maneuver) {
                    this.maneuver = maneuver;
                }

                public static class DistanceBeanX {
                    /**
                     * text : 0.3 km
                     * value : 286
                     */

                    @SerializedName("text")
                    private String text;
                    @SerializedName("value")
                    private int value;

                    public String getText() {
                        return text;
                    }

                    public void setText(String text) {
                        this.text = text;
                    }

                    public int getValue() {
                        return value;
                    }

                    public void setValue(int value) {
                        this.value = value;
                    }
                }

                public static class DurationBeanX {
                    /**
                     * text : 2 mins
                     * value : 131
                     */

                    @SerializedName("text")
                    private String text;
                    @SerializedName("value")
                    private int value;

                    public String getText() {
                        return text;
                    }

                    public void setText(String text) {
                        this.text = text;
                    }

                    public int getValue() {
                        return value;
                    }

                    public void setValue(int value) {
                        this.value = value;
                    }
                }

                public static class EndLocationBeanX {
                    /**
                     * lat : 12.933494
                     * lng : 77.6011017
                     */

                    @SerializedName("lat")
                    private double lat;
                    @SerializedName("lng")
                    private double lng;

                    public double getLat() {
                        return lat;
                    }

                    public void setLat(double lat) {
                        this.lat = lat;
                    }

                    public double getLng() {
                        return lng;
                    }

                    public void setLng(double lng) {
                        this.lng = lng;
                    }
                }

                public static class PolylineBean {
                    /**
                     * points : m~|mAc~sxMc@lEw@xH
                     */

                    @SerializedName("points")
                    private String points;

                    public String getPoints() {
                        return points;
                    }

                    public void setPoints(String points) {
                        this.points = points;
                    }
                }

                public static class StartLocationBeanX {
                    /**
                     * lat : 12.9330309
                     * lng : 77.6036985
                     */

                    @SerializedName("lat")
                    private double lat;
                    @SerializedName("lng")
                    private double lng;

                    public double getLat() {
                        return lat;
                    }

                    public void setLat(double lat) {
                        this.lat = lat;
                    }

                    public double getLng() {
                        return lng;
                    }

                    public void setLng(double lng) {
                        this.lng = lng;
                    }
                }
            }
        }
    }
}
