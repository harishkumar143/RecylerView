package com.kouchan.dyutpassenger.models;


import com.google.gson.annotations.SerializedName;

/**
 * Created by Basavaraj on 10/15/17.
 * KaHa Technologies Pvt Ltd
 * basavaraj.navi@coveiot.com
 * M3APP
 */
public class AdhaarModel {

    @SerializedName("PrintLetterBarcodeData")
    private PrintLetterBarcodeDataBean PrintLetterBarcodeData;

    public PrintLetterBarcodeDataBean getPrintLetterBarcodeData() {
        return PrintLetterBarcodeData;
    }

    public void setPrintLetterBarcodeData(PrintLetterBarcodeDataBean PrintLetterBarcodeData) {
        this.PrintLetterBarcodeData = PrintLetterBarcodeData;
    }

    public static class PrintLetterBarcodeDataBean {
        @SerializedName("pc")
        private String pc;
        @SerializedName("po")
        private String po;
        @SerializedName("subdist")
        private String subdist;
        @SerializedName("dob")
        private String dob;
        @SerializedName("name")
        private String name;
        @SerializedName("state")
        private String state;
        @SerializedName("co")
        private String co;
        @SerializedName("gender")
        private String gender;
        @SerializedName("uid")
        private String uid;
        @SerializedName("yob")
        private String yob;
        @SerializedName("dist")
        private String dist;
        @SerializedName("vtc")
        private String vtc;
        @SerializedName("house")
        private String house;
        @SerializedName("street")
        private String street;
        @SerializedName("lm")
        private String lm;
        @SerializedName("loc")
        private String loc;

        public String getPc() {
            return pc;
        }

        public void setPc(String pc) {
            this.pc = pc;
        }

        public String getPo() {
            return po;
        }

        public void setPo(String po) {
            this.po = po;
        }

        public String getSubdist() {
            return subdist;
        }

        public void setSubdist(String subdist) {
            this.subdist = subdist;
        }

        public String getDob() {
            return dob;
        }

        public void setDob(String dob) {
            this.dob = dob;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getCo() {
            return co;
        }

        public void setCo(String co) {
            this.co = co;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        public String getYob() {
            return yob;
        }

        public void setYob(String yob) {
            this.yob = yob;
        }

        public String getDist() {
            return dist;
        }

        public void setDist(String dist) {
            this.dist = dist;
        }

        public String getVtc() {
            return vtc;
        }

        public void setVtc(String vtc) {
            this.vtc = vtc;
        }

        public String getHouse() {
            return house;
        }

        public void setHouse(String vtc) {
            this.house = house;
        }

        public String getStreet() {
            return street;
        }

        public void setStreet(String street) {
            this.street = street;
        }

        public String getLm() {
            return lm;
        }

        public void setLm(String lm) {
            this.lm = lm;
        }

        public String getLoc() {
            return loc;
        }

        public void setLoc(String loc) {
            this.loc = loc;
        }
    }
}

