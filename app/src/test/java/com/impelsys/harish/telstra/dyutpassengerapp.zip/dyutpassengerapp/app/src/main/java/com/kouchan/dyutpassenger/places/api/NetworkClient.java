package com.kouchan.dyutpassenger.places.api;

import android.util.Log;

import com.google.android.gms.maps.model.LatLng;
import com.kouchan.dyutpassenger.places.models.DirectionResponseModel;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class NetworkClient {


    /**
     * GET DIRECTION ROUTE
     *
     * @param origin
     * @param dest
     * @param key
     * @param apiListener
     */
    public static void getDirectionRouteData(LatLng origin, LatLng dest,
                                             String key, final ApiListener<DirectionResponseModel, ErrorModel> apiListener) {
        // Origin of route
        String source = origin.latitude + "," + origin.longitude;

        // Destination of route
        String destination = dest.latitude + "," + dest.longitude;

        //Avoid of the route
        String avoid = AvoidType.FERRIES + "|" + AvoidType.INDOOR;

        Call<DirectionResponseModel> call = ApiClient.getApiInterface().getRouteJson(source, destination, false, TransportMode.DRIVING, avoid, false, key);
        APIHelper.enqueueWithRetry(call, new Callback<DirectionResponseModel>() {
            @Override
            public void onResponse(Call<DirectionResponseModel> call, Response<DirectionResponseModel> response) {
                if (response.isSuccessful()) {
                    apiListener.onSuccess(response.body());
                } else {
                    Log.d("response", "response: error");
                    apiListener.onFailure(new ErrorModel(response.code(), response.message()));
                }
            }

            @Override
            public void onFailure(Call<DirectionResponseModel> call, Throwable t) {
                Log.d("response", "on failure: error");
                apiListener.onFailure(new ErrorModel(400, t.getMessage()));
            }
        });
    }
}
