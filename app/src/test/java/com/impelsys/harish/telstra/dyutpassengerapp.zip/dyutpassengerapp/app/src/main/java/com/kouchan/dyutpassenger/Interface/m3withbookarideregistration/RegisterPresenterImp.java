package com.kouchan.dyutpassenger.Interface.m3withbookarideregistration;

import android.util.Log;

import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.View.Activities.AadharRegistrationActivity;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class RegisterPresenterImp implements IRegisterPresenter, OnRequestListener {

    IRegisterView iRegisterView;
    AadharRegistrationActivity registerActivity;
    AsyncInteractor asyncInteractor;
    Sharedpreferences prefs;

    public RegisterPresenterImp(IRegisterView iRegisterView) {
        this.iRegisterView = iRegisterView;
        this.registerActivity = (AadharRegistrationActivity) iRegisterView;
        prefs = prefs.getUserDataObj(registerActivity);
        asyncInteractor = new AsyncInteractor(registerActivity);
    }

    @Override
    public void registerValidation(String firstName, String email, String mobile, String password, String adharNumber,String s) {
        sendRequestToNetwork(firstName, email, mobile, password, adharNumber);
    }

    private void sendRequestToNetwork(String name, String email, String mobile, String password, String adharNumber) {
        Utils.showProgress(registerActivity);

        HashMap<String, String> params = new HashMap<>();
        params.put("name", name);
        params.put("mobile", mobile);
        params.put("email", email);
        String shaPassword = Utils.getSHA256Hash(password);
        params.put("password", shaPassword);
        params.put("emergency_contact_name", shaPassword);
        params.put("emergency_contact_mobile", shaPassword);

        asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_REGISTER, Url.PASSENGER_API+"m3registrationofpassenger.php", new JSONObject(params),"");


    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {
    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if (pid == AppConstants.TAG_ID_REGISTER) {

            Log.e("responseRegistration", responseJson.toString());
            if (responseJson != null) {

                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    iRegisterView.onRegisterSuccess(pid, jObj.getString("next_step"));
                } else {
                    iRegisterView.onRegisterError(pid, jObj.getString("error_msg"));
                }
            } else {

                iRegisterView.onRegisterError(pid, "Server Error");
            }
        }

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(registerActivity);
        iRegisterView.onRegisterServerError(pid, error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
