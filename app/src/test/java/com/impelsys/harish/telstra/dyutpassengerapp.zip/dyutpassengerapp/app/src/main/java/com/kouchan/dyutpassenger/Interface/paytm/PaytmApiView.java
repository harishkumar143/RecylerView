package com.kouchan.dyutpassenger.Interface.paytm;

import com.kouchan.dyutpassenger.models.PaytmChecksumModel;

public interface PaytmApiView {
    void checksumGenerationSucess(PaytmChecksumModel checksumModel);
    void checksumGenerationError(String error);
}
