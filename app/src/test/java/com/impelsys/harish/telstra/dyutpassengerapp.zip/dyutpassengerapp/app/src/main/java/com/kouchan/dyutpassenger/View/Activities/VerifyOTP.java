package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.CountDownTimer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.common.eventbus.Subscribe;
import com.google.gson.Gson;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.PrefManager;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Interface.bookrideotpresend.BookRideOTPResendPresenterImpl;
import com.kouchan.dyutpassenger.Interface.bookrideotpresend.IBookRideOTPResendPresenter;
import com.kouchan.dyutpassenger.Interface.bookrideotpresend.IBookRideOTPResendView;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.SMSOtpMessage;
import com.kouchan.dyutpassenger.models.verifyotp.VerifyOtpModel;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class VerifyOTP extends AppCompatActivity implements  IBookRideOTPResendView, OnRequestListener {

    private final int COUNT_DOWN_TIME = 60 * 1000; // 60 sec
    private final int COUNT_DOWN_INTERVAL = 1000;  // 1 sec
    IBookRideOTPResendPresenter bookRideOTPResendPresenter;
    AsyncInteractor asyncInteractor;
    TextView verify_otp_textView, phone_verify_desc;
    String languageCode;
    Resources resources;
    String mobile, otpmsg;
    String type;
    SessionManager sessionManager;
    PrefManager prefManager;
    HashMap<String, String> user = new HashMap<String, String>();
    String VERIFY_OTP_URL = "";
    String RESEND_OTP_URL = "";
    Toolbar mToolbar;
    ImageView verifyOTPBackImageView;
    String otpFromServer;

    VerifyOtpModel verifyOtpModel;
    /*  Bus eventBus;*/
    String otpEntered;
    private TextView phoneNoView;
    private EditText phoneCodeView;
    private Button phoneVerifyButton;
    private TextView phoneTimer;
    private TextView resendOtpButton, resendOtpButton1;
    private TextView resendOtpDesc;
    private EditText mFirstDigitEdtTxt, mSecondDigitEdtTxt, mThirdDigitEdtTxt, mFourthDigitEdtTxt;
    private boolean isCodeFetchDone = false;
    private Sharedpreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_otp);

        prefManager = new PrefManager(getApplicationContext());
        prefManager.setIsWaitingForSms(true);
        sharedpreferences = Sharedpreferences.getUserDataObj(this);
        asyncInteractor = new AsyncInteractor(this);
        sessionManager = new SessionManager(getApplicationContext());
        user = sessionManager.getUserDetails();
        mobile = user.get("mobile");

        type = sessionManager.getType();

        VERIFY_OTP_URL = Url.PASSENGER_API + "register.php";
        RESEND_OTP_URL = Url.PASSENGER_API + "sendotpforregistration.php";

        EventBusManager.getInstance().getEventBus().register(this);

        phoneNoView = (TextView) findViewById(R.id.phone_verify_number_tv);
        phoneCodeView = (EditText) findViewById(R.id.phone_verify_code);
        phoneTimer = (TextView) findViewById(R.id.phone_verify_timer);
        phoneVerifyButton = (Button) findViewById(R.id.phone_verification_submit);/*
        resendOtpDesc = (TextView) findViewById(R.id.phone_verify_resend_otp_description);*/
        resendOtpButton = (TextView) findViewById(R.id.phone_verification_resend_otp_button);
        resendOtpButton1 = (TextView) findViewById(R.id.phone_verification_resend_otp_button1);
/*
        phone_verify_desc = (TextView) findViewById(R.id.phone_verify_desc);*/
        verify_otp_textView = (TextView) findViewById(R.id.verify_otp_textView);

        mFirstDigitEdtTxt = (EditText) findViewById(R.id.otp_code_first_digit_edtTxt);
        mSecondDigitEdtTxt = (EditText) findViewById(R.id.otp_code_second_digit_edtTxt);
        mThirdDigitEdtTxt = (EditText) findViewById(R.id.otp_code_third_digit_edtTxt);
        mFourthDigitEdtTxt = (EditText) findViewById(R.id.otp_code_fourth_digit_edtTxt);

        resendOtpButton.setVisibility(View.GONE);
        resendOtpButton1.setVisibility(View.GONE);
        /*
        resendOtpDesc.setVisibility(View.GONE);*/
        phoneNoView.setText("Enter the 4-digit code sent to you at " + getIntent().getStringExtra("mobile"));
        phoneVerifyButton.setEnabled(true);

        phoneCodeView.setInputType(InputType.TYPE_CLASS_NUMBER);

        final CountDownTimer countDownTimer = new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
                phoneTimer.setText(resources.getString(R.string.seconds_remaining) + millisUntilFinished / 1000);
            }

            public void onFinish() {
                //phoneTimer.setText(resources.getString(R.string.sms_otp_not_recieved));
                resendOtpButton1.setVisibility(View.GONE);
                //resendOtpButton1.setText(resources.getString(R.string.sms_otp_not_recieved));
                resendOtpButton.setVisibility(View.VISIBLE);
                /*resendOtpDesc.setVisibility(View.VISIBLE);*/
                phoneTimer.setText(resources.getString(R.string.sms_otp_not_recieved));
            }
        }.start();


        phoneVerifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // otpEntered = phoneCodeView.getText().toString();
                String firstDigit = mFirstDigitEdtTxt.getText().toString();
                String secondDigit = mSecondDigitEdtTxt.getText().toString();
                String thirdDigit = mThirdDigitEdtTxt.getText().toString();
                String fourthDigit = mFourthDigitEdtTxt.getText().toString();
                otpEntered = firstDigit + secondDigit + thirdDigit + fourthDigit;
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(phoneCodeView.getWindowToken(),
                        InputMethodManager.RESULT_UNCHANGED_SHOWN);

                if (!otpEntered.isEmpty()) {
                    sendValues();
                } else {
                    Toast.makeText(VerifyOTP.this, "Enter valid OTP", Toast.LENGTH_SHORT).show();
                }
            }
        });

        resendOtpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                resendOtpButton.setVisibility(View.GONE);
                // resendOtpDesc.setVisibility(View.GONE);
                bookRideOTPResendPresenter = new BookRideOTPResendPresenterImpl(VerifyOTP.this);
                bookRideOTPResendPresenter.getBookRideOTPResend(getIntent().getStringExtra("mobile"));
                //sendOtpRequest();
//                sendValues();
                countDownTimer.start();
            }
        });
        // mDialog.show();
        //  countDownTimer.start();

        initializeViews();

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }


        mFirstDigitEdtTxt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (count == 1)
                    mSecondDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mSecondDigitEdtTxt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (count == 1)
                    mThirdDigitEdtTxt.requestFocus();

                // detect backspace key
                if (count == 0)
                    mFirstDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mThirdDigitEdtTxt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (count == 1)
                    mFourthDigitEdtTxt.requestFocus();

                // detect backspace key
                if (count == 0)
                    mSecondDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mFourthDigitEdtTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                // detect backspace key
                if (count == 0)
                    mThirdDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    @Subscribe //todo remvoing because sms permision changed in android
   public void onOTPReceivedFromSMS(SMSOtpMessage smsOtpMessage) {

        Toast.makeText(this, "smsOtpMessage", Toast.LENGTH_LONG).show();
       //phoneCodeView.setText(""+smsOtpMessage);
   }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        verify_otp_textView.setText(resources.getString(R.string.verify_otp));
        phoneCodeView.setHint(resources.getString(R.string.enter_otp));
        // phoneVerifyButton.setText(resources.getString(R.string.verify));
        resendOtpButton.setText(resources.getString(R.string.resend_otp));
    }


    @Override
    protected void onResume() {
        super.onResume();
    }

   /* @Subscribe todo remvoing because sms permision changed in android
    public void onOTPReceivedFromSMS(SMSOtpMessage smsOtpMessage) {
        isCodeFetchDone = true;
        otpmsg = smsOtpMessage.getOtp();
    //    phoneCodeView.setText(otpmsg);

      if(otpmsg!=null){
          char[] splitted = otpmsg.toCharArray();
          char one = splitted[0];
          char two = splitted[1];
          char the = splitted[2];
          char four = splitted[3];
          mFirstDigitEdtTxt.setText(""+one);
          mSecondDigitEdtTxt.setText(""+two);
          mThirdDigitEdtTxt.setText(""+the);
          mFourthDigitEdtTxt.setText(""+four);
      }

    }*/


    public void sendValues() {

        Utils.showProgress(this);
        Map<String, String> params = new HashMap<String, String>();

        params.put("mobile", getIntent().getStringExtra("mobile"));
        //params.put("device_id", sharedpreferences.getTagDeviceId());
        params.put("otp", otpEntered);

        if(sharedpreferences.getTagDeviceId()==null || sharedpreferences.getTagDeviceId().isEmpty()){
            String android_id = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
            params.put("device_id",android_id);
        }
        else{
            params.put("device_id",sharedpreferences.getTagDeviceId());
        }

        asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_PASSENGER_REGISTER, Url.PASSENGER_API + ServerApiNames.PASSENGER_REGISTER, new JSONObject(params), "");

    }


    private void initializeViews() {
        setSupportActionBar(mToolbar);
        verifyOTPBackImageView = (ImageView) findViewById(R.id.verifyOTPBackImageView);

        verifyOTPBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();
            }
        });
    }

    @Override
    public void addContentView(View view, ViewGroup.LayoutParams params) {
        super.addContentView(view, params);
    }

    @Override
    public void onGetBookRideOTPResendSuccess(int pid, String String) {

    }

    @Override
    public void onGetBookRideOTPResendError(int pid, String error) {
        Toast.makeText(getApplicationContext(), error, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        Utils.stopProgress(this);

        if (pid == AppConstants.TAG_ID_PASSENGER_REGISTER)
            try {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    Gson gson=new Gson();
                    verifyOtpModel = gson.fromJson(responseJson, VerifyOtpModel.class);
                    prefManager.setIsWaitingForSms(false);
                    sessionManager.setIsLogin(true);

                    sessionManager.createLoginSession(verifyOtpModel.getUser().getName(), verifyOtpModel.getUser().getMobile());
                    sessionManager.createId(verifyOtpModel.getId()+"");
                    sessionManager.createEmail(verifyOtpModel.getUser().getEmail());
                    sessionManager.setUniqueId(verifyOtpModel.getUser().getUniqueId());
                    sessionManager.setBlockstatus(verifyOtpModel.getUser().getBlockStatus());
                    sharedpreferences.setOauthToken(verifyOtpModel.getAccessToken());
                    sharedpreferences.setUserMobile(verifyOtpModel.getUser().getMobile());
                  //  sharedpreferences.setRefreshTokenToken(verifyOtpModel.getRefreshToken());
                    sharedpreferences.setOauthTokenExpiryTime(verifyOtpModel.getExpiresIn());
                    sharedpreferences.setUserId(verifyOtpModel.getUser().getUniqueId());
                    sharedpreferences.setEncriptedPassword(verifyOtpModel.getUser().getEncryptedPassword());

                    startActivity(new Intent(VerifyOTP.this, NavHome.class));
                    finish();

                } else {

                    String errorMsg = jObj.getString("error_msg");
                    Utils.showToast(this,errorMsg);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}






