package com.kouchan.dyutpassenger.View.Activities;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BookingExpand extends AppCompatActivity implements OnRequestListener {

    final static String cancelRideUrl = Url.COMUNICATE_API + "bookingCancellationOfPassenger.php";
    String standardComments = Url.COMUNICATE_API + "get_comments.php?user_type=PASSENGER&comment_type=BEFORE_RIDE_START_CANCELLATION";
    Toolbar mToolbar;
    ImageView advanceBookingDetailsBackImageView, advanceBookingDetailsHomeImageView;

    TextView booking_id_booking, passengernamebooking, mobilebooking, whenrequiredbooking,
            whenrequiredtypebooking, typeofratebooking, ratebooking, metervaluebooking,
            extra_value_booking, fromplacebooking, toplacebooking, distancebooking,
            namebookingtext, mobilebookingtext;

    Button startride, cancelride;
    SessionManager sessionManager;
    AsyncInteractor asyncInteractor;
    String type, bookingUrl, id, advanceBookingStartRideUrl;
    HashMap<String, String> user = new HashMap<String, String>();
    String drivermobile, reason;
    LinearLayout driverLayout;
    Button cancelAdvancePassenger;
    AlertDialog.Builder ab;
    String[] listItems;
    ArrayList<String> listdata = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_expand);

        initializeWidgets();
        initializeViews();

    }

    private void initializeWidgets() {

        asyncInteractor=new AsyncInteractor(this);
        id = getIntent().getStringExtra("booking_id");

        booking_id_booking = (TextView) findViewById(R.id.booking_id_booking);
        passengernamebooking = (TextView) findViewById(R.id.passengernamebooking);
        mobilebooking = (TextView) findViewById(R.id.mobilebooking);
        whenrequiredbooking = (TextView) findViewById(R.id.whenrequiredbooking);
        whenrequiredtypebooking = (TextView) findViewById(R.id.whenrequiredtypebooking);
        typeofratebooking = (TextView) findViewById(R.id.typeofratebooking);
        ratebooking = (TextView) findViewById(R.id.ratebooking);
        metervaluebooking = (TextView) findViewById(R.id.metervaluebooking);
        extra_value_booking = (TextView) findViewById(R.id.extra_value_booking);
        fromplacebooking = (TextView) findViewById(R.id.fromplacebooking);
        toplacebooking = (TextView) findViewById(R.id.toplacebooking);
        distancebooking = (TextView) findViewById(R.id.distancebooking);

        namebookingtext = (TextView) findViewById(R.id.namebookingtext);
        mobilebookingtext = (TextView) findViewById(R.id.mobilebookingtext);

        driverLayout = (LinearLayout) findViewById(R.id.driverLayout);

        startride = (Button) findViewById(R.id.startrideAdvance);
        cancelride = (Button) findViewById(R.id.cancelride);
        cancelAdvancePassenger = (Button) findViewById(R.id.cancelAdvancePassenger);
        sessionManager = new SessionManager(getApplicationContext());
        //type = sessionManager.getType();

        user = sessionManager.getUserDetails();
        ab = new AlertDialog.Builder(BookingExpand.this);

        bookingUrl = Url.COMUNICATE_API + "advanceBookingOfPassengerById.php";
        namebookingtext.setText("Driver Name");
        mobilebookingtext.setText("Driver Mobile");
        driverLayout.setVisibility(View.GONE);
        cancelAdvancePassenger.setVisibility(View.VISIBLE);
        BookingExpandPassengerRequest();

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(BookingExpand.this, RideHistoryActivity.class);
        startActivity(intent);
        finish();
    }

    private void initializeViews() {
        setSupportActionBar(mToolbar);
        advanceBookingDetailsBackImageView = (ImageView) findViewById(R.id.advanceBookingDetailsBackImageView);
        advanceBookingDetailsHomeImageView = (ImageView) findViewById(R.id.advanceBookingDetailsHomeImageView);

        advanceBookingDetailsBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BookingExpand.this, RideHistoryActivity.class);
                startActivity(intent);
                finish();
            }
        });

        advanceBookingDetailsHomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BookingExpand.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });


        startride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rideStartedFromDriver();
            }
        });

        cancelAdvancePassenger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                standardComments();

            }
        });

        cancelride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customAlertDialogBox();
            }
        });
    }

    String cancelType = "";

    public void buildingAlertboxNew() {
        final RadioGroup radioGroup;
        final TextInputLayout reasonInputLayout;
        final EditText reasonEditText;

        final Dialog dialog = new Dialog(this);
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.cancellation_dialog);

        radioGroup = (RadioGroup) dialog.findViewById(R.id.radioGroup);
        final int buttons = listdata.size();
        int i = 0;
        for (i = 0; i < buttons; i++) {
            RadioButton rbn = new RadioButton(this);

            rbn.setId(View.generateViewId());
            rbn.setText(listdata.get(i));
            radioGroup.addView(rbn);
        }

        radioGroup.clearCheck();
        reasonInputLayout = (TextInputLayout) dialog.findViewById(R.id.cancellationReason);
        reasonEditText = (EditText) dialog.findViewById(R.id.cancelEditTex);


        Button cancel = (Button) dialog.findViewById(R.id.cancel);
        Button no = (Button) dialog.findViewById(R.id.no);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cancelType.equalsIgnoreCase("Others")) {
                    reason = reasonEditText.getText().toString();
                }
                if (reason.trim().equalsIgnoreCase("")) {
                    Toast.makeText(BookingExpand.this, "Please enter reason", Toast.LENGTH_SHORT).show();
                } else {
                    rideCancelFromPassenger();

                }
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = (RadioButton) group.findViewById(checkedId);
                if (null != rb && checkedId > -1) {

                    if (listdata.get(buttons - 1).equalsIgnoreCase(rb.getText().toString())) {
                        reasonInputLayout.setVisibility(View.VISIBLE);
                        reasonEditText.setVisibility(View.VISIBLE);
                        reason = reasonEditText.getText().toString();
                        cancelType = "Others";
                    } else {
                        reasonInputLayout.setVisibility(View.GONE);
                        reasonEditText.setVisibility(View.GONE);
                        reason = rb.getText().toString();
                        cancelType = "";
                    }
                    //Toast.makeText(DriverLocationTracking.this, rb.getText(), Toast.LENGTH_SHORT).show();
                }

            }
        });

        dialog.show();

    }

    public void customAlertDialogBox() {

        String[] listsize = new String[listdata.size()];
        listItems = listdata.toArray(listsize);

        final EditText edittext = new EditText(BookingExpand.this);
        edittext.setInputType(InputType.TYPE_CLASS_TEXT);
        edittext.setFilters(new InputFilter[]{new InputFilter.LengthFilter(40)});

        final AlertDialog.Builder mBuilder = new AlertDialog.Builder(BookingExpand.this);
        mBuilder.setTitle(R.string.cancel_message);
        mBuilder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                reason = listItems[i];

            }
        });
        mBuilder.setNegativeButton(R.string.dont_cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {

            }
        });
        mBuilder.setPositiveButton(R.string.cancel_ride_button, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

                rideCancelFromPassenger();
                dialog.dismiss();
            }
        });
        AlertDialog mDialog = mBuilder.create();
        mDialog.show();
    }

    public void buildingAlertbox() {

        final EditText edittext = new EditText(BookingExpand.this);
        edittext.setInputType(InputType.TYPE_CLASS_TEXT);

        edittext.setFilters(new InputFilter[]{new InputFilter.LengthFilter(40)});
        ab.setMessage("please Enter the reason for cancellation");
        ab.setTitle("Reason! ");

        ab.setView(edittext);

        ab.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

                reason = edittext.getText().toString();
                rideCancelFromPassenger();
            }
        });

        ab.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

            }
        });

        ab.show();

    }

    private void rideStartedFromDriver() {

        final ProgressDialog loading = ProgressDialog.show(this, "Logging...", "Please wait...", false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, advanceBookingStartRideUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                finish();

                            } else {

                                String errorMsg = jObj.getString("error_msg");
                                Toast.makeText(BookingExpand.this, errorMsg, Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("bookingid", id);
                params.put("passengermobile", mobilebooking.getText().toString());
                params.put("drivermobile", drivermobile);
                params.put("rate", ratebooking.getText().toString());
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void BookingExpandPassengerRequest() {

        Utils.showProgress(this);
        Map<String, String> params = new HashMap<String, String>();
        params.put("booking_id", id);
        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_ADAVANCE_BOOKING_BY_ID,Url.COMUNICATE_API+ServerApiNames.ADAVANCE_BOOKING_ID,new JSONObject(params));

    }

    private void rideCancelFromPassenger() {

        final ProgressDialog loading = ProgressDialog.show(this, "Logging...", "Please wait...", false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, cancelRideUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                Intent intent = new Intent(BookingExpand.this, NavHome.class);
                                startActivity(intent);
                                finish();

                            } else {

                                String errorMsg = jObj.getString("error_msg");

                                Toast.makeText(BookingExpand.this, errorMsg, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("bookingid", id);
                params.put("reason", reason);
                params.put("drivermobile", mobilebooking.getText().toString());
                params.put("passengermobile", user.get("mobile"));
                params.put("current_lat", "");
                params.put("current_long", "");
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void standardComments() {
        Utils.showProgress(this);
        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_GET_COMMENTS_BEFORE_RIDE_START_CANCELLATION,standardComments,null);
    }


    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        Utils.stopProgress(this);

        if(pid==AppConstants.TAG_ID_ADAVANCE_BOOKING_BY_ID) {


            try {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    booking_id_booking.setText(jObj.getString("booking_id"));
                    passengernamebooking.setText(jObj.getString("drivername"));
                    mobilebooking.setText(jObj.getString("drivermobile"));
                    whenrequiredbooking.setText(jObj.getString("whenrequired"));
                    whenrequiredtypebooking.setText(jObj.getString("whenrequiredtype"));
                    typeofratebooking.setText(jObj.getString("typeofrate"));
                    ratebooking.setText(jObj.getString("rate"));
                    metervaluebooking.setText(jObj.getString("metervalue"));
                    extra_value_booking.setText(jObj.getString("extra_value"));
                    fromplacebooking.setText(jObj.getString("fromplace"));
                    toplacebooking.setText(jObj.getString("toplace"));
                    distancebooking.setText(jObj.getString("distance"));

                } else {

                    String errorMsg = jObj.getString("error_msg");
                    Toast.makeText(BookingExpand.this, errorMsg, Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
            if(pid==AppConstants.TAG_ID_GET_COMMENTS_BEFORE_RIDE_START_CANCELLATION){
                try {
                    JSONObject jObj = new JSONObject(responseJson);
                    boolean error = jObj.getBoolean("error");
                    if (!error) {

                        JSONArray jArray = jObj.getJSONArray("comments");
                        if (jArray != null && listdata.size() == 0) {
                            for (int i = 0; i < jArray.length(); i++) {
                                listdata.add(jArray.getString(i));
                            }
                        }
                        buildingAlertboxNew();
                    } else {

                        String errorMsg = jObj.getString("error_msg");
                        Toast.makeText(BookingExpand.this, errorMsg, Toast.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {

        Utils.stopProgress(this);
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
