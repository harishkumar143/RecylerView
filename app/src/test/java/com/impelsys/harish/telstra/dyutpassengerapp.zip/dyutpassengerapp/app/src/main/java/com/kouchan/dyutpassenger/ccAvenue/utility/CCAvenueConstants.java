package com.kouchan.dyutpassenger.ccAvenue.utility;

public interface CCAvenueConstants {

    String MERCHANT_ID = "224281";
    String REDIRECT_URL = "https://bookarideworldwide.com/CAB2.V.1/ccavenue/ccavResponseHandlerPassenger.php";
    String CANCEL_URL = "https://bookarideworldwide.com/CAB2.V.1/ccavenue/ccavResponseHandlerPassenger.php";
    String GET_RSA_URL ="https://bookarideworldwide.com/CAB2.V.1/ccavenue/getRSA.php";
    String ACCESS_CODE = "AVQH86GG33AF11HQFA";
}
