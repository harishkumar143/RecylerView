package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import com.google.android.material.textfield.TextInputLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;

import android.provider.ContactsContract;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.editprofile.EditProfilePresenterImpl;
import com.kouchan.dyutpassenger.Interface.editprofile.IEditProfilePresnter;
import com.kouchan.dyutpassenger.Interface.editprofile.IEditProfileView;
import com.kouchan.dyutpassenger.Interface.getprofile.GetProfilePresenterImpl;
import com.kouchan.dyutpassenger.Interface.getprofile.IGetProfilePresnter;
import com.kouchan.dyutpassenger.Interface.getprofile.IGetProfileView;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.PassengerModel;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class EditProfileActivity extends AppCompatActivity implements IEditProfileView , View.OnClickListener {

    @BindView(R.id.contactPersonMobile)
    EditText contactPersonMobile;

    @BindView(R.id.contactPersonName)
    EditText contactPersonName;

    @BindView(R.id.emergancyText)
    TextView emergancyText;

    @BindView(R.id.save)
    TextView save;

    @BindView(R.id.contactPersonPhoneBookImage)
    ImageView contactPersonPhoneBookImage;

    @BindView(R.id.emailEditIcon)
    ImageView emailEditIcon;

    @BindView(R.id.emergancyContactEditIcon)
    ImageView emergancyContactEditIcon;

    @BindView(R.id.scroll)
    ScrollView scroll;

    EditText register_mobile,register_firstname,register_emailid;
    TextView myprofile_textView;
    Button submit_button;

    IEditProfilePresnter editProfilePresnter;

    PassengerModel passengerModel;

    ImageView editprofileBackImageViewPassengerDriver;
    Sharedpreferences sharedpreferences;

    TextInputLayout nameTextInputLayout,mobileTextInputLayout,emialTextInputLayout,contactPersonMobileTextInputLayout,contactPersonNameTextInputLayout;

    private SessionManager sessionManager;
    private String languageCode;
    private Resources resources;
    private AsyncInteractor asyncInteractor;
    private static final int TAG_RESULT_PICK__CONTACT = 1001;
    Cursor cursor;
    int phonePosIndex, namePosIndex;
    String userNameValue, userPhoneNumberValue = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        ButterKnife.bind(this);

        sharedpreferences=Sharedpreferences.getUserDataObj(this);
        sessionManager=new SessionManager(this);
        asyncInteractor=new AsyncInteractor(this);
        contactPersonPhoneBookImage.setOnClickListener(this);
        save.setOnClickListener(this);
        String getEmergencyContactUrl = Url.PASSENGER_API+"getemergencydetails.php?mobile="+sessionManager.getUserDetails().get("mobile");

        register_mobile = (EditText) findViewById(R.id.register_mobile);
        myprofile_textView = (TextView) findViewById(R.id.myprofile_textView);

        register_firstname = (EditText) findViewById(R.id.register_firstname);

        register_emailid = (EditText) findViewById(R.id.register_emailid);

        submit_button = (Button) findViewById(R.id.submit_button);
        mobileTextInputLayout = (TextInputLayout)findViewById(R.id.mobileTextInputLayout);
        nameTextInputLayout = (TextInputLayout)findViewById(R.id.nameTextInputLayout);
        emialTextInputLayout = (TextInputLayout)findViewById(R.id.email_id_TextInputLayout);
        nameTextInputLayout = (TextInputLayout)findViewById(R.id.nameTextInputLayout);
        emialTextInputLayout = (TextInputLayout)findViewById(R.id.email_id_TextInputLayout);
        emailEditIcon.setOnClickListener(this);
        emergancyContactEditIcon.setOnClickListener(this);

        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        editprofileBackImageViewPassengerDriver = (ImageView)findViewById(R.id.editprofileBackImageViewPassengerDriver);
        editprofileBackImageViewPassengerDriver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                editProfilePresnter = new EditProfilePresenterImpl(EditProfileActivity.this);
                editProfilePresnter.editProfile(register_mobile.getText().toString().trim(),
                        register_firstname.getText().toString().trim(), register_emailid.getText().toString().trim(),
                        contactPersonName.getText().toString(),contactPersonMobile.getText().toString());

            }
        });

        register_emailid.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                register_emailid.setCursorVisible(true);
                register_emailid.setFocusable(true);
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(register_emailid, InputMethodManager.SHOW_IMPLICIT);
                return false;
            }
        });

        Intent intent=getIntent();
        if(intent!=null){
            String profileResponse=intent.getStringExtra("profileResponse");

            Gson gson=new Gson();
            passengerModel = gson.fromJson(profileResponse, PassengerModel.class);
            if(passengerModel!=null){

                register_mobile.setText(passengerModel.getMobile());
                register_firstname.setText(passengerModel.getName());
                register_emailid.setText(passengerModel.getEmail());
                contactPersonMobile.setText(passengerModel.getEmergencyContactMobile());
                contactPersonName.setText(passengerModel.getEmergencyContactName());
            }
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

            mobileTextInputLayout.setHint(resources.getString(R.string.mobile_no));
        nameTextInputLayout.setHint(resources.getString(R.string.name));
        emialTextInputLayout.setHint(resources.getString(R.string.email_id));
        submit_button.setText(resources.getString(R.string.save));
        myprofile_textView.setText(resources.getString(R.string.edit_profile));
    }

    @Override
    public void editProfileSuccess(int pid, String response) {

        submit_button.setVisibility(View.GONE);
        contactPersonPhoneBookImage.setVisibility(View.GONE);
        Toast.makeText(getApplicationContext(),response,Toast.LENGTH_LONG).show();
        Intent intent = new Intent(EditProfileActivity.this,NavHome.class);
        startActivity(intent);
        finish();

    }

    @Override
    public void editProfileError(int pid, String error) {
        Toast.makeText(getApplicationContext(),error,Toast.LENGTH_LONG).show();
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.save:

                editProfilePresnter = new EditProfilePresenterImpl(EditProfileActivity.this);
                editProfilePresnter.editProfile(register_mobile.getText().toString().trim(),
                        register_firstname.getText().toString().trim(), register_emailid.getText().toString().trim(),
                        contactPersonName.getText().toString(),contactPersonMobile.getText().toString());

                break;

            case R.id.contactPersonPhoneBookImage:
                pickContact(TAG_RESULT_PICK__CONTACT);
                break;

            case R.id.emailEditIcon:

                register_emailid.setFocusable(true);
                register_emailid.setFocusableInTouchMode(true);
                register_emailid.requestFocus();

                int pos = register_emailid.getText().length();
                register_emailid.setSelection(pos);

                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(register_emailid, InputMethodManager.SHOW_IMPLICIT);

                scroll.fullScroll(View.FOCUS_DOWN);
                scroll.scrollTo(0, (int) submit_button.getY());
                submit_button.setVisibility(View.VISIBLE);
                save.setVisibility(View.VISIBLE);

                break;

            case R.id.emergancyContactEditIcon:

                contactPersonMobile.setFocusable(true);
                contactPersonMobile.setFocusableInTouchMode(true);
                contactPersonMobile.requestFocus();

                int pos1 = register_emailid.getText().length();
                register_emailid.setSelection(pos1);

                InputMethodManager imm1 = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm1.showSoftInput(contactPersonMobile, InputMethodManager.SHOW_IMPLICIT);

                contactPersonName.setFocusable(true);
                contactPersonName.setFocusableInTouchMode(true);
                submit_button.setVisibility(View.VISIBLE);
                contactPersonPhoneBookImage.setVisibility(View.VISIBLE);
                save.setVisibility(View.VISIBLE);
                break;
        }
    }

    private void pickContact(int type) {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(intent, type);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==TAG_RESULT_PICK__CONTACT){
            pickedContact(data,requestCode);
        }
    }

    private void pickedContact(Intent data, int requestCode) {

        try {

            // getData() method will have the Content Uri of the selected contact
            Uri uri = data.getData();

            //Query the content uri
            cursor = getContentResolver().query(uri, null, null, null, null);
            cursor.moveToFirst();

            phonePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            // column index of the contact name
            namePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

            userPhoneNumberValue = cursor.getString(phonePosIndex);
            userNameValue = cursor.getString(namePosIndex);
            String[] splitStrPhoneNumber = cursor.getString(phonePosIndex).split("\\s+");

            String refinedNumber = "";

            for (int i = 0; i < splitStrPhoneNumber.length; i++) {

                StringBuilder sb = new StringBuilder();
                sb.append(refinedNumber).append(splitStrPhoneNumber[i]);
                refinedNumber = sb.toString();
            }


            if (userPhoneNumberValue != null && userNameValue != null) {

                if (refinedNumber.length() == 10) {
                    refinedNumber = refinedNumber;
                } else if (refinedNumber.length() > 10) {
                    refinedNumber=refinedNumber.replaceAll("[^0-9]+", "");
                    refinedNumber = refinedNumber.substring(refinedNumber.length() - 10);
                    //
                } else {
                    // whatever is appropriate in this case
                    throw new IllegalArgumentException("Enter A Correct Number!");
                }

                if (requestCode == TAG_RESULT_PICK__CONTACT) {
                    contactPersonName.setText(userNameValue);
                    contactPersonMobile.setText(refinedNumber);
                }

            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
