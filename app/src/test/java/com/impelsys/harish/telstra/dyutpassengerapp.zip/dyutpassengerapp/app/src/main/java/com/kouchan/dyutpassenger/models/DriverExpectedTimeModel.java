package com.kouchan.dyutpassenger.models;

import com.google.gson.annotations.SerializedName;

public class DriverExpectedTimeModel {

    /**
     * error : false
     * message : Distance calculation success
     * distance : 1.3 km
     * time : 5 mins
     * latitude : 12.9751553
     * longitude : 77.6041509
     */

    @SerializedName("error")
    private boolean mError;
    @SerializedName("message")
    private String mMessage;
    @SerializedName("distance")
    private String mDistance;
    @SerializedName("time")
    private String mTime;
    @SerializedName("latitude")
    private String mLatitude;
    @SerializedName("longitude")
    private String mLongitude;

    public boolean isError() {
        return mError;
    }

    public void setError(boolean error) {
        mError = error;
    }

    public String getMessage() {
        return mMessage;
    }

    public void setMessage(String message) {
        mMessage = message;
    }

    public String getDistance() {
        return mDistance;
    }

    public void setDistance(String distance) {
        mDistance = distance;
    }

    public String getTime() {
        return mTime;
    }

    public void setTime(String time) {
        mTime = time;
    }

    public String getLatitude() {
        return mLatitude;
    }

    public void setLatitude(String latitude) {
        mLatitude = latitude;
    }

    public String getLongitude() {
        return mLongitude;
    }

    public void setLongitude(String longitude) {
        mLongitude = longitude;
    }
}
