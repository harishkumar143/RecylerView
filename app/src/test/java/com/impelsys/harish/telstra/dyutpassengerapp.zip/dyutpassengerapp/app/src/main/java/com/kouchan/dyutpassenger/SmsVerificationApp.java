package com.kouchan.dyutpassenger;


import android.app.Application;
import android.util.Log;

import java.util.ArrayList;


public class SmsVerificationApp extends Application {

    @Override public void onCreate() {
        super.onCreate();
        AppSignatureHelper appSignatureHelper = new AppSignatureHelper(this);
        ArrayList<String> signature = appSignatureHelper.getAppSignatures();

        Log.e("AppSignature","S:"+signature.get(0));
    }
}
