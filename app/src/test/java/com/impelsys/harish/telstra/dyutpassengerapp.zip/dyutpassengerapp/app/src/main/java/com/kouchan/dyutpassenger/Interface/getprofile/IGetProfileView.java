package com.kouchan.dyutpassenger.Interface.getprofile;

public interface IGetProfileView {

    void getProfileSuccess(int pid, String balance);

    void getProfileError(int pid, String error);

}
