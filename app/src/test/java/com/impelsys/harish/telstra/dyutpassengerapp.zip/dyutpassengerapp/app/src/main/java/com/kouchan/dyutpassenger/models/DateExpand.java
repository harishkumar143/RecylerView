package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 1/12/2018.
 */

public class DateExpand {

    private String booking_id, vehicle, actualprice, bookingdate, fromplace, toplace, distance, starttime,
            endtime, totaltime;


    public DateExpand(String booking_id, String vehicle, String actualprice, String bookingdate,
                      String fromplace, String toplace, String distance, String starttime, String endtime,
                      String totaltime) {
        this.booking_id = booking_id;
        this.vehicle = vehicle;
        this.actualprice = actualprice;
        this.bookingdate = bookingdate;
        this.fromplace = fromplace;
        this.toplace = toplace;
        this.distance = distance;
        this.starttime = starttime;
        this.endtime = endtime;
        this.totaltime = totaltime;

    }

    public String getBooking_id() {
        return booking_id;
    }

    public String getVehicle() {
        return vehicle;
    }

    public String getActualPrice() {
        return actualprice;
    }

    public String getBookingdate() {
        return bookingdate;
    }

    public String getFromplace() {
        return fromplace;
    }

    public String getToplace() {
        return toplace;
    }

    public String getDistance() {
        return distance;
    }

    public String getStarttime() {
        return starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public String getTotaltime() {
        return totaltime;
    }


}
