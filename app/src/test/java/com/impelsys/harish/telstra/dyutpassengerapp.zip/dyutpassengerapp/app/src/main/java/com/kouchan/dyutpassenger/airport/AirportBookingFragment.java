package com.kouchan.dyutpassenger.airport;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.BounceInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.gson.Gson;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Database.CurrentRide;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.DriverLocationTracking;
import com.kouchan.dyutpassenger.View.Activities.FeedbackActivity;
import com.kouchan.dyutpassenger.View.Activities.LoginActivity;
import com.kouchan.dyutpassenger.View.Activities.PaymentActivity;
import com.kouchan.dyutpassenger.View.Activities.SearchPlaceActivity;
import com.kouchan.dyutpassenger.View.Fragments.FragmentBooking2;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.NearByDriversResponseModel;
import com.kouchan.dyutpassenger.models.OttoDialogPersonalOther;
import com.kouchan.dyutpassenger.models.OttoRepeatRide;
import com.kouchan.dyutpassenger.other.CustomDialogClass;
import com.kouchan.dyutpassenger.other.OttoSelectedFromFavorite;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;
import com.squareup.otto.Subscribe;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import static android.app.Activity.RESULT_OK;

public class AirportBookingFragment extends Fragment implements OnMapReadyCallback, View.OnClickListener, OnRequestListener {

    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private static final int TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT = 1001;
    private static final int PLACE_PICKER_REQUEST_FROM = 1000;
    private static final int PLACE_PICKER_REQUEST_TO = 2000;
    private static final int LOCATION_SETTINGS_REQUEST = 1002;
    private static final int PLACE_PICKER_REQUEST_DROP_FROM= 3000;
    private static final int PLACE_PICKER_REQUEST_DROP_TO= 3001;
    private static final int PLACE_PICKER_REQUEST_ROUND_FROM= 4000;
       private static final int PLACE_PICKER_REQUEST_ROUND_TO= 4001;



    private static final String TAG =" PhomeFrag";

    public static boolean exit = false;
    private final LatLng mDefaultLocation = new LatLng(-33.8523341, 151.2106085);
    public TextView yes, no;
    String userNameValue, userPhoneNumberValue = null;
    Cursor cursor = null;
    int phonePosIndex, namePosIndex;
    Dialog mDialog;
    androidx.appcompat.app.AlertDialog.Builder ad;
    AlertDialog.Builder alert;
    AsyncInteractor asyncInteractor;
    Activity activity;
    RadioGroup rideForRadioGroup;
    RadioButton selfRadioButton, otherRadioButton;
    String type = "Self", othermobile, othername;
    Sharedpreferences sharedpreferences;
    public static int cursorStatus;
    String rideLocationOnMap = "0";
    String currency_symbol;
    Boolean from_Booking2;
    TextView deluxTime, luxuryTime, sedanTime, superLauryTime, nameOfOther;
    NearByDriversResponseModel nearByDriversResponseModel;
    private GoogleMap mGoogleMap;
    private SupportMapFragment mapFrag;
    private BitmapDrawable bitmapdraw;
    private LatLng latLng, destinationLatLng;
    private FusedLocationProviderClient fusedLocationClient;
    private LatLng mCenterLatLong;
    private EditText idname, idmobile;
    private boolean apikey = true;
    private ImageView  selectContactImage;
   // private EditText bookaridefrom, bookarideto;
    private ImageView marker_logo, imageViewFevoritDestination, imageViewFevoritSource, destination_marker_logo;
    private String languageCode;
    private Resources resources;
    private double endLatitude, endLongitude;
    private Double trakingLatitude, trackingLongitude;
    private String choose_vehicle_value, vehical_type_id, when_required_value, when_required_type,date_time;
    private Button later_button, ride_now_button;
    private int mHour, mMinute;
    private Calendar c;
    private boolean isRegistered = false;
    private SessionManager sessionManager;
    private HashMap<String, String> user;
    private String tolatitude, tolongitude ,fromlatitude, fromlongitude;
    private View view;
    private String city, name, state, time;
    private TextView taxi_expected_time, taxiText, rickshaw_expected_time, bike_expected_time, suv_expected_time, rentel_taxi_expected_time;
    private int seconds;
    private Location mLocation;
    private Marker mk;
    SharedPreferences preferences;
    private boolean deluxSelected=true;
    private String availableTime;
    private float mZoom;

    RadioButton radiopickup,radiodrop,radioroundtrip;
    LinearLayout ll_pickup,ll_drop,ll_roundtrip;
    Button btn_increase,btn_decrease;
    TextView tv_passanger_count,tv_luggage;
    Button luggage_button_decrease,luggage_button_increase;

    private  EditText pickup_book_a_ride_from,pickup_book_a_ride_to;
    private Spinner pickup_spinner;
    EditText drop_book_a_ride_from,drop_book_a_ride_to;
    EditText round_trip_book_a_ride_from,round_trip_book_a_ride_to;
    boolean isPickup=true,isDrop,isRoundTrip;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        view = inflater.inflate(R.layout.airport_booking_fragment, container, false);

        sessionManager = new SessionManager(getActivity());
        asyncInteractor = new AsyncInteractor(getActivity());
        sharedpreferences = Sharedpreferences.getUserDataObj(getActivity());

        //fusedLocationClient = LocationServices.getFusedLocationProviderClient(getActivity());

        from_Booking2 = true;

        c = Calendar.getInstance();
        seconds = c.get(Calendar.SECOND);

        CurrentRide currentRide = new CurrentRide(getActivity());
        String statusofride = currentRide.getIsridestarted();
        String statusOfFeedback = currentRide.getFeedback();
        String getPaymentstatus = currentRide.getPaymentstatus();

        if (statusofride.equals("started")) {
            Intent i = new Intent(getActivity(), DriverLocationTracking.class);
            i.putExtra("bookingid", currentRide.getRideid());
            i.putExtra("drivermobile", currentRide.getDrivermobile());
            i.putExtra("vehicle", currentRide.getVehicle());
            startActivity(i);
            getActivity().finish();
        } else if (statusOfFeedback.equals("notgiven")) {
            Intent f = new Intent(getActivity(), FeedbackActivity.class);
            f.putExtra("drivermobile", currentRide.getDrivermobile());
            f.putExtra("booking_id", currentRide.getRideid());
            startActivity(f);
            getActivity().finish();

        } else if (getPaymentstatus.equals("notpaid")) {
            Intent f = new Intent(getActivity(), PaymentActivity.class);
            f.putExtra("booking_id", currentRide.getRideid());
            startActivity(f);
            getActivity().finish();

        } else {
            sessionManager = new SessionManager(getActivity());
            initializeWidget();
            setValuesBasedOnOptions();
            infoImages();
            exit = false;
            getDriversLocations();
            // nearbyVehicleServerCall();
            checkLocationPermission();

            askGpsPermission();
            Bundle bundle = this.getArguments();
            if (bundle != null) {
                setValuesofNextFragment();
            }

            resources = getResources();

            if (sessionManager.getLanguageCode() != null) {
                languageCode = sessionManager.getLanguageCode();
                updateViews(languageCode);
            }

            // taxi_expected_time.setText(deluxTime.getText().toString());

          /*  taxiText.setText("Deluxe");
            choose_vehicle_value = "Taxi(4+1)";
            vehical_type_id = "5";
            taxi.setBackgroundResource(R.drawable.selected_delux);
            auto.setBackgroundResource(R.drawable.new_auto_unselected);
            prime.setBackgroundResource(R.drawable.unselected_suv);*/

        }


        if (!isRegistered) {
            EventBusManager.getInstance().getEventBus().register(this);
            isRegistered = !isRegistered;
        }
        cursorStatus = 1;

        initializeWidget();
        imgDelux.setOnClickListener(this);
        imgSedan.setOnClickListener(this);
        imgLuxury.setOnClickListener(this);
        imgSuperLuxury.setOnClickListener(this);
        Spinner spinner2 = (Spinner) view.findViewById(R.id.pickup_spinner);
        List<String> list = new ArrayList<String>();
        list.add("list 1");
        list.add("list 2");
        list.add("list 3");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter);

        radiopickup=view.findViewById(R.id.radiopickup);
        radiodrop=view.findViewById(R.id.radiodrop);
        radioroundtrip=view.findViewById(R.id.radio_round_trip);
        ll_pickup=view.findViewById(R.id.ll_pickup);
        ll_drop=view.findViewById(R.id.ll_drop);
        ll_roundtrip=view.findViewById(R.id.ll_roundtrip);

        // passanger views
        btn_increase=view.findViewById(R.id.button_increase);
        btn_decrease=view.findViewById(R.id.button_decrease);
        tv_passanger_count=view.findViewById(R.id.tv_passanger_count);

        tv_luggage=view.findViewById(R.id.tv_luggage_count);
        luggage_button_decrease=view.findViewById(R.id.luggage_button_decrease);
        luggage_button_increase=view.findViewById(R.id.luggage_button_increase);


        pickup_book_a_ride_from=view.findViewById(R.id.pickup_book_a_ride_from);
        pickup_spinner=view.findViewById(R.id.pickup_spinner);
        pickup_book_a_ride_to=view.findViewById(R.id.pickup_book_a_ride_to);
        drop_book_a_ride_from=view.findViewById(R.id.drop_book_a_ride_from);
        drop_book_a_ride_to=view.findViewById(R.id.drop_book_a_ride_to);
        round_trip_book_a_ride_from=view.findViewById(R.id.roundtrip_book_a_ride_from);
        round_trip_book_a_ride_to=view.findViewById(R.id.round_trip_book_a_ride_to);

        drop_book_a_ride_to.setHint(resources.getString(R.string.enter_drop_location));
        round_trip_book_a_ride_to.setHint(resources.getString(R.string.enter_drop_location));

        radiopickupListener();
        radiodropListener();
        radioroundtripListener();
        buttonDecrease();
        buttonIncrease();
        buttonLuggageIncrease();
        buttonbuttonLuggageDecrease();
        selectPickupFrom();
        selectDropFrom();
        selectDropTo();
        selectRoundTripDropFrom();
        selectRoundTripDropTo();
        return view;
    }

    private void selectPickupFrom(){
        pickup_book_a_ride_from.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cursorStatus = 100;
                callPlaceAutocompleteActivityIntentFrom(PLACE_PICKER_REQUEST_FROM);
            }
        });


    }

    private void selectDropFrom(){
        drop_book_a_ride_from.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cursorStatus = 102;
                callPlaceAutocompleteActivityIntentFrom(PLACE_PICKER_REQUEST_DROP_FROM);
            }
        });


    }


    private void selectDropTo(){
        drop_book_a_ride_to.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cursorStatus = 103;
                callPlaceAutocompleteActivityIntentTo(PLACE_PICKER_REQUEST_DROP_TO);
            }
        });


    }
    private void selectRoundTripDropFrom(){
        round_trip_book_a_ride_from.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cursorStatus = 104;
                callPlaceAutocompleteActivityIntentFrom(PLACE_PICKER_REQUEST_ROUND_FROM);
            }
        });
    }
    private void selectRoundTripDropTo(){
        round_trip_book_a_ride_to.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cursorStatus = 105;
                callPlaceAutocompleteActivityIntentTo(PLACE_PICKER_REQUEST_ROUND_TO);
            }
        });
    }

    private void setPickupSpinner(){

    }

    private void radiopickupListener(){
        radiopickup.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    ll_pickup.setVisibility(View.VISIBLE);
                    isPickup=true;
                    isDrop=false;
                    isRoundTrip=false;
                    ll_drop.setVisibility(View.GONE);
                    ll_roundtrip.setVisibility(View.GONE);
                }else{
                    ll_pickup.setVisibility(View.GONE);

                }
            }
        });
    }

    private void radiodropListener(){
        radiodrop.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    ll_drop.setVisibility(View.VISIBLE);
                    ll_pickup.setVisibility(View.GONE);
                    ll_roundtrip.setVisibility(View.GONE);
                    isPickup=false;
                    isDrop=true;
                    isRoundTrip=false;
                }else{
                    ll_drop.setVisibility(View.GONE);

                }
            }
        });
    }

    private void radioroundtripListener(){
        radioroundtrip.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    ll_roundtrip.setVisibility(View.VISIBLE);
                    ll_roundtrip_date.setVisibility(View.VISIBLE);
                    ll_drop.setVisibility(View.GONE);
                    ll_pickup.setVisibility(View.GONE);
                    isPickup=false;
                    isDrop=false;
                    isRoundTrip=true;
                }else{
                    ll_roundtrip.setVisibility(View.GONE);
                    ll_roundtrip_date.setVisibility(View.GONE);

                }
            }
        });
    }

    private void buttonIncrease(){
        btn_increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String count=tv_passanger_count.getText().toString();
                int passngerCount=Integer.parseInt(count)+1;
                tv_passanger_count.setText(""+passngerCount);
            }
        });
    }
    private void buttonDecrease(){
        btn_decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String count=tv_passanger_count.getText().toString();
                int passngerCount=Integer.parseInt(count);
                if(passngerCount==1){
                    Toast.makeText(getActivity(), "Minimum passenger count is 1", Toast.LENGTH_SHORT).show();
                }else{
                    passngerCount=passngerCount-1;
                    tv_passanger_count.setText(""+passngerCount);
                }

            }
        });
    }
    private void buttonLuggageIncrease(){
        luggage_button_increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String count=tv_luggage.getText().toString();
                int passngerCount=Integer.parseInt(count)+1;
                tv_luggage.setText(""+passngerCount);
            }
        });
    }
    private void buttonbuttonLuggageDecrease(){
        luggage_button_decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String count=tv_luggage.getText().toString();
                int passngerCount=Integer.parseInt(count);
                if(passngerCount==0){
                    Toast.makeText(getActivity(), "Minimum Luggage  is 0", Toast.LENGTH_SHORT).show();
                }else{
                    passngerCount=passngerCount-1;
                    tv_luggage.setText(""+passngerCount);
                }

            }
        });
    }


    private void selectPickupDate(){

        tv_pickup_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get Current Date
                final Calendar c = Calendar.getInstance();
                int  mYear = c.get(Calendar.YEAR);
                int  mMonth = c.get(Calendar.MONTH);
                int  mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                tv_pickup_date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                datePickerDialog.show();
            }
        });



    }

    private void selectPickupTime(){
        tv_pickup_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get Current Time
                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {

                                tv_pickup_time.setText(hourOfDay + ":" + minute);
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.updateTime(mHour,mMinute);
                timePickerDialog.show();
            }
        });

    }

    private void selectDropDate(){
        tv_drop_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get Current Date
                final Calendar c = Calendar.getInstance();
                int  mYear = c.get(Calendar.YEAR);
                int  mMonth = c.get(Calendar.MONTH);
                int  mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                tv_drop_date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                datePickerDialog.show();
            }
        });

    }

    private void selectDropTime(){
        tv_drop_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get Current Time
                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {

                                tv_drop_time.setText(hourOfDay + ":" + minute);
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.updateTime(mHour,mMinute);
                timePickerDialog.show();
            }
        });
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (!isRegistered) {
                EventBusManager.getInstance().getEventBus().register(this);
                isRegistered = !isRegistered;
            }
        } else {
            if (isRegistered) {
                EventBusManager.getInstance().getEventBus().unregister(this);
                isRegistered = !isRegistered;
            }
        }
    }

    private void setValuesofNextFragment() {
        from_Booking2 = true;
        if (from_Booking2) {
            //bookaridefrom.setText(this.getArguments().getString("from"));
            pickup_book_a_ride_from.setText(this.getArguments().getString("from"));
            drop_book_a_ride_from.setText(this.getArguments().getString("from"));
            round_trip_book_a_ride_from.setText(this.getArguments().getString("from"));
        }
        //bookarideto.setText(this.getArguments().getString("to"));

        drop_book_a_ride_to.setText(this.getArguments().getString("to"));
        round_trip_book_a_ride_to.setText(this.getArguments().getString("to"));

        fromlatitude = this.getArguments().getString("fromlatitude");
        fromlongitude = this.getArguments().getString("fromlongitude");
        tolatitude = this.getArguments().getString("tolatitude");
        tolongitude = this.getArguments().getString("tolongitude");
        choose_vehicle_value = this.getArguments().getString("vehicle_type");

        switch (choose_vehicle_value) {

            case "Deluxe":

                // rental.setBackgroundResource(R.drawable.rentals);
                imgDelux.setBackgroundResource(R.drawable.delux_selected);
                imgSedan.setBackgroundResource(R.drawable.unselected_sedan);
                // mini.setBackgroundResource(R.drawable.mini);
                imgLuxury.setBackgroundResource(R.drawable.unselect_super_luxury);
                imgSuperLuxury.setBackgroundResource(R.drawable.luxury_unselected);
                break;

            case "Sedan":

                imgDelux.setBackgroundResource(R.drawable.unselected_delux);
                imgSedan.setBackgroundResource(R.drawable.sedan_selected);
                // mini.setBackgroundResource(R.drawable.mini);
                imgLuxury.setBackgroundResource(R.drawable.unselect_super_luxury);
                imgSuperLuxury.setBackgroundResource(R.drawable.luxury_unselected);

                break;

            case "Luxury":

                imgDelux.setBackgroundResource(R.drawable.unselected_delux);
                imgSedan.setBackgroundResource(R.drawable.unselected_sedan);
                // mini.setBackgroundResource(R.drawable.mini);
                imgLuxury.setBackgroundResource(R.drawable.super_luxury_selected);
                imgSuperLuxury.setBackgroundResource(R.drawable.luxury_unselected);

                break;


            case "Taxi(6+1)":

                imgDelux.setBackgroundResource(R.drawable.unselected_delux);
                imgSedan.setBackgroundResource(R.drawable.unselected_sedan);
                // mini.setBackgroundResource(R.drawable.mini);
                imgLuxury.setBackgroundResource(R.drawable.unselect_super_luxury);
                imgSuperLuxury.setBackgroundResource(R.drawable.luxury_selected);

                break;

        }


    }
    // add items into spinner dynamically
    public void addItemsOnSpinner2() {

        Spinner spinner2 = (Spinner) view.findViewById(R.id.pickup_spinner);
        List<String> list = new ArrayList<String>();
        list.add("list 1");
        list.add("list 2");
        list.add("list 3");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter);
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(getActivity(), languageCode);
        resources = context.getResources();

        // bookaridefrom.setHint(resources.getString(R.string.enter_pickup_point));
        //bookarideto.setHint(resources.getString(R.string.enter_drop_location));


        selfRadioButton.setText(resources.getString(R.string.for_self));
        otherRadioButton.setText(resources.getString(R.string.for_others));
        later_button.setText(resources.getString(R.string.later));
        ride_now_button.setText(resources.getString(R.string.ride_now));

    }


    private void pickedContact(Intent data, int requestCode) {

        try {
            // getData() method will have the Content Uri of the selected contact
            Uri uri = data.getData();
            cursor = getContext().getContentResolver().query(uri, null, null, null, null);
            cursor.moveToFirst();
            // sendToParentLinearLayout.setVisibility(GONE);
            //pickedContactDetailsLinearLayout.setVisibility(View.VISIBLE);
            // column index of the phone number
            phonePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            // column index of the contact name
            namePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

            userPhoneNumberValue = cursor.getString(phonePosIndex);
            userNameValue = cursor.getString(namePosIndex);


            Log.d("pickedPhoneNum", ":" + cursor.getString(phonePosIndex));
            String[] splitStrPhoneNumber = cursor.getString(phonePosIndex).split("\\s+");

            String refinedNumber = "";

            for (int i = 0; i < splitStrPhoneNumber.length; i++) {

                StringBuilder sb = new StringBuilder();

                Log.d("splitted", "Values" + i + "   " + splitStrPhoneNumber[i]);
                sb.append(refinedNumber).append(splitStrPhoneNumber[i]);

                Log.d("data", ":data came" + sb.toString());

                refinedNumber = sb.toString();
                Log.d("data", ":data came" + refinedNumber);


            }


            if (userPhoneNumberValue != null && userNameValue != null) {


                Log.d("data", ":Length" + refinedNumber.length());

                Log.d("data123", ":data came" + refinedNumber);


                if (refinedNumber.length() == 10) {
                    refinedNumber = refinedNumber;
                } else if (refinedNumber.length() > 10) {
                    refinedNumber = refinedNumber.replaceAll("[^0-9]+", "");
                    refinedNumber = refinedNumber.substring(refinedNumber.length() - 10);
                    //
                } else {
                    // whatever is appropriate in this case
                    throw new IllegalArgumentException("Please Enter Valid Mobile Number");
                }

                Log.d("data123", ":data came" + refinedNumber);
                if (requestCode == TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT) {
                    idname.setText(userNameValue);
                    idmobile.setText(refinedNumber);
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sessionManager = new SessionManager(getActivity());
        user = sessionManager.getUserDetails();
        name = user.get("name");

        getActivity().setTitle("Airport Booking");
    }

    ImageView imgDelux,imgSedan,imgLuxury,imgSuperLuxury;
    TextView tv_pickup_date,tv_pickup_time,tv_drop_date,tv_drop_time;
    LinearLayout ll_roundtrip_date;

    private void initializeWidget() {


        imgDelux = (ImageView) view.findViewById(R.id.book_a_delux);
        imgSedan = (ImageView) view.findViewById(R.id.book_a_ride_sedan);
        imgLuxury = (ImageView) view.findViewById(R.id.book_a_ride_luxury);
        imgSuperLuxury = (ImageView) view.findViewById(R.id.book_a_ride_super_luxury);

        rideForRadioGroup = (RadioGroup) view.findViewById(R.id.rideForRadioGrouop);
        selfRadioButton = (RadioButton) view.findViewById(R.id.selfRadioButton);
        otherRadioButton = (RadioButton) view.findViewById(R.id.otherRadioButton);

      //  bookaridefrom = (EditText) view.findViewById(R.id.book_a_ride_from);
      //  bookarideto = (EditText) view.findViewById(R.id.book_a_ride_to);

        marker_logo = (ImageView) view.findViewById(R.id.pickup_marker_logo);
        destination_marker_logo = (ImageView) view.findViewById(R.id.destination_marker_logo);
       // imageViewFevoritDestination = (ImageView) view.findViewById(R.id.imageViewFevoritDestination);
       // imageViewFevoritSource = (ImageView) view.findViewById(R.id.imageViewFevoritSource);
        later_button = (Button) view.findViewById(R.id.later_button);
        ride_now_button = (Button) view.findViewById(R.id.ride_now_button);

        deluxTime=view.findViewById(R.id.deluxe_expected_time);
        sedanTime=view.findViewById(R.id.sedan_expected_time);
        superLauryTime=view.findViewById(R.id.super_luxury_expected_time);
        luxuryTime=view.findViewById(R.id.luxury_expected_time);

        nameOfOther = (TextView) view.findViewById(R.id.nameOfOther);
        taxi_expected_time = (TextView) view.findViewById(R.id.taxi_expected_time);
        taxiText = (TextView) view.findViewById(R.id.taxiText);
        rickshaw_expected_time = (TextView) view.findViewById(R.id.rickshaw_expected_time);
        bike_expected_time = (TextView) view.findViewById(R.id.bike_expected_time);


        //mini_expected_time = (TextView) view.findViewById(R.id.mini_expected_time);

        suv_expected_time = (TextView) view.findViewById(R.id.prime_expected_time);

        sessionManager = new SessionManager(getActivity());
        sessionManager.couterZero();


        mapFrag = (SupportMapFragment) this.getChildFragmentManager().findFragmentById(R.id.mapViewPassenger);
        mapFrag.getMapAsync(this);

        ride_now_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(isPickup){
                   if (pickup_book_a_ride_from == null || pickup_book_a_ride_from.getText().toString().isEmpty()) {
                       //Todo needs to un select all the selected views
                       //choose_vehicle.clearCheck();
                       Utils.showToast(getActivity(),"Enter your pickup location");
                   } else if (choose_vehicle_value == null) {
                       Toast.makeText(getActivity(), "Please select the vehicle", Toast.LENGTH_LONG).show();
                   } else if (pickup_book_a_ride_to == null || pickup_book_a_ride_to.getText().toString().isEmpty()) {
                       Utils.showToast(getActivity(),"Enter your drop location");
                   }
                   else {
                       when_required_type = "immediate";

                       Calendar mcurrentTime = Calendar.getInstance();
                       int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                       int minute = mcurrentTime.get(Calendar.MINUTE);
                       int dayOfMonth = mcurrentTime.get(Calendar.DAY_OF_MONTH);
                       int monthOfYear = mcurrentTime.get(Calendar.MONTH);
                       int year = mcurrentTime.get(Calendar.YEAR);

                       date_time = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                       when_required_value = date_time + " " + hour + ":" + minute + ":" + seconds;
                       getDistanceByServer();
                   }
               }else if(isDrop){
                   if (drop_book_a_ride_from == null || drop_book_a_ride_from.getText().toString().isEmpty()) {
                       //Todo needs to un select all the selected views
                       //choose_vehicle.clearCheck();
                       Utils.showToast(getActivity(),"Enter your pickup location");
                   } else if (choose_vehicle_value == null) {
                       Toast.makeText(getActivity(), "Please select the vehicle", Toast.LENGTH_LONG).show();
                   } else if (drop_book_a_ride_to == null || drop_book_a_ride_to.getText().toString().isEmpty()) {
                       Utils.showToast(getActivity(),"Enter your drop location");
                   }
                   else {
                       when_required_type = "immediate";

                       Calendar mcurrentTime = Calendar.getInstance();
                       int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                       int minute = mcurrentTime.get(Calendar.MINUTE);
                       int dayOfMonth = mcurrentTime.get(Calendar.DAY_OF_MONTH);
                       int monthOfYear = mcurrentTime.get(Calendar.MONTH);
                       int year = mcurrentTime.get(Calendar.YEAR);

                       date_time = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                       when_required_value = date_time + " " + hour + ":" + minute + ":" + seconds;
                       getDistanceByServer();
                   }
               }else if(isRoundTrip){
                   if (round_trip_book_a_ride_from == null || round_trip_book_a_ride_from.getText().toString().isEmpty()) {
                       //Todo needs to un select all the selected views
                       //choose_vehicle.clearCheck();
                       Utils.showToast(getActivity(),"Enter your pickup location");
                   } else if (choose_vehicle_value == null) {
                       Toast.makeText(getActivity(), "Please select the vehicle", Toast.LENGTH_LONG).show();
                   } else if (round_trip_book_a_ride_to == null || round_trip_book_a_ride_to.getText().toString().isEmpty()) {
                       Utils.showToast(getActivity(),"Enter your drop location");
                   }
                   else {
                       when_required_type = "immediate";

                       Calendar mcurrentTime = Calendar.getInstance();
                       int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                       int minute = mcurrentTime.get(Calendar.MINUTE);
                       int dayOfMonth = mcurrentTime.get(Calendar.DAY_OF_MONTH);
                       int monthOfYear = mcurrentTime.get(Calendar.MONTH);
                       int year = mcurrentTime.get(Calendar.YEAR);

                       date_time = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                       when_required_value = date_time + " " + hour + ":" + minute + ":" + seconds;
                       getDistanceByServer();
                   }
               }

            }
        });

        radioGroupOoperation();

        ll_roundtrip_date=view.findViewById(R.id.ll_roundtrip_date);
        tv_pickup_date=view.findViewById(R.id.tv_pickup_date);
        tv_pickup_time=view.findViewById(R.id.tv_pickup_time);
        tv_drop_date=view.findViewById(R.id.tv_drop_date);
        tv_drop_time=view.findViewById(R.id.tv_drop_time);
        selectPickupDate();
        selectPickupTime();
        selectDropDate();
        selectDropTime();

    }

    private void radioGroupOoperation() {

        rideForRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                View radioButton = rideForRadioGroup.findViewById(checkedId);
                int index = rideForRadioGroup.indexOfChild(radioButton);

                switch (index) {
                    case 0: // first button
                        nameOfOther.setVisibility(View.GONE);
                        break;
                    case 1: // secondbutton

                        mDialog = new Dialog(getActivity());
                        mDialog.setCanceledOnTouchOutside(false);
                        mDialog.setContentView(R.layout.custom_dialog_personal_other);

                        idname = (EditText) mDialog.findViewById(R.id.idname);
                        idmobile = (EditText) mDialog.findViewById(R.id.idmobile);
                        selectContactImage = (ImageView) mDialog.findViewById(R.id.ivSearch);
                        yes = (TextView) mDialog.findViewById(R.id.btn_yes);
                        no = (TextView) mDialog.findViewById(R.id.btn_no);


                        selectContactImage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                pickContactBookForOther(TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT);
                            }
                        });

                        yes.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                if (idmobile.getText().toString().trim().length() == 0) {
                                    Utils.showToast(getActivity(), "Enter passenger mobile number");
                                } else if (idmobile.getText().toString().trim().length() < 10) {
                                    Utils.showToast(getActivity(), "Enter valid mobile number");
                                } else if (idname.getText().toString().trim().length() == 0) {
                                    Utils.showToast(getActivity(), "Enter passenger name");
                                } else {
                                    OttoDialogPersonalOther ottoDialogGeneric = new OttoDialogPersonalOther("Other", idname.getText().toString(), idmobile.getText().toString());
                                    EventBusManager.getInstance().getEventBus().post(ottoDialogGeneric);
                                    nameOfOther.setVisibility(View.VISIBLE);
                                    nameOfOther.setText("Booking For: " + idname.getText().toString());
                                    mDialog.dismiss();
                                }
                            }
                        });

                        no.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                mDialog.dismiss();
                                selfRadioButton.setChecked(true);
                            }
                        });

                        mDialog.show();
                }
            }
        });
    }


    private void pickContactBookForOther(int type) {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(intent, type);
    }

    private void infoImages() {

        marker_logo.clearAnimation();
        TranslateAnimation transAnim = new TranslateAnimation(0, 0, -200, 0);
        transAnim.setStartOffset(100);
        transAnim.setDuration(2000);
        transAnim.setFillAfter(true);
        /*transAnim.setRepeatMode(0);*/
        transAnim.setRepeatCount(2);
        /*transAnim.setRepeatCount(Animation.INFINITE);*/
        transAnim.setInterpolator(new BounceInterpolator());
        transAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                Log.i(TAG, "Starting button dropdown animation");
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Log.i(TAG,
                        "Ending button dropdown animation. Clearing animation and setting layout");
                marker_logo.clearAnimation();
                final int left = marker_logo.getLeft();
                final int top = marker_logo.getTop();
                final int right = marker_logo.getRight();
                final int bottom = marker_logo.getBottom();
                marker_logo.layout(left, top, right, bottom);
            }
        });
        marker_logo.startAnimation(transAnim);



        /*----------------------------------fevoritdestination  button------------------------ */
       /* imageViewFevoritDestination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String address = bookarideto.getText().toString();
                if (address.equals("")) {

                    *//* bookarideto.setError("please select the destination address");*//*
                    Toast.makeText(activity, "Destination point is empty", Toast.LENGTH_SHORT).show();
                } else {
                    CustomDialogClass cdd = new CustomDialogClass(getActivity(), address, tolatitude, tolongitude, sessionManager.getUserDetails().get("mobile"), "destination");
                    cdd.setCancelable(false);
                    cdd.show();
                    Window window = cdd.getWindow();
                    assert window != null;
                    window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);

                }

            }
        });*/

       /* imageViewFevoritSource.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String address = bookaridefrom.getText().toString();
                if (address.equals("")) {
                    Toast.makeText(activity, "Pick up point is empty", Toast.LENGTH_SHORT).show();
                } else {
                    CustomDialogClass cdd = new CustomDialogClass(getActivity(), address, fromlatitude, fromlongitude, sessionManager.getUserDetails().get("mobile"), "source");
                    cdd.setCancelable(false);
                    cdd.show();
                    Window window = cdd.getWindow();
                    assert window != null;
                    window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);

                }
            }
        });*/

    }

    @Override
    public void onResume() {
        super.onResume();
        exit = false;
    }

    private void setValuesBasedOnOptions() {

        user = new HashMap<String, String>();

        user = sessionManager.getUserDetails();

      /*  bookaridefrom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cursorStatus = 1;
                callPlaceAutocompleteActivityIntentFrom();
                marker_logo.setVisibility(View.VISIBLE);

                destination_marker_logo.setVisibility(View.GONE);
                rideLocationOnMap = "1";

            }
        });*/


        later_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(activity, "This feature is presently not available", Toast.LENGTH_SHORT).show();
          /*      when_required_type = "later";

                int mYear = c.get(Calendar.YEAR);
                int mMonth = c.get(Calendar.MONTH);
                int mDay = c.get(Calendar.DAY_OF_MONTH);

                Calendar minCal = Calendar.getInstance();
                minCal.set(Calendar.YEAR, minCal.get(Calendar.YEAR));
                minCal.set(Calendar.MONTH, minCal.get(Calendar.MONTH));
                minCal.set(Calendar.DAY_OF_MONTH, minCal.get(Calendar.DAY_OF_MONTH));

                Calendar maxCal = Calendar.getInstance();
                maxCal.set(Calendar.YEAR, maxCal.get(Calendar.YEAR));
                maxCal.set(Calendar.MONTH, maxCal.get(Calendar.MONTH));
                maxCal.set(Calendar.DAY_OF_MONTH, maxCal.get(Calendar.DAY_OF_MONTH) + 3);

                DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                                date_time = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                                //*************Call Time Picker Here ********************
                                if (dayOfMonth == c.get(Calendar.DAY_OF_MONTH)) {
                                    timePicker();
                                } else {
                                    timePickerNextDay();
                                }

                            }
                        }, mYear, mMonth, mDay);

                datePickerDialog.getDatePicker().setMaxDate(maxCal.getTimeInMillis());
                datePickerDialog.getDatePicker().setMinDate(minCal.getTimeInMillis());
                datePickerDialog.show();*/
            }
        });

    }

    private void timePicker() {

        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        /*hourOfDay=c.get(Calendar.HOUR_OF_DAY);*/

                        if (hourOfDay <= (c.get(Calendar.HOUR_OF_DAY)) &&
                                (minute <= (c.get(Calendar.MINUTE)))) {
                            timePicker();

                        } else if (hourOfDay == (c.get(Calendar.HOUR_OF_DAY))) {
                            timePicker();
                        } else if (hourOfDay == (c.get(Calendar.HOUR_OF_DAY) + 1)) {
                            timePickerMinute();
                        } else {
                            mHour = hourOfDay;
                            mMinute = minute;
                            when_required_value = date_time + " " + hourOfDay + ":" + minute + ":" + seconds;
                            //getDistanceByServer();
                        }
                    }
                }, mHour, mMinute, false);

        timePickerDialog.show();
    }

    private void timePickerMinute() {

        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        if (minute == (c.get(Calendar.MINUTE))) {
                            timePickerMinute();
                        } else if (minute <= (c.get(Calendar.MINUTE))) {
                            timePickerMinute();
                        } else if (minute > (c.get(Calendar.MINUTE))) {
                            mHour = hourOfDay;
                            mMinute = minute;
                            when_required_value = date_time + " " + hourOfDay + ":" + minute + ":" + seconds;

                            /*timePickerMinute();*/
                            getDistanceByServer();

                        } else {
                            mHour = hourOfDay;
                            mMinute = minute;
                            when_required_value = date_time + " " + hourOfDay + ":" + minute + ":" + seconds;

                            getDistanceByServer();

                        }
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }


    private void timePickerNextDay() {
        // Get Current Time

        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        // Launch Time Picker Dialog
        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        mHour = hourOfDay;
                        mMinute = minute;

                        when_required_value = date_time + " " + hourOfDay + ":" + minute + ":" + seconds;

                        getDistanceByServer();

                    }
                }, mHour, mMinute, false);

        timePickerDialog.show();

    }


    private void getDistanceByServer() {


        //  loading = ProgressDialog.show(getActivity(), resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);

        Utils.showProgress(getActivity());

        Map<String, String> params = new HashMap<String, String>();

        params.put("from_lat", fromlatitude);
        params.put("from_long", fromlongitude);
        params.put("to_lat", tolatitude);
        params.put("to_long", tolongitude);
        params.put("vehicle_type_id", vehical_type_id);

        if (city == null) { //todo have to remove hardcoded
            params.put("city_name", "Bengaluru");
        } else {
            params.put("city_name", city);
        }

        if (state == null) {
            params.put("state_name", "Karnataka");
        } else {
            params.put("state_name", state);
        }
        params.put("booking_type", when_required_type);
        params.put("booking_time", "00:58:22");

        params.put("mobile_no", user.get("mobile"));
        params.put("airport_booking_type","YES");

        params.put("round_trip","NA");

        String passengerCount="0";
        try{
            passengerCount=tv_passanger_count.getText().toString();
         }catch (Exception e){
             e.printStackTrace();
         }
        String luggageCount="0";
        try{
            luggageCount=tv_luggage.getText().toString();
        }catch (Exception e){
            e.printStackTrace();
        }
        params.put("no_of_passengers",passengerCount);
        params.put("bag_type","NORMAL");
        params.put("no_of_luggages",luggageCount);

        asyncInteractor.validateCredentialsAsync(this, AppConstants.distanceCalculateByLatLongNew, Url.PASSENGER_API + ServerApiNames.distanceCalculateByLatLongNew, new JSONObject(params));

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {


        mGoogleMap = googleMap;

        getDeviceLocation();


        @SuppressWarnings("ConstantConditions") View locationButton = ((View) mapFrag.getView().findViewById(Integer.parseInt("1")).getParent()).findViewById(Integer.parseInt("2"));
        RelativeLayout.LayoutParams rlp = (RelativeLayout.LayoutParams) locationButton.getLayoutParams();
        // position on right bottom
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0);
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        rlp.setMargins(0, 450, 10, 0);


        mGoogleMap.setOnCameraIdleListener(new GoogleMap.OnCameraIdleListener() {
            @Override
            public void onCameraIdle() {
                // Cleaning all the markers.
                if (mGoogleMap != null) {
                    mGoogleMap.clear();
                }

                mCenterLatLong = mGoogleMap.getCameraPosition().target;
                mZoom = mGoogleMap.getCameraPosition().zoom;

              /*  if (cursorStatus == 1) {
                    getAddress(mCenterLatLong);
                }else if(cursorStatus ==2){
                    getAddressDropTo(mCenterLatLong);
                }else if(cursorStatus ==3){
                    getAddressRoundTo(mCenterLatLong);
                }*/

            }
        });


    }

    private void getDeviceLocation() {
        /*
         * Get the best and most recent location of the device, which may be null in rare
         * cases when a location is not available.
         */
        try {
            if (checkLocationPermission()) {

                fusedLocationClient = LocationServices.getFusedLocationProviderClient(activity);
                Task<Location> locationResult = fusedLocationClient.getLastLocation();
                locationResult.addOnCompleteListener(activity, new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if (task.isSuccessful()) {
                            // Set the map's camera position to the current location of the device.
                            mLocation = task.getResult();
                            if (mLocation != null) {
                                LatLng currentLocation = new LatLng(mLocation.getLatitude(), mLocation.getLongitude());
                                trakingLatitude = mLocation.getLatitude();
                                trackingLongitude = mLocation.getLongitude();
//                            mGoogleMap.addMarker(new MarkerOptions().position(currentLocation)
//                                    .title("current location"));
                                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(
                                        currentLocation, 15));
                                mGoogleMap.setMyLocationEnabled(true);
                                mGoogleMap.getUiSettings().setCompassEnabled(true);
                                mGoogleMap.getUiSettings().setMyLocationButtonEnabled(true);

                                showLocationAddress();
                            } else {

                                Toast.makeText(activity, "Getting locations..", Toast.LENGTH_SHORT).show();

                                LocationRequest mLocationRequest = LocationRequest.create();
                                mLocationRequest.setInterval(3000);
                                mLocationRequest.setFastestInterval(2000);
                                mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
                                LocationCallback mLocationCallback = new LocationCallback() {
                                    @Override
                                    public void onLocationResult(LocationResult locationResult) {
                                        if (locationResult == null) {
                                            return;
                                        }
                                        for (Location location : locationResult.getLocations()) {
                                            if (location != null) {
                                                //TODO: UI updates.
                                            }
                                        }
                                    }
                                };
                                LocationServices.getFusedLocationProviderClient(activity).requestLocationUpdates(mLocationRequest, mLocationCallback,  Looper.myLooper());

                            }

                        } else {
//                            Log.d(TAG, "Current location is null. Using defaults.");
//                            Log.e(TAG, "Exception: %s", task.getException());
                            mGoogleMap.moveCamera(CameraUpdateFactory
                                    .newLatLngZoom(mDefaultLocation, 15));
                        }
                    }
                });
            }
        } catch (SecurityException e) {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    private void showLocationAddress() {

        Geocoder gcd = new Geocoder(activity, Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = gcd.getFromLocation(mLocation.getLatitude(), mLocation.getLongitude(), 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (addresses != null && addresses.size() > 0) {
            String locality = addresses.get(0).getLocality();
            //Toast.makeText(getActivity(), locality, Toast.LENGTH_SHORT).show();
        } else {

        }
    }

    private void getAddress(final LatLng mCenterLatLong) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    Location mLocation = new Location("");
                    mLocation.setLatitude(mCenterLatLong.latitude);
                    mLocation.setLongitude(mCenterLatLong.longitude);
                    Geocoder geocoder;
                    List<Address> yourAddresses;
                    geocoder = new Geocoder(getActivity(), Locale.getDefault());
                    yourAddresses = geocoder.getFromLocation(mLocation.getLatitude(), mLocation.getLongitude(), 1);

                    final String yourAddress = yourAddresses.get(0).getAddressLine(0);
                    if (yourAddresses != null && yourAddresses.size() > 0) {
                        Address address = yourAddresses.get(0);
                        @SuppressWarnings("MismatchedQueryAndUpdateOfStringBuilder") StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                            sb.append(address.getAddressLine(i)).append("\n");
                        }
                        city = address.getLocality();
                        state = address.getAdminArea();
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            //   bookaridefrom.setText(yourAddress);
                            pickup_book_a_ride_from.setText(yourAddress);
                            drop_book_a_ride_from.setText(yourAddress);
                            round_trip_book_a_ride_from.setText(yourAddress);

                            fromlatitude = Double.toString(mCenterLatLong.latitude);
                            fromlongitude = Double.toString(mCenterLatLong.longitude);
                        }
                    });
                } catch (Exception e) {

                }
            }
        }).start();
    }

    private void getAddressDropTo(final LatLng mCenterLatLong) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Location mLocation = new Location("");
                    mLocation.setLatitude(mCenterLatLong.latitude);
                    mLocation.setLongitude(mCenterLatLong.longitude);
                    Geocoder geocoder;
                    List<Address> yourAddresses;
                    geocoder = new Geocoder(getActivity(), Locale.getDefault());
                    yourAddresses = geocoder.getFromLocation(mLocation.getLatitude(), mLocation.getLongitude(), 1);

                    final String yourAddress = yourAddresses.get(0).getAddressLine(0);

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            //  bookarideto.setText(yourAddress);
                            drop_book_a_ride_to.setText(yourAddress);
                           // round_trip_book_a_ride_to.setText(yourAddress);
                            tolatitude = Double.toString(mCenterLatLong.latitude);
                            tolongitude = Double.toString(mCenterLatLong.longitude);

                            Log.d(TAG,"ToLat"+tolatitude+","+"ToLang"+tolongitude+","+"Adrs :"+yourAddress);
                        }
                    });
                } catch (Exception e) {

                }
            }
        }).start();
    }


    private void getAddressRoundTo(final LatLng mCenterLatLong) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Location mLocation = new Location("");
                    mLocation.setLatitude(mCenterLatLong.latitude);
                    mLocation.setLongitude(mCenterLatLong.longitude);
                    Geocoder geocoder;
                    List<Address> yourAddresses;
                    geocoder = new Geocoder(getActivity(), Locale.getDefault());
                    yourAddresses = geocoder.getFromLocation(mLocation.getLatitude(), mLocation.getLongitude(), 1);

                    final String yourAddress = yourAddresses.get(0).getAddressLine(0);

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            //  bookarideto.setText(yourAddress);
                          //  drop_book_a_ride_to.setText(yourAddress);
                            round_trip_book_a_ride_to.setText(yourAddress);
                            tolatitude = Double.toString(mCenterLatLong.latitude);
                            tolongitude = Double.toString(mCenterLatLong.longitude);

                            Log.d(TAG,"ToLat"+tolatitude+","+"ToLang"+tolongitude+","+"Adrs :"+yourAddress);
                        }
                    });
                } catch (Exception e) {

                }
            }
        }).start();
    }

    private void getDriversLocations() {


        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!exit)
                    try {
                        Thread.sleep(5000);
                        if (trakingLatitude == null && trackingLongitude == null) {

                            activity.runOnUiThread(new Runnable() {
                                public void run() {
                                    Toast.makeText(activity, "Getting locations..!", Toast.LENGTH_SHORT).show();
                                    getDeviceLocation();
                                }
                            });
                        } else {
                            locationRequest();
                        }

                    } catch (InterruptedException ignored) {

                    }
            }
        });

        t.start();

    }


    private void locationRequest() {

        Map<String, String> params = new HashMap<String, String>();

        if (fromlatitude == null && fromlongitude == null) {
            params.put("lat", Double.toString(trakingLatitude));
            params.put("lng", Double.toString(trackingLongitude));

        } else {
            params.put("lat", fromlatitude);
            params.put("lng", fromlongitude);
        }
        params.put("range", "2");

        asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_GET_NEAR_BY_DRIVERS, Url.PASSENGER_API + ServerApiNames.GET_NEAR_BY_DRIVERS, new JSONObject(params));

    }


    @Override
    public void onAttach(Context activity) { //todo Activity to context changed
        super.onAttach(activity);
        this.activity = (Activity) activity;
    }


    private void callPlaceAutocompleteActivityIntentTo(int requestcode) {
        try {
            Intent intent = new Intent(getActivity(), SearchPlaceActivity.class);
            intent.putExtra("Source", "to");
            intent.putExtra("latitude",fromlatitude);
            intent.putExtra("longitude",fromlongitude);
            startActivityForResult(intent, requestcode);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void callPlaceAutocompleteActivityIntentFrom(int requestcode) {

        try {

            Intent intent = new Intent(getActivity(), SearchPlaceActivity.class);
            intent.putExtra("Source", "from");
            intent.putExtra("latitude",fromlatitude);
            intent.putExtra("longitude",fromlongitude);
            startActivityForResult(intent, requestcode);

        } catch (Exception e) { //(GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
            // TODO: Handle the error.
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PLACE_PICKER_REQUEST_FROM) {
            if (data != null) {
                String toLat = data.getStringExtra("fromLat");
                String toLong = data.getStringExtra("fromLong");
                fromlatitude = toLat;
                fromlongitude = toLong;

                pickup_book_a_ride_from.setText(data.getStringExtra("fromAddress"));
               // drop_book_a_ride_from.setText(data.getStringExtra("fromAddress"));
               // round_trip_book_a_ride_from.setText(data.getStringExtra("fromAddress"));
                latLng = new LatLng(Double.parseDouble(toLat), Double.parseDouble(toLong));
                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));
                if(checkLocationPermission()){
                    mGoogleMap.setMyLocationEnabled(true);
                }
                marker_logo.setVisibility(View.VISIBLE);
                destination_marker_logo.setVisibility(View.GONE);
                locationRequest();
            }
        } else if (requestCode == PLACE_PICKER_REQUEST_TO) {

            if (data != null) {
                String toLat = data.getStringExtra("toLat");
                String toLong = data.getStringExtra("toLong");
                tolatitude = toLat;
                tolongitude = toLong;
                latLng = new LatLng(Double.parseDouble(toLat), Double.parseDouble(toLong));

                Log.d(TAG,"ToLat"+tolatitude+","+"ToLang"+tolongitude+","+"Adrs :"+data.getStringExtra("toAddress"));

                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));
                mGoogleMap.setMyLocationEnabled(false);

                marker_logo.setVisibility(View.GONE);
                destination_marker_logo.setVisibility(View.VISIBLE);

               // bookarideto.setText(data.getStringExtra("toAddress"));
                drop_book_a_ride_to.setText(data.getStringExtra("toAddress"));
                round_trip_book_a_ride_to.setText(data.getStringExtra("toAddress"));

            }

        }

        else if(requestCode==LOCATION_SETTINGS_REQUEST){

            if(resultCode==RESULT_OK) {

                Log.e("CameInLogin", "Login" + "activity");

                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);
                // getDeviceLocation();
            }
        }

        else if (requestCode == TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT) {
            pickedContact(data, requestCode);
        }else if(requestCode == PLACE_PICKER_REQUEST_DROP_FROM){
            Log.e(TAG,"PLACE_PICKER_REQUEST_DROP_FROM="+PLACE_PICKER_REQUEST_DROP_FROM);
            if (data != null) {
                String toLat = data.getStringExtra("fromLat");
                String toLong = data.getStringExtra("fromLong");
                fromlatitude = toLat;
                fromlongitude = toLong;
                latLng = new LatLng(Double.parseDouble(toLat), Double.parseDouble(toLong));

                Log.d(TAG,"FromLat"+fromlatitude+","+"FromLang"+fromlongitude+","+"Adrs :"+data.getStringExtra("toAddress"));

                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));
                if(checkLocationPermission()){
                    mGoogleMap.setMyLocationEnabled(false);
                }

                marker_logo.setVisibility(View.GONE);
                destination_marker_logo.setVisibility(View.VISIBLE);

                drop_book_a_ride_from.setText(data.getStringExtra("fromAddress"));


            }
        }else if(requestCode == PLACE_PICKER_REQUEST_DROP_TO){
            Log.e(TAG,"PLACE_PICKER_REQUEST_DROP_TO="+PLACE_PICKER_REQUEST_DROP_TO);
            if (data != null) {
                String toLat = data.getStringExtra("toLat");
                String toLong = data.getStringExtra("toLong");
                tolatitude = toLat;
                tolongitude = toLong;
                latLng = new LatLng(Double.parseDouble(toLat), Double.parseDouble(toLong));

                Log.d(TAG,"ToLat"+tolatitude+","+"ToLang"+tolongitude+","+"Adrs :"+data.getStringExtra("toAddress"));

                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));
                if(checkLocationPermission()){
                    mGoogleMap.setMyLocationEnabled(false);
                }

                marker_logo.setVisibility(View.GONE);
                destination_marker_logo.setVisibility(View.VISIBLE);

                drop_book_a_ride_to.setText(data.getStringExtra("toAddress"));


            }
        }else if(requestCode==PLACE_PICKER_REQUEST_ROUND_FROM){
            Log.e(TAG,"PLACE_PICKER_REQUEST_ROUND_FROM="+PLACE_PICKER_REQUEST_ROUND_FROM);
            if (data != null) {
                String toLat = data.getStringExtra("fromLat");
                String toLong = data.getStringExtra("fromLong");
                fromlatitude = toLat;
                fromlongitude = toLong;

                latLng = new LatLng(Double.parseDouble(toLat), Double.parseDouble(toLong));

                Log.d(TAG,"FromLat"+fromlatitude+","+"FromLang"+fromlongitude+","+"Adrs :"+data.getStringExtra("toAddress"));

                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));
                if(checkLocationPermission()){
                    mGoogleMap.setMyLocationEnabled(false);
                }

                marker_logo.setVisibility(View.GONE);
                destination_marker_logo.setVisibility(View.VISIBLE);

                round_trip_book_a_ride_from.setText(data.getStringExtra("fromAddress"));

            }
        }else if(requestCode==PLACE_PICKER_REQUEST_ROUND_TO){
            Log.e(TAG,"PLACE_PICKER_REQUEST_ROUND_TO="+PLACE_PICKER_REQUEST_ROUND_TO);
            if (data != null) {
                String toLat = data.getStringExtra("toLat");
                String toLong = data.getStringExtra("toLong");
                tolatitude = toLat;
                tolongitude = toLong;
                latLng = new LatLng(Double.parseDouble(toLat), Double.parseDouble(toLong));

                Log.d(TAG,"ToLat"+tolatitude+","+"ToLang"+tolongitude+","+"Adrs :"+data.getStringExtra("toAddress"));

                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));
                if(checkLocationPermission()){
                    mGoogleMap.setMyLocationEnabled(false);
                }

                marker_logo.setVisibility(View.GONE);
                destination_marker_logo.setVisibility(View.VISIBLE);

                round_trip_book_a_ride_to.setText(data.getStringExtra("toAddress"));

            }
        }


    }

    @Subscribe
    public void setLatLongFromFavorite(OttoSelectedFromFavorite ottoSelectedFromFavorite) {

        Double latitude = Double.parseDouble(ottoSelectedFromFavorite.getTolatitude());
        Double longitude = Double.parseDouble(ottoSelectedFromFavorite.getTolongitude());


        if ((ottoSelectedFromFavorite.getSetTo()).equals("from")) {

            fromlatitude = ottoSelectedFromFavorite.getTolatitude();
            fromlongitude = ottoSelectedFromFavorite.getTolongitude();

          //  bookaridefrom.setText(ottoSelectedFromFavorite.getAddress());

            pickup_book_a_ride_from.setText(ottoSelectedFromFavorite.getAddress());
            drop_book_a_ride_from.setText(ottoSelectedFromFavorite.getAddress());
            round_trip_book_a_ride_from.setText(ottoSelectedFromFavorite.getAddress());

            latLng = new LatLng(latitude, longitude);

            marker_logo.setVisibility(View.VISIBLE);
            destination_marker_logo.setVisibility(View.GONE);
            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));
            mGoogleMap.getUiSettings().setMyLocationButtonEnabled(true);

/*
            InputMethodManager in = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            in.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
*/


        } else {

           // bookarideto.setText(ottoSelectedFromFavorite.getAddress());


            // marker_logo.setVisibility(View.VISIBLE);
            // destination_marker_logo.setVisibility(View.VISIBLE);
            tolatitude = ottoSelectedFromFavorite.getTolatitude();
            tolongitude = ottoSelectedFromFavorite.getTolongitude();

            //  startLatitude = Double.parseDouble(fromlatitude);
            //  startLongitude = Double.parseDouble(fromlongitude);
            endLatitude = Double.parseDouble(ottoSelectedFromFavorite.getTolatitude());
            endLongitude = Double.parseDouble(ottoSelectedFromFavorite.getTolongitude());

            destinationLatLng = new LatLng(endLatitude, endLongitude);

            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(destinationLatLng));
            mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

            marker_logo.setVisibility(View.GONE);
            destination_marker_logo.setVisibility(View.VISIBLE);
            mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);

/*            InputMethodManager in = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            in.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);*/
        }
    }


    @Override
    public void onPause() {
        exit = true;
        super.onPause();
    }

    @Override
    public void onStart() {
        exit = false;
//        getDriversLocations();
        super.onStart();
    }

    @Subscribe
    public void repeatRide(OttoRepeatRide ottoRepeatRide) {

        //Utils.stopProgress(getActivity());

        //bookaridefrom.setText(ottoRepeatRide.getFrom());
        // bookarideto.setText(ottoRepeatRide.getTo());

        drop_book_a_ride_to.setText(ottoRepeatRide.getTo());
        round_trip_book_a_ride_to.setText(ottoRepeatRide.getTo());

        fromlatitude = ottoRepeatRide.getFromlatitude();
        fromlongitude = ottoRepeatRide.getFromlongitude();
        tolatitude = ottoRepeatRide.getTolatitude();
        tolongitude = ottoRepeatRide.getTolongitude();
        choose_vehicle_value = ottoRepeatRide.getVehicle_type();
        vehical_type_id = ottoRepeatRide.getVehicle_type_id();

        switch (choose_vehicle_value) {

            case "Deluxe":

                // rental.setBackgroundResource(R.drawable.rentals);
                imgDelux.setBackgroundResource(R.drawable.delux_selected);
                imgSedan.setBackgroundResource(R.drawable.unselected_sedan);
                // mini.setBackgroundResource(R.drawable.mini);
                imgLuxury.setBackgroundResource(R.drawable.unselect_super_luxury);
                imgSuperLuxury.setBackgroundResource(R.drawable.luxury_unselected);
                break;

            case "Sedan":

                imgDelux.setBackgroundResource(R.drawable.unselected_delux);
                imgSedan.setBackgroundResource(R.drawable.sedan_selected);
                // mini.setBackgroundResource(R.drawable.mini);
                imgLuxury.setBackgroundResource(R.drawable.unselect_super_luxury);
                imgSuperLuxury.setBackgroundResource(R.drawable.luxury_unselected);

                break;

            case "Luxury":

                imgDelux.setBackgroundResource(R.drawable.unselected_delux);
                imgSedan.setBackgroundResource(R.drawable.unselected_sedan);
                // mini.setBackgroundResource(R.drawable.mini);
                imgLuxury.setBackgroundResource(R.drawable.super_luxury_selected);
                imgSuperLuxury.setBackgroundResource(R.drawable.luxury_unselected);

                break;


            case "Taxi(6+1)":

                imgDelux.setBackgroundResource(R.drawable.unselected_delux);
                imgSedan.setBackgroundResource(R.drawable.unselected_sedan);
                // mini.setBackgroundResource(R.drawable.mini);
                imgLuxury.setBackgroundResource(R.drawable.unselect_super_luxury);
                imgSuperLuxury.setBackgroundResource(R.drawable.luxury_selected);

                break;

        }

    }

/*    private void nearbyVehicleServerCall() {

       // Utils.showProgress(getActivity());
        Map<String, String> params = new HashMap<String, String>();


        params.put("from_lat",  Double.toString(trakingLatitude)); //todo coming null first time
        params.put("from_long",  Double.toString(trackingLongitude));
        params.put("range", "10");

        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_VehiclesDistanceAndTime,Url.PASSENGER_API+ServerApiNames.vehiclesDistanceAndTime,new JSONObject(params));

    }*/

    @Override
    public void onClick(View v) {
        int checkedId = v.getId();

        switch (checkedId) {

            case R.id.book_a_delux:

                if(nearByDriversResponseModel!=null && !nearByDriversResponseModel.getUser().isEmpty()){

                    if(deluxTime.getText().toString().equalsIgnoreCase("NA")){
                        Utils.showToast(getActivity(),"No Deluxe available now, try again after sometime");
                    }else{
                        mGoogleMap.clear();
                        //  taxiText.setText("Deluxe");
                        deluxTime.setText(deluxTime.getText().toString());
                        choose_vehicle_value = "Deluxe";
                        vehical_type_id = "5";
                        deluxSelected=true;
                        imgDelux.setBackgroundResource(R.drawable.delux_selected);
                        imgSedan.setBackgroundResource(R.drawable.unselected_sedan);
                        // mini.setBackgroundResource(R.drawable.mini);
                        imgLuxury.setBackgroundResource(R.drawable.unselect_super_luxury);
                        imgSuperLuxury.setBackgroundResource(R.drawable.luxury_unselected);

                        for (int i = 0; i < nearByDriversResponseModel.getUser().size(); i++){

                            time = nearByDriversResponseModel.getUser().get(i).getTime();
                            double value1 = Double.parseDouble(nearByDriversResponseModel.getUser().get(i).getLat());
                            double value2 = Double.parseDouble(nearByDriversResponseModel.getUser().get(i).getLng());
                            int height = 100;
                            int width = 100;

                            LatLng latLngForNearLocation = new LatLng(value1, value2);

                            if (nearByDriversResponseModel.getUser().get(i).getVehicleTypeId()==5) {
                                bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.delux_top);
                                if (!time.equals("NA"))
                                    deluxTime.setText(time);

                                Bitmap b = bitmapdraw.getBitmap();
                                Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);

                                mk = mGoogleMap.addMarker(new MarkerOptions().position(latLngForNearLocation)
                                        .icon(BitmapDescriptorFactory.fromBitmap((smallMarker))));
                            }

                        }
                    }
                }
                else{
                    Toast.makeText(activity, "Getting vehicles please wait", Toast.LENGTH_SHORT).show();
                }


                break;

            case R.id.book_a_ride_sedan:

                if(nearByDriversResponseModel!=null && !nearByDriversResponseModel.getUser().isEmpty()){

                    if(sedanTime.getText().toString().equalsIgnoreCase("NA")){
                        Utils.showToast(getActivity(),"No Sedan available now, try again after sometime");
                    }else{
                        mGoogleMap.clear();
                        //  taxiText.setText("Sedan");
                        sedanTime.setText(sedanTime.getText().toString());
                        choose_vehicle_value = "Sedan";
                        vehical_type_id = "6";
                        deluxSelected=false;
                        imgDelux.setBackgroundResource(R.drawable.unselected_delux);
                        imgSedan.setBackgroundResource(R.drawable.sedan_selected);
                        // mini.setBackgroundResource(R.drawable.mini);
                        imgLuxury.setBackgroundResource(R.drawable.unselect_super_luxury);
                        imgSuperLuxury.setBackgroundResource(R.drawable.luxury_unselected);

                        for (int i = 0; i < nearByDriversResponseModel.getUser().size(); i++){

                            time = nearByDriversResponseModel.getUser().get(i).getTime();
                            double value1 = Double.parseDouble(nearByDriversResponseModel.getUser().get(i).getLat());
                            double value2 = Double.parseDouble(nearByDriversResponseModel.getUser().get(i).getLng());
                            int height = 100;
                            int width = 100;

                            LatLng latLngForNearLocation = new LatLng(value1, value2);

                            if (nearByDriversResponseModel.getUser().get(i).getVehicleTypeId()==6) {
                                bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.unselected_sedan);
                                if (!time.equals("NA"))
                                    sedanTime.setText(time);

                                Bitmap b = bitmapdraw.getBitmap();
                                Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);

                                mk = mGoogleMap.addMarker(new MarkerOptions().position(latLngForNearLocation)
                                        .icon(BitmapDescriptorFactory.fromBitmap((smallMarker))));
                            }

                        }

                    }

                }
                else{
                    Toast.makeText(activity, "Getting vehicles please wait", Toast.LENGTH_SHORT).show();
                }

                break;

            case R.id.book_a_ride_luxury:

                if(nearByDriversResponseModel!=null && !nearByDriversResponseModel.getUser().isEmpty()){

                    if(superLauryTime.getText().toString().equalsIgnoreCase("NA")){
                        Utils.showToast(getActivity(),"No Spr.Luxury available now, try again after sometime");
                    }else{
                        mGoogleMap.clear();
                        // taxiText.setText("Spr.Luxury");
                        superLauryTime.setText(superLauryTime.getText().toString());
                        choose_vehicle_value = "Luxury";
                        vehical_type_id = "8";
                        deluxSelected=false;
                        imgDelux.setBackgroundResource(R.drawable.unselected_delux);
                        imgSedan.setBackgroundResource(R.drawable.unselected_sedan);
                        // mini.setBackgroundResource(R.drawable.mini);
                        imgLuxury.setBackgroundResource(R.drawable.super_luxury_selected);
                        imgSuperLuxury.setBackgroundResource(R.drawable.luxury_unselected);

                        for (int i = 0; i < nearByDriversResponseModel.getUser().size(); i++){

                            time = nearByDriversResponseModel.getUser().get(i).getTime();
                            double value1 = Double.parseDouble(nearByDriversResponseModel.getUser().get(i).getLat());
                            double value2 = Double.parseDouble(nearByDriversResponseModel.getUser().get(i).getLng());
                            int height = 100;
                            int width = 100;

                            LatLng latLngForNearLocation = new LatLng(value1, value2);

                            if (nearByDriversResponseModel.getUser().get(i).getVehicleTypeId()==8) {
                                bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.luxury_unselected);
                                if (!time.equals("NA"))
                                    superLauryTime.setText(time);

                                Bitmap b = bitmapdraw.getBitmap();
                                Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);

                                mk = mGoogleMap.addMarker(new MarkerOptions().position(latLngForNearLocation)
                                        .icon(BitmapDescriptorFactory.fromBitmap((smallMarker))));
                            }

                        }
                    }
                }
                else{
                    Toast.makeText(activity, "Getting vehicles please wait", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.book_a_ride_super_luxury:



                if(nearByDriversResponseModel!=null && !nearByDriversResponseModel.getUser().isEmpty()){

                    if(luxuryTime.getText().toString().equalsIgnoreCase("NA")){
                        Utils.showToast(getActivity(),"No Luxury available now, try again after sometime");
                    }else{

                        mGoogleMap.clear();
                        //   taxiText.setText("Luxury");
                        luxuryTime.setText(luxuryTime.getText().toString());
                        choose_vehicle_value = "Taxi(6+1)";
                        vehical_type_id = "7";
                        deluxSelected=false;
                        imgDelux.setBackgroundResource(R.drawable.unselected_delux);
                        imgSedan.setBackgroundResource(R.drawable.unselected_sedan);
                        // mini.setBackgroundResource(R.drawable.mini);
                        imgLuxury.setBackgroundResource(R.drawable.unselect_super_luxury);
                        imgSuperLuxury.setBackgroundResource(R.drawable.luxury_selected);

                        for (int i = 0; i < nearByDriversResponseModel.getUser().size(); i++){

                            time = nearByDriversResponseModel.getUser().get(i).getTime();
                            double value1 = Double.parseDouble(nearByDriversResponseModel.getUser().get(i).getLat());
                            double value2 = Double.parseDouble(nearByDriversResponseModel.getUser().get(i).getLng());
                            int height = 100;
                            int width = 100;

                            LatLng latLngForNearLocation = new LatLng(value1, value2);

                            if (nearByDriversResponseModel.getUser().get(i).getVehicleTypeId()==7) {
                                bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.unselect_super_luxury);
                                if (!time.equals("NA"))
                                    luxuryTime.setText(time);

                                Bitmap b = bitmapdraw.getBitmap();
                                Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);

                                mk = mGoogleMap.addMarker(new MarkerOptions().position(latLngForNearLocation)
                                        .icon(BitmapDescriptorFactory.fromBitmap((smallMarker))));
                            }

                        }
                    }

                }
                else{
                    Toast.makeText(activity, "Getting vehicles please wait", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    @Subscribe
    public void ottoDialogBoxLogout(OttoDialogPersonalOther ottoDialogPersonalOther) {

        type = ottoDialogPersonalOther.getType();
        othermobile = ottoDialogPersonalOther.getMobile();
        othername = ottoDialogPersonalOther.getName();
        //   personal.setText(type);

    }

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(activity,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                //  TODO: Prompt with explanation!

                //Prompt the user once explanation has been shown
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);

            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay!
                    if (ActivityCompat.checkSelfPermission(getActivity(),
                            Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        mGoogleMap.setMyLocationEnabled(true);
                    }
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(getActivity(), "permission denied", Toast.LENGTH_LONG).show();
                }
                return;
            }

        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        if (pid == AppConstants.TAG_ID_GET_NEAR_BY_DRIVERS) {
            try {

                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    //  mGoogleMap.clear();
                    Gson gson = new Gson();
                    nearByDriversResponseModel = gson.fromJson(responseJson.toString(), NearByDriversResponseModel.class);

                    if(nearByDriversResponseModel!=null && !nearByDriversResponseModel.getUser().isEmpty()){
                        for (int i = 0; i < nearByDriversResponseModel.getUser().size(); i++){

                            time = nearByDriversResponseModel.getUser().get(i).getTime();

                            switch (nearByDriversResponseModel.getUser().get(i).getVehicleType()){

                                case  "Auto":
                                    if (!time.equals("NA"))
                                        rickshaw_expected_time.setText(time);
                                    break;

                            /*case  "Taxi(4+1)":
                                if (!time.equals("NA"))
                                    taxi_expected_time.setText(time);
                                break;*/

                                case  "Taxi(6+1)":
                                    if (!time.equals("NA"))
                                        suv_expected_time.setText(time);
                                    break;
                            }

                        }

                        if(deluxSelected)

                            for (int i = 0; i < nearByDriversResponseModel.getUser().size(); i++){

                                time = nearByDriversResponseModel.getUser().get(i).getTime();
                                double value1 = Double.parseDouble(nearByDriversResponseModel.getUser().get(i).getLat());
                                double value2 = Double.parseDouble(nearByDriversResponseModel.getUser().get(i).getLng());
                                int height = 100;
                                int width = 100;

                                LatLng latLngForNearLocation = new LatLng(value1, value2);

                                if (nearByDriversResponseModel.getUser().get(i).getVehicleTypeId()==5) {
                                    bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.car_top_view);
                                    if (!time.equals("NA"))
                                        deluxTime.setText(time);

                                    Bitmap b = bitmapdraw.getBitmap();
                                    Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);

                                    mk = mGoogleMap.addMarker(new MarkerOptions().position(latLngForNearLocation)
                                            .icon(BitmapDescriptorFactory.fromBitmap((smallMarker))));
                                }

                            }
                    }else{
                        deluxTime.setText("NA");
                        sedanTime.setText("NA");
                        superLauryTime.setText("NA");
                        luxuryTime.setText("NA");
                        nearByDriversResponseModel = null;
                    }

                } else {
                    String errorMsg = jObj.getString("error_msg");

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        else if (pid == AppConstants.distanceCalculateByLatLongNew) {

            Utils.stopProgress(getActivity());
            try {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                Toast.makeText(getActivity(),"vevhicle id="+vehical_type_id,Toast.LENGTH_LONG).show();
                if (!error) {

                    currency_symbol = jObj.getString("currency_symbol");

                    sessionManager.setCurrency(currency_symbol);

                    String distance = jObj.getString("distance");
                    String time = jObj.getString("time");

                    Bundle bundle = new Bundle();

                    bundle.putString("currency_symbol", currency_symbol);
                     if(isPickup){
                         bundle.putString("from", pickup_book_a_ride_from.getText().toString());
                         bundle.putString("to", pickup_book_a_ride_to.getText().toString());
                     }else if(isDrop){
                         bundle.putString("from", drop_book_a_ride_from.getText().toString());
                         bundle.putString("to", drop_book_a_ride_to.getText().toString());
                     }else if(isRoundTrip){
                         bundle.putString("from", round_trip_book_a_ride_from.getText().toString());
                         bundle.putString("to", round_trip_book_a_ride_to.getText().toString());
                     }

                    bundle.putString("distance", distance);
                    bundle.putString("fromlatitude", fromlatitude);
                    bundle.putString("fromlongitude", fromlongitude);
                    bundle.putString("tolatitude", tolatitude);
                    bundle.putString("tolongitude", tolongitude);
                    bundle.putString("when_required_value", when_required_value);
                    bundle.putString("when_required_type", when_required_type);
                    bundle.putString("comingFromCity", city);
                    bundle.putString("comingFromState", state);
                    bundle.putString("vehical_type_id", vehical_type_id);

                    bundle.putString("bookingForType", type);
                    bundle.putString("othermobile", othermobile);
                    bundle.putString("othername", othername);

                    bundle.putString("toll_charge", jObj.getString("toll_charge"));
                    bundle.putString("toll_names", jObj.getString("toll_names"));

                    FragmentBooking2 nextFragment = new FragmentBooking2();
                    // FragmentManager fragmentManager = getActivity().getSupportFragmentManager();

                    FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();

                    String prime_rate = jObj.getString("meter_value");
                    String tax_amount_prime = jObj.getString("tax_amount");
                    String service_charge_prime = jObj.getString("service_charge");
                    String total_amount_prime = jObj.getString("total_amount");
                    String minimum_fare_prime = jObj.getString("minimum_fare");
                    String per_km_prime = jObj.getString("per_km");
                    String min_dist_prime = jObj.getString("min_dist");

                    bundle.putString("vehicle_type", choose_vehicle_value);
                    bundle.putString("rate", prime_rate);
                    bundle.putString("minimum_fare", minimum_fare_prime);
                    bundle.putString("per_km", per_km_prime);
                    bundle.putString("total_rate", total_amount_prime);
                    bundle.putString("dyutBalance", jObj.getString("DYUT_balance"));

                    bundle.putString("meter_sgst", jObj.getString("meter_sgst"));
                    bundle.putString("meter_cgst", jObj.getString("meter_cgst"));
                    bundle.putString("meter_igst", jObj.getString("meter_igst"));
                    bundle.putString("service_charge", jObj.getString("service_charge"));
                    bundle.putString("insurance_amount_val", jObj.getString("insurance_amount_val"));
                    bundle.putString("insurance_sgst_val", jObj.getString("insurance_sgst_val"));
                    bundle.putString("insurance_cgst_val", jObj.getString("insurance_cgst_val"));
                    bundle.putString("insurance_igst_val", jObj.getString("insurance_igst_val"));

                    /*Below parameters for airport booking*/

                        bundle.putString("airport_booking_type", jObj.getString("airport_booking_type"));
                        String passengerCount="0";
                        try{
                            passengerCount=tv_passanger_count.getText().toString();
                        }catch (Exception e){
                            e.printStackTrace();
                        }

                        bundle.putString("no_of_passengers",passengerCount);

                        bundle.putString("round_trip", jObj.getString("round_trip"));
                        bundle.putString("bag_charges", jObj.getString("bag_charges"));
                        bundle.putString("no_of_luggages", jObj.getString("no_of_luggages"));
                        bundle.putString("airport_waiting_time_charges", jObj.getString("airport_waiting_time_charges"));
                        bundle.putString("airport_drop_charges", jObj.getString("airport_drop_charges"));
                        bundle.putString("airport_pickup_charges", jObj.getString("airport_pickup_charges"));
                        bundle.putString("picup_airport_name", jObj.getString("picup_airport_name"));
                        bundle.putString("drop_airport_name", jObj.getString("drop_airport_name"));
                        bundle.putString("parking_charge", jObj.getString("parking_charge"));
                        bundle.putString("waiting_charge_per_minute", jObj.getString("waiting_charge_per_minute"));
                        bundle.putString("bag_type", "NORMAL");



                    nextFragment.setArguments(bundle);

                    transaction.replace(R.id.content_frame, nextFragment);
                    transaction.addToBackStack(null);

                    transaction.commit();
                    //  fragmentManager.beginTransaction().replace(R.id.content_frame, nextFragment).commit();

                } else {
                    String errorMsg = jObj.getString("error_msg");
                    androidx.appcompat.app.AlertDialog.Builder builder1 = new androidx.appcompat.app.AlertDialog.Builder(getContext(), R.style.MyDialogTheme);
                    builder1.setMessage(errorMsg);
                    builder1.setCancelable(true);
                    builder1.setTitle("Alert !");

                    builder1.setPositiveButton(
                            "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });

                    androidx.appcompat.app.AlertDialog mDialog = builder1.create();
                    mDialog.show();
                    //Todo needs to clear all the selected view in vehicles
                    //choose_vehicle.clearCheck();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        deluxTime.setText("NA");
        sedanTime.setText("NA");
        superLauryTime.setText("NA");
        luxuryTime.setText("NA");
        nearByDriversResponseModel = null;

        Utils.showToast(getActivity(),error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }

    void askGpsPermission() {
        //location request
        LocationRequest mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(1 * 1000)
                .setFastestInterval(1 * 1000);

        //location setting request

        LocationSettingsRequest.Builder settingsBuilder = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest);
        settingsBuilder.setAlwaysShow(true);

        //location setting response task

        Task<LocationSettingsResponse> result = LocationServices.getSettingsClient(activity)
                .checkLocationSettings(settingsBuilder.build());

        //Add a OnCompleteListener to get the result from the Task

        result.addOnCompleteListener(new OnCompleteListener<LocationSettingsResponse>() {
            @Override
            public void onComplete(@NonNull Task<LocationSettingsResponse> task) {
                try {
                    LocationSettingsResponse response = task.getResult(ApiException.class);
                    response.getLocationSettingsStates();

                } catch (ApiException ex) {
                    switch (ex.getStatusCode()) {
                        case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                            try {
                                ResolvableApiException resolvableApiException = (ResolvableApiException) ex;
                                resolvableApiException.startResolutionForResult(activity, LOCATION_SETTINGS_REQUEST);
                            } catch (IntentSender.SendIntentException e) {

                            }
                            break;
                        case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:


                            break;
                    }
                }
            }
        });

    }

}