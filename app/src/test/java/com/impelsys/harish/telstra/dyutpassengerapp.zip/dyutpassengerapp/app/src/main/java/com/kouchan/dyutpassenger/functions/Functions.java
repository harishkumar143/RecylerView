package com.kouchan.dyutpassenger.functions;

import androidx.appcompat.app.AppCompatActivity;

import com.kouchan.dyutpassenger.Database.SessionManager;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by KOUCHAN-ADMIN on 12/5/2016.
 */

public class Functions {
    public static boolean isEmailValid(String email) {
        boolean isValid = false;

        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isMobileValid(String mobile) {
        boolean isValid = false;

        if (mobile.length() == 10) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isPasswordValid(String password, String confirmPassword) {
        boolean isValid = false;

        if (password.length() > 6 && password.equals(confirmPassword)) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isEmpty(String value) {
        boolean isValid = false;

        if (!value.isEmpty()) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isVehicleTypeValid(String value) {
        boolean isValid = false;
        if (!value.isEmpty() && (value.equalsIgnoreCase("Taxi") || value.equalsIgnoreCase("Auto") || value.equalsIgnoreCase("Bike") || value.equalsIgnoreCase("Private Car"))) {
            isValid = true;
        }
        return isValid;
    }

    public static void setTitleAsPerUser(SessionManager sessionManager, AppCompatActivity appCompatActivity) {
        HashMap<String, String> user = sessionManager.getUserDetails();

        String stringName = user.get(sessionManager.KEY_NAME);

        appCompatActivity.setTitle("Welcome , " + stringName);
    }

    public static String getMobileAsPerUser(SessionManager sessionManager, AppCompatActivity appCompatActivity) {
        HashMap<String, String> user = sessionManager.getUserDetails();

        return user.get(sessionManager.KEY_MOBILE);
    }

    //String whichInfo cant have two values either "mobile" or "name"
    public static String getSessionInformation(SessionManager sessionManager, String whichInfo) {
        HashMap<String, String> user = sessionManager.getUserDetails();
        String sessionDetail;

        if (whichInfo.equals("mobile")) {
            sessionDetail = user.get(sessionManager.KEY_MOBILE);
        } else {
            sessionDetail = user.get(sessionManager.KEY_NAME);
        }

        return sessionDetail;
    }

    public static boolean isFromToSelected(String fromlatitude, String fromlongitude, String tolatitude, String tolongitude) {
        boolean isValid = false;
        if (!(fromlatitude == null) && !(tolatitude == null)/* && !fromlongitude.isEmpty()&& !tolatitude.isEmpty()&& !tolongitude.isEmpty()*/) {
            isValid = true;
        }
        return isValid;
    }


    public static boolean isAllBookingFieldSelected(String choose_vehicle_value, String when_required_value, String string_type_of_rate, String type_of_rate_value,
                                                    String fromlatitude, String tolatitude) {
        boolean isValid = false;
        if (!(fromlatitude == null) && !(tolatitude == null) && !(choose_vehicle_value == null) && !(when_required_value == null) && !(string_type_of_rate == null) && !(type_of_rate_value == null)) {
            isValid = true;
        }
        return isValid;
    }


    public static boolean isNumberSame(String mobile, String alternatemobile) {
        boolean isValid = true;

        if (mobile.equals(alternatemobile)) {
            isValid = false;
        }
        return isValid;
    }

    public static boolean isConfirmPasswordSame(String password, String confirmPassword) {
        boolean isValid = false;

        if (password.equals(confirmPassword)) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isMeterTypeAndRateSelected(String string_type_of_rate, String type_of_rate_value) {
        boolean isValid = false;
        if (!(string_type_of_rate == null) && !(type_of_rate_value == null)) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isMeterRateSelected(String type_of_rate_value) {
        boolean isValid = false;
        if (!(type_of_rate_value == null)) {
            isValid = true;
        }
        return isValid;
    }
}
