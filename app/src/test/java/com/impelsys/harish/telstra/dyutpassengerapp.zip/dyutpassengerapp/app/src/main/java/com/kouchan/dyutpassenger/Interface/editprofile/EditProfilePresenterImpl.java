package com.kouchan.dyutpassenger.Interface.editprofile;

import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.View.Activities.EditProfileActivity;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class EditProfilePresenterImpl implements IEditProfilePresnter,OnRequestListener {

    EditProfileActivity navHome;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IEditProfileView getProfileView;

    public EditProfilePresenterImpl(IEditProfileView getProfileView) {
        this.navHome = (EditProfileActivity) getProfileView ;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(navHome);
        this.asyncInteractor = new AsyncInteractor(navHome);
        this.getProfileView = getProfileView;
    }

    @Override
    public void editProfile(String mobileNo, String name, String email,String emergency_contact_name,String emergency_contact_mobile) {
        if(NetworkStatus.checkNetworkStatus(navHome)){
            Utils.showProgress(navHome);
            Map<String, String> params = new HashMap<String, String>();
            params.put("mobile",mobileNo);
            params.put("name",name);
            params.put("email",email);
            params.put("emergency_contact_name",emergency_contact_name);
            params.put("emergency_contact_mobile",emergency_contact_mobile);

            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_EDITPROFILE, Url.PASSENGER_API+"editProfileOfPassenger.php",new JSONObject(params));
        } else {
            Utils.showToast(navHome, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if(pid==AppConstants.TAG_ID_EDITPROFILE){
            Utils.stopProgress(navHome);
            if(responseJson!=null){
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if(!error) {
                    getProfileView.editProfileSuccess(pid,jObj.getString("message"));
                }
                else {
                    getProfileView.editProfileError(pid,jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        getProfileView.editProfileError(pid,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        getProfileView.editProfileError(pid,error);
    }
}
