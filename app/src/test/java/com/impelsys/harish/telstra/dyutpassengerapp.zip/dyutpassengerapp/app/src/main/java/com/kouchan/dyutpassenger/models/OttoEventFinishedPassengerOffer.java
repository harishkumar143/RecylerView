package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 3/13/2018.
 */

public class OttoEventFinishedPassengerOffer {

    String finishTimer;

    public OttoEventFinishedPassengerOffer(String finishTimer) {
        this.finishTimer = finishTimer;
    }

    public String getFinishTimer() {
        return finishTimer;
    }
}
