package com.kouchan.dyutpassenger.View.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kouchan.dyutpassenger.R;

public class DeclarationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_declaration);
    }
}
