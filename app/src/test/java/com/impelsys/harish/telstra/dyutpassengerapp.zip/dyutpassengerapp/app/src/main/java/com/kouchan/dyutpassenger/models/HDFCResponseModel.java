package com.kouchan.dyutpassenger.models;

import com.google.gson.annotations.SerializedName;

public class HDFCResponseModel {


    /**
     * id : 403993715520163339
     * mode : CC
     * status : success
     * unmappedstatus : captured
     * key : 7rnFly
     * txnid : 2f9da4475697af65f1a8
     * transaction_fee : 10.00
     * amount : 10.00
     * cardCategory : domestic
     * discount : 0.00
     * addedon : 2019-11-26 11:27:05
     * productinfo : DYUT
     * firstname : Gulab Rathod
     * email : gulabrathod12@gmail.com
     * phone : 8971599295
     * udf1 : udf1
     * udf2 : udf2
     * udf3 : udf3
     * udf4 : udf4
     * udf5 : udf5
     * hash : ab820f84ebe8c9bf76843806521adaa9784039ad04a57bde18b979c7e343bf1c66e6ef6e60e76d963840807e0ff6d7466ad3d804930c90ad3be263cd7ed83ee6
     * field1 : 933010000291
     * field2 : 000000
     * field3 : 201933075945984
     * field4 : 700201933024030257
     * field5 : 05
     * field7 : AUTHPOSITIVE
     * payment_source : payu
     * PG_TYPE : HDFCPG
     * bank_ref_no : 201933075945984
     * ibibo_code : CC
     * error_code : E000
     * Error_Message : No Error
     * name_on_card : PayuUser
     * card_no : 401200XXXXXX1112
     * is_seamless : 1
     * surl : https://payuresponse.firebaseapp.com/success
     * furl : https://payuresponse.firebaseapp.com/failure
     */

    @SerializedName("id")
    private long mId;
    @SerializedName("mode")
    private String mMode;
    @SerializedName("status")
    private String mStatus;
    @SerializedName("unmappedstatus")
    private String mUnmappedstatus;
    @SerializedName("key")
    private String mKey;
    @SerializedName("txnid")
    private String mTxnid;
    @SerializedName("transaction_fee")
    private String mTransactionFee;
    @SerializedName("amount")
    private String mAmount;
    @SerializedName("cardCategory")
    private String mCardCategory;
    @SerializedName("discount")
    private String mDiscount;
    @SerializedName("addedon")
    private String mAddedon;
    @SerializedName("productinfo")
    private String mProductinfo;
    @SerializedName("firstname")
    private String mFirstname;
    @SerializedName("email")
    private String mEmail;
    @SerializedName("phone")
    private String mPhone;
    @SerializedName("udf1")
    private String mUdf1;
    @SerializedName("udf2")
    private String mUdf2;
    @SerializedName("udf3")
    private String mUdf3;
    @SerializedName("udf4")
    private String mUdf4;
    @SerializedName("udf5")
    private String mUdf5;
    @SerializedName("hash")
    private String mHash;
    @SerializedName("field1")
    private String mField1;
    @SerializedName("field2")
    private String mField2;
    @SerializedName("field3")
    private String mField3;
    @SerializedName("field4")
    private String mField4;
    @SerializedName("field5")
    private String mField5;
    @SerializedName("field7")
    private String mField7;
    @SerializedName("payment_source")
    private String mPaymentSource;
    @SerializedName("PG_TYPE")
    private String mPGTYPE;
    @SerializedName("bank_ref_no")
    private String mBankRefNo;
    @SerializedName("ibibo_code")
    private String mIbiboCode;
    @SerializedName("error_code")
    private String mErrorCode;
    @SerializedName("Error_Message")
    private String mErrorMessage;
    @SerializedName("name_on_card")
    private String mNameOnCard;
    @SerializedName("card_no")
    private String mCardNo;
    @SerializedName("is_seamless")
    private int mIsSeamless;
    @SerializedName("surl")
    private String mSurl;
    @SerializedName("furl")
    private String mFurl;

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public String getMode() {
        return mMode;
    }

    public void setMode(String mode) {
        mMode = mode;
    }

    public String getStatus() {
        return mStatus;
    }

    public void setStatus(String status) {
        mStatus = status;
    }

    public String getUnmappedstatus() {
        return mUnmappedstatus;
    }

    public void setUnmappedstatus(String unmappedstatus) {
        mUnmappedstatus = unmappedstatus;
    }

    public String getKey() {
        return mKey;
    }

    public void setKey(String key) {
        mKey = key;
    }

    public String getTxnid() {
        return mTxnid;
    }

    public void setTxnid(String txnid) {
        mTxnid = txnid;
    }

    public String getTransactionFee() {
        return mTransactionFee;
    }

    public void setTransactionFee(String transactionFee) {
        mTransactionFee = transactionFee;
    }

    public String getAmount() {
        return mAmount;
    }

    public void setAmount(String amount) {
        mAmount = amount;
    }

    public String getCardCategory() {
        return mCardCategory;
    }

    public void setCardCategory(String cardCategory) {
        mCardCategory = cardCategory;
    }

    public String getDiscount() {
        return mDiscount;
    }

    public void setDiscount(String discount) {
        mDiscount = discount;
    }

    public String getAddedon() {
        return mAddedon;
    }

    public void setAddedon(String addedon) {
        mAddedon = addedon;
    }

    public String getProductinfo() {
        return mProductinfo;
    }

    public void setProductinfo(String productinfo) {
        mProductinfo = productinfo;
    }

    public String getFirstname() {
        return mFirstname;
    }

    public void setFirstname(String firstname) {
        mFirstname = firstname;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public String getPhone() {
        return mPhone;
    }

    public void setPhone(String phone) {
        mPhone = phone;
    }

    public String getUdf1() {
        return mUdf1;
    }

    public void setUdf1(String udf1) {
        mUdf1 = udf1;
    }

    public String getUdf2() {
        return mUdf2;
    }

    public void setUdf2(String udf2) {
        mUdf2 = udf2;
    }

    public String getUdf3() {
        return mUdf3;
    }

    public void setUdf3(String udf3) {
        mUdf3 = udf3;
    }

    public String getUdf4() {
        return mUdf4;
    }

    public void setUdf4(String udf4) {
        mUdf4 = udf4;
    }

    public String getUdf5() {
        return mUdf5;
    }

    public void setUdf5(String udf5) {
        mUdf5 = udf5;
    }

    public String getHash() {
        return mHash;
    }

    public void setHash(String hash) {
        mHash = hash;
    }

    public String getField1() {
        return mField1;
    }

    public void setField1(String field1) {
        mField1 = field1;
    }

    public String getField2() {
        return mField2;
    }

    public void setField2(String field2) {
        mField2 = field2;
    }

    public String getField3() {
        return mField3;
    }

    public void setField3(String field3) {
        mField3 = field3;
    }

    public String getField4() {
        return mField4;
    }

    public void setField4(String field4) {
        mField4 = field4;
    }

    public String getField5() {
        return mField5;
    }

    public void setField5(String field5) {
        mField5 = field5;
    }

    public String getField7() {
        return mField7;
    }

    public void setField7(String field7) {
        mField7 = field7;
    }

    public String getPaymentSource() {
        return mPaymentSource;
    }

    public void setPaymentSource(String paymentSource) {
        mPaymentSource = paymentSource;
    }

    public String getPGTYPE() {
        return mPGTYPE;
    }

    public void setPGTYPE(String pGTYPE) {
        mPGTYPE = pGTYPE;
    }

    public String getBankRefNo() {
        return mBankRefNo;
    }

    public void setBankRefNo(String bankRefNo) {
        mBankRefNo = bankRefNo;
    }

    public String getIbiboCode() {
        return mIbiboCode;
    }

    public void setIbiboCode(String ibiboCode) {
        mIbiboCode = ibiboCode;
    }

    public String getErrorCode() {
        return mErrorCode;
    }

    public void setErrorCode(String errorCode) {
        mErrorCode = errorCode;
    }

    public String getErrorMessage() {
        return mErrorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        mErrorMessage = errorMessage;
    }

    public String getNameOnCard() {
        return mNameOnCard;
    }

    public void setNameOnCard(String nameOnCard) {
        mNameOnCard = nameOnCard;
    }

    public String getCardNo() {
        return mCardNo;
    }

    public void setCardNo(String cardNo) {
        mCardNo = cardNo;
    }

    public int getIsSeamless() {
        return mIsSeamless;
    }

    public void setIsSeamless(int isSeamless) {
        mIsSeamless = isSeamless;
    }

    public String getSurl() {
        return mSurl;
    }

    public void setSurl(String surl) {
        mSurl = surl;
    }

    public String getFurl() {
        return mFurl;
    }

    public void setFurl(String furl) {
        mFurl = furl;
    }
}
