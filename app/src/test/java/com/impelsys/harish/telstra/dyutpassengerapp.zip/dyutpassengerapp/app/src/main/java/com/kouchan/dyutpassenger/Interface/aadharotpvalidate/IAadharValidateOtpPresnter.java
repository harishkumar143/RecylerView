package com.kouchan.dyutpassenger.Interface.aadharotpvalidate;

public interface IAadharValidateOtpPresnter {

    void validateAadhatOtp( String mobile, String password, String adharnumber);
    
}
