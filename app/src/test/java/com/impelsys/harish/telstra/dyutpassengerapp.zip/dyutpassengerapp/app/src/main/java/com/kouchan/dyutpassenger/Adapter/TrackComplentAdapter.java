package com.kouchan.dyutpassenger.Adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.holders.TrackCOmplentHolder;
import com.kouchan.dyutpassenger.models.ComplentsModel;

import java.util.ArrayList;
import java.util.List;


public class TrackComplentAdapter extends RecyclerView.Adapter<TrackCOmplentHolder> {

    Context context;
    List<ComplentsModel> complentList = new ArrayList();

    public TrackComplentAdapter(Context context, List complentList) {
        this.context = context;
        this.complentList = complentList;
    }


    @NonNull
    @Override
    public TrackCOmplentHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.track_complent_item, viewGroup, false);
        return new TrackCOmplentHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TrackCOmplentHolder holder, int i) {
        holder.complentId.setText(complentList.get(i).getComplaint_id());
        holder.bookingId.setText(complentList.get(i).getBooking_id());
        holder.complentType.setText(complentList.get(i).getComplaint_type());
        holder.comments.setText(complentList.get(i).getComments());
        holder.status.setText(complentList.get(i).getStatus());

    }

    @Override
    public int getItemCount() {
        return complentList.size();
    }
}
