package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Adapter.SecurityAndSettingsAdapter;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SecurityAndSettingsActivity extends AppCompatActivity {

    @BindView(R.id.securityAndSettingsToolbar)
    Toolbar mToolbar;

    ArrayList<String> securityAndSettingsArrayList = new ArrayList<>();

    @BindView(R.id.securityAndSettingsRecyclerView)
    RecyclerView mSecurityAndSettingsRecyclerView;

    @BindView(R.id.securityAndSettingActivityBackImageView)
    ImageView securityAndSettingActivityBackImageView;

    TextView security_and_settings_textView;
    String languageCode;
    Resources resources;

    SessionManager sessionManager;

    SecurityAndSettingsAdapter mSecurityAndSettingsAdapter;

    String changePas, changeLan, terms, policy, fraud;
    int[] imagesForSecurityAndSettings = {R.drawable.change_password, R.drawable.change_langauage, R.drawable.terms_and_condition, R.drawable.privacy_policy, R.drawable.fraud};

    String[] values;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security_and_settings);
        ButterKnife.bind(this);

        security_and_settings_textView = (TextView) findViewById(R.id.security_and_settings_textView);



        initializeViews();

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }


    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        security_and_settings_textView.setText(resources.getString(R.string.security_and_settings));
        settingUpListOfSecurityAndSettingsOfM3();
    }


    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        securityAndSettingActivityBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SecurityAndSettingsActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });

     /*   if (Utils.appCode != null) {
            languageCode = Utils.appCode.toString();
            updateViews(languageCode);
        }*//*
        preparingListOfSecurityAndSettingsOfM3();*/

    }

    /*private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();*/
        /*changePas ="r";
        changeLan =resources.getString(R.string.ssChangeLan);
        terms =resources.getString(R.string.ssTerms);
        policy =resources.getString(R.string.ssPrivacy);
         fraud =resources.getString(R.string.ssFraud);*/
   /* }
*/
    /*private void preparingListOfSecurityAndSettingsOfM3() {
        securityAndSettingsArrayList.add("Change Password");
        securityAndSettingsArrayList.add("Change Language");
        securityAndSettingsArrayList.add("Terms and Conditions");
        securityAndSettingsArrayList.add("Policy");
        securityAndSettingsArrayList.add("Fraud");
    }*/

    private void settingUpListOfSecurityAndSettingsOfM3() {

        values=resources.getStringArray(R.array.security_and_settings_item);

        mSecurityAndSettingsAdapter = new SecurityAndSettingsAdapter(SecurityAndSettingsActivity.this, values, imagesForSecurityAndSettings);
        mSecurityAndSettingsRecyclerView.setHasFixedSize(true);

        mSecurityAndSettingsRecyclerView.setLayoutManager(new LinearLayoutManager(SecurityAndSettingsActivity.this));
           /*for animation*/
        mSecurityAndSettingsRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mSecurityAndSettingsRecyclerView.setAdapter(mSecurityAndSettingsAdapter);
    }


}
