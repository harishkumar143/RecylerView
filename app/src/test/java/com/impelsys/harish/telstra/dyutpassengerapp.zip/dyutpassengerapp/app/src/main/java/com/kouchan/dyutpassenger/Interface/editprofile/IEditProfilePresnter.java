package com.kouchan.dyutpassenger.Interface.editprofile;

public interface IEditProfilePresnter {

    void editProfile(String mobileNumber, String name, String email,String emergancyContactMobile,String emergancyContactName);

}
