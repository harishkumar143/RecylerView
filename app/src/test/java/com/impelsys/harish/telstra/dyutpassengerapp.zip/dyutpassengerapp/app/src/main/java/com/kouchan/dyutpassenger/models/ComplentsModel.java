package com.kouchan.dyutpassenger.models;

public class ComplentsModel {

    String complaint_id, booking_id, complaint_type, comments, status;

    public ComplentsModel(String complaint_id, String booking_id, String complaint_type, String comments, String status) {

        this.complaint_id = complaint_id;
        this.booking_id = booking_id;
        this.complaint_type = complaint_type;
        this.comments = comments;
        this.status = status;
    }

    public String getComplaint_id() {
        return complaint_id;
    }

    public String getBooking_id() {
        return booking_id;
    }

    public String getComplaint_type() {
        return complaint_type;
    }

    public String getComments() {
        return comments;
    }

    public String getStatus() {
        return status;
    }
}
