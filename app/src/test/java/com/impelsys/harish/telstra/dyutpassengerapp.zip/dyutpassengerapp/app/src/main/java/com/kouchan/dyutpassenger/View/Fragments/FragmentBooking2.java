package com.kouchan.dyutpassenger.View.Fragments;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.ContactsContract;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.DirectionsJSONParser;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.NavHome;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.functions.Functions;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.OttoAllDriversRejected;
import com.kouchan.dyutpassenger.paytm.AddMoneyToDyutAccActivity;
import com.kouchan.dyutpassenger.places.api.ApiListener;
import com.kouchan.dyutpassenger.places.api.ErrorModel;
import com.kouchan.dyutpassenger.places.api.NetworkClient;
import com.kouchan.dyutpassenger.places.models.DirectionResponseModel;
import com.kouchan.dyutpassenger.places.models.RouteDecode;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;
import com.squareup.otto.Subscribe;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FragmentBooking2 extends Fragment implements OnMapReadyCallback, OnRequestListener {

    public Button yes, no;
    String from, to, distance, fromlatitude, fromlongitude, tolatitude, tolongitude, vehicle_type, vehical_type_id, rate,
            minimum_fare, per_km, when_required_value, when_required_type, total_fare, paymentType, dyutBal;
    TextView book_a_ride_from, book_a_ride_to, type_of_meter_textView,
            selected_vehicle_type_of_meter_textView;
    AsyncInteractor asyncInteractor;
    String type, othermobile, othername, toolCharge, toolName;
    CountDownTimer countDownTimer;
    int i = 0;
    int j = 0;
    String status;
    SessionManager sessionManager;
    String bookingid, message;
    RadioGroup rideForRadioGroup, paymentModeRadioGroup;
    RadioButton selfRadioButton, otherRadioButton, cashRadioButton, m3RadioButton;
    SupportMapFragment mapFrag;
    Button personal, otherBooking;
    String rupees_symbol;
    private ImageView infoImagePerMeter,selected_vehicle_type_of_meter,booking_fragment2_back;

    private RadioGroup type_of_rate;
    private RadioButton fixed_amount,ride_per_meter,meter_plus_extra,meter_minus_extra;

    private EditText edit_fixed_amount,edit_per_meter,edit_meter_plus,edit_meter_less;

    private TextView finding_nearest_textView, walletBal, vehicleType;
    private TextView driver_response_textView, paymentModeText, taxInfoText;
    private ProgressBar passenger_offer_progressbar;
    private Button cancel_ride_request_button, book_a_ride_submit_button, addMoneyButton,retry_ride_request_button;
    private String languageCode;
    private Resources resources;
    private String type_of_rate_value;
    private String meter_value;
    private String string_type_of_rate;
    private View view;
    private LinearLayout linearLayout_background_blur, paymentModeLinearLayout;
    private LinearLayout linearLayout_retry_cancel_buttons;
    private String displayRateInISymbol;
    private String currency_symbol, city, state, meter_sgst, meter_cgst, meter_igst, service_charge, insurance_amount_val, insurance_sgst_val, insurance_cgst_val, insurance_igst_val;
    private CountDownTimer waitingTimerRideRequest;
    private int range_count;
    private GoogleMap mGoogleMap;
    private boolean apikey = true;
    List<Polyline> polylineList;
    private Marker mCurrLocationMarker,mDestinationMarker;
    double distanceFromMap = 0;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
        view = inflater.inflate(R.layout.fragment_booking_2, container, false);

        sessionManager = new SessionManager(getActivity());
        asyncInteractor = new AsyncInteractor(getActivity());


        rupees_symbol = getString(R.string.rupee_symbol);

        currency_symbol = this.getArguments().getString("currency_symbol");
        from = this.getArguments().getString("from");
        to = this.getArguments().getString("to");
        distance = this.getArguments().getString("distance");
        fromlatitude = this.getArguments().getString("fromlatitude");
        fromlongitude = this.getArguments().getString("fromlongitude");
        tolatitude = this.getArguments().getString("tolatitude");
        tolongitude = this.getArguments().getString("tolongitude");
        vehicle_type = this.getArguments().getString("vehicle_type");
        vehical_type_id = this.getArguments().getString("vehical_type_id");
        rate = this.getArguments().getString("rate");
        minimum_fare = this.getArguments().getString("minimum_fare");
        total_fare = this.getArguments().getString("total_rate");
        dyutBal = this.getArguments().getString("dyutBalance");
        per_km = this.getArguments().getString("per_km");
        when_required_value = this.getArguments().getString("when_required_value");
        when_required_type = this.getArguments().getString("when_required_type");
        city = this.getArguments().getString("comingFromCity");
        state = this.getArguments().getString("comingFromState");

        type = this.getArguments().getString("bookingForType");
        othermobile = this.getArguments().getString("othermobile");
        othername = this.getArguments().getString("othername");
        toolCharge = this.getArguments().getString("toll_charge");
        toolName = this.getArguments().getString("toll_names");

        meter_sgst = this.getArguments().getString("meter_sgst");
        meter_cgst = this.getArguments().getString("meter_cgst");
        meter_igst = this.getArguments().getString("meter_igst");
        service_charge = this.getArguments().getString("service_charge");
        insurance_amount_val = this.getArguments().getString("insurance_amount_val");
        insurance_sgst_val = this.getArguments().getString("insurance_sgst_val");
        insurance_cgst_val = this.getArguments().getString("insurance_cgst_val");
        insurance_igst_val = this.getArguments().getString("insurance_igst_val");


        initializeWidget();
        checkVehicleType();
        // vehicleType.setText(vehicle_type);
        ride_per_meter.setChecked(true);
        ride_per_meter.setBackgroundResource(R.drawable.curved_shape_light_colour);

        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
        meter_value = rate;
        type_of_rate_value = "0";
        string_type_of_rate = "Permeter";

        typeOfMeter();
        infoImageValues();
        m3RadioButton.setChecked(true);
        if (m3RadioButton.isChecked()) {
            paymentType = "DYUT";
        }
        book_a_ride_from.setText(from);
        book_a_ride_to.setText(to);
        edit_per_meter.setText(total_fare);

        radioGroupOoperation();
        status = "searching";
        range_count = 1;

        EventBusManager.getInstance().getEventBus().register(this);

        if (dyutBal != null) {
            walletBal.setText(resources.getString(R.string.avaliable_dyut_bal) + "" + dyutBal);
        }


        editTextClick();

        return view;
    }

    private void editTextClick() {

        edit_fixed_amount.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                fixed_amount.setBackgroundResource(R.drawable.curved_shape_light_colour);
                ride_per_meter.setBackgroundResource(R.color.vistara_color);
                meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                meter_minus_extra.setBackgroundResource(R.color.vistara_color);

                edit_per_meter.setEnabled(false);
                edit_fixed_amount.requestFocus();
                edit_fixed_amount.setFocusableInTouchMode(true);
                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(edit_fixed_amount, InputMethodManager.SHOW_FORCED);
                edit_meter_plus.setText("");
                edit_meter_less.setText("");
                type_of_rate_value = edit_fixed_amount.getText().toString();
                string_type_of_rate = "Fixed Amount";

                edit_fixed_amount.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        type_of_rate_value = edit_fixed_amount.getText().toString();
                        string_type_of_rate = "Fixed Amount";
                    }
                });

                return false;
            }
        });


        edit_meter_plus.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                fixed_amount.setBackgroundResource(R.color.vistara_color);
                ride_per_meter.setBackgroundResource(R.color.vistara_color);
                meter_plus_extra.setBackgroundResource(R.drawable.curved_shape_light_colour);
                meter_minus_extra.setBackgroundResource(R.color.vistara_color);

                edit_per_meter.setEnabled(false);


                edit_meter_plus.requestFocus();
                edit_meter_plus.setFocusableInTouchMode(true);

                InputMethodManager imm2 = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm2.showSoftInput(edit_meter_plus, InputMethodManager.SHOW_FORCED);

                edit_fixed_amount.setText("");
                edit_meter_less.setText("");

                type_of_rate_value = edit_meter_plus.getText().toString();
                string_type_of_rate = "Meter Plus Extra";

                edit_meter_plus.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                        type_of_rate_value = edit_meter_plus.getText().toString();
                        string_type_of_rate = "Meter Plus Extra";
                    }
                });
                return false;
            }
        });


        edit_meter_less.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                fixed_amount.setBackgroundResource(R.color.vistara_color);
                ride_per_meter.setBackgroundResource(R.color.vistara_color);
                meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                meter_minus_extra.setBackgroundResource(R.drawable.curved_shape_light_colour);

                edit_per_meter.setEnabled(false);

                edit_fixed_amount.setText("");
                //   edit_per_meter.setText("");
                edit_meter_plus.setText("");

                edit_meter_less.requestFocus();
                edit_meter_less.setFocusableInTouchMode(true);

                InputMethodManager imm3 = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm3.showSoftInput(edit_meter_less, InputMethodManager.SHOW_FORCED);

                type_of_rate_value = edit_meter_less.getText().toString();
                string_type_of_rate = "Meter Minus Extra";

                edit_meter_less.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                        type_of_rate_value = edit_meter_less.getText().toString();
                        string_type_of_rate = "Meter Minus Extra";
                    }
                });
                return false;
            }
        });
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(getActivity(), languageCode);
        resources = context.getResources();

        paymentModeText.setText(resources.getString(R.string.select_payment_method));
        cashRadioButton.setText(resources.getString(R.string.cash));
        m3RadioButton.setText(resources.getString(R.string.dyut));
        fixed_amount.setText(resources.getString(R.string.fixed_amount));

        ride_per_meter.setText(resources.getString(R.string.per_meter));
        m3RadioButton.setText(resources.getString(R.string.dyut));
        meter_plus_extra.setText(resources.getString(R.string.meter_plus_extra));
        meter_minus_extra.setText(resources.getString(R.string.meter_less_extra));
        taxInfoText.setText(resources.getString(R.string.your_offer_ride_charges_includes));
        selected_vehicle_type_of_meter_textView.setText(resources.getString(R.string.vehicle_type));
        book_a_ride_submit_button.setText(resources.getString(R.string.submit));
        finding_nearest_textView.setText(resources.getString(R.string.finding_nearest_ride_available));
    }

    private void radioGroupOoperation() {
        paymentModeRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                View radioButton = paymentModeRadioGroup.findViewById(checkedId);
                int index = paymentModeRadioGroup.indexOfChild(radioButton);

                switch (index) {
                    case 0: // first button
                        paymentType = "CASH";
                        break;
                    case 1: // secondbutton
                        paymentType = "DYUT";
                }
            }
        });
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }


    private void infoImageValues() {

        infoImagePerMeter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(getActivity())
                        .setMessage(displayRateInISymbol)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        }).show();
            }
        });
    }

    private void checkVehicleType() {
        switch (vehicle_type) {
            case "Taxi(4+1)":

                if (vehical_type_id.equalsIgnoreCase("5")) {
                    selected_vehicle_type_of_meter.setImageResource(R.drawable.delux_selected);
                    vehicleType.setText("Deluxe");

                    displayRateInISymbol = "Minimum Fare for Deluxe is " + rupees_symbol + minimum_fare + "." +
                            "\n Rate per Km is " + rupees_symbol + per_km + "." +
                            " Total Estimated Amount: " + rupees_symbol + total_fare + " including service charges,taxes,tolls if any, etc.";

                } else if (vehical_type_id.equalsIgnoreCase("6")) {
                    selected_vehicle_type_of_meter.setImageResource(R.drawable.sedan_selected);
                    vehicleType.setText("Sedan");

                    displayRateInISymbol = "Minimum Fare for Sedan is " + rupees_symbol + minimum_fare + "." +
                            "\n Rate per Km is " + rupees_symbol + per_km + "." +
                            " Total Estimated Amount: " + rupees_symbol + total_fare + " including service charges,taxes,tolls if any, etc...";
                } else if (vehical_type_id.equalsIgnoreCase("7")) {
                    selected_vehicle_type_of_meter.setImageResource(R.drawable.super_luxury_selected);
                    vehicleType.setText("Luxury");

                    displayRateInISymbol = "Minimum Fare for Luxury is " + rupees_symbol + minimum_fare + "." +
                            "\n Rate per Km is " + rupees_symbol + per_km + "." +
                            " Total Estimated Amount: " + rupees_symbol + total_fare + " including service charges,taxes,tolls if any, etc...";
                } else if (vehical_type_id.equalsIgnoreCase("8")) {
                    selected_vehicle_type_of_meter.setImageResource(R.drawable.luxury_selected);
                    vehicleType.setText("Super Luxury");

                    displayRateInISymbol = "Minimum Fare for Super Luxury is " + rupees_symbol + minimum_fare + "." +
                            " Rate per Km is " + rupees_symbol + per_km + "." +
                            " Total Estimated Amount: " + rupees_symbol + total_fare + " including service charges,taxes,tolls if any, etc...";
                } else {
                    selected_vehicle_type_of_meter.setImageResource(R.drawable.car_selected_ic);
                }

                break;
            case "Auto":
                selected_vehicle_type_of_meter.setImageResource(R.drawable.new_auto_selected);

                displayRateInISymbol = "Minimum Fare of Auto is " + rupees_symbol + minimum_fare +
                        "\n Rate per Km is " + rupees_symbol + per_km + "." +
                        "\n Total Estimated Amount: " + rupees_symbol + total_fare + " including service charges,taxes, etc...";

                vehicleType.setText("Auto");

                break;
            case "Bike":

                selected_vehicle_type_of_meter.setImageResource(R.drawable.bike_selected_ic);

                displayRateInISymbol = "Minimum Fare of Bike is " + rupees_symbol + minimum_fare +
                        "\nBike Rate per kilometer is " + rupees_symbol + per_km +
                        "\n Total: " + rupees_symbol + total_fare;

                break;

            case "Taxi(6+1)":
                selected_vehicle_type_of_meter.setImageResource(R.drawable.seleted_suv);

                displayRateInISymbol = "Minimum Fare for Taxi (6+1) is " + rupees_symbol + minimum_fare + "." +
                        "\nrate/Km is " + rupees_symbol + per_km +
                        " Total: " + rupees_symbol + total_fare + " including service charges,taxes,tolls if any, etc...";

                break;

        }
    }

    private void initializeWidget() {

        infoImagePerMeter = (ImageView) view.findViewById(R.id.infoImagePerMeter);
        selected_vehicle_type_of_meter = (ImageView) view.findViewById(R.id.selected_vehicle_type_of_meter);
        booking_fragment2_back = (ImageView) view.findViewById(R.id.booking_fragment2_back);

        book_a_ride_submit_button = (Button) view.findViewById(R.id.book_a_ride_submit_button);
        addMoneyButton = (Button) view.findViewById(R.id.addMoneyButton);

        rideForRadioGroup = (RadioGroup) view.findViewById(R.id.rideForRadioGrouop);
        selfRadioButton = (RadioButton) view.findViewById(R.id.selfRadioButton);
        otherRadioButton = (RadioButton) view.findViewById(R.id.otherRadioButton);

        paymentModeRadioGroup = (RadioGroup) view.findViewById(R.id.paymentModeRadioGroup);
        m3RadioButton = (RadioButton) view.findViewById(R.id.m3RadioButton);
        cashRadioButton = (RadioButton) view.findViewById(R.id.cashRadioButton);

        type_of_rate = (RadioGroup) view.findViewById(R.id.book_a_ride_type_of_rate);
        fixed_amount = (RadioButton) view.findViewById(R.id.book_a_ride_fixed_amount);
        ride_per_meter = (RadioButton) view.findViewById(R.id.book_a_ride_per_meter);
        meter_plus_extra = (RadioButton) view.findViewById(R.id.book_a_ride_meter_plus_extra);
        meter_minus_extra = (RadioButton) view.findViewById(R.id.book_a_ride_meter_minus_extra);

        book_a_ride_from = (TextView) view.findViewById(R.id.book_a_ride_from);
        book_a_ride_to = (TextView) view.findViewById(R.id.book_a_ride_to);
        type_of_meter_textView = (TextView) view.findViewById(R.id.type_of_meter_textView);
        selected_vehicle_type_of_meter_textView = (TextView) view.findViewById(R.id.selected_vehicle_type_of_meter_textView);

        edit_fixed_amount = (EditText) view.findViewById(R.id.edit_fixed_amount);
        edit_per_meter = (EditText) view.findViewById(R.id.edit_per_meter);
        edit_per_meter.setEnabled(false);
        edit_meter_plus = (EditText) view.findViewById(R.id.edit_meter_plus);
        edit_meter_less = (EditText) view.findViewById(R.id.edit_meter_less);

        passenger_offer_progressbar = (ProgressBar) view.findViewById(R.id.passenger_offer_progressbar);

        linearLayout_background_blur = (LinearLayout) view.findViewById(R.id.linearLayout_background_blur);
        paymentModeLinearLayout = (LinearLayout) view.findViewById(R.id.paymentModeLinearLayout);
        linearLayout_retry_cancel_buttons = (LinearLayout) view.findViewById(R.id.linearLayout_retry_cancel_buttons);
        /*linearLayout_background_blur.setBackgroundResource(R.color.white);*/

        finding_nearest_textView = (TextView) view.findViewById(R.id.finding_nearest_textView);
        driver_response_textView = (TextView) view.findViewById(R.id.driver_response_textView);

        retry_ride_request_button = (Button) view.findViewById(R.id.retry_ride_request_button);
        cancel_ride_request_button = (Button) view.findViewById(R.id.cancel_ride_request_button);

        walletBal = (TextView) view.findViewById(R.id.walletBal);
        vehicleType = (TextView) view.findViewById(R.id.vehicleType);
        paymentModeText = (TextView) view.findViewById(R.id.paymentModeText);
        taxInfoText = (TextView) view.findViewById(R.id.taxInfoText);


        mapFrag = (SupportMapFragment) this.getChildFragmentManager().findFragmentById(R.id.mapViewPassengerBooking2);
        mapFrag.getMapAsync(this);

        personal = (Button) view.findViewById(R.id.personal);
        otherBooking = (Button) view.findViewById(R.id.otherBooking);


    }

    private void typeOfMeter() {
        type_of_rate.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.book_a_ride_fixed_amount:

                        fixed_amount.setBackgroundResource(R.drawable.curved_shape_light_colour);
                        ride_per_meter.setBackgroundResource(R.color.vistara_color);
                        meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                        meter_minus_extra.setBackgroundResource(R.color.vistara_color);

                        edit_fixed_amount.setEnabled(true);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(false);
                        edit_fixed_amount.requestFocus();
                        edit_fixed_amount.setFocusableInTouchMode(true);
                        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.showSoftInput(edit_fixed_amount, InputMethodManager.SHOW_FORCED);
                        edit_meter_plus.setText("");
                        edit_meter_less.setText("");
                        type_of_rate_value = edit_fixed_amount.getText().toString();
                        string_type_of_rate = "Fixed Amount";
/*
                        fixed_amount.setBackgroundResource(R.color.vistara_color_blur_1);
                        ride_per_meter.setBackgroundResource(R.color.vistara_color);
                        meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                        meter_minus_extra.setBackgroundResource(R.color.vistara_color);*/

                        edit_fixed_amount.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                type_of_rate_value = edit_fixed_amount.getText().toString();
                                //string_type_of_rate = "Fixed Amount";
                            }
                        });
                        break;

                    case R.id.book_a_ride_per_meter:

                        fixed_amount.setBackgroundResource(R.color.vistara_color);
                        ride_per_meter.setBackgroundResource(R.drawable.curved_shape_light_colour);
                        meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                        meter_minus_extra.setBackgroundResource(R.color.vistara_color);

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(false);
                        // meter_value = edit_per_meter.getText().toString();
                        // type_of_rate_value = "0";
                        string_type_of_rate = "Permeter";
                        edit_fixed_amount.setText("");
                        edit_meter_plus.setText("");
                        edit_meter_less.setText("");
                        type_of_rate_value = edit_per_meter.getText().toString();

                        //type_of_rate_value = rate;

                        break;

                    case R.id.book_a_ride_meter_plus_extra:

                        fixed_amount.setBackgroundResource(R.color.vistara_color);
                        ride_per_meter.setBackgroundResource(R.color.vistara_color);
                        meter_plus_extra.setBackgroundResource(R.drawable.curved_shape_light_colour);
                        meter_minus_extra.setBackgroundResource(R.color.vistara_color);

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(true);
                        edit_meter_less.setEnabled(false);


                        edit_meter_plus.requestFocus();
                        edit_meter_plus.setFocusableInTouchMode(true);

                        InputMethodManager imm2 = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm2.showSoftInput(edit_meter_plus, InputMethodManager.SHOW_FORCED);

                        edit_fixed_amount.setText("");
                        edit_meter_less.setText("");

                        type_of_rate_value = edit_meter_plus.getText().toString();
                        string_type_of_rate = "Meter Plus Extra";

                        edit_meter_plus.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                                type_of_rate_value = edit_meter_plus.getText().toString();
                                //string_type_of_rate = "Meter Plus Extra";
                            }
                        });

                        break;

                    case R.id.book_a_ride_meter_minus_extra:

                        fixed_amount.setBackgroundResource(R.color.vistara_color);
                        ride_per_meter.setBackgroundResource(R.color.vistara_color);
                        meter_plus_extra.setBackgroundResource(R.color.vistara_color);
                        meter_minus_extra.setBackgroundResource(R.drawable.curved_shape_light_colour);

                        edit_fixed_amount.setEnabled(false);
                        edit_per_meter.setEnabled(false);
                        edit_meter_plus.setEnabled(false);
                        edit_meter_less.setEnabled(true);

                        edit_fixed_amount.setText("");
                        //   edit_per_meter.setText("");
                        edit_meter_plus.setText("");

                        edit_meter_less.requestFocus();
                        edit_meter_less.setFocusableInTouchMode(true);

                        InputMethodManager imm3 = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm3.showSoftInput(edit_meter_less, InputMethodManager.SHOW_FORCED);

                        type_of_rate_value = edit_meter_less.getText().toString();
                        string_type_of_rate = "Meter Minus Extra";

                        edit_meter_less.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                                type_of_rate_value = edit_meter_less.getText().toString();
                                //string_type_of_rate = "Meter Minus Extra";
                            }
                        });

                        break;
                }
            }
        });


        booking_fragment2_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("from", from);
                bundle.putString("to", to);
                bundle.putString("fromlatitude", fromlatitude);
                bundle.putString("fromlongitude", fromlongitude);
                bundle.putString("tolatitude", tolatitude);
                bundle.putString("tolongitude", tolongitude);
                bundle.putString("vehicle_type", vehicle_type);
//                MenuPassenger backFragment = new MenuPassenger();
//                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//                backFragment.setArguments(bundle);
//                fragmentManager.beginTransaction()
//                        .replace(R.id.content_frame, backFragment)
//                        .commit();

                Intent i = new Intent(getActivity(), NavHome.class); //todo loading current location not enterd location
                i.putExtras(bundle);
                startActivity(i);
                getActivity().finish();

            }
        });


        book_a_ride_submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (countDownTimer != null) {
                    countDownTimer.cancel();
                    countDownTimer = null;

                }


                if (paymentModeRadioGroup.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(getActivity(), "Selecet payment mode", Toast.LENGTH_LONG).show();
                } else {
                    meter_value = edit_per_meter.getText().toString();
                    if (!(Functions.isAllBookingFieldSelected(vehicle_type, when_required_value, string_type_of_rate, type_of_rate_value, fromlatitude, tolatitude))) {
                    } else if (when_required_value.equals(null)) {


                    } else {

                        linearLayout_background_blur.setVisibility(View.VISIBLE);
                        finding_nearest_textView.setVisibility(View.VISIBLE);

                        passenger_offer_progressbar.setVisibility(View.VISIBLE);
                        walletBal.setVisibility(View.GONE);
                        paymentModeLinearLayout.setVisibility(View.GONE);
//                        passenger_offer_progressbar.setBackgroundColor(getResources().getColor(R.color.white));
//                        passenger_offer_progressbar.setMax(100);
//                        passenger_offer_progressbar.setProgress(40);
//                        passenger_offer_progressbar.setIndeterminate(true);
                        /*sendRideRequest();*/


                        passenger_offer_progressbar.setProgress(i);
                        countDownTimer = new CountDownTimer(126000, 1000) {

                            @Override
                            public void onTick(long millisUntilFinished) {
                                Log.v("Log_tag", "Tick of Progress" + i + millisUntilFinished);
                                i++;
                                passenger_offer_progressbar.setProgress((int) i * 100 / (126000 / 1000));

                            }

                            @Override
                            public void onFinish() {
                                //Do what you want
                                i++;
                                passenger_offer_progressbar.setProgress(100);

                                linearLayout_background_blur.setBackgroundResource(R.color.white);
                                /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white));*/
                                finding_nearest_textView.setVisibility(View.GONE);
                                passenger_offer_progressbar.setVisibility(View.GONE);
                                j = 0;
                                retry_ride_request_button.setVisibility(View.VISIBLE);
                                cancel_ride_request_button.setVisibility(View.VISIBLE);
                                driver_response_textView.setVisibility(View.VISIBLE);
                                driver_response_textView.setText("Vehicles not found, Please try after sometime");
                            }
                        };
                        countDownTimer.start();
                        booking_fragment2_back.setEnabled(false);
                        setTimerForRideRequest();

                    }
                }

            }
        });


        retry_ride_request_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (waitingTimerRideRequest != null) {
                    waitingTimerRideRequest.cancel();
                    waitingTimerRideRequest = null;

                }
                status = "searching";

                linearLayout_background_blur.setBackgroundResource(R.color.white_light_transparent_1);

                /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white_light_transparent_1));*/
                finding_nearest_textView.setVisibility(View.VISIBLE);
                passenger_offer_progressbar.setVisibility(View.VISIBLE);
                retry_ride_request_button.setVisibility(View.GONE);
                cancel_ride_request_button.setVisibility(View.GONE);
                driver_response_textView.setVisibility(View.GONE);
                walletBal.setVisibility(View.GONE);
                paymentModeLinearLayout.setVisibility(View.GONE);

                passenger_offer_progressbar.setProgress(i);

                countDownTimer = new CountDownTimer(126000, 1000) {

                    @Override
                    public void onTick(long millisUntilFinished) {
                        Log.v("Log_tag", "Tick of Progress" + j + millisUntilFinished);
                        j++;
                        passenger_offer_progressbar.setProgress((int) j * 100 / (126000 / 1000));

                    }

                    @Override
                    public void onFinish() {
                        //Do what you want
                        j++;
                        passenger_offer_progressbar.setProgress(100);

                        linearLayout_background_blur.setBackgroundResource(R.color.white);
                        /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white));*/
                        finding_nearest_textView.setVisibility(View.GONE);
                        passenger_offer_progressbar.setVisibility(View.GONE);
                        j = 0;
                        retry_ride_request_button.setVisibility(View.VISIBLE);
                        cancel_ride_request_button.setVisibility(View.VISIBLE);
                        driver_response_textView.setVisibility(View.VISIBLE);
                        driver_response_textView.setText("Vehicles not found, Please try after sometime");
                    }
                };
                countDownTimer.start();

                setTimerForRideRequest();
            }
        });

        cancel_ride_request_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (waitingTimerRideRequest != null) {
                    waitingTimerRideRequest.cancel();
                    waitingTimerRideRequest = null;
                }
                Bundle bundle = new Bundle();
                bundle.putString("from", from);
                bundle.putString("to", to);
                bundle.putString("fromlatitude", fromlatitude);
                bundle.putString("fromlongitude", fromlongitude);
                bundle.putString("tolatitude", tolatitude);
                bundle.putString("tolongitude", tolongitude);
                bundle.putString("vehicle_type", vehicle_type);
                PassengerHomeFragment backFragment = new PassengerHomeFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                backFragment.setArguments(bundle);
                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, backFragment)
                        .commit();
            }
        });

        addMoneyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), AddMoneyToDyutAccActivity.class);
                intent.putExtra("comingFrom","booking2");
                startActivity(intent);
            }
        });

    }


    private void sendRideRequest() {

        Map<String, String> params = new HashMap<String, String>();

        params.put("passengername", sessionManager.getUserDetails().get("name"));
        params.put("passengermobile", sessionManager.getUserDetails().get("mobile"));
        params.put("vehicle", vehicle_type);
        params.put("whenrequired", when_required_value);
        params.put("whenrequiredtype", when_required_type);
        params.put("typeofrate", string_type_of_rate);
        params.put("rate", type_of_rate_value);
        /* params.put("metervalue", getIntent().getStringExtra("metervalue"));*/
        params.put("from", from);
        params.put("to", to);
        params.put("vehicle_id", vehical_type_id);
        params.put("fromlatitude", fromlatitude);
        params.put("fromlongitude", fromlongitude);
        params.put("tolatitude", tolatitude);
        params.put("tolongitude", tolongitude);
        params.put("paymenttype", paymentType);
        params.put("distance", distance);
        params.put("range_count", "4"); // todo range count hardcoded
        params.put("metervalue", rate);
        if (city == null) {
            params.put("city_name", "Bengaluru");
        } else {
            params.put("city_name", city);
        }

        if (state == null) {
            params.put("state_name", "Karnataka");
        } else {
            params.put("state_name", state);
        }
        params.put("minimum_fare", minimum_fare);

        params.put("toll_charge", toolCharge);
        params.put("toll_names", toolName);


        params.put("booking_type", type);

        if (type.equalsIgnoreCase("Other")) {

            params.put("other_passengername", othername);
            params.put("other_passengernumber", othermobile);
        }

        params.put("meter_sgst", meter_sgst);
        params.put("meter_cgst", meter_cgst);
        params.put("meter_igst", meter_igst);
        params.put("service_charge", service_charge);
        params.put("insurance_amount_val", insurance_amount_val);
        params.put("insurance_sgst_val", insurance_sgst_val);
        params.put("insurance_cgst_val", insurance_cgst_val);
        params.put("insurance_igst_val", insurance_igst_val);

        /*Below parameters for airport booking*/

        params.put("airport_booking_type",this.getArguments().getString("airport_booking_type"));
        params.put("airport_name",this.getArguments().getString("airport_name"));
        params.put("airport_drop_charges", this.getArguments().getString("airport_drop_charges"));
        params.put("airport_pickup_charges",this.getArguments().getString("airport_pickup_charges"));
        params.put("airport_waiting_time_charges", this.getArguments().getString("airport_waiting_time_charges"));
        params.put("round_trip", this.getArguments().getString("round_trip"));
        params.put("no_of_passengers", this.getArguments().getString("no_of_passengers"));
        params.put("bag_type", this.getArguments().getString("bag_type"));
        params.put("no_of_luggages", this.getArguments().getString("no_of_luggages"));
        params.put("bag_charges", this.getArguments().getString("bag_charges"));
        params.put("parking_charge", this.getArguments().getString("parking_charge"));
        params.put("waiting_charge_per_minute", this.getArguments().getString("waiting_charge_per_minute"));



        asyncInteractor.validateCredentialsAsync(this, AppConstants.rideRequest, Url.COMUNICATE_API + ServerApiNames.rideRequest, new JSONObject(params));


    }


    /*---------------------------------------------------------------------------------------------------------*/
    @Subscribe
    public void getButtonStatus(OttoAllDriversRejected data) {
        Log.i("Activity", data.getRejection());


        if (data.getRejection().equals("Request timeout")) {
            if (waitingTimerRideRequest != null) {
                waitingTimerRideRequest.cancel();
                waitingTimerRideRequest = null;

            }

            /*linearLayout_background_blur.setBackgroundResource(R.color.white);*/


            finding_nearest_textView.setVisibility(View.GONE);
            passenger_offer_progressbar.setVisibility(View.GONE);
            retry_ride_request_button.setVisibility(View.VISIBLE);
            cancel_ride_request_button.setVisibility(View.VISIBLE);
            driver_response_textView.setVisibility(View.VISIBLE);
            driver_response_textView.setText("Vehicles not found, Please try after sometime");

        }
    }

    private void setTimerForRideRequest() {

        waitingTimerRideRequest = new CountDownTimer(130000, 10000) {

            public void onTick(long millisUntilFinished) {

                if (millisUntilFinished >= 80000 && status.equals("searching")) {

                    range_count++;
                    sendRideRequest();
                } else if (status.equals("searching")) {
                    linearLayout_background_blur.setBackgroundResource(R.color.white);
                    /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white));*/
                    finding_nearest_textView.setVisibility(View.GONE);
                    passenger_offer_progressbar.setVisibility(View.GONE);
                    paymentModeRadioGroup.setVisibility(View.GONE);
                    retry_ride_request_button.setVisibility(View.VISIBLE);
                    cancel_ride_request_button.setVisibility(View.VISIBLE);
                    driver_response_textView.setVisibility(View.VISIBLE);
                    driver_response_textView.setText("Vehicles not found in your area");
                }
            }

            public void onFinish() {

                linearLayout_background_blur.setBackgroundResource(R.color.white);
                /*linearLayout_background_blur.setBackgroundColor(getResources().getColor(R.color.white));*/
                finding_nearest_textView.setVisibility(View.GONE);
                passenger_offer_progressbar.setVisibility(View.GONE);
                j = 0;
                retry_ride_request_button.setVisibility(View.VISIBLE);
                cancel_ride_request_button.setVisibility(View.VISIBLE);
                driver_response_textView.setVisibility(View.VISIBLE);
                driver_response_textView.setText("Vehicles not found, Please try after sometime");
            }
        }.start();
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;


        LatLng latLng = new LatLng(Double.parseDouble(fromlatitude), Double.parseDouble(fromlongitude));
        LatLng latLng2 = new LatLng(Double.parseDouble(tolatitude), Double.parseDouble(tolongitude));


            NetworkClient.getDirectionRouteData(latLng, latLng2, getResources().getString(R.string.google_direction_api),
                    new ApiListener<DirectionResponseModel, ErrorModel>() {
                        @Override
                        public void onSuccess(DirectionResponseModel data) {

                            if (data.getRoutes().size() > 0) {
                                PolylineOptions options = null;
                                polylineList = new ArrayList<>();

                                for (int i = 0; i < data.getRoutes().size(); i++) {
                                    options = new PolylineOptions();
                                    options.geodesic(true);
                                    options.clickable(true);
                                    options.width(8);
                                    options.color(Color.parseColor("#2E8CDD"));
                                    options.addAll(RouteDecode.decodePoly(data.getRoutes().get(i).getOverviewPolyline().getPoints()));
                                    Polyline polyline = mGoogleMap.addPolyline(options);
                                    polylineList.add(polyline);

                                }

                                mCurrLocationMarker = Utils.addMarker(latLng, mGoogleMap, BitmapDescriptorFactory.fromResource(R.drawable.source_point_vistara),"");
                                mDestinationMarker = Utils.addMarker(latLng2, mGoogleMap, BitmapDescriptorFactory.fromResource(R.drawable.drop_location_red),distance);
                                mDestinationMarker.showInfoWindow();
                                Utils.fixDirectionToScreen(getActivity(), mCurrLocationMarker, mDestinationMarker, mGoogleMap);
                            }

                        }

                        @Override
                        public void onFailure(ErrorModel error) {

                        }
                    });



    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        if (pid == AppConstants.rideRequest) {
            try {

                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    status = jObj.getString("status");

                    // bookingid = jObj.getString("bookingid");

                    if (status.equals("got")) {
                        bookingid = jObj.getString("bookingid");
                        if (waitingTimerRideRequest != null) {
                            waitingTimerRideRequest.cancel();
                        }

                    }
                    message = jObj.getString("message");

                } else {
                    String errorMsg = jObj.getString("error_msg");
                              /*  Intent home = new Intent(getActivity(), NavHome.class);
                                startActivity(home);*/

                    linearLayout_background_blur.setVisibility(View.GONE);
                    finding_nearest_textView.setVisibility(View.GONE);
                    passenger_offer_progressbar.setVisibility(View.GONE);
                    countDownTimer.cancel();
                    countDownTimer = null;
                    waitingTimerRideRequest.cancel();
                    // passenger_offer_progressbar.setProgress(100);
                    booking_fragment2_back.setEnabled(true);
                    walletBal.setVisibility(View.VISIBLE);
                    paymentModeLinearLayout.setVisibility(View.VISIBLE);
                    androidx.appcompat.app.AlertDialog.Builder builder1 = new androidx.appcompat.app.AlertDialog.Builder(getContext(), R.style.MyDialogTheme);
                    builder1.setMessage(errorMsg);
                    builder1.setCancelable(true);
                    builder1.setTitle("Alert !");

                    builder1.setPositiveButton(
                            "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });

                    androidx.appcompat.app.AlertDialog mDialog = builder1.create();
                    mDialog.show();

                    if (waitingTimerRideRequest != null) {
                        waitingTimerRideRequest.cancel();
                        waitingTimerRideRequest = null;
                    }

                    //getActivity().finish();

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {

        if (pid == AppConstants.rideRequest) {
            String errorMsg = error;
                              /*  Intent home = new Intent(getActivity(), NavHome.class);
                                startActivity(home);*/

            linearLayout_background_blur.setVisibility(View.GONE);
            finding_nearest_textView.setVisibility(View.GONE);
            passenger_offer_progressbar.setVisibility(View.GONE);
            countDownTimer.cancel();
            countDownTimer = null;
            waitingTimerRideRequest.cancel();
            // passenger_offer_progressbar.setProgress(100);
            booking_fragment2_back.setEnabled(true);
            walletBal.setVisibility(View.VISIBLE);
            paymentModeLinearLayout.setVisibility(View.VISIBLE);
            androidx.appcompat.app.AlertDialog.Builder builder1 = new androidx.appcompat.app.AlertDialog.Builder(getContext(), R.style.MyDialogTheme);
            builder1.setMessage(errorMsg);
            builder1.setCancelable(true);
            builder1.setTitle("Alert !");

            builder1.setPositiveButton(
                    "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });

            androidx.appcompat.app.AlertDialog mDialog = builder1.create();
            mDialog.show();

            if (waitingTimerRideRequest != null) {
                waitingTimerRideRequest.cancel();
                waitingTimerRideRequest = null;
            }
        }
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }

}
