package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.kouchan.dyutpassenger.Adapter.TrackComplentAdapter;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Api.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.ComplentsModel;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TrackComplentActivity extends AppCompatActivity implements OnRequestListener {

    RecyclerView trackComplentRecyclerView;
    SessionManager sessionManager;
    TextView about_us_textView;
    String userId, url;
    List<ComplentsModel> complentsModelList = new ArrayList<>();
    TrackComplentAdapter mAdapter;
    ImageView nav_about_usBackImageView;

    AsyncInteractor asyncInteractor;
    private String languageCode;
    private Resources resources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_complent);
        asyncInteractor=new AsyncInteractor(this);
        intailizeViews();
        getComplentsAPICall();


        mAdapter = new TrackComplentAdapter(this, complentsModelList);
        trackComplentRecyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        trackComplentRecyclerView.setLayoutManager(mLayoutManager);
        trackComplentRecyclerView.setAdapter(mAdapter);

        if (Utils.appCode != null) {
            languageCode = Utils.appCode.toString();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        about_us_textView.setText(resources.getString(R.string.track_complaint));
    }

    private void intailizeViews() {
        sessionManager = new SessionManager(this);
        trackComplentRecyclerView = (RecyclerView) findViewById(R.id.trackComplentRecyclerView);
        nav_about_usBackImageView = (ImageView) findViewById(R.id.nav_about_usBackImageView);
        about_us_textView = (TextView) findViewById(R.id.about_us_textView);

        nav_about_usBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    public void getComplentsAPICall() {

        url = Url.PASSENGER_API + "getcomplaints.php?user_id=" + sessionManager.getId() + "&user_type=" + sessionManager.getType();

        Utils.showProgress(this);
        asyncInteractor.validateCredentialsAsync(this,AppConstants.TAG_ID_GET_COMPLAINTS,url,null);
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        if(pid==AppConstants.TAG_ID_GET_COMPLAINTS){
            try {
                Utils.stopProgress(this);
                JSONObject jsonObj = new JSONObject(responseJson);
                boolean error = jsonObj.getBoolean("error");
                if (!error) {

                    JSONArray contacts = jsonObj.getJSONArray("complaints");
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        String complaint_id = c.getString("complaint_id");
                        String booking_id = c.getString("booking_id");
                        String complaint_type = c.getString("complaint_type");
                        String comments = c.getString("comments");
                        String status = c.getString("status");

                        ComplentsModel model = new ComplentsModel(complaint_id, booking_id, complaint_type, comments, status);
                        complentsModelList.add(model);
                        mAdapter.notifyDataSetChanged();
                    }
                } else {
                    String errorMsg = jsonObj.getString("error_msg");
                    Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_LONG).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(this);
        Utils.showToast(this,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
