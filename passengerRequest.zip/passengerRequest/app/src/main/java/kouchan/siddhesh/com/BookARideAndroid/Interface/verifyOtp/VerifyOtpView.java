package kouchan.siddhesh.com.BookARideAndroid.Interface.verifyOtp;

public interface VerifyOtpView {

    void verifyOtpSuccess(int pid, String verifyOtpModel);

    void verifyOtpError(int pid, String error);

}
