package kouchan.siddhesh.com.BookARideAndroid.other;

/**
 * Created by KOUCHAN-ADMIN on 3/26/2018.
 */

public class OttoSelectedFromFavorite {


    String address,  tolatitude,  tolongitude,  setTo;

    public OttoSelectedFromFavorite(String address, String tolatitude, String tolongitude, String setTo) {
        this.address = address;
        this.tolatitude = tolatitude;
        this.tolongitude = tolongitude;
        this.setTo = setTo;
    }

    public String getAddress() {
        return address;
    }

    public String getTolatitude() {
        return tolatitude;
    }

    public String getTolongitude() {
        return tolongitude;
    }

    public String getSetTo() {
        return setTo;
    }

}
