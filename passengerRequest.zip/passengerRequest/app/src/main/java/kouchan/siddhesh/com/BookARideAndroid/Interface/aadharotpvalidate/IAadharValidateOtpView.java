package kouchan.siddhesh.com.BookARideAndroid.Interface.aadharotpvalidate;

public interface IAadharValidateOtpView {

    void aadharOtpSuccess(int pid, String aadharOtpmodel);

    void aadharOtpError(int pid, String error);

}
