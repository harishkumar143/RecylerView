package kouchan.siddhesh.com.BookARideAndroid.Interface.deletefavourite;

public interface IDeleteFavouriteView {

    void deleteFavouriteSuccess(int pid, String response);

    void deleteFavouriteError(int pid, String error);

}
