package kouchan.siddhesh.com.BookARideAndroid.Interface.editprofile;

public interface IEditProfilePresnter {

    void editProfile(String mobileNumber, String name, String email,String adharno,
                     String bdate,String gender,String address,String state,String pin);

}
