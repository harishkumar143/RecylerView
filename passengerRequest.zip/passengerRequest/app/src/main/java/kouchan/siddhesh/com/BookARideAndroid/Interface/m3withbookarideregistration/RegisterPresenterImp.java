package kouchan.siddhesh.com.BookARideAndroid.Interface.m3withbookarideregistration;

import android.util.Log;
import android.widget.EditText;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import kouchan.siddhesh.com.BookARideAndroid.Api.ApiClient;
import kouchan.siddhesh.com.BookARideAndroid.Api.ServerApiNames;
import kouchan.siddhesh.com.BookARideAndroid.Modules.RegisterModel;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.AadharRegistrationActivity;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.Registration;
import kouchan.siddhesh.com.BookARideAndroid.async.AsyncInteractor;
import kouchan.siddhesh.com.BookARideAndroid.async.OnRequestListener;
import kouchan.siddhesh.com.BookARideAndroid.utils.AppConstants;
import kouchan.siddhesh.com.BookARideAndroid.utils.Sharedpreferences;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

public class RegisterPresenterImp implements IRegisterPresenter, OnRequestListener {

    IRegisterView iRegisterView;
    AadharRegistrationActivity registerActivity;
    AsyncInteractor asyncInteractor;
    Sharedpreferences prefs;
    RegisterModel registerModel;

    public RegisterPresenterImp(IRegisterView iRegisterView) {
        this.iRegisterView = iRegisterView;
        this.registerActivity = (AadharRegistrationActivity) iRegisterView;
        prefs = prefs.getUserDataObj(registerActivity);
        asyncInteractor = new AsyncInteractor(registerActivity);
    }

    @Override
    public void registerValidation(String firstName, String email, String mobile, String password, String adharNumber) {
        sendRequestToNetwork(firstName, email, mobile, password, adharNumber);
    }

    private void sendRequestToNetwork(String name, String email, String mobile, String password, String adharNumber) {
        Utils.showProgress(registerActivity);

        HashMap<String, String> params = new HashMap<>();
        params.put("name", name);
        params.put("mobile", mobile);
        params.put("email", email);
        String shaPassword = Utils.getSHA256Hash(password);
        params.put("password", shaPassword);
        params.put("adharno", adharNumber);
        asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_REGISTER, "https://bookarideworldwide.com/CAB2.V.1/passenger_api/m3registrationofpassenger.php", new JSONObject(params));


    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {
    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if (pid == AppConstants.TAG_ID_REGISTER) {

            Log.e("responseRegistration", responseJson.toString());
            if (responseJson != null) {

                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    iRegisterView.onRegisterSuccess(pid, jObj.getString("next_step"));
                } else {
                    iRegisterView.onRegisterError(pid, jObj.getString("error_msg"));
                }
            } else {

                iRegisterView.onRegisterError(pid, "Server Error");
            }
        }

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        Utils.stopProgress(registerActivity);
        iRegisterView.onRegisterServerError(pid, error);
    }
}
