package kouchan.siddhesh.com.BookARideAndroid.Interface.aftercancel;

import java.util.ArrayList;

public interface IGetAfterCancelView {

    void getAfterCancelSuccess(int pid, ArrayList<String> afterCancel);

    void getAfterCancelError(int pid, String error);

}
