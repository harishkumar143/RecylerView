package kouchan.siddhesh.com.BookARideAndroid.Interface.bookrideotpresend;

import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.View.Activities.VerifyOTP;
import kouchan.siddhesh.com.BookARideAndroid.async.AsyncInteractor;
import kouchan.siddhesh.com.BookARideAndroid.async.OnRequestListener;
import kouchan.siddhesh.com.BookARideAndroid.utils.AppConstants;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

public class BookRideOTPResendPresenterImpl implements OnRequestListener, IBookRideOTPResendPresenter {

    IBookRideOTPResendView iBookRideOTPView;
    VerifyOTP verifyOTP;
    AsyncInteractor asyncInteractor;

    public BookRideOTPResendPresenterImpl(VerifyOTP verifyOTP) {
        this.iBookRideOTPView = verifyOTP;
        this.verifyOTP = verifyOTP;
        asyncInteractor = new AsyncInteractor(verifyOTP);
    }

    @Override
    public void getBookRideOTPResend(String stringMobile) {
        Map<String, String> params = new HashMap<String, String>();
        Utils.showProgress(verifyOTP);
        params.put("mobile", stringMobile);
        asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_BOOKRIDERESENDOTP, "https://bookarideworldwide.com/CAB2.V.1/passenger_api/resend_otp.php", new JSONObject(params));
    }


    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {
    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        Utils.stopProgress(verifyOTP);
        if (pid == AppConstants.TAG_ID_BOOKRIDERESENDOTP) {
            if (responseJson != null) {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    iBookRideOTPView.onGetBookRideOTPResendSuccess(pid, responseJson);
                    Toast.makeText( verifyOTP, jObj.getString("message"), Toast.LENGTH_SHORT ).show();
                } else {
                    String errorMsg = jObj.getString("error_msg");
                    iBookRideOTPView.onGetBookRideOTPResendError(pid, errorMsg);
                    Toast.makeText( verifyOTP, errorMsg, Toast.LENGTH_SHORT ).show();
                }
            } else {
                iBookRideOTPView.onGetBookRideOTPResendError(pid, "");
            }
        }

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(verifyOTP);
        iBookRideOTPView.onGetBookRideOTPResendError(pid, error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        Utils.stopProgress(verifyOTP);
        iBookRideOTPView.onGetBookRideOTPResendError(pid, error);
    }

}
