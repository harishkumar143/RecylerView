package kouchan.siddhesh.com.BookARideAndroid.Interface;

/**
 * Created by KOUCHAN-ADMIN on 8/5/2017.
 */

public interface Url {

    String PASSENGER_API = "https://www.bookarideworldwide.com/CAB2.V.1/passenger_api/";
    String DRIVER_API = "https://www.bookarideworldwide.com/CAB2.V.1/driver_api/";
    String COMUNICATE_API = "https://www.bookarideworldwide.com/CAB2.V.1/comunicate_api/";
}
