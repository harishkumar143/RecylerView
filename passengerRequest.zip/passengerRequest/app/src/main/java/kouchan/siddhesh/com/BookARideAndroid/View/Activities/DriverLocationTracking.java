package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.Projection;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.SquareCap;
import com.google.maps.android.PolyUtil;
import com.squareup.otto.Subscribe;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.CurrentRide;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.DirectionsJSONParser;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Modules.DirectionFinder;
import kouchan.siddhesh.com.BookARideAndroid.Modules.DirectionFinderListener;
import kouchan.siddhesh.com.BookARideAndroid.Modules.Distance;
import kouchan.siddhesh.com.BookARideAndroid.Modules.Duration;
import kouchan.siddhesh.com.BookARideAndroid.Modules.Route;
import kouchan.siddhesh.com.BookARideAndroid.Otto.EventBusManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.View.Fragments.FragmentBooking2;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoEventActivityFinish;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoRideStarted;
import kouchan.siddhesh.com.BookARideAndroid.models.events.BeginJourneyEvent;
import kouchan.siddhesh.com.BookARideAndroid.models.events.CurrentJourneyEvent;
import kouchan.siddhesh.com.BookARideAndroid.models.events.EndJourneyEvent;
import kouchan.siddhesh.com.BookARideAndroid.other.CircleTransform;
import kouchan.siddhesh.com.BookARideAndroid.utils.JourneyEventBus;
import kouchan.siddhesh.com.BookARideAndroid.models.events.CurrentJourneyEvent;
import static com.google.android.gms.maps.model.JointType.ROUND;


public class DriverLocationTracking extends AppCompatActivity
        implements OnMapReadyCallback, DirectionFinderListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    final static String updateLocation = Url.DRIVER_API + "getDriverLocation.php";
    final static String driverInfoAfterBooking = Url.COMUNICATE_API + "driverDetailAfterBooking.php";
    final static String cancelRideUrl = Url.COMUNICATE_API + "bookingCancellationOfPassenger.php";
    final static String sosurl = Url.COMUNICATE_API + "sosPassenger.php";
    final static String beforeridestart = "https://bookarideworldwide.com/CAB2.V.1/comunicate_api/get_comments.php?user_type=PASSENGER&comment_type=BEFORE_RIDE_START_CANCELLATION";
    final static String afterridestart = "https://bookarideworldwide.com/CAB2.V.1/comunicate_api/get_comments.php?user_type=PASSENGER&comment_type=RIDE_START_CANCELLATION";
    String URL = beforeridestart;
    GoogleMap mGoogleMap;
    LocationRequest mLocationRequest;
    GoogleApiClient mGoogleApiClient;
    Location mLastLocation;
    Marker mCurrLocationMarker;
    double lat, lng;
    SupportMapFragment mapFrag;
    String drivermobile, bookingid, vehicle, reason = "";
    String fromlatitude;
    String fromlongitude;
    String tolatitude;
    String tolongitude;
    TextView token, expectedtime, vehicleno, vehicletype, drivermobilew, book_a_ride_from, book_a_ride_to,
            vehicle_model_text, driver_nameA, driver_rating, vehicalSeat;
    TextView driver_tracking_textView, ride_token_textView, expected_time_textView,
            vehicle_number_textView, vehicle_type_textView, driver_mobile_textView,
            ride_OTP_text;
    String languageCode;
    Resources resources;
    Toolbar mToolbar;
    ImageView driverLocationTrackingBackImageView, driverLocationTrackingSosButton,
            pickup_marker_logo, destination_marker_logo, selected_vehicle_WhenRequire, driver_photo;
    Button cancelridedlt, startNavigationButton;
    AlertDialog.Builder ab;
    ProgressDialog loading;
    double value1;
    /*driverLocationTrackingHomeImageView;*/
    double value2;
    Marker mk = null;
    BitmapDrawable bitmapdraw;
    LatLng latLng;
    SessionManager sessionManager;
    HashMap<String, String> user = new HashMap<String, String>();
    String name, mobile;
    CurrentRide currentRide;
    int cameraCount = 1;
    ImageView call_Driver, share_ride_details;
    String whenRequerd;
    ImageView help_and_support;
    private List<Marker> originMarkers = new ArrayList<>();
    private List<Marker> destinationMarkers = new ArrayList<>();
    private List<Polyline> polylinePaths = new ArrayList<>();
    private ProgressDialog progressDialog;
    private int markerCount;
    private RatingBar ratingBar;
    private List<LatLng> polyLineList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_location_tracking);

        //EventBusManager.getInstance().getEventBus().register(this);

        drivermobile = getIntent().getStringExtra("drivermobile");
        bookingid = getIntent().getStringExtra("bookingid");
        vehicle = getIntent().getStringExtra("vehicle");

        sessionManager = new SessionManager(this);
        user = sessionManager.getUserDetails();
        name = user.get("name");
        mobile = user.get("mobile");
        polyLineList = new ArrayList<>();

        currentRide = new CurrentRide(getApplicationContext());
        currentRide.setDrivermobile(getIntent().getStringExtra("drivermobile"));
        currentRide.setRideid(getIntent().getStringExtra("bookingid"));
        currentRide.setVehicle(getIntent().getStringExtra("vehicle"));
        currentRide.setIsRideStarted("started");


        mapFrag = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapView2);
        mapFrag.getMapAsync(this);

        token = (TextView) findViewById(R.id.code);
        expectedtime = (TextView) findViewById(R.id.expectedTime);
        vehicleno = (TextView) findViewById(R.id.vehicleNo);
        vehicletype = (TextView) findViewById(R.id.vehicleType);
        drivermobilew = (TextView) findViewById(R.id.driverMobile);
        cancelridedlt = (Button) findViewById(R.id.cancelridedlt);
        startNavigationButton = (Button) findViewById(R.id.startNavigationButton);
        ab = new AlertDialog.Builder(DriverLocationTracking.this);
        ratingBar = (RatingBar) findViewById(R.id.ratingBar);

        driver_tracking_textView = (TextView) findViewById(R.id.driver_tracking_textView);
        ride_token_textView = (TextView) findViewById(R.id.ride_token_textView);
        expected_time_textView = (TextView) findViewById(R.id.expected_time_textView);
        vehicle_number_textView = (TextView) findViewById(R.id.vehicle_number_textView);
        vehicle_type_textView = (TextView) findViewById(R.id.vehicle_type_textView);
        driver_mobile_textView = (TextView) findViewById(R.id.driver_mobile_textView);

        book_a_ride_from = (TextView) findViewById(R.id.book_a_ride_from);
        book_a_ride_to = (TextView) findViewById(R.id.book_a_ride_to);
        vehicle_model_text = (TextView) findViewById(R.id.vehicle_model_text);
        driver_nameA = (TextView) findViewById(R.id.driver_name);
        driver_rating = (TextView) findViewById(R.id.driver_rating);
        vehicalSeat = (TextView) findViewById(R.id.vehicalSeat);
        ride_OTP_text = (TextView) findViewById(R.id.ride_OTP_text);

        pickup_marker_logo = (ImageView) findViewById(R.id.pickup_marker_logo);
        destination_marker_logo = (ImageView) findViewById(R.id.destination_marker_logo);
        selected_vehicle_WhenRequire = (ImageView) findViewById(R.id.selected_vehicle_WhenRequire);
        call_Driver = (ImageView) findViewById(R.id.call_Driver);
        share_ride_details = (ImageView) findViewById(R.id.share_ride_details);

        driver_photo = (ImageView) findViewById(R.id.driver_photo);

        help_and_support = (ImageView) findViewById(R.id.help_and_support);

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();
        mGoogleApiClient.connect();

        startNavigationButton.setText(resources.getString(R.string.start_navigation));

        startNavigationButton.setEnabled(false);


        markerCount = 0;

      /*  drivermobilew.setText(drivermobile);
        vehicletype.setText(vehicle);*/
        cancelridedlt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                standardComments();

//
            }

        });

        help_and_support.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(), HelpAndSupport.class);
                i.putExtra("drivermobile", getIntent().getStringExtra("drivermobile"));
                i.putExtra("bookingid", getIntent().getStringExtra("bookingid"));
                i.putExtra("vehicle", getIntent().getStringExtra("vehicle"));
                startActivity(i);
            }
        });

        call_Driver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Here, thisActivity is the current activity

                String phone_no = currentRide.getDrivermobile();
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + phone_no));
                callIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (ActivityCompat.checkSelfPermission(DriverLocationTracking.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                startActivity(callIntent);
            }
        });

        share_ride_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "Book A Ride");
                    String strShareMessage = name + " travelling by: Dyut Rides" + "\nBooking Id: " + currentRide.getRideid() + "\nDriver Name: " + driver_nameA.getText().toString() +
                            "\nVehicle: " + currentRide.getVehicle() + "\nPickup point: " + book_a_ride_from.getText().toString() +
                            "\nDrop point: " + book_a_ride_to.getText().toString() + "\nVehicle Number: " + vehicleno.getText().toString()
                            + "\nDeparture Time: " + whenRequerd + "\nTrack Me: " + "https://www.google.co.in/";
                    //  Uri screenshotUri = Uri.parse("android.resource://packagename/drawable/image_name");
                    // i.setType("image/png");
                    //  i.putExtra(Intent.EXTRA_STREAM, screenshotUri);
                    i.putExtra(Intent.EXTRA_TEXT, strShareMessage);
                    startActivity(Intent.createChooser(i, resources.getString(R.string.nav_share_via)));
                } catch (Exception e) {
                    //e.toString();
                }
            }
        });

        bookingInfo();

        (new Thread(new Runnable() {

            @Override
            public void run() {
                while (!Thread.interrupted())
                    try {
                        Thread.sleep(3000);
                        runOnUiThread(new Runnable() // start actions in UI thread
                        {

                            @Override
                            public void run() {
                                // this action have to be in UI thread
                            /*noteTS = Calendar.getInstance().getTime();

                            String time = "hh:mm"; // 12:00
                            text.setText(DateFormat.format(time, noteTS));*/
                                locationRequest();
                            }
                        });
                    } catch (InterruptedException e) {


                    }
            }
        })).start();

        initializeViews();

        driverLocationTrackingSosButton.setVisibility(View.GONE);

        if (currentRide.getSosstatus().equals("on")) {

            driverLocationTrackingSosButton.setVisibility(View.VISIBLE);
            startNavigationButton.setText(resources.getString(R.string.start_navigation));
            startNavigationButton.setEnabled(true);
        }


    }

    @Override
    protected void onStart() {
        EventBusManager.getInstance().getEventBus().register(this);
        super.onStart();
    }

    @Override
    protected void onStop() {
        EventBusManager.getInstance().getEventBus().unregister(this);
        super.onStop();
    }

    @Override
    public void onConnected(Bundle bundle) {
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(
                mGoogleApiClient);
        if (mLastLocation != null) {
            lat = mLastLocation.getLatitude();
            lng = mLastLocation.getLongitude();

            /*LatLng loc = new LatLng(lat, lng);
            mMap.addMarker(new MarkerOptions().position(loc).title("New Marker"));
            mMap.moveCamera(CameraUpdateFactory.newLatLng(loc));*/
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        driver_tracking_textView.setText(resources.getString(R.string.driver_tracking));
        ride_token_textView.setText(resources.getString(R.string.ride_token));
        expected_time_textView.setText(resources.getString(R.string.expected_time));
        vehicle_number_textView.setText(resources.getString(R.string.vehicle_number));
        vehicle_type_textView.setText(resources.getString(R.string.vehicle_type));
        driver_mobile_textView.setText(resources.getString(R.string.driver_mobile));
        //cancelridedlt.setText(resources.getString(R.string.cancel_ride));
        startNavigationButton.setText(resources.getString(R.string.waiting_for_driver));
    }

    String cancelType = "";

    public void buildingAlertbox() {
        final RadioGroup radioGroup;
        final TextInputLayout reasonInputLayout;
        final EditText reasonEditText;

        final Dialog dialog = new Dialog(this);
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.cancellation_dialog);

        radioGroup = (RadioGroup) dialog.findViewById(R.id.radioGroup);
        final int buttons = listdata.size();
        int i = 0;
        for (i = 0; i < buttons; i++) {
            RadioButton rbn = new RadioButton(this);

            rbn.setId(View.generateViewId());
            rbn.setText(listdata.get(i));
            radioGroup.addView(rbn);
        }

        radioGroup.clearCheck();
        reasonInputLayout = (TextInputLayout) dialog.findViewById(R.id.cancellationReason);
        reasonEditText = (EditText) dialog.findViewById(R.id.cancelEditTex);


        Button cancel = (Button) dialog.findViewById(R.id.cancel);
        Button no = (Button) dialog.findViewById(R.id.no);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cancelType.equalsIgnoreCase("Others")) {
                    reason = reasonEditText.getText().toString();
                }
                if (reason.trim().equalsIgnoreCase("")) {
                    Toast.makeText(DriverLocationTracking.this, "Please enter reason", Toast.LENGTH_SHORT).show();
                } else {
                    cancelReason();
                }
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = (RadioButton) group.findViewById(checkedId);
                if (null != rb && checkedId > -1) {

                    if (listdata.get(buttons - 1).equalsIgnoreCase(rb.getText().toString())) {
                        reasonInputLayout.setVisibility(View.VISIBLE);
                        reasonEditText.setVisibility(View.VISIBLE);
                        reason = reasonEditText.getText().toString();
                        cancelType = "Others";
                    } else {
                        reasonInputLayout.setVisibility(View.GONE);
                        reasonEditText.setVisibility(View.GONE);
                        reason = rb.getText().toString();
                        cancelType = "";
                    }
                    //Toast.makeText(DriverLocationTracking.this, rb.getText(), Toast.LENGTH_SHORT).show();
                }

            }
        });

        dialog.show();
     /*   final EditText edittext = new EditText(DriverLocationTracking.this);
        edittext.setInputType(InputType.TYPE_CLASS_TEXT);

        edittext.setFilters(new InputFilter[]{new InputFilter.LengthFilter(40)});
        ab.setMessage(resources.getString(R.string.please_enter_the_reason_for_cancellation));
        ab.setTitle(resources.getString(R.string.reason));

        ab.setView(edittext);

        ab.setPositiveButton(resources.getString(R.string.ok), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

                reason = edittext.getText().toString();
                if (reason.equals("")) {
                    Toast.makeText(DriverLocationTracking.this, "Please enter reason", Toast.LENGTH_SHORT).show();
                } else {
                    cancelReason();
                }
            }
        });

        ab.setNegativeButton(resources.getString(R.string.cancel), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

            }
        });

        ab.show();*/

    }

    ArrayList<String> listdata = new ArrayList<String>();

    private void standardComments() {

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                JSONArray jArray = jObj.getJSONArray("comments");
                                if (jArray != null && listdata.size() == 0) {
                                    for (int i = 0; i < jArray.length(); i++) {
                                        listdata.add(jArray.getString(i));
                                    }
                                }
                                buildingAlertbox();

                            } else {

                                String errorMsg = jObj.getString("error_msg");
                                Toast.makeText(DriverLocationTracking.this, errorMsg, Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    LatLng previous_latlng=null;
    LatLng current_latlng=null;


    private void locationRequest() {

        String vehicleType = vehicletype.getText().toString();
        int height = 100;
        int width = 100;

        if (vehicleType.equals("Taxi(4+1)")) {
            bitmapdraw = (BitmapDrawable) getResources().getDrawable(R.drawable.carmarker);
        } else if (vehicleType.equals("Taxi(7+1)")) {
            bitmapdraw = (BitmapDrawable) getResources().getDrawable(R.drawable.carmarker);
        } else if (vehicleType.equalsIgnoreCase("auto")) {
            bitmapdraw = (BitmapDrawable) getResources().getDrawable(R.drawable.auto_selected_ic);
        } else {
            bitmapdraw = (BitmapDrawable) getResources().getDrawable(R.drawable.bike_selected_ic);
        }
        Bitmap b = bitmapdraw.getBitmap();
        final Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);


        StringRequest stringRequest = new StringRequest(Request.Method.POST, updateLocation,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            Log.e("Driverlocation","Drivre location=--"+ jObj.toString());
                            if (!error) {

                                if (mCurrLocationMarker != null) {
                                    mCurrLocationMarker.remove();
                                }

                                String lat = jObj.getString("lat");
                                String longi = jObj.getString("long");

                                value1 = Double.parseDouble(lat);
                                value2 = Double.parseDouble(longi);

                                /*adMarker();*/

                                fromlatitude = lat;
                                fromlongitude = longi;

                                latLng = new LatLng(value1, value2);

                              /*  MarkerOptions markerOptions = new MarkerOptions();
                                markerOptions.position(latLng);
                                markerOptions.title("Current Position");
                                markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA));
                                mCurrLocationMarker = mGoogleMap.addMarker(markerOptions);*/

                               /* mCurrLocationMarker = mGoogleMap.addMarker(new MarkerOptions().position(latLng)
                                        .icon(BitmapDescriptorFactory.fromBitmap((smallMarker))));*/

                                //move map camera
                                if (cameraCount == 1) {
                                    mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                                    mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(16));
                                    cameraCount = 2;
                                }
                                if(previous_latlng==null){
                                    Log.e("previous_latlng","previous_latlng is null");
                                    previous_latlng = new LatLng(value1, value2);
                                    calldata();
                                }else {
                                    //updaterouteinfo();
                                    previous_latlng = new LatLng(value1, value2);
                                    Log.e("previous_latlng","previous_latlng is not null");
                                   /* if (drivertopickuplatlng != null){
                                        for (int i = 0; i < drivertopickuplatlng.size() - 1; i++) {
                                            LatLng segmentP1 = drivertopickuplatlng.get(i);
                                            LatLng segmentP2 = drivertopickuplatlng.get(i + 1);
                                            List<LatLng> segment = new ArrayList<>(2);
                                            segment.add(segmentP1);
                                            segment.add(segmentP2);

                                            if (PolyUtil.isLocationOnPath(latLng, segment, true, 30)) {
                                                Log.e("previous_latlng","previous_latlng is not null isLocationOnPath");
                                                polylineOptions = new PolylineOptions();
                                                polylineOptions.addAll(segment);
                                                polylineOptions.width(10);
                                                polylineOptions.color(Color.RED);
                                                mGoogleMap.addPolyline(polylineOptions);
                                                LatLng snappedToSegment = getMarkerProjectionOnSegment(latLng, segment, mGoogleMap.getProjection());
                                                addMarker(snappedToSegment,BitmapDescriptorFactory.fromBitmap((smallMarker)));
                                                break;
                                            }
                                        }
                                }*/
                                }





                            } else {

                                // Error occurred in registration. Get the error

                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("mobile", drivermobile);


                return params;
            }
        };

        VolleySingleton.getInstance(DriverLocationTracking.this).addToRequestQueue(stringRequest);
    }


    private void bookingInfo() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, driverInfoAfterBooking,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            Log.e("bookingInfo","bookingInfo----------------"+jObj.toString());
                            if (!error) {

                                String rideToken = jObj.getString("ride_token");
                                String driver_name = jObj.getString("drivername");
                                String driver_mobile = jObj.getString("drivermobile");
                                String vehicle_no = jObj.getString("vehicle_no");
                                String vehicle_type = jObj.getString("vehicle_type");
                                String from_place = jObj.getString("fromplace");
                                String to_place = jObj.getString("toplace");
                                String vehicle_model = jObj.getString("vehicle_model");
                                String get_driver_rating = jObj.getString("driver_rating");

                                whenRequerd = jObj.getString("whenrequired");

                                String urlProfileImg = jObj.getString("driver_photo");

                                fromlatitude = jObj.getString("fromlatitude");
                                fromlongitude = jObj.getString("fromlongitude");
                                tolatitude = jObj.getString("tolatitude");
                                tolongitude = jObj.getString("tolongitude");

                                token.setText(rideToken);
                                expectedtime.setText(resources.getString(R.string.coming_soon));
                                driver_rating.setText(get_driver_rating);
                                try {
                                    ratingBar.setRating(Float.parseFloat(get_driver_rating));
                                } catch (NumberFormatException e) {
                                    e.printStackTrace();
                                }

                                vehicleno.setText(vehicle_no);
                                vehicletype.setText(vehicle_type);
                                vehicalSeat.setText(vehicle_type);
                                switch (vehicle_type) {
                                    case "Taxi(4+1)":
                                        selected_vehicle_WhenRequire.setBackgroundResource(R.drawable.car_selected_ic);
                                        break;
                                    case "Auto":
                                        selected_vehicle_WhenRequire.setBackgroundResource(R.drawable.auto_selected_ic);
                                        break;
                                    case "Bike":
                                        selected_vehicle_WhenRequire.setBackgroundResource(R.drawable.bike_selected_ic);
                                        break;
                                    case "Taxi(7+1)":
                                        selected_vehicle_WhenRequire.setBackgroundResource(R.drawable.suv_selected_ic);
                                        break;
                                    case "Taxi(3+1)":
                                        selected_vehicle_WhenRequire.setBackgroundResource(R.drawable.mini);
                                        break;
                                    /*case "Rental":
                                        selected_vehicle_WhenRequire.setBackgroundResource(R.drawable.rentals);
                                        break;*/
                                }
                                drivermobilew.setText(driver_mobile);
                                driver_nameA.setText(driver_name);
                                book_a_ride_from.setText(from_place);
                                book_a_ride_to.setText(to_place);
                                vehicle_model_text.setText(vehicle_model);


                                // Loading profile image
                                Glide.with(DriverLocationTracking.this).load(urlProfileImg)
                                        .crossFade()
                                        .thumbnail(0.5f)
                                        .bitmapTransform(new CircleTransform(DriverLocationTracking.this))
                                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                                        .into(driver_photo);


                                showRouteOnMap(fromlatitude, fromlongitude, tolatitude, tolongitude);


                            } else {

                                // Error occurr.ed in registration. Get the error

                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("id", bookingid);


                return params;
            }
        };

        VolleySingleton.getInstance(DriverLocationTracking.this).addToRequestQueue(stringRequest);

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;


        //Initialize Google Play Services
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {

                mGoogleMap.setMyLocationEnabled(true);
            }
        } else {
            mGoogleMap.setMyLocationEnabled(true);

        }
    }


    @Override
    public void onBackPressed() {
        //        super.onBackPressed();
          /*Intent intent = new Intent(DriverLocationTracking.this, NavHome.class);
          startActivity(intent);
          finish();*/
    }

    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        driverLocationTrackingBackImageView = (ImageView) findViewById(R.id.driverLocationTrackingBackImageView);
        driverLocationTrackingSosButton = (ImageView) findViewById(R.id.driverLocationTrackingSosButton);

        driverLocationTrackingBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Intent intent = new Intent(DriverLocationTracking.this, NavHome.class);
                startActivity(intent);
                finish();*/
            }
        });

        driverLocationTrackingSosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sos();

            }
        });


        startNavigationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String format = "geo:0,0?q=" + tolatitude +
                        "," + tolongitude + "( Destination)";

                Uri uri = Uri.parse(format);

                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    private void sos() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, sosurl,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {


                                callPolice(); //todo call this method


                            } else {


                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();


                params.put("passengermobile", mobile);
                params.put("booking_id", bookingid);


                return params;
            }
        };
        VolleySingleton.getInstance(DriverLocationTracking.this).addToRequestQueue(stringRequest);
    }


    @Subscribe
    public void ottoEventActivityFinish(OttoEventActivityFinish finish) {
        if (finish.getFinishActivity().equals("driverlocationtracking")) {
            currentRide.setIsRideStarted("ended");
            finish();
        }
    }

    public void cancelReason() {

        final ProgressDialog loading = ProgressDialog.show(this, resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, cancelRideUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                startActivity(new Intent(DriverLocationTracking.this, NavHome.class));

                                currentRide.setIsRideStarted("ended");
                                currentRide.setSosStatus("off");


                                finish();


                            } else {
                                String errorMsg = jObj.getString("error_msg");
                                Toast.makeText(DriverLocationTracking.this, errorMsg, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("bookingid", bookingid);
                params.put("reason", reason);
                params.put("drivermobile", drivermobile);
                params.put("passengermobile", mobile);
                params.put("current_lat", String.valueOf(lat));
                params.put("current_long", String.valueOf(lng));

                return params;
            }
        };
        VolleySingleton.getInstance(DriverLocationTracking.this).addToRequestQueue(stringRequest);
    }

    @Subscribe
    public void getRideStatus(OttoRideStarted data) {
        Log.i("Activity", data.getRidestatus());
        URL = afterridestart;
      /*  android.support.v7.app.AlertDialog.Builder builder;
        builder = new android.support.v7.app.AlertDialog.Builder(DriverLocationTracking.this, android.R.style.Theme_Material_Dialog_Alert);

        builder.setTitle("Ride Started")
                .setMessage("Your Ride has been started.")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing
                    }
                }).setIcon(android.R.drawable.ic_dialog_alert)
                .show();*/
        startNavigationButton.setText(resources.getString(R.string.start_navigation));
        startNavigationButton.setEnabled(true);

        currentRide.setSosStatus("on");

        driverLocationTrackingSosButton.setVisibility(View.VISIBLE);

        driver_tracking_textView.setText("Now Your Ride has started");


        String format = "geo:0,0?q=" + tolatitude +
                "," + tolongitude + "( Destination)";

        Uri uri = Uri.parse(format);

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
/*    public void adMarker(){


        LatLng latLng = new LatLng(value1, value2);
        mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

        if(markerCount==1){
            animateMarker(mLastLocation,mk);
        }
        else if (markerCount==0){
            //Set Custom BitMap for Pointer
            int height = 70;
            int width = 110;

            if (vehicletype.equals("Taxi")){
                bitmapdraw = (BitmapDrawable) getResources().getDrawable(R.mipmap.carmarker);
            }
            else
            {

                bitmapdraw = (BitmapDrawable) getResources().getDrawable(R.mipmap.rickshawtopview);

            }

            Bitmap b = bitmapdraw.getBitmap();
            Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);


            mk= mGoogleMap.addMarker(new MarkerOptions().position(latLng)
                    .icon(BitmapDescriptorFactory.fromBitmap((smallMarker))));

           *//* mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlong, 18));*//*
            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(18));

            markerCount=1;

    }}*/

 /*   public static void animateMarker(final Location destination, final Marker marker) {
        if (marker != null) {
            final LatLng startPosition = marker.getPosition();
            final LatLng endPosition = new LatLng(destination.getLatitude(), destination.getLongitude());

            final float startRotation = marker.getRotation();

            final DriverLocationTracking.LatLngInterpolator latLngInterpolator = new DriverLocationTracking.LatLngInterpolator.LinearFixed();
            ValueAnimator valueAnimator = ValueAnimator.ofFloat(0, 1);
            valueAnimator.setDuration(1000); // duration 1 second
            valueAnimator.setInterpolator(new LinearInterpolator());
            valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator animation) {
                    try {
                        float v = animation.getAnimatedFraction();
                        LatLng newPosition = latLngInterpolator.interpolate(v, startPosition, endPosition);
                        marker.setPosition(newPosition);
                        marker.setRotation(computeRotation(v, startRotation, destination.getBearing()));
                    } catch (Exception ex) {
                        // I don't care atm..
                    }
                }
            });

            valueAnimator.start();
        }
    }

    private interface LatLngInterpolator {
        LatLng interpolate(float fraction, LatLng a, LatLng b);

        class LinearFixed implements DriverLocationTracking.LatLngInterpolator {
            @Override
            public LatLng interpolate(float fraction, LatLng a, LatLng b) {
                double lat = (b.latitude - a.latitude) * fraction + a.latitude;
                double lngDelta = b.longitude - a.longitude;
                // Take the shortest path across the 180th meridian.
                if (Math.abs(lngDelta) > 180) {
                    lngDelta -= Math.signum(lngDelta) * 360;
                }
                double lng = lngDelta * fraction + a.longitude;
                return new LatLng(lat, lng);
            }
        }
    }*/

/*    private static float computeRotation(float fraction, float start, float end) {
        float normalizeEnd = end - start; // rotate start to 0
        float normalizedEndAbs = (normalizeEnd + 360) % 360;

        float direction = (normalizedEndAbs > 180) ? -1 : 1; // -1 = anticlockwise, 1 = clockwise
        float rotation;
        if (direction > 0) {
            rotation = normalizedEndAbs;
        } else {
            rotation = normalizedEndAbs - 360;
        }

        float result = fraction * rotation + start;
        return (result + 360) % 360;
    }*/


    }


    public void callPolice() {

        ab.setMessage(resources.getString(R.string.call_police));
        ab.setTitle(resources.getString(R.string.call_to_the_police_station));
        ab.setPositiveButton(resources.getString(R.string.ok), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

                String phone_no = "9036008829";
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + phone_no));
                callIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (ActivityCompat.checkSelfPermission(DriverLocationTracking.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                startActivity(callIntent);
            }
        });

        ab.setNegativeButton(resources.getString(R.string.cancel), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

            }
        });

        ab.show();

    }


    private void showRouteOnMap(String fromlatitude, String fromlongitude, String tolatitude, String tolongitude) {

        // These points are your markers coordinates
        LatLng origin = new LatLng(Double.parseDouble(fromlatitude), Double.parseDouble(fromlongitude));
        LatLng dest = new LatLng(Double.parseDouble(tolatitude), Double.parseDouble(tolongitude));

        // Getting URL to the Google Directions API
        String url = getDirectionsUrl(origin, dest);
        DownloadTask downloadTask = new DownloadTask();

        // Creating a marker
        MarkerOptions markerOptions1 = new MarkerOptions();
        markerOptions1.position(origin);
        // Creating a marker2
        MarkerOptions markerOptions2 = new MarkerOptions();
        markerOptions2.position(origin);


// Start downloading json data from Google Directions API
        downloadTask.execute(url);
        sendRequest();

    }


    private String getDirectionsUrl(LatLng origin, LatLng dest) {


        // Origin of route
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;

        // Destination of route
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;

        // Sensor enabled
        String sensor = "sensor=false";

        // Building the parameters to the web service
        String parameters = str_origin + "&" + str_dest + "&" + sensor;

        // Output format
        String output = "json";

        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;

        return url;
    }


    /**
     * A method to download json data from url
     */
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {


            URL url = new URL(strUrl);

            // Creating an http connection to communicate with url
            urlConnection = (HttpURLConnection) url.openConnection();

            // Connecting to url
            urlConnection.connect();

            // Reading data from url
            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();

            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        } catch (Exception e) {

        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }


    @Override
    public void onDirectionFinderSuccess(List<Route> routes) {
        //progressDialog.dismiss();
        polylinePaths = new ArrayList<>();
        originMarkers = new ArrayList<>();
        drivertopickuplatlng=new ArrayList<>();
         polylineOptions = new PolylineOptions();

        destinationMarkers = new ArrayList<>();


        for (Route route : routes) {
            mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(route.startLocation, 12));
            /*((TextView) findViewById(R.id.tvDuration)).setText(route.duration.text);
            ((TextView) findViewById(R.id.tvDistance)).setText(route.distance.text);*/

            originMarkers.add(mGoogleMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker))
                    .title(route.startAddress)
                    .position(route.startLocation)));
            destinationMarkers.add(mGoogleMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker))
                    .title(route.endAddress)
                    .position(route.endLocation)));

              polylineOptions = new PolylineOptions().
                    geodesic(true).
                    color(Color.BLUE).
                    width(10);

            for (int i = 0; i < route.points.size(); i++) {
                polylineOptions.add(route.points.get(i));
                drivertopickuplatlng.add(route.points.get(i));

            }

            polylinePaths.add(mGoogleMap.addPolyline(polylineOptions));
        }
    }
    boolean readjsonfile=true;
    private void calldata(){



        if(readjsonfile) {
            readjsonfile=false;

                DownloadRawData parserTask = new DownloadRawData();
                parserTask.execute("");


        }
    }

    private class DownloadRawData extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {

            String json = null;
            try {
                InputStream is = getAssets().open("driverlocation.json");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                json = new String(buffer, "UTF-8");
                return json;
            } catch (IOException ex) {
                ex.printStackTrace();

            }
            return null;
        }

        @Override
        protected void onPostExecute(String res) {
            try {
                parseJSon(res);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void parseJSon(String data) throws JSONException {
        if (data == null)
            return;

        List<Route> routes = new ArrayList<Route>();
        JSONObject jsonData = new JSONObject(data);
        JSONArray jsonRoutes = jsonData.getJSONArray("routes");
        for (int i = 0; i < jsonRoutes.length(); i++) {
            JSONObject jsonRoute = jsonRoutes.getJSONObject(i);
            Route route = new Route();

            JSONObject overview_polylineJson = jsonRoute.getJSONObject("overview_polyline");
            JSONArray jsonLegs = jsonRoute.getJSONArray("legs");
            JSONObject jsonLeg = jsonLegs.getJSONObject(0);
            JSONObject jsonDistance = jsonLeg.getJSONObject("distance");
            JSONObject jsonDuration = jsonLeg.getJSONObject("duration");
            JSONObject jsonEndLocation = jsonLeg.getJSONObject("end_location");
            JSONObject jsonStartLocation = jsonLeg.getJSONObject("start_location");

            route.distance = new Distance(jsonDistance.getString("text"), jsonDistance.getInt("value"));
            route.duration = new Duration(jsonDuration.getString("text"), jsonDuration.getInt("value"));
            route.endAddress = jsonLeg.getString("end_address");
            route.startAddress = jsonLeg.getString("start_address");
            route.startLocation = new LatLng(jsonStartLocation.getDouble("lat"), jsonStartLocation.getDouble("lng"));
            route.endLocation = new LatLng(jsonEndLocation.getDouble("lat"), jsonEndLocation.getDouble("lng"));
            route.points = decodePolyLine(overview_polylineJson.getString("points"));
            polyLineList = decodePolyLine(overview_polylineJson.getString("points"));
            routes.add(route);
        }
        drawPolyLineAndAnimateCar();
      //  onDirectionFinderSuccess(routes);
    }

    private List<LatLng> decodePolyLine(final String poly) {
        int len = poly.length();
        int index = 0;
        List<LatLng> decoded = new ArrayList<LatLng>();
        int lat = 0;
        int lng = 0;

        while (index < len) {
            int b;
            int shift = 0;
            int result = 0;
            do {
                b = poly.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = poly.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            decoded.add(new LatLng(
                    lat / 100000d, lng / 100000d
            ));
        }

        return decoded;
    }



    @Override
    public void onDirectionFinderStart() {
        // progressDialog = ProgressDialog.show(this, resources.getString(R.string.please_wait),
        //    resources.getString(R.string.finding_direction), true);

        if (originMarkers != null) {
            for (Marker marker : originMarkers) {
                marker.remove();
            }
        }

        if (destinationMarkers != null) {
            for (Marker marker : destinationMarkers) {
                marker.remove();
            }
        }

        if (polylinePaths != null) {
            for (Polyline polyline : polylinePaths) {
                polyline.remove();
            }
        }
    }

    private void sendRequest() {

        String origin = fromlatitude + "," + fromlongitude;
        String destination = tolatitude + "," + tolongitude;

        try {
            new DirectionFinder(this, origin, destination).execute();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    // Fetches data from url passed
    List<LatLng> drivertopickuplatlng=null;
    PolylineOptions polylineOptions = null;
    private class DownloadTask extends AsyncTask<String, Void, String> {

        // Downloading data in non-ui thread
        @Override
        protected String doInBackground(String... url) {

            // For storing data from web service
            String data = "";

            try {
                // Fetching the data from web service
                data = downloadUrl(url[0]);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        // Executes in UI thread, after the execution of
        // doInBackground()
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ParserTask parserTask = new ParserTask();

            // Invokes the thread for parsing the JSON data
            parserTask.execute(result);
        }
    }

    /**
     * A class to parse the Google Places in JSON format
     */
    private class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {

        // Parsing the data in non-ui thread
        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try {
                jObject = new JSONObject(jsonData[0]);
                DirectionsJSONParser parser = new DirectionsJSONParser();

                // Starts parsing data
                routes = parser.parse(jObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return routes;
        }

        // Executes in UI thread, after the parsing process
        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {


            MarkerOptions markerOptions = new MarkerOptions();
             drivertopickuplatlng=null;
             polylineOptions = null;
            // Traversing through all the routes
            for (int i = 0; i < result.size(); i++) {
                drivertopickuplatlng = new ArrayList<LatLng>();
                polylineOptions = new PolylineOptions();

                // Fetching i-th route
                List<HashMap<String, String>> path = result.get(i);

                // Fetching all the points in i-th route
                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);

                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);

                    drivertopickuplatlng.add(position);
                }

                // Adding all the points in the route to LineOptions
                polylineOptions.addAll(drivertopickuplatlng);
                polylineOptions.width(5);
                polylineOptions.color(Color.RED);
            }

            // Drawing polyline in the Google Map for the i-th route
            /*mGoogleMap.addPolyline(lineOptions);*/
        }
    }

    private LatLng getMarkerProjectionOnSegment(LatLng carPos, List<LatLng> segment, Projection projection) {
        LatLng markerProjection = null;

        Point carPosOnScreen = projection.toScreenLocation(carPos);
        Point p1 = projection.toScreenLocation(segment.get(0));
        Point p2 = projection.toScreenLocation(segment.get(1));
        Point carPosOnSegment = new Point();

        float denominator = (p2.x - p1.x) * (p2.x - p1.x) + (p2.y - p1.y) * (p2.y - p1.y);
        // p1 and p2 are the same
        if (Math.abs(denominator) <= 1E-10) {
            markerProjection = segment.get(0);
        } else {
            float t = (carPosOnScreen.x * (p2.x - p1.x) - (p2.x - p1.x) * p1.x
                    + carPosOnScreen.y * (p2.y - p1.y) - (p2.y - p1.y) * p1.y) / denominator;
            carPosOnSegment.x = (int) (p1.x + (p2.x - p1.x) * t);
            carPosOnSegment.y = (int) (p1.y + (p2.y - p1.y) * t);
            markerProjection = projection.fromScreenLocation(carPosOnSegment);
        }
        return markerProjection;
    }

    public void addMarker(LatLng latLng,BitmapDescriptor smallMarker) {

        mCurrLocationMarker = mGoogleMap.addMarker(new MarkerOptions().position(latLng)
                .icon(smallMarker));
        /*mGoogleMap.addMarker(new MarkerOptions()
                .position(latLng)
        );
*/    }

    private int index, next;
    private Handler handler;
    private LatLng startPosition, endPosition;
    private PolylineOptions  blackPolylineOptions;
    private Polyline blackPolyline, greyPolyLine;
    private Marker marker;
    private float v;
    private void drawPolyLineAndAnimateCar() {
        //Adjusting bounds
        LatLngBounds.Builder builder = new LatLngBounds.Builder();

        for (LatLng latLng : polyLineList) {
            builder.include(latLng);
        }
        LatLngBounds bounds = builder.build();
        CameraUpdate mCameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, 2);
        mGoogleMap.animateCamera(mCameraUpdate);

        polylineOptions = new PolylineOptions();
        polylineOptions.color(Color.GRAY);
        polylineOptions.width(5);
        polylineOptions.startCap(new SquareCap());
        polylineOptions.endCap(new SquareCap());
        polylineOptions.jointType(ROUND);
        polylineOptions.addAll(polyLineList);
        greyPolyLine = mGoogleMap.addPolyline(polylineOptions);

        blackPolylineOptions = new PolylineOptions();
        blackPolylineOptions.width(5);
        blackPolylineOptions.color(Color.BLACK);
        blackPolylineOptions.startCap(new SquareCap());
        blackPolylineOptions.endCap(new SquareCap());
        blackPolylineOptions.jointType(ROUND);
        blackPolyline = mGoogleMap.addPolyline(blackPolylineOptions);

        mGoogleMap.addMarker(new MarkerOptions()
                .position(polyLineList.get(polyLineList.size() - 1)));

        ValueAnimator polylineAnimator = ValueAnimator.ofInt(0, 100);
        polylineAnimator.setDuration(2000);
        polylineAnimator.setInterpolator(new LinearInterpolator());
        polylineAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                List<LatLng> points = greyPolyLine.getPoints();
                int percentValue = (int) valueAnimator.getAnimatedValue();
                int size = points.size();
                int newPoints = (int) (size * (percentValue / 100.0f));
                List<LatLng> p = points.subList(0, newPoints);
                blackPolyline.setPoints(p);
            }
        });
        polylineAnimator.start();
        marker = mGoogleMap.addMarker(new MarkerOptions().position(previous_latlng)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.carmarker)));
         handler = new Handler();
        index = -1;
        next = 1;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (index < polyLineList.size() - 1) {
                    index++;
                    next = index + 1;
                }
                if (index < polyLineList.size() - 1) {
                    startPosition = polyLineList.get(index);
                    endPosition = polyLineList.get(next);
                }
                if (index == 0) {
                    BeginJourneyEvent beginJourneyEvent = new BeginJourneyEvent();
                    beginJourneyEvent.setBeginLatLng(startPosition);
                    JourneyEventBus.getInstance().setOnJourneyBegin(beginJourneyEvent);
                }
                if (index == polyLineList.size() - 1) {
                    EndJourneyEvent endJourneyEvent = new EndJourneyEvent();
                    endJourneyEvent.setEndJourneyLatLng(new LatLng(polyLineList.get(index).latitude,
                            polyLineList.get(index).longitude));
                    JourneyEventBus.getInstance().setOnJourneyEnd(endJourneyEvent);
                }
                ValueAnimator valueAnimator = ValueAnimator.ofFloat(0, 1);
                valueAnimator.setDuration(3000);
                valueAnimator.setInterpolator(new LinearInterpolator());
                valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator valueAnimator) {
                        v = valueAnimator.getAnimatedFraction();
                        lng = v * endPosition.longitude + (1 - v)
                                * startPosition.longitude;
                        lat = v * endPosition.latitude + (1 - v)
                                * startPosition.latitude;
                        LatLng newPos = new LatLng(lat, lng);
                        CurrentJourneyEvent currentJourneyEvent = new CurrentJourneyEvent();
                        currentJourneyEvent.setCurrentLatLng(newPos);
                        JourneyEventBus.getInstance().setOnJourneyUpdate(currentJourneyEvent);
                        marker.setPosition(newPos);
                        marker.setAnchor(0.5f, 0.5f);
                        marker.setRotation(getBearing(startPosition, newPos));
                        mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition
                                (new CameraPosition.Builder().target(newPos)
                                        .zoom(15.5f).build()));
                    }
                });
                valueAnimator.start();
                if (index != polyLineList.size() - 1) {
                    handler.postDelayed(this, 3000);
                }
            }
        }, 3000);
    }
    private float getBearing(LatLng begin, LatLng end) {
        double lat = Math.abs(begin.latitude - end.latitude);
        double lng = Math.abs(begin.longitude - end.longitude);

        if (begin.latitude < end.latitude && begin.longitude < end.longitude)
            return (float) (Math.toDegrees(Math.atan(lng / lat)));
        else if (begin.latitude >= end.latitude && begin.longitude < end.longitude)
            return (float) ((90 - Math.toDegrees(Math.atan(lng / lat))) + 90);
        else if (begin.latitude >= end.latitude && begin.longitude >= end.longitude)
            return (float) (Math.toDegrees(Math.atan(lng / lat)) + 180);
        else if (begin.latitude < end.latitude && begin.longitude >= end.longitude)
            return (float) ((90 - Math.toDegrees(Math.atan(lng / lat))) + 270);
        return -1;
    }
}