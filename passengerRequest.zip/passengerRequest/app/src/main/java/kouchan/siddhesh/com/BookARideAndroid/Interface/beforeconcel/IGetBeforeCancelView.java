package kouchan.siddhesh.com.BookARideAndroid.Interface.beforeconcel;

import java.util.ArrayList;

public interface IGetBeforeCancelView {

    void getBeforeCancelSuccess(int pid, ArrayList<String> faq);

    void getBeforeCancelError(int pid, String error);

}
