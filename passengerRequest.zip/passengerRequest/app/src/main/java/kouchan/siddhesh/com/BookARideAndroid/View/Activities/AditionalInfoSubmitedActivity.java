package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import kouchan.siddhesh.com.BookARideAndroid.R;

public class AditionalInfoSubmitedActivity extends AppCompatActivity {

    Button thanks_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        thanks_button=(Button)findViewById(R.id.thanks_button);

        thanks_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AditionalInfoSubmitedActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed()
    {
        // code here to show dialog
        super.onBackPressed();
        Intent intent= new Intent(getApplicationContext(), NavHome.class);
        startActivity(intent);
        finish();
    }
}
