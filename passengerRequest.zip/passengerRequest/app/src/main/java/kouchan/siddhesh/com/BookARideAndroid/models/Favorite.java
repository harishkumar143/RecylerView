package kouchan.siddhesh.com.BookARideAndroid.models;

/**
 * Created by KOUCHAN-ADMIN on 3/23/2018.
 */

public class Favorite {

    String type;
    String address;
    String tolatitude;
    String tolongitude;
    String latlongtype;

    public Favorite(String type, String address, String tolatitude, String tolongitude,String latlongtype) {
        this.type = type;
        this.address = address;
        this.tolatitude = tolatitude;
        this.tolongitude = tolongitude;
        this.latlongtype=latlongtype;
    }

    public String getType() {
        return type;
    }

    public String getAddress() {
        return address;
    }

    public String getTolatitude() {
        return tolatitude;
    }

    public String getTolongitude() {
        return tolongitude;
    }
    public String getLatlongtype() {
        return latlongtype;
    }
}
