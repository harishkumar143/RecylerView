package kouchan.siddhesh.com.BookARideAndroid.Interface.getprofile;

public interface IGetProfileView {

    void getProfileSuccess(int pid, String balance);

    void getProfileError(int pid, String error);

}
