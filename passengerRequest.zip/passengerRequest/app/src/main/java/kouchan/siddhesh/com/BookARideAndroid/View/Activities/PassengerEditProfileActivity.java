package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.functions.Functions;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

public class PassengerEditProfileActivity extends AppCompatActivity implements View.OnClickListener {
    EditText mobile, name, emailid, dob, alternatename, alternatemobile, gender, pinno, aadharcard;

    ImageButton editmobile, editname, editemailid, editdob, editalternatename, editalternatemobile, editgender, editaddress, editpinno, editaadharcard;

    ImageView passenger_profile_BackImageView;
    Toolbar mToolbar;

    Button editButton;

    RadioGroup gender_options;
    boolean isGenderSelected;
    String stringGenderOptions;
    RadioButton male, female, other;
    TextView register_gender, passenger_profile_textView;

    TextInputLayout mobile_no_TextInputLayout, edit_name_TextInputLayout, aadhar_card_TextInputLayout,
            email_id_TextInputLayout, birth_date_TextInputLayout, alternatename_TextInputLayout,
            alternate_mobilenumber_TextInputLayout, address_TextInputLayout, building_name_no_TextInputLayout,
            street_name_TextInputLayout, city_TextInputLayout, pincode_TextInputLayout, state_TextInputLayout;

    String languageCode;
    Resources resources;

    String passengerProfileUrl = Url.PASSENGER_API + "getPassengerProfile.php";

    String passengerProfileUpdateUrl = Url.PASSENGER_API + "editProfileOfPassenger.php";

    String isValid, stringName, stringEmail_ID, stringMobile, stringDob, stringAlternateName, stringAlternateMobile,
            stringGender, stringState, stringPinNo, stringAadharNo;

    ProgressDialog loading;

    String verifiedPassword;

    private AwesomeValidation awesomeValidation;

    AlertDialog.Builder ab;

    SessionManager sessionManager;
    HashMap<String, String> user = new HashMap<String, String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_edit_profile);
        /*getSupportActionBar().setDisplayHomeAsUpEnabled(true);*/
        initializeWidgets();
        ab = new AlertDialog.Builder(PassengerEditProfileActivity.this);

        sessionManager = new SessionManager(getApplicationContext());
        user = sessionManager.getUserDetails();
        stringMobile = user.get("mobile");

        receiverValuesOfPassenger();
        chooseOptions();


        /*setValues();*/

      /*  editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendValues();
            }
        });*/

        editemailid.setOnClickListener(this);
      /*  editmobile.setOnClickListener(this);*/
        editname.setOnClickListener(this);
        editalternatename.setOnClickListener(this);
        editalternatemobile.setOnClickListener(this);
       /* editaddress.setOnClickListener(this);*/
        editpinno.setOnClickListener(this);
       /* editstate.setOnClickListener(this);*/
        /*editgender.setOnClickListener(this);*/
        /*editdob.setOnClickListener(this);*/
        editaadharcard.setOnClickListener(this);

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        initializeViews();
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
/*
        register_gender.setText(resources.getString(R.string.forgot_password));
        passenger_profile_textView.setText(resources.getString(R.string.forgot_password));
        editButton.setText(resources.getString(R.string.save));

        mobile_no_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        edit_name_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        aadhar_card_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        email_id_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        birth_date_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        alternatename_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        alternate_mobilenumber_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        address_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        building_name_no_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        street_name_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        city_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        pincode_TextInputLayout.setHint(resources.getString(R.string.enter_otp));
        state_TextInputLayout.setHint(resources.getString(R.string.enter_otp));*/

    }

    private void initializeWidgets() {

        passenger_profile_BackImageView = (ImageView) findViewById(R.id.passenger_profile_BackImageView);
        editemailid = (ImageButton) findViewById(R.id.edit_register_emailid);
        //   editmobile = (ImageButton) findViewById(R.id.edit_register_mobile);
        editname = (ImageButton) findViewById(R.id.edit_register_name);
        editalternatename = (ImageButton) findViewById(R.id.edit_register_alternatename);
        editalternatemobile = (ImageButton) findViewById(R.id.edit_register_alternate_mobilenumber);
       /* editaddress = (ImageButton) findViewById(R.id.edit_register_address);*/
        editpinno = (ImageButton) findViewById(R.id.edit_register_pinno);
        /*editstate = (ImageButton) findViewById(R.id.edit_register_state);*/
        // editgender = (ImageButton) findViewById(R.id.edit_register_gender_options);
        //  editdob = (ImageButton) findViewById(R.id.edit_register_dob);
        editaadharcard = (ImageButton) findViewById(R.id.edit_register_aadhar_card);


        emailid = (EditText) findViewById(R.id.edit_emailid);
        mobile = (EditText) findViewById(R.id.edit_mobile);
        name = (EditText) findViewById(R.id.edit_name);
        dob = (EditText) findViewById(R.id.edit_dob);
        dob.setFocusable(false);
        alternatename = (EditText) findViewById(R.id.edit_alternatename);
        alternatemobile = (EditText) findViewById(R.id.edit_alternate_mobilenumber);
        /*address = (EditText) findViewById(R.id.edit_address);*/
        pinno = (EditText) findViewById(R.id.edit_pinno);
       /* state = (EditText) findViewById(R.id.edit_state);*/
        //  gender = (EditText) findViewById(R.id.edit_gender_options);
        aadharcard = (EditText) findViewById(R.id.edit_aadhar_card);
        editButton = (Button) findViewById(R.id.edit_button);

        gender_options = (RadioGroup) findViewById(R.id.register_gender_options);
        male = (RadioButton) findViewById(R.id.register_male);
        female = (RadioButton) findViewById(R.id.register_female);
        other = (RadioButton) findViewById(R.id.register_other);
        register_gender = (TextView) findViewById(R.id.register_gender);

        passenger_profile_textView = (TextView) findViewById(R.id.passenger_profile_textView);

        mobile_no_TextInputLayout = (TextInputLayout) findViewById(R.id.mobile_no_TextInputLayout);
        edit_name_TextInputLayout = (TextInputLayout) findViewById(R.id.edit_name_TextInputLayout);
        aadhar_card_TextInputLayout = (TextInputLayout) findViewById(R.id.aadhar_card_TextInputLayout);
        email_id_TextInputLayout = (TextInputLayout) findViewById(R.id.email_id_TextInputLayout);
        birth_date_TextInputLayout = (TextInputLayout) findViewById(R.id.birth_date_TextInputLayout);
        alternatename_TextInputLayout = (TextInputLayout) findViewById(R.id.alternatename_TextInputLayout);
        alternate_mobilenumber_TextInputLayout = (TextInputLayout) findViewById(R.id.alternate_mobilenumber_TextInputLayout);
      /*  address_TextInputLayout = (TextInputLayout) findViewById(R.id.address_TextInputLayout);
        building_name_no_TextInputLayout = (TextInputLayout) findViewById(R.id.building_name_no_TextInputLayout);
        street_name_TextInputLayout = (TextInputLayout) findViewById(R.id.street_name_TextInputLayout);
        city_TextInputLayout = (TextInputLayout) findViewById(R.id.city_TextInputLayout);*/
        pincode_TextInputLayout = (TextInputLayout) findViewById(R.id.pincode_TextInputLayout);
     /*   state_TextInputLayout = (TextInputLayout) findViewById(R.id.state_TextInputLayout);*/

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        awesomeValidation.addValidation(this, R.id.edit_emailid, Patterns.EMAIL_ADDRESS, R.string.emailerror);
        awesomeValidation.addValidation(this, R.id.edit_mobile, "^[7-9]{1}[0-9]{9}$", R.string.mobileerror);
        awesomeValidation.addValidation(this, R.id.edit_name, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.nameerror);
        awesomeValidation.addValidation(this, R.id.edit_alternatename, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.altnameerror);
        awesomeValidation.addValidation(this, R.id.edit_alternate_mobilenumber, "^[7-9]{1}[0-9]{9}$", R.string.altmobileerror);
/*
        awesomeValidation.addValidation(this, R.id.edit_address, "^.{1,}$", R.string.addresserror);
*/
        awesomeValidation.addValidation(this, R.id.edit_pinno, "^[1-9]{1}[0-9]{5}$", R.string.pincodeerror);
/*
        awesomeValidation.addValidation(this, R.id.edit_state, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.statenameerror);
*/
        awesomeValidation.addValidation(this, R.id.edit_aadhar_card, "^[2-9]{1}[0-9]{11}$", R.string.aadharcardnoerror);

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                saveEditProfile();

            }
        });

    }

    public void showDatePickerDialog(View view) {
        Calendar mcurrentTime = Calendar.getInstance();
        int day = mcurrentTime.get(Calendar.DAY_OF_MONTH);
        int month = mcurrentTime.get(Calendar.DAY_OF_MONTH);
        int year = mcurrentTime.get(Calendar.YEAR);
        DatePickerDialog mDatePicker;
        mDatePicker = new DatePickerDialog(PassengerEditProfileActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                dob.setText(dayOfMonth + "/" + month + "/" + year);
            }
        }, year, month, day);//Yes 24 hour time
        mDatePicker.setTitle(resources.getString(R.string.select_time));
        mDatePicker.show();
        dob.setFocusable(true);
    }

    public void chooseOptions() {
        gender_options.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {

                    case R.id.register_male:
                        stringGenderOptions = "male";
                        isGenderSelected = true;
                        register_gender.setError(null);
                        break;

                    case R.id.register_female:
                        stringGenderOptions = "female";
                        isGenderSelected = true;
                        break;

                    case R.id.register_other:
                        stringGenderOptions = "other";
                        isGenderSelected = true;
                        register_gender.setError(null);
                        break;
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId() /*to get clicked view id**/) {
            case R.id.edit_register_emailid:

                emailid.setEnabled(true);

                break;

            case R.id.edit_register_name:

                name.setEnabled(true);

                break;
            case R.id.edit_register_alternatename:

                alternatename.setEnabled(true);

                break;
            case R.id.edit_register_alternate_mobilenumber:

                alternatemobile.setEnabled(true);

                break;

            case R.id.edit_register_pinno:

                pinno.setEnabled(true);

                break;

            case R.id.edit_register_aadhar_card:

                gender.setEnabled(true);

                break;

            default:
                break;
        }
    }

    private void receiverValuesOfPassenger() {

        if(Utils.isInternetAvailable(PassengerEditProfileActivity.this)) {

            Utils.showProgress(PassengerEditProfileActivity.this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, passengerProfileUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Utils.stopProgress(PassengerEditProfileActivity.this);
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                /*stringStatus=jObj.getString("status");*/
                                stringName = jObj.getString("name");
                                stringEmail_ID = jObj.getString("email");
                                stringMobile = jObj.getString("mobile");
                                stringDob = jObj.getString("bdate");
                                stringAlternateName = jObj.getString("alternateName");
                                stringAlternateMobile = jObj.getString("alternateMobile");
                                stringGender = jObj.getString("gender");
                                stringPinNo = jObj.getString("pin");
                                stringAadharNo = jObj.getString("adharno");
                               /* startActivity(new Intent(PassengerEditProfileActivity.this,NavHome.class));
                                finish();*/
                                emailid.setText(stringEmail_ID);
                                mobile.setText(stringMobile);
                                name.setText(stringName);
                                dob.setText(stringDob);
                                alternatename.setText(stringAlternateName);
                                alternatemobile.setText(stringAlternateMobile);
                                    /*address.setText(stringAddress);*/
                                pinno.setText(stringPinNo);
                                 /*   state.setText(stringState);*/
                                   /* gender.setText(stringGender);*/
                                aadharcard.setText(stringAadharNo);

                            } else {

                                // Error occurred in registration. Get the error
                                // message
                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Utils.stopProgress(PassengerEditProfileActivity.this);
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("mobile", stringMobile);
                return params;
            }

        };

        VolleySingleton.getInstance(PassengerEditProfileActivity.this).addToRequestQueue(stringRequest);
        }else {

            Utils.showToast(PassengerEditProfileActivity.this,"please connect to the internate");
        }
    }

    public void saveEditProfile() {

        stringAlternateName = alternatename.getText().toString();
        stringAlternateMobile = alternatemobile.getText().toString();
        stringPinNo = pinno.getText().toString();
        stringEmail_ID = emailid.getText().toString();

        if (!(awesomeValidation.validate())) {

            //process the data further
        } else if (!(Functions.isNumberSame(stringMobile, stringAlternateMobile))) {
            dob.setError(null);
            dob.clearFocus();
            alternatemobile.setError(resources.getString(R.string.same_mobile));

        } else {

            alternatemobile.setError(null);
            alternatemobile.clearFocus();

            if(Utils.isInternetAvailable(PassengerEditProfileActivity.this)) {

                Utils.showProgress(PassengerEditProfileActivity.this);

            StringRequest stringRequestSaveProfile = new StringRequest(Request.Method.POST, passengerProfileUpdateUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                Utils.stopProgress(PassengerEditProfileActivity.this);
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {

                                    Intent i = new Intent(PassengerEditProfileActivity.this, NavHome.class);
                                    startActivity(i);
                                    finish();

                                } else {

                                    // Error occurred in registration. Get the error
                                    // message
                                    String errorMsg = jObj.getString("error_msg");
                                 }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Utils.stopProgress(PassengerEditProfileActivity.this);
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("mobile", stringMobile);
                    params.put("email", stringEmail_ID);
                    params.put("alternateName", stringAlternateName);
                    params.put("alternateMobile", stringAlternateMobile);
                    params.put("pin", stringPinNo);
                    return params;
                }
            };

            VolleySingleton.getInstance(PassengerEditProfileActivity.this).addToRequestQueue(stringRequestSaveProfile);
            }else {

                Utils.showToast(PassengerEditProfileActivity.this,"please connect to the internate");
            }
        }
}


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(PassengerEditProfileActivity.this, NavHome.class);
        startActivity(intent);
        finish();
    }
    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        passenger_profile_BackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(PassengerEditProfileActivity.this,NavHome.class);
                startActivity(intent);
                finish();
            }
        });

    }

}


