package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fr.ganfra.materialspinner.MaterialSpinner;
import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.R;


public class MailQueryActivity extends AppCompatActivity {

    MaterialSpinner subjectSpinner;
    EditText qyeryEditText;
    TextView contactUsRefNumber;
    Button submitButton;
    ImageView nav_about_usBackImageView;
    List spinnerItems = new ArrayList();
    ArrayAdapter spinnerAdaper;
    String bookingId;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mail_query);
        sessionManager = new SessionManager(this);
        intializeViews();
        subjectApiCall();
    }

    private void intializeViews() {
        subjectSpinner = (MaterialSpinner) findViewById(R.id.subjectSpinner);
        qyeryEditText = (EditText) findViewById(R.id.qyeryEditText);
        submitButton = (Button) findViewById(R.id.submitButton);
        nav_about_usBackImageView = (ImageView) findViewById(R.id.nav_about_usBackImageView);
        contactUsRefNumber = (TextView) findViewById(R.id.contactUsRefNumber);

        Intent i = getIntent();
        if (i != null) {
            bookingId = i.getStringExtra("bookingId");
        }
        contactUsRefNumber.setText(bookingId);


        spinnerAdaper = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, spinnerItems);
        spinnerAdaper.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subjectSpinner.setAdapter(spinnerAdaper);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitQueryApiCall();
            }
        });

        nav_about_usBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }


    private void submitQueryApiCall() {

        String url = Url.PASSENGER_API + "complaintregister.php";
        // final ProgressDialog loading = ProgressDialog.show(getApplicationContext(),resources.getString(R.string.processing),resources.getString(R.string.please_wait),false,false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            if (!error) {
                                Toast.makeText(MailQueryActivity.this, jsonObj.getString("message"), Toast.LENGTH_SHORT).show();
                                finish();
                                Intent i = new Intent(MailQueryActivity.this, TrackComplentActivity.class);
                                startActivity(i);
                            } else {
                                String errorMsg = jsonObj.getString("error_msg");
                                Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                        //          loading.dismiss();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("booking_id", bookingId);
                params.put("user_id", sessionManager.getId());
                params.put("complaint_type", subjectSpinner.getSelectedItem().toString());
                params.put("comments", qyeryEditText.getText().toString());
                params.put("user_type", sessionManager.getType());
                return params;
            }

        };
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }

    private void subjectApiCall() {
        String url = Url.COMUNICATE_API + "get_comments.php?user_type=PASSENGER&comment_type=HELP";
        // final ProgressDialog loading = ProgressDialog.show(getApplicationContext(),resources.getString(R.string.processing),resources.getString(R.string.please_wait),false,false);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //                   loading.dismiss();
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            if (!error) {
                                JSONArray contacts = jsonObj.getJSONArray("comments");

                                for (int i = 0; i < contacts.length(); i++) {
                                    String s = contacts.getString(i);
                                    spinnerItems.add(s);
                                }
                            } else {
                                String errorMsg = jsonObj.getString("error_msg");
                                Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                        //          loading.dismiss();
                    }
                });
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);


    }
}
