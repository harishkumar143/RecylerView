package kouchan.siddhesh.com.BookARideAndroid.Interface.changedestination;

public interface IChangeDestinationView {

    void changeDestinationSuccess(int pid, String response);

    void changeDestinationError(int pid, String error);

}
