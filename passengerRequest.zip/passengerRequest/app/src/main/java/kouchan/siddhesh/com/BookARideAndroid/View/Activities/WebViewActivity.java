package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

import kouchan.siddhesh.com.BookARideAndroid.R;

public class WebViewActivity extends AppCompatActivity {

    private WebView webview;
    private TextView webViewName;
    private ImageView webviewBackbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_web_view );

        Bundle bundle = getIntent().getExtras();
        String url = bundle.getString( "url" );
        String action_bar_name = bundle.getString( "action_bar_name" );
        webViewName = (TextView) findViewById( R.id.webViewName );
        webViewName.setText( action_bar_name );
        webview = (WebView) findViewById( R.id.webview );
        webview.setWebViewClient( new WebViewClient() );
        webview.loadUrl( url );

        webviewBackbutton = (ImageView) findViewById( R.id.webviewBackbutton );
        webviewBackbutton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        } );
    }
}
