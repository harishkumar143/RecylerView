package kouchan.siddhesh.com.BookARideAndroid.Interface;

import android.view.View;

/**
 * Created by KOUCHAN-ADMIN on 3/14/2018.
 */

public interface IButtonAcceptOffer {

    void  acceptButton(View v,int position);
}
