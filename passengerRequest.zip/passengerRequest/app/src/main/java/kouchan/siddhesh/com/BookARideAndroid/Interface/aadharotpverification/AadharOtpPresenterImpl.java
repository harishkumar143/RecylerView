package kouchan.siddhesh.com.BookARideAndroid.Interface.aadharotpverification;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Api.ApiClient;
import kouchan.siddhesh.com.BookARideAndroid.Api.ServerApiNames;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.AdharOTPValidationActivity;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.Registration;
import kouchan.siddhesh.com.BookARideAndroid.async.AsyncInteractor;
import kouchan.siddhesh.com.BookARideAndroid.async.OnRequestListener;
import kouchan.siddhesh.com.BookARideAndroid.models.aatharotp.AadharOtpModel;
import kouchan.siddhesh.com.BookARideAndroid.utils.AppConstants;
import kouchan.siddhesh.com.BookARideAndroid.utils.NetworkStatus;
import kouchan.siddhesh.com.BookARideAndroid.utils.Sharedpreferences;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;


public class AadharOtpPresenterImpl implements IAadharOtpPresnter, OnRequestListener {

    AdharOTPValidationActivity registrationPassengerDriverActivity;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    AadharOtpModel aadharOtpModel;
    IAadharOtpView iAadharOtpView;


    public AadharOtpPresenterImpl(IAadharOtpView iAadharOtpView) {
        this.registrationPassengerDriverActivity = (AdharOTPValidationActivity) iAadharOtpView;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(registrationPassengerDriverActivity);
        this.asyncInteractor = new AsyncInteractor(registrationPassengerDriverActivity);
        this.aadharOtpModel = aadharOtpModel;
        this.iAadharOtpView = iAadharOtpView;
    }

    @Override
    public void aadhatOtp(String aadharOTP, String mobile, String password) {
        if (NetworkStatus.checkNetworkStatus(registrationPassengerDriverActivity)) {
            Map<String, String> params = new HashMap<String, String>();
            params.put("mobile", mobile);
            params.put("password", password);
            params.put("adhar_otp", aadharOTP);

            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_AADHAR_OTP, "https://bookarideworldwide.com/CAB2.V.1/passenger_api/m3aadharotpverify.php", new JSONObject(params));
        } else {
            Utils.showToast(registrationPassengerDriverActivity, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        if (pid == AppConstants.TAG_ID_AADHAR_OTP) {
            if (responseJson != null) {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    iAadharOtpView.aadharOtpSuccess(pid, jObj.getString("next_step"));
                } else {
                    iAadharOtpView.aadharOtpError(pid, jObj.getString("error_msg"));
                }


            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        iAadharOtpView.aadharOtpError(pid, error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }

}
