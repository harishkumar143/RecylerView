package kouchan.siddhesh.com.BookARideAndroid.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.holders.TrackCOmplentHolder;
import kouchan.siddhesh.com.BookARideAndroid.models.ComplentsModel;

public class TrackComplentAdapter extends RecyclerView.Adapter<TrackCOmplentHolder> {

    Context context;
    List<ComplentsModel> complentList = new ArrayList();

    public TrackComplentAdapter(Context context, List complentList) {
        this.context = context;
        this.complentList = complentList;
    }


    @NonNull
    @Override
    public TrackCOmplentHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.track_complent_item, viewGroup, false);
        return new TrackCOmplentHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TrackCOmplentHolder holder, int i) {
        holder.complentId.setText(complentList.get(i).getComplaint_id());
        holder.bookingId.setText(complentList.get(i).getBooking_id());
        holder.complentType.setText(complentList.get(i).getComplaint_type());
        holder.comments.setText(complentList.get(i).getComments());
        holder.status.setText(complentList.get(i).getStatus());

    }

    @Override
    public int getItemCount() {
        return complentList.size();
    }
}
