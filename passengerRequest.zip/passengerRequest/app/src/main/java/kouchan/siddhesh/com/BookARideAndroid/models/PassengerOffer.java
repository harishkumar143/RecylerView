package kouchan.siddhesh.com.BookARideAndroid.models;

/**
 * Created by KOUCHAN-ADMIN on 12/1/2017.
 */

public class PassengerOffer {

    private String message;
    private String stage;
    private String bookingid;
    private String passengername;
    private String passengermobile;
    private String vehicle;
    private String whenrequired;
    private String whenrequiredtyp;
    private String val;
    private String typeofrate;
    private String rate;
    private String metervalue;
    private String from;
    private String to;
    private String fromlatitude;
    private String fromlongitude;
    private String tolatitude;
    private String tolongitude;
    private String distance;
    private String finalPriceForSortingOfPassenger;
    private String expiry_time;
    public long timeRemaining = 60000;

    public PassengerOffer(String message, String stage, String bookingid, String passengername,
                          String passengermobile, String vehicle, String whenrequired, String whenrequiredtyp,
                          String typeofrate, String rate, String metervalue, String from, String to,
                          String fromlatitude, String fromlongitude, String tolatitude, String tolongitude,
                          String distance, String finalPriceForSortingOfPassenger, String expiry_time) {
        this.message = message;
        this.stage = stage;
        this.bookingid = bookingid;
        this.passengername = passengername;
        this.passengermobile = passengermobile;
        this.vehicle = vehicle;
        this.whenrequired = whenrequired;
        this.whenrequiredtyp = whenrequiredtyp;
        this.typeofrate = typeofrate;
        this.rate = rate;
        this.metervalue = metervalue;
        this.from = from;
        this.to = to;
        this.fromlatitude = fromlatitude;
        this.fromlongitude = fromlongitude;
        this.tolatitude = tolatitude;
        this.tolongitude = tolongitude;
        this.distance = distance;
        this.finalPriceForSortingOfPassenger = finalPriceForSortingOfPassenger;
        this.expiry_time = expiry_time;
    }

    public String getMessage() {
        return message;
    }

    public String getStage() {
        return stage;
    }

    public String getBookingid() {
        return bookingid;
    }

    public String getPassengername() {
        return passengername;
    }

    public String getPassengermobile() {
        return passengermobile;
    }

    public String getVehicle() {
        return vehicle;
    }

    public String getWhenrequired() {
        return whenrequired;
    }

    public String getWhenrequiredtyp() {
        return whenrequiredtyp;
    }

    public String getVal() {
        return val;
    }

    public String getTypeofrate() {
        return typeofrate;
    }

    public String getRate() {
        return rate;
    }

    public String getMetervalue() {
        return metervalue;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getFromlatitude() {
        return fromlatitude;
    }

    public String getFromlongitude() {

        return fromlongitude;
    }

    public String getTolatitude() {
        return tolatitude;
    }

    public String getTolongitude() {
        return tolongitude;
    }

    public String getDistance() {
        return distance;
    }

    public String finalPriceForSortingOfPassenger() {
        return finalPriceForSortingOfPassenger;
    }

    public long getExpiry_time() {

        return Long.parseLong(expiry_time);
    }

}
