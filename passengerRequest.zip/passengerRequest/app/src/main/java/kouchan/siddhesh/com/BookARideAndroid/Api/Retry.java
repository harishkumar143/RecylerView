package kouchan.siddhesh.com.BookARideAndroid.Api;


/**
 * Created by Basavaraj on 11/21/17.
 * KaHa Technologies Pvt Ltd
 * basavaraj.navi@coveiot.com
 * M3APP
 */


public class Retry {
  public static int method = 0;
}
