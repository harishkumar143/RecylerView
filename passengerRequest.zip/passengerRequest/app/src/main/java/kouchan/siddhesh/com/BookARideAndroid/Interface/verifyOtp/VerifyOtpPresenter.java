package kouchan.siddhesh.com.BookARideAndroid.Interface.verifyOtp;

public interface VerifyOtpPresenter {

    void verifyOtp(String userOtp, String mobile, String password);

}
