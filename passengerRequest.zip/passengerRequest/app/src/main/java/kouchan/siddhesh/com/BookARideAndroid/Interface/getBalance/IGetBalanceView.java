package kouchan.siddhesh.com.BookARideAndroid.Interface.getBalance;

public interface IGetBalanceView {

    void getBalanceSuccess(int pid, String balance);

    void getBalanceError(int pid, String error);

}
