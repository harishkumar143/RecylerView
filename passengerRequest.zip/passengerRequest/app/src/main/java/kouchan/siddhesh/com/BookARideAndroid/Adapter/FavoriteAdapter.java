package kouchan.siddhesh.com.BookARideAndroid.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.models.Favorite;

/**
 * Created by KOUCHAN-ADMIN on 3/23/2018.
 */

public class FavoriteAdapter extends RecyclerView.Adapter<FavoriteAdapter.MyFavoriteViiwHolder> {

    Context context;
    List<Favorite> favoritList;


    public class MyFavoriteViiwHolder extends RecyclerView.ViewHolder {

        public TextView typeFavorite, addressFavorite;

        public MyFavoriteViiwHolder(View itemView) {
            super(itemView);

            typeFavorite=(TextView) itemView.findViewById(R.id.typeFavorite);
            addressFavorite=(TextView) itemView.findViewById(R.id.addressFavorite);
        }
    }

    public FavoriteAdapter(Context context, List<Favorite> favoritList)
    {
        this.context=context;
        this.favoritList=favoritList;
    }



    @Override
    public MyFavoriteViiwHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.favorite_list_item,parent,false);
        return new MyFavoriteViiwHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyFavoriteViiwHolder holder, int position) {

        Favorite favorite=favoritList.get(position);
        holder.addressFavorite.setText(favorite.getAddress());
        holder.typeFavorite.setText(favorite.getType());
    }

    @Override
    public int getItemCount() {
        return favoritList.size();
    }


}
