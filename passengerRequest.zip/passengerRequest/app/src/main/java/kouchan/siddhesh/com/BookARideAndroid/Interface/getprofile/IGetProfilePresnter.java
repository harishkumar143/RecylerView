package kouchan.siddhesh.com.BookARideAndroid.Interface.getprofile;

public interface IGetProfilePresnter {

    void getProfile(String mobileNumber);

}
