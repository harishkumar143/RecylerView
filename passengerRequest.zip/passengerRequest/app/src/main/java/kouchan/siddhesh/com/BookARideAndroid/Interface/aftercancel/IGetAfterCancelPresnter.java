package kouchan.siddhesh.com.BookARideAndroid.Interface.aftercancel;

public interface IGetAfterCancelPresnter {

    void getAfterCancel();

}

