package kouchan.siddhesh.com.BookARideAndroid.async;

public interface IAsyncInteractor {
    void validateCredentialsAsync(OnRequestListener listener, int pid, String url);

}
