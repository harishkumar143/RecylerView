package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.CurrentRide;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Interface.payment.IPaymentPresnter;
import kouchan.siddhesh.com.BookARideAndroid.Interface.payment.IPaymentView;
import kouchan.siddhesh.com.BookARideAndroid.Interface.payment.PaymentPresenterImpl;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.VolleyJsonObjectRequest;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.PaymentModel;

public class PaymentActivity extends AppCompatActivity implements IPaymentView {

    TextView booking_id_payment, vehicle_payment, from_payment, to_payment, distance_payment,
            start_time_payment, end_time_payment, total_time_payment, actual_price_payment,pending_amount,current_ride_fare;

    TextView thank_you_for_riding_with_us_textView, ref_no_textView, from_textView, to_textView,
            distance_covered_textView, journey_time_textView, to_time_textView, total_time_textView,
            total_amount_textView, select_payment_method_textView;

    String languageCode,amount;
    Resources resources;

    ProgressDialog loading;
    String sendEmail;

    SessionManager sessionManager;
    IPaymentPresnter paymentPresnter;

    ImageView taxi_payment, rickshaw_payment;
  //  RadioButton cash_payment, m3_payment;
    Button pay_now_payment;

    RadioGroup cashradioGroup;
    RadioButton m3RadioButton;
    RadioButton cashRadioButton;

    CurrentRide currentRide;
    String driverMobileNumber = "";
    String bookingId = "";

    String booking_id;
    final static String paymentReceipt = Url.COMUNICATE_API + "paymentReceipt.php";
    final static String paymentDone = Url.COMUNICATE_API + "actualPriceUpdate.php";
    String url="http://api.oauth.m3ewallet.com/oauth/token?grant_type=password&client_id=M3_ANDROID_CLIENT&client_secret=android-m3-kouchan-secret&username=9036008829&password=8D969EEF6ECAD3C29A3A629280E686CF0C3F5D5A86AFF3CA12020C923ADC6C92&scope";
    String sendMoneyUrl="https://api.m3ewallet.com/transaction/sendMoneyToWallet";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        currentRide = new CurrentRide(getApplicationContext());
        paymentPresnter = new PaymentPresenterImpl(this);
        currentRide.setRideid(getIntent().getStringExtra("booking_id"));

        driverMobileNumber = getIntent().getStringExtra("drivermobile");
        booking_id = getIntent().getStringExtra("booking_id");

        initializeWidgets();
        paymentReceipt();




        pay_now_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (cashradioGroup.getCheckedRadioButtonId() == -1)
                {
                    Toast.makeText(PaymentActivity.this, "Selecet payment method", Toast.LENGTH_LONG).show();
                }
                else
                {
                    int selectedId=cashradioGroup.getCheckedRadioButtonId();

                    if(R.id.m3_payment == selectedId){
                        paidPayment("M3");

                    } else if(R.id.cashPayment == selectedId){
                        paidPayment("CASH");
                    }
                }

            }
        });


        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }



    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

    }

    private void initializeWidgets() {

        booking_id_payment = (TextView) findViewById(R.id.ref_no_textView);
        //vehicle_payment = (TextView) findViewById(R.id.vehicle_payment);
        from_payment = (TextView) findViewById(R.id.from_payment);
        to_payment = (TextView) findViewById(R.id.to_payment);
        distance_payment = (TextView) findViewById(R.id.distance_payment);
        start_time_payment = (TextView) findViewById(R.id.start_time_payment);
        end_time_payment = (TextView) findViewById(R.id.end_time_payment);
    //    total_time_payment = (TextView) findViewById(R.id.total_time_payment);
        actual_price_payment = (TextView) findViewById(R.id.actual_price_payment);
    //pendding amount
        //pending_amount = (TextView) findViewById(R.id.pending_amount);
            //    current_ride_fare = (TextView) findViewById(R.id.current_ride_fare);
        //taxi_payment = (ImageView) findViewById(R.id.taxi_payment);
        rickshaw_payment = (ImageView) findViewById(R.id.rickshaw_payment);

      //  cash_payment = (RadioButton) findViewById(R.id.cash_payment);
        m3RadioButton = (RadioButton) findViewById(R.id.m3_payment);
        cashRadioButton = (RadioButton) findViewById(R.id.cashPayment);

        cashradioGroup = (RadioGroup)findViewById(R.id.paymentRadioButton);
        pay_now_payment = (Button) findViewById(R.id.pay_now_payment);

    //    thank_you_for_riding_with_us_textView = (TextView) findViewById(R.id.thank_you_for_riding_with_us_textView);
        ref_no_textView = (TextView) findViewById(R.id.ref_no_textView);
        from_textView = (TextView) findViewById(R.id.from_textView);
        to_textView = (TextView) findViewById(R.id.to_textView);
        distance_covered_textView = (TextView) findViewById(R.id.distance_covered_textView);
        journey_time_textView = (TextView) findViewById(R.id.journey_time_textView);
        to_time_textView = (TextView) findViewById(R.id.to_time_textView);
        total_time_textView = (TextView) findViewById(R.id.total_time_textView);
    //    total_amount_textView = (TextView) findViewById(R.id.total_amount_textView);
     //   select_payment_method_textView = (TextView) findViewById(R.id.select_payment_method_textView);

        booking_id = getIntent().getStringExtra("booking_id");

    }


    public void paymentReceipt() {

        final ProgressDialog loading = ProgressDialog.show(this,getString(R.string.processing), getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, paymentReceipt,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                {
                                    booking_id_payment.setText("Ref. No :"+jObj.getString("booking_id"));
                                 String vehicalType= jObj.getString("vehicle");

                                    if (vehicalType.equalsIgnoreCase("Taxi(4+1)")) {

                                        rickshaw_payment.setImageResource(R.drawable.car_driver_request);
                                    } else if(vehicalType.equalsIgnoreCase("Auto")){
                                        rickshaw_payment.setImageResource(R.drawable.auto_driver_request);
                                    }
                                    else if(vehicalType.equalsIgnoreCase("Bike")){
                                        rickshaw_payment.setImageResource(R.drawable.bike_driver_request);
                                    }
                                    else if(vehicalType.equalsIgnoreCase("Taxi(7+1)")){
                                        rickshaw_payment.setImageResource(R.drawable.suv_selected_ic);
                                    }


                                    from_payment.setText(jObj.getString("fromplace"));
                                    to_payment.setText(jObj.getString("toplace"));
                                    distance_payment.setText(jObj.getString("distance"));
                                    start_time_payment.setText(jObj.getString("ride_start_time"));
                                    end_time_payment.setText(jObj.getString("ride_end_time"));
                                  //  total_time_payment.setText(jObj.getString("journey_time"));
                              //      current_ride_fare.setText(jObj.getString("actualprice"));
                                    amount=jObj.getString("total_amount");
                                    actual_price_payment.setText(jObj.getString("total_amount"));
                                   // pending_amount.setText(jObj.getString("previous_pending_amount"));


                                }

                            } else {


                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("booking_id", booking_id);

                return params;
            }
        };
        VolleySingleton.getInstance(PaymentActivity.this).addToRequestQueue(stringRequest);
    }


    public void paidPayment(String paymentMode) {
        paymentPresnter.payment(booking_id,paymentMode);
    }

    @Override
    public void paymentSuccess(int pid, PaymentModel paymentModel) {
        loading = ProgressDialog.show(this, getString(R.string.processing), getString(R.string.please_wait), false, false);
        sendEmail = "https://www.bookarideworldwide.com/CAB2.V.1/PHPMailer-master/email.php?booking_id="+booking_id;
        VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, sendEmail, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            loading.dismiss();
                            boolean error = response.getBoolean("error");
                            if (!error) {
                                Intent intent3 = new Intent(getApplicationContext(), PaymentStatusActivity.class);
                                CurrentRide currentRide = new CurrentRide(getApplicationContext());
                                currentRide.setIsRideStarted("ended");
                                intent3.putExtra("drivermobile", driverMobileNumber);
                                intent3.putExtra("booking_id", booking_id);
                                intent3.putExtra("amount", amount);

                                startActivity(intent3);


                                finish();
                            } else {

                                String errorMsg = response.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                });
        // Adding request to volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        currentRide.setPaymentStatus("paid");

    }

    @Override
    public void paymentError(int pid, String error) {

    }
}
