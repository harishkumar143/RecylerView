package kouchan.siddhesh.com.BookARideAndroid.Interface.aadharotpverification;

public interface IAadharOtpPresnter {

    void aadhatOtp(String aadharOTP, String mobile, String password);

}
