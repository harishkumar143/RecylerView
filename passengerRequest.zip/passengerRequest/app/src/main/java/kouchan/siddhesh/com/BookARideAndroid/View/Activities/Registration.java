package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.gson.Gson;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import fr.arnaudguyon.xmltojsonlib.XmlToJson;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Interface.aadharotpverification.IAadharOtpPresnter;
import kouchan.siddhesh.com.BookARideAndroid.Interface.m3withbookarideregistration.IRegisterPresenter;
import kouchan.siddhesh.com.BookARideAndroid.Interface.verifyOtp.VerifyOtpPresenter;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.VolleyJsonObjectRequest;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.AdhaarModel;
import kouchan.siddhesh.com.BookARideAndroid.utils.Sharedpreferences;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;


public class Registration extends AppCompatActivity implements com.google.android.gms.location.LocationListener,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, OnMapReadyCallback {

    EditText email_id, mobile_no,
            first_name, alternateName, alternateMobile,
            aadhar_card_number, pin_code;

    static EditText dob;

    private static final String TAG = "RegistrationPassengerDriverActivity";
    private static final long INTERVAL = 1000 * 10;
    private static final long FASTEST_INTERVAL = 1000 * 5;
    LocationRequest mLocationRequest;

    GoogleApiClient mGoogleApiClient;
    private GoogleMap mMap;
    Location mCurrentLocation;


    IRegisterPresenter iRegisterPresenter;
    IAadharOtpPresnter iAadharOtpPresnter;
    VerifyOtpPresenter verifyOtpPresenter;

    RadioButton male, female, other;

    Dialog mDialog;

    String state, address, pin;

    private TextView phoneNoView;
    private EditText phoneCodeView;
    private Button phoneVerifyButton;
    private TextView resendOtpButton;

    TextView register_gender, passenger_registration_textView, qronaadhar_text, registerAcivityLoginTextView, loginInSignUp, termsAndConditionText;
    TextInputLayout register_mobile_TextInput, aadhar_card_number_TextInput, register_firstname_TextInput,
            register_emailid_TextInput, register_dob_TextInput, alternate_persone_name_TextInput,
            alternate_persone_mobile_TextInput, pin_code_TextInput, register_password_passenger_TextInput,
            register_confirm_password_passenger_TextInput;

    TextInputEditText register_password_passenger, register_confirm_password_passenger;

    String languageCode;
    Resources resources;

    /* String emailerror = resources.getString(R.string.emailerror);*/

    public AwesomeValidation awesomeValidation;

    String stringEmail, stringAlternateName, stringAlternateMobile, stringMobile, stringPassword, stringFirstName, stringDOB, stringMessagingID;
    String stringConfirmPassword;
    RadioGroup gender_options;

    boolean isGenderSelected;
    String stringGenderOptions;
    Button submit_button;
    String stringName, id, email, string_aadhar_card_number, string_pin_code;

    ImageView infoImagePassword, infoImageConfirmPassword, infoImageBirthDate, infoImageAlternateMobile;

    AlertDialog.Builder ab;

    private static final String REGISTER_URL = Url.PASSENGER_API + "sendotpforregistration.php";

    static final int PICK_CONTACT = 4;
    private static final int REQUEST_CODE = 1;

    private static final int TAG_RESULT_PICK_ALTERNATIVE_CONTACT = 1001;


    Toolbar mToolbar;
    ImageView passengerRegistrationBackImageView, info_qr_on_aadhar;

    Cursor cursor = null;
    int phonePosIndex, namePosIndex;
    String userNameValue, userPhoneNumberValue = null;

    SessionManager sessionManager;
    Sharedpreferences sharedpreferences;
    CheckBox mAcceptCheckBox;


    private static final int REQUEST_CODE_PERMISSION = 89;
    String mPermission = Manifest.permission.GET_ACCOUNTS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_registration);
        ab = new AlertDialog.Builder(Registration.this);
        sessionManager = new SessionManager(getApplicationContext());

        // iRegisterPresenter = new RegisterPresenterImp(this);
        sharedpreferences = Sharedpreferences.getUserDataObj(this);
        // iAadharOtpPresnter = new AadharOtpPresenterImpl(this);

        initializeWidgets();
        //infoImages();
        //chooseOptions();


        initializeViews();

        if (!isGooglePlayServicesAvailable()) {
        }
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();
        mGoogleApiClient.connect();

        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setValuesForSubmisssion();
                sendValues();
            }

        });


       /* dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogFragment newFragment = new SelectDateFragment();
                newFragment.show(getSupportFragmentManager(), "DatePicker");
            }
        });


        dob.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().trim().length() > 0) {
                    dob.setError(null);
                }
            }
        });

        alternateName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().trim().length() > 0) {
                    alternateName.setError(null);
                }
            }
        });

        alternateMobile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().trim().length() > 0) {
                    alternateMobile.setError(null);
                }
            }
        });*/

       /* info_qr_on_aadhar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAdhaarScanClick();

            }
        });*/

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        //register_gender.setText(resources.getString(R.string.gender));
        //passenger_registration_textView.setText(resources.getString(R.string.passenger_registration));
        /*personal_information_textView.setText(resources.getString(R.string.personal_information));*/
        // qronaadhar_text.setText(resources.getString(R.string.qr_on_aadhar));
        // male.setText(resources.getString(R.string.male));
        //female.setText(resources.getString(R.string.female));
        // other.setText(resources.getString(R.string.other));
        //  register_mobile_TextInput.setHint(resources.getString(R.string.mobile_no));
        // aadhar_card_number_TextInput.setHint(resources.getString(R.string.aadhar_card));
        // register_firstname_TextInput.setHint(resources.getString(R.string.name_as_per_the_aadhar));
        //  register_emailid_TextInput.setHint(resources.getString(R.string.email_id));
        //  register_dob_TextInput.setHint(resources.getString(R.string.birth_date));
        //  alternate_persone_name_TextInput.setHint(resources.getString(R.string.alternate_mobile_holder_name));
        //  alternate_persone_mobile_TextInput.setHint(resources.getString(R.string.alternate_mobile_holder_number));
        //  pin_code_TextInput.setHint(resources.getString(R.string.pincode));
        //  register_password_passenger_TextInput.setHint(resources.getString(R.string.password));
        //  register_confirm_password_passenger_TextInput.setHint(resources.getString(R.string.confirm_password));
        submit_button.setText(resources.getString(R.string.registration));
        getMailId();
    }

    private void onAdhaarScanClick() {
    /*Intent intent = new Intent(HomeActivity.this,ScanQRCodeActivity.class);
    startActivity(intent);*/
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setPrompt(resources.getString(R.string.scan_aadhar_qr_code));
        integrator.setOrientationLocked(false);
        integrator.initiateScan();
    }


    private void initializeWidgets() {

        email_id = (EditText) findViewById(R.id.register_emailid);
        mobile_no = (EditText) findViewById(R.id.register_mobile);

        String code = "+91 ";
        //mobile_no.setCompoundDrawablesWithIntrinsicBounds(new TextDrawable(code), null, null, null);
        //mobile_no.setCompoundDrawablePadding(code.length() * 18);

        termsAndConditionText = (TextView) findViewById(R.id.termsAndConditionText);
        register_password_passenger = (TextInputEditText) findViewById(R.id.register_password_passenger);
        //register_confirm_password_passenger = (TextInputEditText) findViewById(R.id.register_confirm_password_passenger);
        first_name = (EditText) findViewById(R.id.register_firstname);
        // dob = (EditText) findViewById(R.id.register_dob);
        //dob.setFocusable(false);

        //gender_options = (RadioGroup) findViewById(R.id.register_gender_options);
        //male = (RadioButton) findViewById(R.id.register_male);
        //female = (RadioButton) findViewById(R.id.register_female);
        // other = (RadioButton) findViewById(R.id.register_other);
        //register_gender = (TextView) findViewById(R.id.register_gender);
        // alternateName = (EditText) findViewById(R.id.alternate_persone_name);
        // alternateMobile = (EditText) findViewById(R.id.alternate_persone_mobile);

        infoImagePassword = (ImageView) findViewById(R.id.infoImagePassword);
        // infoImageConfirmPassword = (ImageView) findViewById(R.id.infoImageConfirmPassword);
        // infoImageBirthDate = (ImageView) findViewById(R.id.infoImageBirthDate);
        // infoImageAlternateMobile = (ImageView) findViewById(R.id.infoImageAlternateMobile);

        // info_qr_on_aadhar = (ImageView) findViewById(R.id.info_qr_on_aadhar);
        // aadhar_card_number = (EditText) findViewById(R.id.aadhar_card_number);
        // pin_code = (EditText) findViewById(R.id.pin_code);

        // passenger_registration_textView = (TextView) findViewById(R.id.passenger_registration_textView);

        // qronaadhar_text = (TextView) findViewById(R.id.qronaadhar_text);

        // register_mobile_TextInput = (TextInputLayout) findViewById(R.id.register_mobile_TextInput);
        //aadhar_card_number_TextInput = (TextInputLayout) findViewById(R.id.aadhar_card_number_TextInput);
        //register_firstname_TextInput = (TextInputLayout) findViewById(R.id.register_firstname_TextInput);
        //register_emailid_TextInput = (TextInputLayout) findViewById(R.id.register_emailid_TextInput);
        //register_dob_TextInput = (TextInputLayout) findViewById(R.id.register_dob_TextInput);
        //alternate_persone_name_TextInput = (TextInputLayout) findViewById(R.id.alternate_persone_name_TextInput);
        //alternate_persone_mobile_TextInput = (TextInputLayout) findViewById(R.id.alternate_persone_mobile_TextInput);
        // pin_code_TextInput = (TextInputLayout) findViewById(R.id.pin_code_TextInput);
        // register_password_passenger_TextInput = (TextInputLayout) findViewById(R.id.register_password_passenger_TextInput);
        // register_confirm_password_passenger_TextInput = (TextInputLayout) findViewById(R.id.register_confirm_password_passenger_TextInput);

        loginInSignUp = (TextView) findViewById(R.id.loginInSignUp);
        //loginInSignUp.setPaintFlags(loginInSignUp.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        loginInSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Registration.this, LoginActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
                finish();
            }
        });
        registerAcivityLoginTextView = (TextView) findViewById(R.id.registerAcivityLoginTextView);
        //registerAcivityLoginTextView.setPaintFlags(registerAcivityLoginTextView.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        registerAcivityLoginTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Registration.this, LoginActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
                finish();
            }
        });

        submit_button = (Button) findViewById(R.id.submit_button);

        // requiredm3 = (CheckBox) findViewById(R.id.requiredm3);

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);


        awesomeValidation.addValidation(this, R.id.register_emailid, Patterns.EMAIL_ADDRESS, R.string.emailerror);
        awesomeValidation.addValidation(this, R.id.register_mobile, "^[7-9]{1}[0-9]{9}$", R.string.mobileerror);
        awesomeValidation.addValidation(this, R.id.register_firstname, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.nameerror);
        //awesomeValidation.addValidation(this, R.id.alternate_persone_name, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.altnameerror);
        // awesomeValidation.addValidation(this, R.id.alternate_persone_mobile, "^[7-9]{1}[0-9]{9}$", R.string.altmobileerror);

        /* awesomeValidation.addValidation(this, R.id.aadhar_card_number,  RegexTemplate.NOT_EMPTY, R.string.aadharcardnoerror);*/

        /*String regexPassword = "^[a-zA-Z0-9@.#$%^&*_!~`+=/-]{8,}$";*/
        String regexPassword = ".{6,8}";
        awesomeValidation.addValidation(this, R.id.register_password_passenger, regexPassword, R.string.passworderror);
        //awesomeValidation.addValidation(this, R.id.register_confirm_password_passenger, R.id.register_password_passenger, R.string.invalid_confirm_password);

        // awesomeValidation.addValidation(this, R.id.aadhar_card_number, "^[2-9]{1}[0-9]{11}$", R.string.aadharcardnoerror);
        //awesomeValidation.addValidation(this, R.id.pin_code, "^[1-9]{1}[0-9]{5}$", R.string.pincodeerror);
        mAcceptCheckBox = (CheckBox) findViewById(R.id.checkBox);

        termsAndConditionText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Registration.this, WebViewActivity.class);

                String URL = "https://bookarideworldwide.com/CAB2.V.1/web/p_tnc.html";
                String webview_titel = "Terms & Conditions";
                i.putExtra("url", URL);
                i.putExtra("action_bar_name", webview_titel);
                startActivity(i);
            }
        });

    }

    private void infoImages() {
        /*final String alertmsg = getResources().getString(R.string.alert);*/

        infoImagePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(Registration.this)
                        /*.setTitle(alertmsg)*/
                        .setMessage(resources.getString(R.string.password))
                        .setPositiveButton(resources.getString(R.string.ok), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();

                            }
                        }).show();
            }
        });

        infoImageConfirmPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(Registration.this)
                        /*.setTitle(alertmsg)*/
                        .setMessage(resources.getString(R.string.confirm_password))
                        .setPositiveButton(resources.getString(R.string.ok), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        }).show();
            }
        });

        infoImageBirthDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(Registration.this)
                        /*.setTitle(alertmsg)*/
                        .setMessage(resources.getString(R.string.birth_date))
                        .setPositiveButton(resources.getString(R.string.ok), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        }).show();
            }
        });

        infoImageAlternateMobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(Registration.this)
                        /*.setTitle(alertmsg)*/
                        .setMessage(resources.getString(R.string.alternate_mobile_number))
                        .setPositiveButton(resources.getString(R.string.ok), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        }).show();
            }
        });
    }

    public void chooseOptions() {
        gender_options.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.register_male:
                        stringGenderOptions = "male";
                        isGenderSelected = true;
                        register_gender.setError(null);
                        break;

                    case R.id.register_female:
                        stringGenderOptions = "female";
                        isGenderSelected = true;
                        break;

                    case R.id.register_other:
                        stringGenderOptions = "other";
                        isGenderSelected = true;
                        register_gender.setError(null);
                        break;
                }
            }
        });
    }


    private void setValuesForSubmisssion() {
        stringEmail = email_id.getText().toString();
        stringMobile = mobile_no.getText().toString();
        stringPassword = register_password_passenger.getText().toString();
        //stringConfirmPassword = register_confirm_password_passenger.getText().toString();
        stringFirstName = first_name.getText().toString();
        //stringDOB = dob.getText().toString();

        //stringAlternateName = alternateName.getText().toString();
        //stringAlternateMobile = alternateMobile.getText().toString();

        stringMessagingID = sessionManager.getToken();

        //string_aadhar_card_number = aadhar_card_number.getText().toString();
        //string_pin_code = pin_code.getText().toString();

    }


    @SuppressLint("ValidFragment")
    public static class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {


        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            int yy = calendar.get(Calendar.YEAR);
            int mm = calendar.get(Calendar.MONTH);
            int dd = calendar.get(Calendar.DAY_OF_MONTH);

            Calendar minCal = Calendar.getInstance();
            minCal.set(Calendar.YEAR, minCal.get(Calendar.YEAR) - 100);
            Calendar maxCal = Calendar.getInstance();
            maxCal.set(Calendar.YEAR, maxCal.get(Calendar.YEAR) - 12);
          /*  dialog.getDatePicker().setMinDate(minCal.getTimeInMillis());
            dialog.getDatePicker().setMaxDate(maxCal.getTimeInMillis());*/

            DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), this, yy, mm, dd);
            datePickerDialog.getDatePicker().setMaxDate(maxCal.getTimeInMillis());
            datePickerDialog.getDatePicker().setMinDate(minCal.getTimeInMillis());
            return datePickerDialog;
        }

        public void onDateSet(DatePicker view, int yy, int mm, int dd) {

            Calendar c = Calendar.getInstance();
            c.add(Calendar.DATE, 1);
            Date newDate = c.getTime();
            view.setMaxDate(newDate.getTime() - (newDate.getTime() % (24 * 60 * 60 * 1000)));
            populateSetDate(yy, mm + 1, dd);

        }

        /*changes by today here*/
        public void populateSetDate(int year, int month, int day) {

            dob.setText(day + "/" + month + "/" + year);
            //from_date = transactionFromTextView.getText().toString();


        }
    }

   /* @Override
    protected void onStart() {
        EventBusManager.getInstance().getEventBus().register(this);
        super.onStart();}*/

    public void sendValues() {
        try {
            Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude(), 1);
            address = addresses.get(0).getAddressLine(0);
            // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
            String city = addresses.get(0).getLocality();
            state = addresses.get(0).getAdminArea();
            String country = addresses.get(0).getCountryName();
            pin = addresses.get(0).getPostalCode();
            String knownName = addresses.get(0).getFeatureName();
        } catch (Exception e) {
            Log.d("Location", "Not Updated");
        }
        if (!(awesomeValidation.validate())) {

            //process the data further
        } /*else if (gender_options.getCheckedRadioButtonId() <= 0) {//Grp is your radio group object

            register_gender.requestFocus();
            register_gender.setError(resources.getString(R.string.select_gender));//Set error to last Radio button

        } else if (dob.getText().toString().equals("")) {//Grp is your radio group object
            register_gender.setError(null);
            register_gender.clearFocus();
            dob.requestFocus();
            dob.setError(resources.getString(R.string.select_birthdate));//Set error to last Radio button

        } else if (!(Functions.isNumberSame(stringMobile, stringAlternateMobile))) {
            dob.setError(null);
            dob.clearFocus();
            alternateMobile.setError(resources.getString(R.string.same_mobile));

        }*/ else {

            if (mAcceptCheckBox.isChecked()) {

                if (Utils.isInternetAvailable(Registration.this)) {

                    Utils.showProgress(Registration.this);

                    Map<String, String> params = new HashMap<String, String>();

                    params.put("email", stringEmail);
                    params.put("mobile", stringMobile);
                    params.put("password", stringPassword);
                    params.put("name", stringFirstName);
                    params.put("messagingid", stringMessagingID);
                    params.put("pin", pin);
                    params.put("address", address);
                    params.put("state_name", state);

                    JSONObject json = new JSONObject(params);

                    /* if (!requiredm3.isChecked()) {*/
                    VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, REGISTER_URL, json,
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {
                                    try {
                                        Utils.stopProgress(Registration.this);
                                        JSONObject jObj = new JSONObject(response.toString());
                                        boolean error = jObj.getBoolean("error");
                                        if (!error) {

                                            //if (!requiredm3.isChecked()) {
                                            Intent intent = new Intent(Registration.this, VerifyOTP.class);

                                            intent.putExtra("email", stringEmail);
                                            intent.putExtra("mobile", stringMobile);
                                            intent.putExtra("password", stringPassword);
                                            intent.putExtra("name", stringFirstName);
                                            intent.putExtra("bdate", stringDOB);
                                            intent.putExtra("gender", stringGenderOptions);
                                            intent.putExtra("alternateName", stringAlternateName);
                                            intent.putExtra("alternateMobile", stringAlternateMobile);
                                            intent.putExtra("messagingid", stringMessagingID);
                                            intent.putExtra("pin", pin);
                                            intent.putExtra("address", address);
                                            intent.putExtra("state", state);
                                            intent.putExtra("adharno", string_aadhar_card_number);
                                            // intent.putExtra("otp", jObj.getInt("otp"));

                                            startActivity(intent);
                                            finish();
                                           /* } else {
                                                iRegisterPresenter.registerValidation(first_name, email_id, mobile_no, register_password_passenger);
                                            }*/


                                        } else {
                                            String errorMsg = jObj.getString("error_msg");
                                            Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_SHORT).show();
                                            //Utils.showToast(Registration.this, errorMsg);
                                            /*Intent intent = new Intent(Registration.this,LoginActivity.class);
                                            startActivity(intent);
                                            finish();*/
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Utils.stopProgress(Registration.this);
                                }
                            }) /*{
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<String, String>();

                            params.put("email", stringEmail);
                            params.put("mobile", stringMobile);
                            params.put("password", stringPassword);
                            params.put("name", stringFirstName);
                          //  params.put("bdate", stringDOB);
                          //  params.put("gender", stringGenderOptions);
                           // params.put("alternateName", stringAlternateName);
                           // params.put("alternateMobile", stringAlternateMobile);
                            params.put("messagingid", stringMessagingID);
                            params.put("pin", "411060");
                            //params.put("adharno", string_aadhar_card_number);

                            return params;
                        }
                    }*/;

                    RequestQueue requestQueue = Volley.newRequestQueue(this);
                    requestQueue.add(stringRequest);
               /* } else {
                    iRegisterPresenter.registerValidation(first_name, email_id, mobile_no, register_password_passenger);
                }*/
                } else {

                    Utils.showToast(Registration.this, "please connect to the internate");
                }
            } else {
                Utils.showToast(Registration.this, "Check the Terms and Conditions");
            }

        }


    }


    public void pickContact(View view) {
        pickAContact(TAG_RESULT_PICK_ALTERNATIVE_CONTACT);

    }

    private void pickAContact(int type) {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(intent, type);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null && result.getContents() != null) {
            String adhaarResult = result.getContents();
            parseXml(adhaarResult);

        }

        if (resultCode == RESULT_OK) {
            // Check for the request code, we might be usign multiple startActivityForReslut
            switch (requestCode) {
                case (TAG_RESULT_PICK_ALTERNATIVE_CONTACT):

                    if (resultCode == Activity.RESULT_OK) {

                        pickedContact(data, requestCode);
                    }
                    break;

             /*   case REQUEST_CODE:
                    String accountName = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                    email_id.setText(accountName);
                    break;*/
            }
        } else {
            Log.e("MainActivity", "Failed to pick contact");
        }
    }

    private void pickedContact(Intent data, int requestCode) {

        try {

            // getData() method will have the Content Uri of the selected contact
            Uri uri = data.getData();

            //Query the content uri
            cursor = getContentResolver().query(uri, null, null, null, null);
            cursor.moveToFirst();
            // sendToParentLinearLayout.setVisibility(GONE);
            //pickedContactDetailsLinearLayout.setVisibility(View.VISIBLE);
            // column index of the phone number
            phonePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            // column index of the contact name
            namePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

            userPhoneNumberValue = cursor.getString(phonePosIndex);
            userNameValue = cursor.getString(namePosIndex);


            Log.d("pickedPhoneNum", ":" + cursor.getString(phonePosIndex));
            String[] splitStrPhoneNumber = cursor.getString(phonePosIndex).split("\\s+");

            String refinedNumber = "";

            for (int i = 0; i < splitStrPhoneNumber.length; i++) {

                StringBuilder sb = new StringBuilder();

                Log.d("splitted", "Values" + i + "   " + splitStrPhoneNumber[i]);
                sb.append(refinedNumber).append(splitStrPhoneNumber[i]);

                Log.d("data", ":data came" + sb.toString());

                refinedNumber = sb.toString();
                Log.d("data", ":data came" + refinedNumber);


            }


            if (userPhoneNumberValue != null && userNameValue != null) {


                Log.d("data", ":Length" + refinedNumber.length());

                Log.d("data123", ":data came" + refinedNumber);


                if (refinedNumber.length() == 10) {
                    refinedNumber = refinedNumber;
                } else if (refinedNumber.length() > 10) {
                    refinedNumber = refinedNumber.replaceAll("[^0-9]+", "");
                    refinedNumber = refinedNumber.substring(refinedNumber.length() - 10);
                    //
                } else {
                    // whatever is appropriate in this case
                    throw new IllegalArgumentException(resources.getString(R.string.please_enter_the_valid_mobile_number));
                }

                Log.d("data123", ":data came" + refinedNumber);
                if (requestCode == TAG_RESULT_PICK_ALTERNATIVE_CONTACT) {
                    alternateName.setText(userNameValue);
                    alternateMobile.setText(refinedNumber);
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void getMailId() {

        if (Build.VERSION.SDK_INT >= 23) {

            if (checkSelfPermission(mPermission) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(Registration.this, new String[]{mPermission}, REQUEST_CODE_PERMISSION);
                return;
            } else {
                String email = getEmail(this);
                if (email != null) {
                    email_id.setText(email);
                } else {
                    email_id.setText(resources.getString(R.string.account_not_found));
                }
            }

        } else {
            String email = getEmail(this);
            if (email != null) {
                email_id.setText(email);
            } else {
                email_id.setText(resources.getString(R.string.account_not_found));
            }
        }
    }

    static String getEmail(Context context) {
        AccountManager accountManager = AccountManager.get(context);
        Account account = getAccount(accountManager);

        if (account == null) {
            return null;
        } else {
            return account.name;
        }
    }

    private static Account getAccount(AccountManager accountManager) {
        Account[] accounts = accountManager.getAccountsByType("com.google");
        Account account;
        if (accounts.length > 0) {
            account = accounts[0];
        } else {
            account = null;
        }
        return account;
    }

    public void parseXml(String stringXml) {

        String json = convertXmlToJson(stringXml);
        /* if (json != null && json.toString().isEmpty()) {*/
        AdhaarModel model = new Gson().fromJson(json.toString(), AdhaarModel.class);

        Log.d("adhaar", "Name " + model.getPrintLetterBarcodeData().getName());
        Log.d("adhaar", "gender " + model.getPrintLetterBarcodeData().getGender());
        Log.d("adhaar", "co  " + model.getPrintLetterBarcodeData().getCo());
        Log.d("adhaar", "pc " + model.getPrintLetterBarcodeData().getPc());
        Log.d("adhaar", "DOB " + model.getPrintLetterBarcodeData().getDob());
        Log.d("adhaar", "dist " + model.getPrintLetterBarcodeData().getDist());
        Log.d("adhaar", "PO " + model.getPrintLetterBarcodeData().getPo());
        Log.d("adhaar", "VTC " + model.getPrintLetterBarcodeData().getVtc());
        Log.d("adhaar", "uid " + model.getPrintLetterBarcodeData().getUid());
        Log.d("adhaar", "state " + model.getPrintLetterBarcodeData().getState());

        if (model.getPrintLetterBarcodeData().getUid() != null) {
            String myString = model.getPrintLetterBarcodeData().getUid();
            String newString = myString.replaceAll("\\s+", "");/*replaceAll("(.{4})(?!$)", "$1 ");*/
            aadhar_card_number.setText(newString);
        }
        if (model.getPrintLetterBarcodeData().getName() != null) {
            first_name.setText(model.getPrintLetterBarcodeData().getName());
        }

       /* if(model.getPrintLetterBarcodeData().getGender() !=null) {
            if(model.getPrintLetterBarcodeData().getGender().equalsIgnoreCase("M")) {
                genderSpinner.setSelection(1);
            }
            else if(model.getPrintLetterBarcodeData().getGender().equalsIgnoreCase("F")) {
                genderSpinner.setSelection(2);
            }
            else{
                genderSpinner.setSelection(3);
            }

        }*/
        if (model.getPrintLetterBarcodeData().getDob() != null) {
            dob.setText(model.getPrintLetterBarcodeData().getDob());
        } else {
            dob.setError("");
        }
        pin_code.setText(model.getPrintLetterBarcodeData().getPc());
    }


    public String convertXmlToJson(String xml) {
        XmlToJson xmlToJson = new XmlToJson.Builder(xml)
                .build();
        return xmlToJson.toString();
    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(Registration.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void initializeViews() {

        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
       /* passengerRegistrationBackImageView = (ImageView) findViewById(R.id.passengerRegistrationBackImageView);

        passengerRegistrationBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Registration.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });*/
    }

    @Override
    public void onLocationChanged(Location location) {
        mCurrentLocation = location;
    }

    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(INTERVAL);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    private boolean isGooglePlayServicesAvailable() {
        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (ConnectionResult.SUCCESS == status) {
            return true;
        } else {
            //GooglePlayServicesUtil.getErrorDialog(status, GPS_Service.this, 0).show();
            return false;
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mCurrentLocation = LocationServices.FusedLocationApi.getLastLocation(
                mGoogleApiClient);

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

    }
}
