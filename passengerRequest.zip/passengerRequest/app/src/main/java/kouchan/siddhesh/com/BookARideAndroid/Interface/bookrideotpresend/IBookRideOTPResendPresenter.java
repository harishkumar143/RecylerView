package kouchan.siddhesh.com.BookARideAndroid.Interface.bookrideotpresend;

public interface IBookRideOTPResendPresenter {

    void getBookRideOTPResend(String stringMobile);

}
