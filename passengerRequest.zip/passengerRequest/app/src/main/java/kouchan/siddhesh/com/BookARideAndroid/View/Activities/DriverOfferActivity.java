package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.app.Dialog;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.otto.Subscribe;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Adapter.DriverOfferAdapter;
import kouchan.siddhesh.com.BookARideAndroid.Adapter.RecyclerTouchListener;
import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Otto.EventBusManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.DriverOffer;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoAllDriversRejected;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoEventActivityFinish;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoEventDriverList;
import kouchan.siddhesh.com.BookARideAndroid.other.DividerItemDecoration;

public class DriverOfferActivity extends AppCompatActivity {



    private List<DriverOffer> driverOfferList = new ArrayList<>();
    private RecyclerView recyclerView;
    private DriverOfferAdapter mAdapter;
    SessionManager sessionManager;

    String drivermobile,whenrequiredtype,typeofmeter;
    String passengername ,passengermobile,price,drivername,bookingid,vehicle,rating;
    private String service_tax_val;
    private String service_charge_val;
    private String final_amount_val;
    HashMap<String, String> user;

    TextView driver_offers_textView;

    Button DriverOfferCancel;

    String notificationURL= Url.COMUNICATE_API+"passengerSelectionOfDriver.php";

    String cancelRideUrl=Url.COMUNICATE_API+"passengerCancel.php";

    String sendReadReceiptUrl=Url.COMUNICATE_API+"read_track.php";

    CountDownTimer waitTimer;

    TextView driverOfferTimer;
    String languageCode;
    Resources resources;

    ProgressDialog  loading;

    MediaPlayer mp;
/*
    Bus eventBus;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_offer);

        mp = MediaPlayer.create(this, R.raw.musicone);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        driverOfferTimer=(TextView)findViewById(R.id.driverOfferTimer) ;
        DriverOfferCancel=(Button)findViewById(R.id.DriverOfferCancel) ;

        DriverOfferCancel.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                cancelRide();
            }
        });

        driver_offers_textView=(TextView)findViewById(R.id.driver_offers_textView) ;

        EventBusManager.getInstance().getEventBus().register(this);


        NotificationManager notificationManager = (NotificationManager)getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
        notificationManager.cancelAll();


        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        mAdapter = new DriverOfferAdapter(getApplicationContext(), driverOfferList);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        sessionManager=new SessionManager(getApplicationContext());

        user = new HashMap<String, String>();
        user=sessionManager.getUserDetails();
        passengername=user.get("name");
        passengermobile=user.get("mobile");


        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, final int position) {

                /*AlertDialog.Builder builder;
                builder = new AlertDialog.Builder(DriverOfferActivity.this, android.R.style.Theme_Material_Dialog_Alert);

                builder.setMessage(resources.getString(R.string.do_you_want_to_select_this_offer))
                        .setPositiveButton(resources.getString(R.string.yes), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                DriverOffer driverOffer = driverOfferList.get(position);
                                drivermobile=driverOffer.getDrivermobile();
                                price=driverOffer.getPrice();
                                drivername=driverOffer.getDrivername();
                                bookingid=driverOffer.getBookingid();
                                vehicle=driverOffer.getVehicle();
                                rating=driverOffer.getRating();

                                sendNotification();

                            }
                        })
                        .setNegativeButton(resources.getString(R.string.no), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        }).setIcon(android.R.drawable.ic_dialog_alert)
                        .show();*/

                final Dialog dialog = new Dialog(DriverOfferActivity.this);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setCancelable(false);
                dialog.setContentView(R.layout.custom_alert_dialog);
                Window window = dialog.getWindow();
                window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                TextView text = (TextView) dialog.findViewById(R.id.txt_dia);
                text.setText("Do you want to select this offer");
                Button okButton = (Button) dialog.findViewById(R.id.btn_yes);
                Button cancleButton = (Button) dialog.findViewById(R.id.btn_no);

                okButton.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        //Perfome Action
                        DriverOffer driverOffer = driverOfferList.get(position);
                        drivermobile=driverOffer.getDrivermobile();
                        price=driverOffer.getExtraLessValue();
                        service_charge_val = driverOffer.getService_charge_val();
                        service_tax_val = driverOffer.getService_tax_val();
                        final_amount_val = driverOffer.getFinal_amount_val();
                        drivername=driverOffer.getDrivername();
                        bookingid=driverOffer.getBookingid();
                        vehicle=driverOffer.getVehicle();
                        rating=driverOffer.getRating();
                        typeofmeter=driverOffer.getTypeofmeter();
                        sendNotification();
                        //Do stuff, possibly set wantToCloseDialog to true then...
                        //if (wantToCloseDialog)
                        dialog.dismiss();
                    }
                });
                cancleButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

    prepareMovieData();

        waitTimer = new CountDownTimer(120000, 1000) {

            public void onTick(long millisUntilFinished) {

                driverOfferTimer.setText(""+ millisUntilFinished / 1000);
            }

            public void onFinish() {
                //After 15000 milliseconds (60 sec) finish current
                cancelRide();
            }
        }.start();


       /* eventBus = new Bus(ThreadEnforcer.MAIN);
        eventBus.register(this);*/

       /* EventBusManager.getInstance().getEventBus().register(this);*/

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        driver_offers_textView.setText(resources.getString(R.string.driver_offer));
        /*DriverOfferCancel.setText(resources.getString(R.string.cancel));*/
    }

    private void cancelRide() {

        loading = ProgressDialog.show(this, resources.getString(R.string.processing),resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, cancelRideUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                    Intent c = new Intent(getApplicationContext(), NavHome.class);
                                    startActivity(c);
                                    finish();

                            } else {

                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();

                    }
                }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();

                params.put("bookingid",getIntent().getStringExtra("bookingid"));
                params.put("passengermobile",passengermobile);

                return params;

            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public void prepareMovieData() {

       DriverOffer driverOffer = new DriverOffer( getIntent().getStringExtra("drivername"),
                                                  getIntent().getStringExtra("drivermobile"),
               getIntent().getStringExtra("stringFinalPriceForSorting"),
               getIntent().getStringExtra("bookingid"),
               getIntent().getStringExtra("vehicle"),
               getIntent().getStringExtra("rating"),
               getIntent().getStringExtra("meter_value"),
               getIntent().getStringExtra("prise"),
               getIntent().getStringExtra("typeofrate"),
               getIntent().getStringExtra("whenrequiredtype"),
               getIntent().getStringExtra("myoffer"),
               getIntent().getStringExtra("service_tax_val"),
               getIntent().getStringExtra("service_charge_val"),
               getIntent().getStringExtra("final_amount_val"),
               getIntent().getStringExtra("myoffer_service_charge"),
               getIntent().getStringExtra("myoffer_gst"),
               getIntent().getStringExtra("vehicle_model"),
               getIntent().getStringExtra("vehicle_sub_type"));


       driverOfferList.add(driverOffer);

        //sendPassengerReadREceiptNetworkCall(getIntent().getStringExtra("bookingid"),passengermobile,getIntent().getStringExtra("drivermobile"));
        mAdapter.notifyDataSetChanged();
        whenrequiredtype=getIntent().getStringExtra("whenrequiredtype");

        mp.start();
    }

/*    @Override
    protected void onStop() {
        sessionManager=new SessionManager(getApplicationContext());
        sessionManager.couterZero();
        super.onStop();}

    @Override
    protected void onDestroy() {
        sessionManager=new SessionManager(getApplicationContext());
        sessionManager.couterZero();
        super.onDestroy();}*/

  /*  @Override
    protected void onStart() {
        EventBusManager.getInstance().getEventBus().register(this);
        super.onStart();}*/


    @Subscribe
    public void onOTPReceivedFromSMS(final OttoEventDriverList driverMessage) {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                List<String> list= driverMessage.getOtp();
                DriverOffer driverOffer = new DriverOffer(list.get(0),list.get(1),list.get(2),list.get(3),list.get(4),list.get(5),list.get(6),list.get(7),list.get(8),list.get(9),list.get(10),
                        list.get(11),list.get(12),list.get(13),list.get(14),list.get(15),list.get(16),list.get(17));
                driverOfferList.add(driverOffer);
                whenrequiredtype=list.get(9);
                typeofmeter = list.get(8);

                Collections.sort(driverOfferList, new Comparator<DriverOffer>() {
                    @Override
                    public int compare(DriverOffer o1, DriverOffer o2) {
                        int year1=Integer.parseInt(o1.getPrice()), year2=Integer.parseInt(o2.getPrice());

                        return year1-year2;
                    }
                });

                mAdapter.notifyDataSetChanged();
                mp.start();

            }
        }, 500);
    }

    public void sendNotification()
    {
        loading = ProgressDialog.show(this,resources.getString(R.string.processing),resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, notificationURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                if(whenrequiredtype.equals("later")){

                                    Intent h = new Intent(getApplicationContext(), NavHome.class);
                                    startActivity(h);
                                    finish();

                                }
                                else {

                                    Intent i = new Intent(getApplicationContext(), DriverLocationTracking.class);
                                    i.putExtra("bookingid", bookingid);
                                    i.putExtra("drivermobile", drivermobile);
                                    i.putExtra("vehicle", vehicle);

                                    startActivity(i);
                                    finish();
                                }

                            } else {

                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();

                    }
                }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();
                params.put("passengername",passengername);
                params.put("passengermobile",passengermobile);
                params.put("drivername",drivername);
                params.put("drivermobile",drivermobile);
                params.put("whenrequiredtype",whenrequiredtype);
                params.put("rate",price);
                params.put("bookingid",bookingid);
                params.put("vehicle",vehicle);
                params.put("typeofrate",typeofmeter);
                params.put("service_tax_val",service_tax_val);
                params.put("service_charge_val",service_charge_val);
                params.put("final_amount_val",final_amount_val);
                return params;

            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
    }

    @Subscribe
    public void ottoEventActivityFinish(OttoEventActivityFinish finish) {
        if(finish.getFinishActivity().equals("driveroffer")){
            finish();
        }
    }

    @Subscribe
    public void getButtonStatus(OttoAllDriversRejected data) {
        Log.i("Activity", data.getRejection());
        AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(DriverOfferActivity.this, android.R.style.Theme_Material_Dialog_Alert);

        if(data.getRejection().equals("Request timeout")){

            builder.setTitle(resources.getString(R.string.request_time_out))
                    .setMessage(resources.getString(R.string.no_response_from_driver))
                    .setPositiveButton(resources.getString(R.string.yes), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            startActivity(new Intent(DriverOfferActivity.this, NavHome.class));
                            finish();
                        }
                    })
                    .setNegativeButton(resources.getString(R.string.no), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            // do nothing
                        }
                    }).setIcon(android.R.drawable.ic_dialog_alert)
                    .show();
        }
}

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (waitTimer!=null) {
            waitTimer.cancel();
            waitTimer = null;
        }
        EventBusManager.getInstance().getEventBus().unregister(this);
    }


    private void sendPassengerReadREceiptNetworkCall(final String id, final String passengerMobile, final String drivermobile) {

        /*if (Utils.isInternetAvailable(DriverOfferActivity.this)) {*/

           /* Utils.showProgress(DriverOfferActivity.this);*/
            StringRequest stringRequest = new StringRequest(Request.Method.POST, sendReadReceiptUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                /*Utils.stopProgress(DriverOfferActivity.this);*/
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {




                                } else {


                                    String errorMsg = jObj.getString("error_msg");
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
/*
                            Utils.stopProgress(DriverOfferActivity.this);
*/
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("bookingid", id);
                    params.put("passengermobile", passengerMobile);
                    params.put("drivermobile", drivermobile);
                    params.put("timestamp", String.valueOf(Calendar.getInstance().getTime()));
                    params.put("status", "4");

                    return params;
                }
            };

            VolleySingleton.getInstance(DriverOfferActivity.this).addToRequestQueue(stringRequest);


    }

}


