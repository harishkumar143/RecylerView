package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import kouchan.siddhesh.com.BookARideAndroid.R;

public class Account extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);


    }
}
