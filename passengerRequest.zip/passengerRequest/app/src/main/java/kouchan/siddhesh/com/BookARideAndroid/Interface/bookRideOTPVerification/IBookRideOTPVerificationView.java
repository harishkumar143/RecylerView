package kouchan.siddhesh.com.BookARideAndroid.Interface.bookRideOTPVerification;

public interface IBookRideOTPVerificationView {

    void onGetBookRideOTPSuccess(int pid, String String);

    void onGetBookRideOTPError(int pid, String regModel);

}
