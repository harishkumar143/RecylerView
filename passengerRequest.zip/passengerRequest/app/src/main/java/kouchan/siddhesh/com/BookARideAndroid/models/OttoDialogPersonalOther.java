package kouchan.siddhesh.com.BookARideAndroid.models;

/**
 * Created by KOUCHAN-ADMIN on 18-Apr-18.
 */

public class OttoDialogPersonalOther {

    String type, name, mobile;

    public OttoDialogPersonalOther(String type, String name, String mobile) {
        this.type = type;
        this.name = name;
        this.mobile = mobile;
    }

    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public String getMobile() {
        return mobile;
    }

}
