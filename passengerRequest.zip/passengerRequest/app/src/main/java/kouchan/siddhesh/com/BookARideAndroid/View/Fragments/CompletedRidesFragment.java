package kouchan.siddhesh.com.BookARideAndroid.View.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Adapter.HistoryAdapter;
import kouchan.siddhesh.com.BookARideAndroid.Adapter.RecyclerTouchListener;
import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.SplashActivity;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.MonthExpandActivity;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.History;
import kouchan.siddhesh.com.BookARideAndroid.other.DividerItemDecoration;


public class CompletedRidesFragment extends Fragment{

    private List<History> historyList = new ArrayList<>();
    private String TAG = SplashActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private RecyclerView recyclerView;
    private HistoryAdapter mAdapter;


    String languageCode;
    Resources resources;

    /*ExpandableListAdapter listAdapter;
    ExpandableListView expListView;
    List<String> listDataHeader;
    private List<History> historyList = new ArrayList<>();

    HashMap<String, List<String>> listDataChild;*/

    HashMap<String, String> user;
    String passengermobile,type;
    String historyUrl= "";
    SessionManager sessionManager;

    Toolbar mToolbar;
    ImageView historyBackImageView, historyHomeImageView;

    View view;

    public CompletedRidesFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflate the layout for this fragment

        view= inflater.inflate(R.layout.fragment_two, container, false);
        historyList.clear();
        recyclerView = (RecyclerView)view. findViewById(R.id.recycler_view_history);

        mAdapter = new HistoryAdapter(historyList,getActivity());
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);

        recyclerView.setAdapter(mAdapter);


// get the listview
        /*expListView = (ExpandableListView) view.findViewById(R.id.lvExp);*/

        // preparing list data


       /* listAdapter = new ExpandableListAdapter(getActivity(), listDataHeader, listDataChild);

        // setting list adapter
        expListView.setAdapter(listAdapter);*/
        sessionManager=new SessionManager(getActivity());

        user = new HashMap<String, String>();
        user=sessionManager.getUserDetails();

        passengermobile=user.get("mobile");

        type=sessionManager.getType();

        /*switch (type){
            case "passenger":*/

        historyUrl= Url.PASSENGER_API+"passengerHistoryByMonth.php";
               /* break;

            case "driver":

                historyUrl= Url.DRIVER_API+"driverHistoryByMonth.php";
                break;

            case "both":

                historyUrl= Url.DRIVER_API+"driverHistoryByMonth.php";
                break;
        }*/

   /*displayHistoy();*/

        /*prepareListData();*/
       /* History movie = new History("Mad Max: Fury Road", "Action & Adventure", "2015","sx","hj","ghhj");
        historyList.add(movie);

        mAdapter.notifyDataSetChanged();*/


        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                History history = historyList.get(position);

              /*  OneFragment fragment2=new OneFragment();
                FragmentManager fragmentManager=getActivity().getFragmentManager();
                FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.viewpager,fragment2,"tag");
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();*/

                Intent i=new Intent(getActivity(),MonthExpandActivity.class);

                i.putExtra("month",history.getMonth());
                i.putExtra("year",history.getYear());

                startActivity(i);



            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));



     /*   expListView = (ExpandableListView)view. findViewById(R.id.lvExp);

        // preparing list data
       *//* prepareListData();*//*

        listAdapter = new ExpandableListAdapter(getActivity(), listDataHeader, listDataChild,historyList);

        // setting list adapter
        expListView.setAdapter(listAdapter);

        // Listview Group click listener
        expListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

            @Override
            public boolean onGroupClick(ExpandableListView parent, View v,
                                        int groupPosition, long id) {

                return false;
            }
        });

        // Listview Group expanded listener
        expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
            }
        });

        // Listview Group collasped listener
        expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {

            }
        });

        // Listview on child click listener
        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                // TODO Auto-generated method stub
                return false;
            }
        });*/



/*        sessionManager=new SessionManager(getActivity());

        user = new HashMap<String, String>();
        user=sessionManager.getUserDetails();

        passengermobile=user.get("mobile");

        type=sessionManager.getType();

        switch (type){
            case "passenger":

                historyUrl= Url.PASSENGER_API+"passengerHistory.php";
                break;

            case "driver":

                historyUrl= Url.DRIVER_API+"driverHistoryByMonth.php";
                break;

            case "both":

                historyUrl= Url.DRIVER_API+"driverHistory.php";
                break;
        }

        listDataHeader = new ArrayList<>();
        listDataChild = new HashMap<String, List<String>>();*/

        displayHistoy();

        sessionManager = new SessionManager(getActivity());
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        return view;
    }



    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(getActivity(), languageCode);
        resources = context.getResources();

        /*forgot_password_tv.setText(resources.getString(R.string.forgot_password));*/

    }


  /*  private void prepareListData() {
        listDataHeader = new ArrayList<>();
        listDataChild = new HashMap<String, List<String>>();

        // Adding child data
        History movie = new History("jan", "2013", "5","2000");
        historyList.add(movie);
        listDataHeader.add("jan");

        movie = new History("feb", "2013", "5","2001");
        historyList.add(movie);
        listDataHeader.add("feb");

        movie = new History("mar", "2013", "5","2001");
        historyList.add(movie);
        listDataHeader.add("mar");

        // Adding child data
        List<String> top250 = new ArrayList<String>();
        top250.add("The Shawshank Redemption");
        top250.add("The Godfather");
        top250.add("The Godfather: Part II");
        top250.add("Pulp Fiction");
        top250.add("The Good, the Bad and the Ugly");
        top250.add("The Dark Knight");
        top250.add("12 Angry Men");

        List<String> nowShowing = new ArrayList<String>();
        nowShowing.add("The Conjuring");
        nowShowing.add("Despicable Me 2");
        nowShowing.add("Turbo");
        nowShowing.add("Grown Ups 2");
        nowShowing.add("Red 2");
        nowShowing.add("The Wolverine");

        List<String> comingSoon = new ArrayList<String>();
        comingSoon.add("2 Guns");
        comingSoon.add("The Smurfs 2");
        comingSoon.add("The Spectacular Now");
        comingSoon.add("The Canyons");
        comingSoon.add("Europa Report");

        String.valueOf(listDataHeader.get(0));

        listDataChild.put(listDataHeader.get(0), top250); // Header, Child data
        listDataChild.put(listDataHeader.get(1), nowShowing);
        listDataChild.put(listDataHeader.get(2), comingSoon);
    }*/



    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("Ride History");

    }

    public void displayHistoy(){
        final ProgressDialog loading = ProgressDialog.show(getActivity(),getString(R.string.processing),getString(R.string.please_wait),false,false);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, historyUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            if (!error) {


                                JSONArray contacts = jsonObj.getJSONArray("user");

                                for (int i = 0; i < contacts.length(); i++) {
                                    JSONObject c = contacts.getJSONObject(i);

                                    String month = c.getString("month");
                                    String year = c.getString("year");
                                    String total_no_of_rides = c.getString("total_no_of_rides");
                                    String total_fare = c.getString("total_fare");
                                   /* String actualprice = c.getString("actualprice");
                                    String vehicle = c.getString("vehicle");*/

                                        History history=new History(month,year,total_no_of_rides,total_fare);
                                        historyList.add(history);
                                        mAdapter.notifyDataSetChanged();
                                        /*listDataHeader.add(month);*/



                                    /*mAdapter.notifyDataSetChanged();*/
                                    // tmp hash map for single contact
                                HashMap<String, String> contact = new HashMap<>();

                                // adding each child node to HashMap key => value

                          /*      contact.put("id",id);
                                contact.put("paymenttype",paymenttype);
                                contact.put("bookingtime",bookingtime);
                                contact.put("ridestatus",ridestatus);
                                contact.put("actualprice",actualprice);
                                contact.put("vehicle",vehicle);*/


                                    // adding contact to contact list
                                }
                            }else {
                                String errorMsg = jsonObj.getString("error_msg");
                            }
                            //         ListAdapter adapter = new SimpleAdapter(getApplicationContext(), contactList, R.layout.history_list_item, new String[]{"paymenttype", "bookingtime", "ridestatus","actualprice","vehicle"}, new int[]{R.id.paymenttype, R.id.bookingtime, R.id.ridestatus, R.id.actualprice, R.id.vehicle});
//
//                            lv.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {

                Map<String,String> params=new HashMap<String, String>();

                params.put("mobile",passengermobile);


                return params ;
            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        historyList.clear();
        mAdapter.notifyDataSetChanged();
    }
}
