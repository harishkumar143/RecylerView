package kouchan.siddhesh.com.BookARideAndroid.Adapter;

import android.content.Context;
import android.content.res.Resources;
import android.support.v7.util.SortedList;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.util.List;

import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.DriverOffer;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

public class DriverOfferAdapter extends RecyclerView.Adapter<DriverOfferAdapter.MyViewHolder> {

    private List<DriverOffer> moviesList;

    String languageCode;
    Resources resources;
    SessionManager sessionManager;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title, year, genre, vehicle, bookingId, rating, typeofmeter, extralessvalue, metervalue, myoffer;

        public TextView name_textView, mobile_no_textView, vehicle_type_textView, rating_textView,
                type_of_meter_textView, my_offer_textView, extra_value_textView, meter_value_textView,
                driver_offers_textView, total_price_textView,service_charge,service_charge_textView,taxamount,
                taxamount_textView, taxAndFees, totalFair,vehicleType;

        public Button acceptCounterOffer,reject;
        public RatingBar ratingBar;
        public ImageView vehicleIv;

        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.title);
            genre = (TextView) view.findViewById(R.id.genre);
            year = (TextView) view.findViewById(R.id.year);
            vehicle = (TextView) view.findViewById(R.id.vehicleTextView);
            rating = (TextView) view.findViewById(R.id.ratingTextView);
            ratingBar = (RatingBar) view.findViewById(R.id.ratingBar);
            reject = (Button) view.findViewById(R.id.reject);
            typeofmeter = (TextView) view.findViewById(R.id.typeofmeter);
            extralessvalue = (TextView) view.findViewById(R.id.extralessvalue);
            metervalue = (TextView) view.findViewById(R.id.metervalue);
            vehicleIv = (ImageView) view.findViewById(R.id.vehicleIv);
            myoffer = (TextView) view.findViewById(R.id.myoffer);
            vehicleType = (TextView) view.findViewById(R.id.vehicleType);

            name_textView = (TextView) view.findViewById(R.id.name_textView);
            mobile_no_textView = (TextView) view.findViewById(R.id.mobile_no_textView);
            vehicle_type_textView = (TextView) view.findViewById(R.id.vehicle_type_textView);
            rating_textView = (TextView) view.findViewById(R.id.rating_textView);
            type_of_meter_textView = (TextView) view.findViewById(R.id.type_of_meter_textView);
            my_offer_textView = (TextView) view.findViewById(R.id.my_offer_textView);
            extra_value_textView = (TextView) view.findViewById(R.id.extra_value_textView);
            meter_value_textView = (TextView) view.findViewById(R.id.meter_value_textView);
            driver_offers_textView = (TextView) view.findViewById(R.id.driver_offers_textView);
            total_price_textView = (TextView) view.findViewById(R.id.total_price_textView);
            acceptCounterOffer = (Button) view.findViewById(R.id.acceptCounterOffer);

            service_charge = (TextView) view.findViewById(R.id.service_charge);
            service_charge_textView = (TextView) view.findViewById(R.id.service_charge_textView);
            taxamount = (TextView) view.findViewById(R.id.taxamount);
            taxamount_textView = (TextView) view.findViewById(R.id.taxamount_textView);

            taxAndFees = (TextView) view.findViewById(R.id.taxAndFees);
            totalFair = (TextView) view.findViewById(R.id.totalFair);
        }
    }

    private Context mContext;
    private LayoutInflater mLayoutInflater;
    private SortedList<DriverOffer> mPersons;

    public DriverOfferAdapter(Context context, List<DriverOffer> moviesList) {
        mContext = context;
        this.moviesList = moviesList;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mPersons = new SortedList<>(DriverOffer.class, new DriverListCallback());
        mPersons.addAll(moviesList);
        this.context = context;
    }

    public void addPerson(DriverOffer driverOffer) {
        mPersons.add(driverOffer);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.driver_offer_list_row, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        DriverOffer driverOffer = moviesList.get(position);
        holder.title.setText(driverOffer.getDrivername());
        holder.genre.setText(driverOffer.getDrivermobile());
        holder.year.setText(driverOffer.getFinal_amount_val());
        holder.vehicle.setText(driverOffer.getVehicle());
        holder.rating.setText(driverOffer.getRating());
        try {
            holder.ratingBar.setRating(Float.parseFloat(driverOffer.getRating()));
            switch (driverOffer.getVehicle()) {

                case "Taxi(4+1)":
                    holder.vehicleIv.setImageResource(R.drawable.ic_car_passenger);
                    break;

                case "Auto":
                    holder.vehicleIv.setImageResource(R.drawable.ic_auto_passenger);
                    break;

                case "Bike":
                    holder.vehicleIv.setImageResource(R.drawable.ic_bike_passenger);
                    break;

                case "Taxi(7+1)":
                    holder.vehicleIv.setImageResource(R.drawable.suv_unselected_ic);
                    break;

            }

        }catch (Exception e){
            e.printStackTrace();
        }
        holder.typeofmeter.setText(moviesList.get(position).getTypeofmeter());
        holder.extralessvalue.setText("₹ "+moviesList.get(position).getExtraLessValue());
        holder.metervalue.setText(moviesList.get(position).getMetervalue());
        holder.vehicleType.setText(moviesList.get(position).getVehicle_model()+moviesList.get(position).getVehicle_sub_type());

        holder.service_charge.setText("₹ "+moviesList.get(position).getService_charge_val());
        holder.taxamount.setText("₹ "+moviesList.get(position).getService_tax_val());


        holder.myoffer.setText("My Fare: ₹ "+moviesList.get(position).getMyoffer());
        // holder.bookingId.setText(driverOffer.getBookingid());

        String myOffer = moviesList.get(position).getMyoffer();

       String serviceCharge= moviesList.get(position).getMyoffer_service_charge();
       String gst = moviesList.get(position).getMyoffer_gst();

        double d = Double.parseDouble(serviceCharge);
        double d1 = Double.parseDouble(gst);
        double d2 = Double.parseDouble(myOffer);
        double sum=d+d1;
       // String serviceChAndGst = Double.toString(sum);

        BigDecimal big= Utils.roundTo(new BigDecimal(sum),2);

        double totalFare = sum+d2;

        holder.totalFair.setText("Total Fare: ₹  "+totalFare);
        holder.taxAndFees.setText("Taxes & Fees: ₹ "+big);

        sessionManager = new SessionManager(context);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();

            Context contexta = LocaleHelper.setLocale(context, languageCode);
            resources = contexta.getResources();
            holder.name_textView.setText(resources.getString(R.string.driver_name));
            holder.mobile_no_textView.setText(resources.getString(R.string.mobile_no));
            holder.vehicle_type_textView.setText(resources.getString(R.string.vehicle_type));
            holder.rating_textView.setText(resources.getString(R.string.rating));
            holder.type_of_meter_textView.setText(resources.getString(R.string.type_of_meter));
            holder.my_offer_textView.setText(resources.getString(R.string.my_offer));
            holder.extra_value_textView.setText(resources.getString(R.string.driver_offer));
            holder.meter_value_textView.setText(resources.getString(R.string.meter_value));
            holder.driver_offers_textView.setText(resources.getString(R.string.driver_offer));
            holder.total_price_textView.setText(resources.getString(R.string.driver_offer));
            holder.acceptCounterOffer.setText(resources.getString(R.string.accept_counter_offer));

        }

        holder.reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Coming soon!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
}


class DriverListCallback extends SortedList.Callback<DriverOffer> {

    @Override
    public int compare(DriverOffer p1, DriverOffer p2) {
        String[] rank1 = p1.getPrice().split("\n");
        String[] rank2 = p2.getPrice().split("\n");
        int diff = Integer.parseInt(rank1[0]) - Integer.parseInt(rank2[0]);
        return (diff == 0) ? p1.getDrivername().compareTo(p2.getDrivername()) : diff;
    }

    @Override
    public void onInserted(int position, int count) {
        //notifyItemInserted(position);
    }

    @Override
    public void onRemoved(int position, int count) {
        //notifyItemRemoved(position);
    }

    @Override
    public void onMoved(int fromPosition, int toPosition) {
    }

    @Override
    public void onChanged(int position, int count) {
    }

    @Override
    public boolean areContentsTheSame(DriverOffer oldItem, DriverOffer newItem) {
        return false;
    }

    @Override
    public boolean areItemsTheSame(DriverOffer item1, DriverOffer item2) {
        return false;
    }

}


