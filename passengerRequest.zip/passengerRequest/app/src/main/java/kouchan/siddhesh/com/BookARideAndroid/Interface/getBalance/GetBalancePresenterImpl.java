package kouchan.siddhesh.com.BookARideAndroid.Interface.getBalance;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Api.ServerApiNames;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.NavHome;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.PaymentActivity;
import kouchan.siddhesh.com.BookARideAndroid.async.AsyncInteractor;
import kouchan.siddhesh.com.BookARideAndroid.async.OnRequestListener;
import kouchan.siddhesh.com.BookARideAndroid.models.PaymentModel;
import kouchan.siddhesh.com.BookARideAndroid.utils.AppConstants;
import kouchan.siddhesh.com.BookARideAndroid.utils.NetworkStatus;
import kouchan.siddhesh.com.BookARideAndroid.utils.Sharedpreferences;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

public class GetBalancePresenterImpl implements IGetBalancePresnter,OnRequestListener {

    NavHome navHome;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IGetBalanceView getBalanceView;

    public GetBalancePresenterImpl(IGetBalanceView getBalanceView) {
        this.navHome =(NavHome) getBalanceView;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(navHome);
        this.asyncInteractor = new AsyncInteractor(navHome);
        this.getBalanceView = getBalanceView;
    }

    @Override
    public void getBalance(String mobileNo) {
        if(NetworkStatus.checkNetworkStatus(navHome)){
            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_GETBALANCE, "https://bookarideworldwide.com/CAB2.V.1/driver_api/m3getbalance.php?mobile="+mobileNo);
        } else {
            Utils.showToast(navHome, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if(pid==AppConstants.TAG_ID_GETBALANCE){
        //    Utils.stopProgress(navHome);
            if(responseJson!=null){
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if(!error) {
                    getBalanceView.getBalanceSuccess(pid,jObj.getString("walletBalance"));
                }
                else {
                    getBalanceView.getBalanceError(pid,jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(navHome);
        getBalanceView.getBalanceError(pid,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        Utils.stopProgress(navHome);
        getBalanceView.getBalanceError(pid,error);
    }
}
