package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.otto.Subscribe;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.BroadcastReceivers.NetworkChangeReceiver;
import kouchan.siddhesh.com.BookARideAndroid.Database.PrefManager;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Interface.faq.GetFAQPresenterImpl;
import kouchan.siddhesh.com.BookARideAndroid.Interface.faq.IGetFAQPresnter;
import kouchan.siddhesh.com.BookARideAndroid.Interface.faq.IGetFAQView;
import kouchan.siddhesh.com.BookARideAndroid.Interface.getBalance.GetBalancePresenterImpl;
import kouchan.siddhesh.com.BookARideAndroid.Interface.getBalance.IGetBalancePresnter;
import kouchan.siddhesh.com.BookARideAndroid.Interface.getBalance.IGetBalanceView;
import kouchan.siddhesh.com.BookARideAndroid.Interface.getprofile.GetProfilePresenterImpl;
import kouchan.siddhesh.com.BookARideAndroid.Interface.getprofile.IGetProfilePresnter;
import kouchan.siddhesh.com.BookARideAndroid.Interface.getprofile.IGetProfileView;
import kouchan.siddhesh.com.BookARideAndroid.Otto.EventBusManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.View.Fragments.Menu2;
import kouchan.siddhesh.com.BookARideAndroid.View.Fragments.MenuPassenger;
import kouchan.siddhesh.com.BookARideAndroid.View.Fragments.PassengerHomeFragment;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoEventActivityFinish;
import kouchan.siddhesh.com.BookARideAndroid.other.CustomeDialogGeneric;
import kouchan.siddhesh.com.BookARideAndroid.other.OttoDialogGeneric;

public class NavHome extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, IGetBalanceView,
        IGetProfileView, IGetFAQView {


    private View navHeader;
    TextView txtName, txtWebsite, txtId, txtEmail, toolbarTextView;
    private static final String urlProfileImg = "https://lh3.googleusercontent.com/eCtE_G34M9ygdkmOpYvCag1vBARCmZwnVS6rS5t4JLzJ6QgQSBquM0nuTsCpLhYbKljoyS-txg";
    private ImageView imgProfile;
    SessionManager sessionManager;
    HashMap<String, String> user = new HashMap<String, String>();
    String name, mobile;

    NavigationView navigationView;

    IGetBalancePresnter getBalancePresnter;
    IGetProfilePresnter getProfilePresnter;
    IGetFAQPresnter getFAQPresnter;

    String faqresponse;

    String type, id, email;

    NetworkChangeReceiver receiver;

    private String passengerData;

    private PrefManager prefManager;

    AlertDialog.Builder builder;

    MenuItem nav_walletBalance;

    ProgressDialog loading;

    String tokenUpdateUrl = Url.PASSENGER_API + "firebaseTokenUpdate.php";

    String versionupdate = Url.COMUNICATE_API + "apkversion.php";

    String URL_FAQ = "https://bookarideworldwide.com/CAB2.V.1/web/p_faq.html";

    String languageCode;
    Resources resources;
    String from,to,fromlatitude,fromlongitude,tolatitude,tolongitude,vehicalType;

    CustomeDialogGeneric cdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        EventBusManager.getInstance().getEventBus().register(this);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

/*
        getSupportActionBar().setCustomView(R.layout.actionbar_logo);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
*/

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);

        navHeader = navigationView.getHeaderView(0);
        txtName = (TextView) navHeader.findViewById(R.id.name);
        txtWebsite = (TextView) navHeader.findViewById(R.id.website);
        txtEmail = (TextView) navHeader.findViewById(R.id.email);
        txtId = (TextView) navHeader.findViewById(R.id.textViewId);
        imgProfile = (ImageView) navHeader.findViewById(R.id.img_profile);

        sessionManager = new SessionManager(getApplicationContext());
        prefManager = new PrefManager(NavHome.this);

        user = sessionManager.getUserDetails();
        name = user.get("name");
        mobile = user.get("mobile");

        id = sessionManager.getId();
        email = sessionManager.getKeyEmail();

        getProfilePresnter = new GetProfilePresenterImpl(this);
        getProfilePresnter.getProfile(mobile);


        Intent i=getIntent();
        if(i!=null){
            from=i.getStringExtra("from");
            to=i.getStringExtra("to");
            fromlatitude=i.getStringExtra("fromlatitude");
            fromlongitude=i.getStringExtra("fromlongitude");
            tolatitude=i.getStringExtra("tolatitude");
            tolongitude=i.getStringExtra("tolongitude");
            vehicalType=i.getStringExtra("vehicle_type");

        }
        /*-----------------------------------------------------------------------------------*/

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);

        // get menu from navigationView
        Menu menu = navigationView.getMenu();

        // do the same for other MenuItems
        MenuItem nav_home = menu.findItem(R.id.nav_home);
        nav_home.setTitle(resources.getString(R.string.nav_home));

        MenuItem nav_additional_info = menu.findItem(R.id.nav_additional_info);
        nav_additional_info.setTitle(resources.getString(R.string.nav_Additionalinfo));

        MenuItem nav_m3account = menu.findItem(R.id.nav_m3account);
        nav_m3account.setTitle(resources.getString(R.string.nav_m3account));

        MenuItem nav_booking_history = menu.findItem(R.id.nav_booking_history);
        nav_booking_history.setTitle(resources.getString(R.string.nav_booking_history));

        MenuItem nav_security_settings = menu.findItem(R.id.nav_security_settings);
        nav_security_settings.setTitle(resources.getString(R.string.nav_security_settings));

        MenuItem nav_invite_friends = menu.findItem(R.id.nav_invite_friends);
        nav_invite_friends.setTitle(resources.getString(R.string.nav_invite_friends));

        MenuItem nav_faqs = menu.findItem(R.id.nav_faqs);
        nav_faqs.setTitle(resources.getString(R.string.nav_faqs));

        MenuItem edit_profile = menu.findItem(R.id.edit_profile);
        edit_profile.setTitle(resources.getString(R.string.edit_profile));

        MenuItem nav_about_us = menu.findItem(R.id.nav_contact_us);
        nav_about_us.setTitle(resources.getString(R.string.nav_contact_us));

        MenuItem nav_logout = menu.findItem(R.id.nav_logout);
        nav_logout.setTitle(resources.getString(R.string.nav_logout));

        MenuItem nav_payment = menu.findItem(R.id.nav_payment);
        nav_payment.setTitle(resources.getString(R.string.nav_payment));

        MenuItem nav_favorit = menu.findItem(R.id.nav_favorit);
        nav_favorit.setTitle(resources.getString(R.string.nav_favorit));

        nav_walletBalance = menu.findItem(R.id.get_balance);

//        if (sessionManager.getM3otpstatus().equalsIgnoreCase("1")) {
//            //   nav_walletBalance.setVisible(true);
//            getBalancePresnter = new GetBalancePresenterImpl(this);
//            getBalancePresnter.getBalance(mobile);
//        }

        // add NavigationItemSelectedListener to check the navigation clicks
        navigationView.setNavigationItemSelectedListener(this);

        /*-----------------------------------------------------------------------------------*/


        loadNavHeader();
        //add this line to display menu1 when the activity is loaded
        receiver = new NetworkChangeReceiver();
        registerReceiver(receiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));


        type = sessionManager.getType();
        Menu nav_Menu = navigationView.getMenu();

        displaySelectedScreen(R.id.nav_home);
        txtId.setText("User Id-P " + id);
        //firebaseTokenUpdate();
        txtEmail.setText(email);

        imgProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Intent editProP = new Intent(getApplicationContext(), EditProfileActivity.class);
                ///startActivity(editProP);
                //finish();

            }
        });


        versionUpdate();


    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        /*forgot_password_tv.setText(resources.getString(R.string.forgot_password));*/

    }

    private void firebaseTokenUpdate() {


        user = sessionManager.getUserDetails();
        loading = ProgressDialog.show(this, resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, tokenUpdateUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {
                                // User sRIuccessfully stored in MySQL


                            } else {

                                // Error occurred in registration. Get the error
                                // message
                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("mobile", user.get("mobile"));
                params.put("token", sessionManager.getToken());
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    private void loadNavHeader() {

        txtName.setText(name);
        txtWebsite.setText("+91 " + mobile);


        // Loading profile image
     /*   Glide.with(this).load(urlProfileImg)
                .crossFade()
                .thumbnail(0.5f)
                .bitmapTransform(new CircleTransform(this))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(imgProfile);*/
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        FragmentManager manager = getSupportFragmentManager();


        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            /*super.onBackPressed();*/
            if (manager.getBackStackEntryCount() > 0) {
                // If there are back-stack entries, leave the FragmentActivity
                // implementation take care of them.
                getFragmentManager().popBackStackImmediate();

            } else {
                new AlertDialog.Builder(this)
                        .setMessage(resources.getString(R.string.are_you_sure_you_want_to_exit))
                        .setNegativeButton(resources.getString(R.string.no), null)
                        .setPositiveButton(resources.getString(R.string.yes), new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface arg0, int arg1) {

                                NavHome.super.onBackPressed();

                            }
                        }).create().show();
            }
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        /*getMenuInflater().inflate(R.menu.main, menu);*/
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the AditionalInfoSubmitedActivity/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
       /* if (id == R.id.action_settings) {
            return true;
        }*/

        return super.onOptionsItemSelected(item);
    }

    private void displaySelectedScreen(int itemId) {

        //creating fragment object
        Fragment fragment = null;

        //initializing the fragment object which is selected
        switch (itemId) {
            case R.id.nav_home:
                fragment = new MenuPassenger();

                Bundle bundle=new Bundle();
                bundle.putString("from", from);
                bundle.putString("to", to);
                bundle.putString("fromlatitude", fromlatitude);
                bundle.putString("fromlongitude", fromlongitude);
                bundle.putString("tolatitude", tolatitude);
                bundle.putString("tolongitude", tolongitude);
                bundle.putString("vehicle_type", vehicalType);

                if(from!=null){
                    fragment.setArguments(bundle);
                }
                break;
            case R.id.nav_payment:
                fragment = new Menu2();
                break;
            case R.id.nav_favorit:
                // fragment = new Menu2();
                break;

            case R.id.nav_invite_friends:
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "My app name");
                    String strShareMessage = resources.getString(R.string.nav_let_me_recommend_you);
                    strShareMessage = strShareMessage + "https://play.google.com/store/apps/details?id=" + getPackageName();
                    //  Uri screenshotUri = Uri.parse("android.resource://packagename/drawable/image_name");
                    // i.setType("image/png");
                    //  i.putExtra(Intent.EXTRA_STREAM, screenshotUri);
                    i.putExtra(Intent.EXTRA_TEXT, strShareMessage);
                    startActivity(Intent.createChooser(i, resources.getString(R.string.nav_share_via)));
                } catch (Exception e) {
                    //e.toString();
                }
                break;

            case R.id.nav_additional_info:


                if (!prefManager.isAddInfo()) {
                    launchHomeScreen();
                } else {
                    Intent ad = new Intent(getApplicationContext(), AdditionInfoActivity.class);
                    startActivity(ad);
                    finish();
                }
                break;

            case R.id.nav_contact_us:
                Intent au = new Intent(getApplicationContext(), ContactUsActivity.class);
                startActivity(au);
                break;

            case R.id.nav_faqs:
                Intent faq = new Intent(getApplicationContext(), WebViewActivity.class);
                faq.putExtra("url", URL_FAQ);
                String faqs_titel = "FAQs";
                faq.putExtra("action_bar_name", faqs_titel);
                startActivity(faq);

                break;

            case R.id.edit_profile:
                Intent au1 = new Intent(getApplicationContext(), EditProfileActivity.class);
                au1.putExtra("PassengerData", passengerData);
                startActivity(au1);
                //finish();
                break;

           /* case R.id.nav_privacy_policy:
                Intent i = new Intent(getApplicationContext(), AboutUs.class);
                startActivity(i);
                break;*/

            case R.id.nav_security_settings:
                Intent intent = new Intent(getApplicationContext(), SecurityAndSettingsActivity.class);
                startActivity(intent);
                break;

            case R.id.nav_booking_history:
                Intent history = new Intent(getApplicationContext(), RideHistoryActivity.class);
                startActivity(history);
                break;

            case R.id.nav_m3account:
                Intent m3account = new Intent(getApplicationContext(), AadharRegistrationActivity.class);
                ArrayList<String> data = sessionManager.loginData();
                m3account.putExtra("mobile", data.get(1));
                m3account.putExtra("name", data.get(0));
                m3account.putExtra("password", sessionManager.getPassword());
                m3account.putExtra("email", sessionManager.getKeyEmail());
                startActivity(m3account);
                break;

            case R.id.nav_booking:
                Intent booking = new Intent(getApplicationContext(), AdvanceBooking.class);
                startActivity(booking);
                finish();
                break;

            case R.id.nav_logout:

                cdd = new CustomeDialogGeneric(NavHome.this, resources.getString(R.string.nav_logout), resources.getString(R.string.nav_would_you_like_to_logout), resources.getString(R.string.yes), resources.getString(R.string.no), "logout", receiver);
                cdd.setCancelable(false);
                cdd.show();
                Window window = cdd.getWindow();
                assert window != null;
                window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);

                break;
        }

        //replacing the fragment
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.content_frame, fragment);
            ft.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    private void launchHomeScreen() {
        startActivity(new Intent(NavHome.this, AditionalInfoSubmitedActivity.class));
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        //calling the method displayselectedscreen and passing the id of selected menu
        displaySelectedScreen(item.getItemId());
        //make this method blank
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        getFAQPresnter = new GetFAQPresenterImpl(this);
        getFAQPresnter.getFAQ();

    }

    @Override
    protected void onStop() {
        super.onStop();

        /*finish();*/
    }

    @Override
    protected void onStart() {
        super.onStart();


    }

    @Subscribe
    public void ottoEventActivityFinish(OttoEventActivityFinish finish) {
        if (finish.getFinishActivity().equals("navhome")) {
            finish();
        }
    }


    private void versionUpdate() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, versionupdate,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {


                            } else {


                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }) {
            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();

                params.put("mobile", mobile);
                params.put("name", name);
                params.put("version", "1.0");
                params.put("type", type);

                return params;

            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    @Subscribe
    public void ottoDialogBoxLogout(OttoDialogGeneric ottoDialogGeneric) {

        if (ottoDialogGeneric.getType().equals("logout")) {

            if (ottoDialogGeneric.getValue().equals("yes")) {

                //  cdd.dismiss();

                sessionManager.logoutUser(NavHome.this);
                prefManager.setSelectionScreen(true);
                finish();

            }
        }

    }

    @Override
    public void getBalanceSuccess(int pid, String balance) {

        nav_walletBalance.setTitle(balance);
        sessionManager.setWalletBal(balance);
    }

    @Override
    public void getBalanceError(int pid, String error) {

    }

    @Override
    public void getProfileSuccess(int pid, String balance) {
        passengerData = balance;
    }

    @Override
    public void getProfileError(int pid, String error) {

        getProfilePresnter.getProfile(mobile);
    }

    @Override
    public void getFAQSuccess(int pid, String response) {
        this.faqresponse = response;
    }

    @Override
    public void getFAQError(int pid, String error) {

    }
}
