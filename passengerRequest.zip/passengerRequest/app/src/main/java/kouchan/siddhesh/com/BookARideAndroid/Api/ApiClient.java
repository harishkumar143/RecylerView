package kouchan.siddhesh.com.BookARideAndroid.Api;


public interface ApiClient {
 String REGENERATE_OAUTH_TOKEN = "http://www.m3.in.net:8080/kouchan-m3application/oauth/token?grant_type=refresh_token&client_id=M3_ANDROID_CLIENT&client_secret=android-m3-kouchan-secret&refresh_token=";
}

