package kouchan.siddhesh.com.BookARideAndroid.Api;

public interface ServerApiNames {
  String PAYMENT = "paymentintegration.php";
}
