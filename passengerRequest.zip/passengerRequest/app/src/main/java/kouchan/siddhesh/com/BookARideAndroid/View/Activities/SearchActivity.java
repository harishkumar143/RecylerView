package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.location.places.PlaceBuffer;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Adapter.CustomItemClickListener;
import kouchan.siddhesh.com.BookARideAndroid.Adapter.FavouriteAdapter;
import kouchan.siddhesh.com.BookARideAndroid.Adapter.PlaceAutocompleteAdapter;
import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Interface.deletefavourite.DeleteFavouritePresenterImpl;
import kouchan.siddhesh.com.BookARideAndroid.Interface.deletefavourite.IDeleteFavouritePresnter;
import kouchan.siddhesh.com.BookARideAndroid.Interface.deletefavourite.IDeleteFavouriteView;
import kouchan.siddhesh.com.BookARideAndroid.Otto.EventBusManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.models.FavoriteModel;
import kouchan.siddhesh.com.BookARideAndroid.other.OttoSelectedFromFavorite;

public class SearchActivity extends AppCompatActivity implements PlaceAutocompleteAdapter.PlaceAutoCompleteInterface, GoogleApiClient.OnConnectionFailedListener,
        GoogleApiClient.ConnectionCallbacks,View.OnClickListener,IDeleteFavouriteView {
        Context mContext;
        GoogleApiClient mGoogleApiClient;
        Toolbar mToolbar;
        LinearLayout mParent;
        private RecyclerView mRecyclerView;
        private RecyclerView mFavRecyclerView;
        ImageView searchActivityBackImageView;
        LinearLayoutManager llm;
        PlaceAutocompleteAdapter mAdapter;
        FavouriteAdapter favouriteAdapter;
        ArrayList<FavoriteModel> favoriteModels;
        String favoriteUrl= Url.PASSENGER_API+"getfavorites.php";
        IDeleteFavouritePresnter deleteFavouritePresnter;
        private static final LatLngBounds BOUNDS_INDIA = new LatLngBounds(
                new LatLng(-0, 0), new LatLng(0, 0));
        TextView fav;
        EditText mSearchEdittext;
        ImageView mClear;

        SessionManager sessionManager;

        @Override
        public void onStart() {
            mGoogleApiClient.connect();
            super.onStart();

        }

        @Override
        public void onStop() {
            mGoogleApiClient.disconnect();
            super.onStop();
        }

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_search);
            searchActivityBackImageView = (ImageView) findViewById(R.id.searchActivityBackImageView);
            searchActivityBackImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
            mContext = SearchActivity.this;
            sessionManager=new SessionManager(getApplicationContext());
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .enableAutoManage(this, 0 /* clientId */, this)
                    .addApi(Places.GEO_DATA_API)
                    .build();

            initViews();
        }

    /*
   Initialize Views
    */
        private void initViews(){
            mToolbar = (Toolbar) findViewById(R.id.searchToolbar);
           // setSupportActionBar(mToolbar);
            mRecyclerView = (RecyclerView)findViewById(R.id.list_search);
            mFavRecyclerView = (RecyclerView)findViewById(R.id.favlist);
            mRecyclerView.setHasFixedSize(true);
            llm = new LinearLayoutManager(mContext);
            fav = (TextView) findViewById(R.id.fav);
            mFavRecyclerView.setLayoutManager(llm);
            mSearchEdittext = (EditText)findViewById(R.id.search_et);
            mClear = (ImageView)findViewById(R.id.clear);
            mClear.setOnClickListener(this);

            if(getIntent().getStringExtra("Source")!=null){
                if(getIntent().getStringExtra("Source").equalsIgnoreCase("from")){
                    mSearchEdittext.setHint("Enter Pickup Location");
                }
                else{
                    mSearchEdittext.setHint("Enter Drop Location");
                }
            }
            mAdapter = new PlaceAutocompleteAdapter(this, R.layout.view_placesearch,
                    mGoogleApiClient, BOUNDS_INDIA, null,getIntent().getStringExtra("Source"));
            mRecyclerView.setAdapter(mAdapter);

            mRecyclerView.setVisibility(View.GONE);
            favoriteModels = new ArrayList<>();
            StringRequest stringRequest=new StringRequest(Request.Method.POST, favoriteUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {

                                JSONObject jsonObj = new JSONObject(response);
                                boolean error = jsonObj.getBoolean("error");
                                if (!error) {


                                    JSONArray contacts = jsonObj.getJSONArray("user");

                                    for (int i = 0; i < contacts.length(); i++) {
                                        JSONObject c = contacts.getJSONObject(i);

                                        int id=c.getInt("id");
                                        String type = c.getString("addresstype");
                                        String address = c.getString("address");
                                        String tolatitude = c.getString("latitude");
                                        String tolongitude = c.getString("longitude");
                                        /* String latlongtype = c.getString("latlongtype");*/
                                        String latlongtype="source";

                                        FavoriteModel favorite=new FavoriteModel(String.valueOf(id),type,address,tolatitude,tolongitude);

                                        favoriteModels.add(favorite);

                                    }
                                }else {
                                    String errorMsg = jsonObj.getString("error_msg");

                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    }){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError
                {

                    Map<String,String> params=new HashMap<String, String>();

                    params.put("mobile",sessionManager.getUserDetails().get("mobile"));

                    return params ;
                }
            };

            VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);

            favouriteAdapter = new FavouriteAdapter(this, R.layout.view_favourite,
                    getIntent().getStringExtra("Source"), favoriteModels,new CustomItemClickListener() {
                @Override
                public void onItemClick(View v, String position) {
                    deleteFavouritePresnter = new DeleteFavouritePresenterImpl(SearchActivity.this);
                    deleteFavouritePresnter.deleteFavourite(position);
                }
            });

            mFavRecyclerView.setAdapter(favouriteAdapter);

            mSearchEdittext.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (count > 0) {
                        mClear.setVisibility(View.VISIBLE);
                        if (mAdapter != null) {
                            mFavRecyclerView.setVisibility(View.GONE);
                            llm = new LinearLayoutManager(mContext);
                            mRecyclerView.setLayoutManager(llm);
                            mRecyclerView.setAdapter(mAdapter);
                            mRecyclerView.setVisibility(View.VISIBLE);
                            fav.setVisibility(View.GONE);
                        }
                    } else {
                        mClear.setVisibility(View.GONE);
                        mRecyclerView.setVisibility(View.GONE);
                        fav.setVisibility(View.VISIBLE);
                        llm = new LinearLayoutManager(mContext);
                        mFavRecyclerView.setLayoutManager(llm);
                        mFavRecyclerView.setAdapter(favouriteAdapter);
                        mFavRecyclerView.setVisibility(View.VISIBLE);
                    }
                    if (!s.toString().equals("") && mGoogleApiClient.isConnected()) {
                        mAdapter.getFilter().filter(s.toString());
                    } else if (!mGoogleApiClient.isConnected()) {
//                       Log.e("", "NOT CONNECTED");
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });

        }

        @Override
        public void onClick(View v) {
            if(v == mClear){
                mSearchEdittext.setText("");
                if(mAdapter!=null){
                    mAdapter.clearList();
                }

            }
        }



        @Override
        public void onConnected(Bundle bundle) {

        }

        @Override
        public void onConnectionSuspended(int i) {

        }

        @Override
        public void onConnectionFailed(ConnectionResult connectionResult) {

        }

        @Override
        public void onPlaceClick(ArrayList<PlaceAutocompleteAdapter.PlaceAutocomplete> mResultList, int position,final String status) {
            if(mResultList!=null){
                try {
                    final String placeId = String.valueOf(mResultList.get(position).placeId);
                        /*
                             Issue a request to the Places Geo Data API to retrieve a Place object with additional details about the place.
                         */

                    PendingResult<PlaceBuffer> placeResult = Places.GeoDataApi
                            .getPlaceById(mGoogleApiClient, placeId);
                    placeResult.setResultCallback(new ResultCallback<PlaceBuffer>() {
                        @Override
                        public void onResult(PlaceBuffer places) {
                            if(places.getCount()==1){
                                //Do the things here on Click.....
                               /* Intent data = new Intent();
                                data.putExtra("lat",String.valueOf(places.get(0).getLatLng().latitude));
                                data.putExtra("lng", String.valueOf(places.get(0).getLatLng().longitude));
                                setResult(SearchActivity.RESULT_OK, data);*/
                                OttoSelectedFromFavorite ottoSelectedFromFavorite= new OttoSelectedFromFavorite( String.valueOf(places.get(0).getAddress()),String.valueOf(places.get(0).getLatLng().latitude),
                                        String.valueOf(places.get(0).getLatLng().longitude),status);
                                EventBusManager.getInstance().getEventBus().post(ottoSelectedFromFavorite);
                                finish();
                            }else {
                            }
                        }
                    });
                }
                catch (Exception e){

                }

            }
        }

    @Override
    public void deleteFavouriteSuccess(int pid, String response) {
        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void deleteFavouriteError(int pid, String error) {
        Toast.makeText(getApplicationContext(), error, Toast.LENGTH_SHORT).show();
    }
}
