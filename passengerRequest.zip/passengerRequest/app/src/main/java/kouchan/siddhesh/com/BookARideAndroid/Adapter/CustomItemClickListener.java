package kouchan.siddhesh.com.BookARideAndroid.Adapter;

import android.view.View;

public interface CustomItemClickListener {

    public void onItemClick(View v, String position);
}
