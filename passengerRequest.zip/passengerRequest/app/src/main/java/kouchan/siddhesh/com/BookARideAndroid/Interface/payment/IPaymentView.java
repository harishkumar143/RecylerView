package kouchan.siddhesh.com.BookARideAndroid.Interface.payment;

import kouchan.siddhesh.com.BookARideAndroid.models.PaymentModel;

public interface IPaymentView {

    void paymentSuccess(int pid, PaymentModel paymentModel);

    void paymentError(int pid, String error);

}
