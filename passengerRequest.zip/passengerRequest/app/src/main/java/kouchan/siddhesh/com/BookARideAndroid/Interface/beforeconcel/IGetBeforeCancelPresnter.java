package kouchan.siddhesh.com.BookARideAndroid.Interface.beforeconcel;

public interface IGetBeforeCancelPresnter {

    void getBeforeCancel();

}

