package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.squareup.otto.Subscribe;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.PrefManager;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.functions.Functions;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

import static kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager.KEY_MOBILE;


public class LoginActivity extends AppCompatActivity {

    private static final String requestForOTP = Url.PASSENGER_API + "forgotPassword.php";
    public static String stringMobile, id, email, vehicleType;
    public AwesomeValidation awesomeValidation;
    TextView activity_passenger_login;
    TextView forgotPassword;
    TextView registration_text_passenger, registration_text_passenger1;
    ProgressDialog loading;
    EditText mobile;
    EditText password;
    SessionManager sessionManager;
    PrefManager prefManager;
    String stringPassword;
    Button login;
    Toolbar mToolbar;
    String languageCode;
    Resources resources;
    String mobile_no_session;
    HashMap<String, String> user = new HashMap<String, String>();
    AlertDialog alertDialog1;
    CharSequence[] values = {"Current Mobile Number", "Alternate Mobile Number"};
    String selectedOption;
    private String LOGIN_URL = Url.PASSENGER_API + "login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sessionManager = new SessionManager(getApplicationContext());
        prefManager = new PrefManager(getApplicationContext());


        if (sessionManager.isLoggedIn() && !prefManager.isWaitingForSms()) {
            startActivity(new Intent(getApplicationContext(), NavHome.class));
            finish();
        } else {

            selectedOption = "passenger";
            sessionManager.createType(selectedOption);

            mobile = (EditText) findViewById(R.id.login_mobile);
// Request focus and show soft keyboard automatically
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            user = sessionManager.getUserDetails();
            mobile_no_session = user.get(KEY_MOBILE);

            //mobile.setTextSize(14);
            //String code = "+91 ";
            // mobile.setCompoundDrawablesWithIntrinsicBounds(new TextDrawable(code), null, null, null);

            //mobile.setCompoundDrawablePadding(code.length() * 18);
            // mobile.setText(mobile_no_session);


            password = (EditText) findViewById(R.id.login_password);
            login = (Button) findViewById(R.id.login_button);
            // signup_passenger = (Button) findViewById(R.id.signup_passenger);

            //changeLanguagePassenger = (TextView) findViewById(R.id.changeLanguagePassenger);

            forgotPassword = (TextView) findViewById(R.id.forgotPasswordPassenger);
            //forgotPassword.setPaintFlags(forgotPassword.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

            registration_text_passenger = (TextView) findViewById(R.id.registration_text_passenger);
            //registration_text_passenger.setPaintFlags(registration_text_passenger.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

            registration_text_passenger1 = (TextView) findViewById(R.id.registration_text_passenger1);
            // registration_text_passenger1.setPaintFlags(registration_text_passenger1.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

            // app_name = (TextView) findViewById(R.id.app_name);
            activity_passenger_login = (TextView) findViewById(R.id.activity_passenger_login);

            // login_mobile_TextInputLayout = (TextInputLayout) findViewById(R.id.login_mobile_TextInputLayout);
            //login_password_TextInputLayout = (TextInputLayout) findViewById(R.id.login_password_TextInputLayout);

            awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
            awesomeValidation.addValidation(this, R.id.login_mobile, "^[7-9]{1}[0-9]{9}$", R.string.mobileerror);
            /*String regexPassword = "^[a-zA-Z0-9@.#$%^&*_!~`+=/-]{8,}$";*/
            String regexPassword = ".{6,8}";
            // awesomeValidation.addValidation(this, R.id.login_password_TextInputLayout, regexPassword, R.string.passworderror);


            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (!(awesomeValidation.validate())) {
                    } else {

                        stringMobile = mobile.getText().toString();
                        stringPassword = password.getText().toString();
                        sendValues();
                    }
                }
            });


            password.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {

                    stringMobile = mobile.getText().toString();
                    stringPassword = password.getText().toString();
                    int passwordLength = stringPassword.length();
                    if (passwordLength == 8) {
                        //sendValues();
                    }
                    /*if (!(awesomeValidation.validate())) {
                    } else {
                        stringMobile = mobile.getText().toString();
                        stringPassword = password.getText().toString();
                        sendValues();
                    }*/
                }
            });


            forgotPassword.setOnClickListener(new View.OnClickListener() {
                                                  @Override
                                                  public void onClick(View v) {

                                                      stringMobile = mobile.getText().toString();
                                                      if (!(Functions.isMobileValid(mobile.getText().toString()))) {
                                                          Toast.makeText(LoginActivity.this, "Please check mobile number", Toast.LENGTH_SHORT).show();
                                                      } else {

                                                          CreateAlertDialogWithRadioButtonGroup();

                                                      }
                                                  }
                                              }
            );


           /* changeLanguagePassenger.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(LoginActivity.this, LanguageSelectionActivity.class);
                    startActivity(intent);
                }
            });*/

            registration_text_passenger.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(LoginActivity.this, Registration.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                    finish();
                }
            });

            registration_text_passenger1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(LoginActivity.this, Registration.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                    finish();
                }
            });

            sessionManager = new SessionManager(this);
            if (sessionManager.getLanguageCode() != null) {
                languageCode = sessionManager.getLanguageCode();
                updateViews(languageCode);
            }

        }

        permission();
    }


    /*----------------------------------------------------------------------*/

    public void CreateAlertDialogWithRadioButtonGroup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
        builder.setTitle("Did you forget your password?")
                .setPositiveButton(resources.getString(R.string.yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        sendPasswordForOTP();
                    }
                })
                .setNegativeButton(resources.getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing
                        alertDialog1.dismiss();
                    }
                }).setIcon(android.R.drawable.ic_dialog_alert)
                .show();
        /*builder.set
        builder.setSingleChoiceItems(values, -1, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int item) {

                switch (item) {

                    case 0:

                        sendPasswordForOTP(1);

                        break;
                    case 1:

                        sendPasswordForOTP(2);

                        break;
                }
                alertDialog1.dismiss();
            }
        });*/
        alertDialog1 = builder.create();
        alertDialog1.show();
    }

    /*-----------------------------------------------------------------------*/

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        activity_passenger_login.setText(resources.getString(R.string.login));
        // app_name.setText(resources.getString(R.string.app_name));
        //login_mobile_TextInputLayout.setHint(resources.getString(R.string.mobile_no));
        // login_password_TextInputLayout.setHint(resources.getString(R.string.password));
        login.setText(resources.getString(R.string.login));
        forgotPassword.setText(resources.getString(R.string.forgot_password));
        // changeLanguagePassenger.setText(resources.getString(R.string.select_language));
        // signup_passenger.setText(resources.getString(R.string.registration));

    }


    private void sendPasswordForOTP() {

        if (Utils.isInternetAvailable(LoginActivity.this)) {

            Utils.showProgress(LoginActivity.this);
            final StringRequest stringRequest = new StringRequest(Request.Method.POST, requestForOTP,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                Utils.stopProgress(LoginActivity.this);
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {

                                    Intent i = new Intent(LoginActivity.this, ForgotPassword.class);
                                    i.putExtra("mobile", stringMobile);
                                    startActivity(i);
                                    finish();


                                } else {

                                    String errorMsg = jObj.getString("error_msg");
                                    Toast.makeText(LoginActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Utils.stopProgress(LoginActivity.this);
                        }
                    }) {

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String, String> params = new HashMap<String, String>();

                    params.put("mobile", stringMobile);


                    return params;
                }
            };
            VolleySingleton.getInstance(LoginActivity.this).addToRequestQueue(stringRequest);
        } else {

            Utils.showToast(LoginActivity.this, "please connect to the internate");

        }
    }


    @Subscribe
    public void getMessage(String s) {

    }

    private void sendValues() {

        if (Utils.isInternetAvailable(LoginActivity.this)) {

            Utils.showProgress(LoginActivity.this);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, LOGIN_URL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                Utils.stopProgress(LoginActivity.this);
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {
                                    // User successfully stored in MySQL
                                    prefManager.setIsWaitingForSms(false);
                                    sessionManager.setIsLogin(true);

                                    String id = jObj.getString("id");

                                    JSONObject user = jObj.getJSONObject("user");
                                    String stringName = user.getString("name");
                                    String stringMobile = user.getString("mobile");
                                    String email = user.getString("email");
                                    String created_at = user.getString("created_at");

                                    String blockStatus = user.getString("block_status");

                                    String m3otpStatus = user.getString("m3otp_status");

                                   // String m3adharOtpStatus = user.getString("m3adhar_otp_status");

                                    String uniqueId = user.getString("unique_id");

                                    sessionManager.createLoginSession(stringName, stringMobile);
                                    sessionManager.createId(id);
                                    sessionManager.createEmail(email);
                                    sessionManager.setUniqueId(uniqueId);
                                    sessionManager.setBlockstatus(blockStatus);
                                    //sessionManager.setM3adharotpstatus(m3adharOtpStatus);
                                    sessionManager.setM3otpstatus(m3otpStatus);
                                    sessionManager.setName(stringName);
                                    sessionManager.setPassword(stringPassword);
                                    startActivity(new Intent(LoginActivity.this, NavHome.class));
                                    finish();

                                    /*if (stringStatus.equals("1")) {

                                        sessionManager.createLoginSession(stringName, stringMobile);
                                        sessionManager.createId(id);
                                        sessionManager.createEmail(email);
                                        startActivity(new Intent(LoginActivity.this, NavHome.class));
                                        finish();

                                    } else {
                                        sessionManager.createLoginSession(stringName, stringMobile);
                                        sessionManager.createId(id);
                                        sessionManager.createEmail(email);
                                        sessionManager.setIsLogin(false);
                                        startActivity(new Intent(LoginActivity.this, VerifyOTP.class));
                                        finish();
                                    }*/

                                } else {

                                    // Error occurred in registration. Get the error
                                    // message
                                    String errorMsg = jObj.getString("error_msg");
                                    Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Utils.stopProgress(LoginActivity.this);
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("mobile", stringMobile);
                    params.put("password", stringPassword);

                    if (sessionManager.getToken() != null)
                        params.put("token", sessionManager.getToken());

                    return params;
                }

            };

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);

        } else {

            Utils.showToast(LoginActivity.this, "please connect to the internate");
        }
    }


    public void openReg(View v) {

        Intent i = new Intent(getApplicationContext(), Registration.class);
        startActivity(i);
        finish();
    }

    public void startForgotPasswordActivity(View v) {
    }


    private void permission() {

        Dexter.withActivity(this)
                .withPermissions(
                        android.Manifest.permission.CAMERA,
                        android.Manifest.permission.READ_CONTACTS,
                        android.Manifest.permission.RECORD_AUDIO,
                        android.Manifest.permission.READ_SMS,
                        android.Manifest.permission.RECEIVE_SMS,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION,
                        android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.GET_ACCOUNTS,
                        android.Manifest.permission.CALL_PHONE
                ).withListener(new MultiplePermissionsListener() {
            @Override
            public void onPermissionsChecked(MultiplePermissionsReport report) {
            }

            @Override
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {/* ... */}
        }).check();

    }
}
