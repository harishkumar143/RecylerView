package kouchan.siddhesh.com.BookARideAndroid.View.Fragments;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.BounceInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.squareup.otto.Subscribe;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.CurrentRide;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.Otto.EventBusManager;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.DriverLocationTracking;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.FeedbackActivity;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.NavHome;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.PaymentActivity;
import kouchan.siddhesh.com.BookARideAndroid.View.Activities.SearchActivity;
import kouchan.siddhesh.com.BookARideAndroid.functions.Functions;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.OttoRepeatRide;
import kouchan.siddhesh.com.BookARideAndroid.other.CustomDialogClass;
import kouchan.siddhesh.com.BookARideAndroid.other.CustomDialogFavorites;
import kouchan.siddhesh.com.BookARideAndroid.other.OttoSelectedFromFavorite;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;
import static android.content.ContentValues.TAG;


public class MenuPassenger extends Fragment implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, LocationListener,View.OnClickListener {

    private GoogleMap mGoogleMap;
    private SupportMapFragment mapFrag;
    private BitmapDrawable bitmapdraw;
    private LatLng latLng;
    private int count;
    String userNameValue, userPhoneNumberValue = null;
    Cursor cursor = null;
    int phonePosIndex, namePosIndex;
    private int countAddress;
    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private LatLng mCenterLatLong;

    private static final int TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT = 1001;
    Dialog mDialog;
    private EditText idname, idmobile;
    private ImageView selectContactImage;
    public Button yes, no;


    android.support.v7.app.AlertDialog.Builder ad;
    AlertDialog.Builder alert;

    private LinearLayout choose_vehicle;

    private ImageView taxi;
    private ImageView auto;
    private ImageView bike;
    private ImageView mini;
    private ImageView prime;
    private ImageView rental;

    private EditText bookaridefrom;
    private EditText bookarideto;

    NavHome activity;

    private HorizontalScrollView choose_your_ride_horizontal_scroll_view;

    private ProgressBar passenger_offer_progressbar;

    private ImageView marker_logo;

    private ImageView imageViewFevoritDestination;
    private ImageView imageViewFevoritSource;
    private ImageView destination_marker_logo;

    private TextInputLayout book_a_ride_from_TextInput;
    private TextInputLayout book_a_ride_to_TextInput;


    private TextView date;
    private TextView book_a_ride_weekDay;

    private String languageCode;
    private Resources resources;

    RadioGroup rideForRadioGroup;
    RadioButton selfRadioButton,otherRadioButton;

    private double startLatitude;
    private double startLongitude;
    private double endLatitude;
    private double endLongitude;
    private Double trakingLatitude;
    private Double trackingLongitude;


    private String choose_vehicle_value;
    private String when_required_value;
    private String when_required_type;
    private String type_of_rate_value;
    private String meter_value;

    private Button later_button;
    private Button ride_now_button;
    private String date_time;
    private int mHour;
    private int mMinute;
    private Calendar c;


    private SessionManager sessionManager;

    private HashMap<String, String> user;

    private final String getPriceAndTIme = Url.PASSENGER_API + "distanceCalculateByLatLong.php";
    private final String updateLocationOfDrivers = Url.PASSENGER_API + "getNearByDrivers.php";

    private String string_type_of_rate;

    private static final int PLACE_PICKER_REQUEST_FROM = 1000;
    private static final int PLACE_PICKER_REQUEST_TO = 2000;
    private GoogleApiClient mClient;

    private String tolatitude;
    private String tolongitude;
    private String fromlatitude;
    private String fromlongitude;

    private LatLngBounds latLngBounds;
    private View view;

    private ProgressDialog loading;

    private String city,name,state;
    private Marker mk;


    private String status;

    private AlphaAnimation fadeIn;
    private AlphaAnimation fadeOut;

    private CustomDialogFavorites cdd;
    int cursorStatus;

    String notChangeAddress;

    String currency_symbol;

    String nearbyVehicleUrl;

    private TextView taxi_expected_time;
    private TextView rickshaw_expected_time;
    private TextView bike_expected_time;
    private TextView mini_expected_time;//todo remove this
    private TextView prime_expected_time;
    private TextView rentel_taxi_expected_time;

    Thread timeVehicle;

    private int seconds;

    Boolean from_Booking2;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        view = inflater.inflate(R.layout.activity_booking, container, false);
        nearbyVehicleUrl = Url.PASSENGER_API + "vehiclesDistanceAndTime.php";
        sessionManager = new SessionManager(getActivity());

        from_Booking2 = true;

        c = Calendar.getInstance();
        seconds = c.get(Calendar.SECOND);

        CurrentRide currentRide = new CurrentRide(getActivity());
        String statusofride = currentRide.getIsridestarted();
        String statusOfFeedback = currentRide.getFeedback();
        String getPaymentstatus = currentRide.getPaymentstatus();

        if (statusofride.equals("started")) {
            Intent i = new Intent(getActivity(), DriverLocationTracking.class);
            i.putExtra("bookingid", currentRide.getRideid());
            i.putExtra("drivermobile", currentRide.getDrivermobile());
            i.putExtra("vehicle", currentRide.getVehicle());
            startActivity(i);
            getActivity().finish();
        } else if (statusOfFeedback.equals("notgiven")) {
            Intent f = new Intent(getActivity(), FeedbackActivity.class);
            f.putExtra("drivermobile", currentRide.getDrivermobile());
            f.putExtra("booking_id", currentRide.getRideid());
            startActivity(f);
            getActivity().finish();

        } else if (getPaymentstatus.equals("notpaid")) {
            Intent f = new Intent(getActivity(), PaymentActivity.class);
            f.putExtra("booking_id", currentRide.getRideid());
            startActivity(f);
            getActivity().finish();

        } else {
            sessionManager = new SessionManager(getActivity());
            initializeWidget();
            setValuesBasedOnOptions();
            infoImages();
            getDriversLocations();
            checkLocationPermission();
            Bundle bundle = this.getArguments();
            if (bundle != null) {
                setValuesofNextFragment();
            }
        }

        resources = getResources();

        /*if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }*/

        EventBusManager.getInstance().getEventBus().register(this);

        cursorStatus = 1;


        nearbyVehicleServerCall();
        initializeWidget();
        taxi.setOnClickListener(this);
        auto.setOnClickListener(this);
        bike.setOnClickListener(this);
        mini.setOnClickListener(this);
        prime.setOnClickListener(this);
        rental.setOnClickListener(this);

        return view;
    }

    private void setValuesofNextFragment() {
        from_Booking2 = true;
        if (from_Booking2) {
            bookaridefrom.setText(this.getArguments().getString("from"));
        }
        bookarideto.setText(this.getArguments().getString("to"));
        fromlatitude = this.getArguments().getString("fromlatitude");
        fromlongitude = this.getArguments().getString("fromlongitude");
        tolatitude = this.getArguments().getString("tolatitude");
        tolongitude = this.getArguments().getString("tolongitude");
        choose_vehicle_value = this.getArguments().getString("vehicle_type");

        switch (choose_vehicle_value) {

            case "Taxi(4+1)":
                rental.setBackgroundResource(R.drawable.car_unselected_ic);
                taxi.setBackgroundResource(R.drawable.car_selected_ic);
                auto.setBackgroundResource(R.drawable.auto_unselected_ic);
                mini.setBackgroundResource(R.drawable.car_unselected_ic);
                prime.setBackgroundResource(R.drawable.suv_unselected_ic);
                bike.setBackgroundResource(R.drawable.bike_unselected_ic);
                break;

            case "Auto":
                taxi.setBackgroundResource(R.drawable.car_unselected_ic);
                auto.setBackgroundResource(R.drawable.auto_selected_ic);
                mini.setBackgroundResource(R.drawable.car_unselected_ic);
                prime.setBackgroundResource(R.drawable.suv_unselected_ic);
                bike.setBackgroundResource(R.drawable.bike_unselected_ic);
                break;

            case "Bike":
                rental.setBackgroundResource(R.drawable.car_unselected_ic);
                taxi.setBackgroundResource(R.drawable.car_unselected_ic);
                auto.setBackgroundResource(R.drawable.auto_unselected_ic);
                mini.setBackgroundResource(R.drawable.car_unselected_ic);
                prime.setBackgroundResource(R.drawable.suv_unselected_ic);
                bike.setBackgroundResource(R.drawable.bike_selected_ic);
                break;

            case "Taxi(7+1)":
                rental.setBackgroundResource(R.drawable.car_unselected_ic);
                taxi.setBackgroundResource(R.drawable.car_unselected_ic);
                auto.setBackgroundResource(R.drawable.auto_unselected_ic);
                mini.setBackgroundResource(R.drawable.car_unselected_ic);
                prime.setBackgroundResource(R.drawable.suv_selected_ic);
                bike.setBackgroundResource(R.drawable.bike_unselected_ic);
                break;


        }

/*        user = sessionManager.getUserDetails();
        name = user.get("name");*/

    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(getActivity(), languageCode);
        resources = context.getResources();

        //book_a_ride_from_TextInput.setHint(resources.getString(R.string.pickup_point));
        //book_a_ride_to_TextInput.setHint(resources.getString(R.string.destination_point));

    }


    private void pickedContact(Intent data, int requestCode) {

        try {
            // getData() method will have the Content Uri of the selected contact
            Uri uri = data.getData();
            cursor = getContext().getContentResolver().query(uri, null, null, null, null);
            cursor.moveToFirst();
            // sendToParentLinearLayout.setVisibility(GONE);
            //pickedContactDetailsLinearLayout.setVisibility(View.VISIBLE);
            // column index of the phone number
            phonePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            // column index of the contact name
            namePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

            userPhoneNumberValue = cursor.getString(phonePosIndex);
            userNameValue = cursor.getString(namePosIndex);


            Log.d("pickedPhoneNum", ":" + cursor.getString(phonePosIndex));
            String[] splitStrPhoneNumber = cursor.getString(phonePosIndex).split("\\s+");

            String refinedNumber = "";

            for (int i = 0; i < splitStrPhoneNumber.length; i++) {

                StringBuilder sb = new StringBuilder();

                Log.d("splitted", "Values" + i + "   " + splitStrPhoneNumber[i]);
                sb.append(refinedNumber).append(splitStrPhoneNumber[i]);

                Log.d("data", ":data came" + sb.toString());

                refinedNumber = sb.toString();
                Log.d("data", ":data came" + refinedNumber);


            }


            if (userPhoneNumberValue != null && userNameValue != null) {


                Log.d("data", ":Length" + refinedNumber.length());

                Log.d("data123", ":data came" + refinedNumber);


                if (refinedNumber.length() == 10) {
                    refinedNumber = refinedNumber;
                } else if (refinedNumber.length() > 10) {
                    refinedNumber = refinedNumber.replaceAll("[^0-9]+", "");
                    refinedNumber = refinedNumber.substring(refinedNumber.length() - 10);
                    //
                } else {
                    // whatever is appropriate in this case
                    throw new IllegalArgumentException("Please Enter Valid Mobile Number");
                }

                Log.d("data123", ":data came" + refinedNumber);
                if (requestCode == TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT) {
                    idname.setText(userNameValue);
                    idmobile.setText(refinedNumber);
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sessionManager = new SessionManager(getActivity());
        user = sessionManager.getUserDetails();
        name = user.get("name");
        getActivity().setTitle("Welcome "+name);
    }

    @Override
    public void onConnected(Bundle connectionHint) {

        LocationRequest mLocationRequestPassenger = new LocationRequest();
        mLocationRequestPassenger.setInterval(1000);
        mLocationRequestPassenger.setFastestInterval(1000);
        mLocationRequestPassenger.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            //TODO needs to uncomment below line to get the user current location current comment in coz app is crashing
            if (mClient.isConnected()) {
                LocationServices.FusedLocationApi.requestLocationUpdates(mClient, mLocationRequestPassenger, this);
            }
        }


        LocationSettingsRequest req = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequestPassenger)
                .build();
        PendingResult<LocationSettingsResult> result = LocationServices.SettingsApi.checkLocationSettings(mClient, req);
        result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
            @Override
            public void onResult(@NonNull LocationSettingsResult result) {
                final Status status = result.getStatus();
                switch (status.getStatusCode()) {
                    case LocationSettingsStatusCodes.SUCCESS:

                        break;

                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                        // Location settings are not satisfied. But could be fixed by showing the user a dialog.
                        try {
                            // Show the dialog by calling startResolutionForResult(),
                            // and check the result in onActivityResult().
                            status.startResolutionForResult(getActivity(), 110);
                        } catch (IntentSender.SendIntentException e) {
                            Log.e(TAG, e.getLocalizedMessage());
                        }
                        break;

                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:

                        break;
                }
            }
        });


    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    private void initializeWidget() {

        choose_vehicle = (LinearLayout) view.findViewById(R.id.book_a_ride_choose_vehicle);
        taxi = (ImageView) view.findViewById(R.id.book_a_ride_taxi);
        auto = (ImageView) view.findViewById(R.id.book_a_ride_auto);
        bike = (ImageView) view.findViewById(R.id.book_a_ride_bike);
        mini = (ImageView) view.findViewById(R.id.book_a_ride_mini);
        prime = (ImageView) view.findViewById(R.id.book_a_ride_prime);
        rental = (ImageView) view.findViewById(R.id.book_a_ride_rental);

        rideForRadioGroup = (RadioGroup) view.findViewById(R.id.rideForRadioGrouop);
        selfRadioButton = (RadioButton) view.findViewById(R.id.selfRadioButton);
        otherRadioButton = (RadioButton) view.findViewById(R.id.otherRadioButton);

        // any = (RadioButton) view.findViewById(R.id.book_a_ride_any);
        bookaridefrom = (EditText) view.findViewById(R.id.book_a_ride_from);
        bookarideto = (EditText) view.findViewById(R.id.book_a_ride_to);
        passenger_offer_progressbar = (ProgressBar) view.findViewById(R.id.passenger_offer_progressbar);
        book_a_ride_weekDay = (TextView) view.findViewById(R.id.book_a_ride_weekDay);
        date = (TextView) view.findViewById(R.id.book_a_ride_date);
        //choose_your_ride_horizontal_scroll_view = (HorizontalScrollView) view.findViewById(R.id.choose_your_ride_horizontal_scroll_view);
        marker_logo = (ImageView) view.findViewById(R.id.pickup_marker_logo);
        destination_marker_logo = (ImageView) view.findViewById(R.id.destination_marker_logo);
        imageViewFevoritDestination = (ImageView) view.findViewById(R.id.imageViewFevoritDestination);
        imageViewFevoritSource = (ImageView) view.findViewById(R.id.imageViewFevoritSource);
        //book_a_ride_from_TextInput = (EditText) view.findViewById(R.id.book_a_ride_from_TextInput);
        //book_a_ride_to_TextInput = (TextInputLayout) view.findViewById(R.id.book_a_ride_to_TextInput);
        later_button = (Button) view.findViewById(R.id.later_button);
        ride_now_button = (Button) view.findViewById(R.id.ride_now_button);

        taxi_expected_time = (TextView) view.findViewById(R.id.taxi_expected_time);
        rickshaw_expected_time = (TextView) view.findViewById(R.id.rickshaw_expected_time);
        bike_expected_time = (TextView) view.findViewById(R.id.bike_expected_time);
        rentel_taxi_expected_time = (TextView) view.findViewById(R.id.rentel_taxi_expected_time);

        //mini_expected_time = (TextView) view.findViewById(R.id.mini_expected_time);

        prime_expected_time = (TextView) view.findViewById(R.id.prime_expected_time);

        sessionManager = new SessionManager(getActivity());
        sessionManager.couterZero();


        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        Date dates = cal.getTime();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateformat = new SimpleDateFormat("MMM dd, yyyy");
        date.setText(dateformat.format(dates));

        String weekDay;
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);

        Calendar calendar = Calendar.getInstance();
        weekDay = dayFormat.format(calendar.getTime());
        book_a_ride_weekDay.setText(weekDay);

        mapFrag = (SupportMapFragment) this.getChildFragmentManager().findFragmentById(R.id.mapViewPassenger);
        mapFrag.getMapAsync(this);
        count = 1;
        countAddress = 1;


        ride_now_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!(Functions.isFromToSelected(fromlatitude, fromlongitude, tolatitude, tolongitude))) {
                    //Todo needs to un select all the selected views
                    //choose_vehicle.clearCheck();
                    Toast.makeText(getActivity(), "Please enter the destination", Toast.LENGTH_LONG).show();
                } else if (choose_vehicle_value == null) {
                    Toast.makeText(getActivity(), "Please select the vehicle", Toast.LENGTH_LONG).show();
                } else if (bookarideto == null || bookarideto.getText().toString().isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter the destination", Toast.LENGTH_LONG).show();
                } else {
                    when_required_type = "immediate";

                    Calendar mcurrentTime = Calendar.getInstance();
                    int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                    int minute = mcurrentTime.get(Calendar.MINUTE);

                    int dayOfMonth = mcurrentTime.get(Calendar.DAY_OF_MONTH);
                    int monthOfYear = mcurrentTime.get(Calendar.MONTH);
                    int year = mcurrentTime.get(Calendar.YEAR);

                    String AM_PM;
                    if (hour < 12) {
                        AM_PM = "AM";
                    } else {
                        AM_PM = "PM";
                        hour -= 12;
                    }

                    /*when_required_value = +hour % 12 + ":" + minute + AM_PM;*/

                    /*date_time = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;*/
                    date_time = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                    when_required_value = date_time + " " + hour + ":" + minute + ":" + seconds;
                    getDistanceByServer();
                }
            }
        });

        radioGroupOoperation();
    }

    private void radioGroupOoperation() {
        rideForRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                View radioButton = rideForRadioGroup.findViewById(checkedId);
                int index = rideForRadioGroup.indexOfChild(radioButton);

                switch (index) {
                    case 0: // first button


                        break;
                    case 1: // secondbutton
                        mDialog = new Dialog(getActivity());
                        mDialog.setCanceledOnTouchOutside(false);
                        mDialog.setContentView(R.layout.custom_dialog_personal_other);

                        idname = (EditText) mDialog.findViewById(R.id.idname);
                        idmobile = (EditText) mDialog.findViewById(R.id.idmobile);
                        selectContactImage=(ImageView)mDialog.findViewById(R.id.ivSearch);
                        yes =(Button)mDialog.findViewById(R.id.btn_yes);
                        no = (Button) mDialog.findViewById(R.id.btn_no);


                        selectContactImage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                pickContactBookForOther(TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT);
                            }
                        });

                        yes.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                if(idname.getText().toString().trim().length()==0){
                                    Utils.showToast(getActivity(),"Enter passenger name");
                                }

                                else if(idmobile.getText().toString().trim().length()==0){
                                    Utils.showToast(getActivity(),"Enter passenger mobile number");
                                }

                                else{
/*                            OttoDialogPersonalOther ottoDialogGeneric = new OttoDialogPersonalOther("other", idname.getText().toString(), idmobile.getText().toString());
                            EventBusManager.getInstance().getEventBus().post(ottoDialogGeneric);*/
                                    mDialog.dismiss();
                                }
                            }
                        });

                        no.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                mDialog.dismiss();
                                selfRadioButton.setChecked(true);
                            }
                        });

                        mDialog.show();
                }
            }
        });
    }

    private void pickContactBookForOther(int type) {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(intent, type);
    }

    private void infoImages() {

        marker_logo.clearAnimation();
        TranslateAnimation transAnim = new TranslateAnimation(0, 0, -200, 0);
        transAnim.setStartOffset(100);
        transAnim.setDuration(2000);
        transAnim.setFillAfter(true);
        /*transAnim.setRepeatMode(0);*/
        transAnim.setRepeatCount(2);
        /*transAnim.setRepeatCount(Animation.INFINITE);*/
        transAnim.setInterpolator(new BounceInterpolator());
        transAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                Log.i(TAG, "Starting button dropdown animation");
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Log.i(TAG,
                        "Ending button dropdown animation. Clearing animation and setting layout");
                marker_logo.clearAnimation();
                final int left = marker_logo.getLeft();
                final int top = marker_logo.getTop();
                final int right = marker_logo.getRight();
                final int bottom = marker_logo.getBottom();
                marker_logo.layout(left, top, right, bottom);
            }
        });
        marker_logo.startAnimation(transAnim);



        /*----------------------------------fevoritdestination  button------------------------ */
        imageViewFevoritDestination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String address = bookarideto.getText().toString();
                if (address.equals("")) {

                    /* bookarideto.setError("please select the destination address");*/
                } else {
                    CustomDialogClass cdd = new CustomDialogClass(getActivity(), address, tolatitude, tolongitude, sessionManager.getUserDetails().get("mobile"), "destination");
                    cdd.setCancelable(false);
                    cdd.show();
                    Window window = cdd.getWindow();
                    assert window != null;
                    window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);

                }

            }
        });

        imageViewFevoritSource.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String address = bookaridefrom.getText().toString();
                if (address.equals("")) {

                    /* bookarideto.setError("please select the destination address");*/
                } else {
                    CustomDialogClass cdd = new CustomDialogClass(getActivity(), address, tolatitude, tolongitude, sessionManager.getUserDetails().get("mobile"), "source");
                    cdd.setCancelable(false);
                    cdd.show();
                    Window window = cdd.getWindow();
                    assert window != null;
                    window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);

                }

            }
        });

    }

    private void setValuesBasedOnOptions() {

        user = new HashMap<String, String>();

        user = sessionManager.getUserDetails();
        //-------------------------------------------------------------------------------------------------------------------------
//--------------------------set the selected values for vehicle choice based choice of passenger---------------------------
//-------------------------------------------------------------------------------------------------------------------------
/*
        choose_vehicle.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {*/

       // });


        bookaridefrom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cursorStatus = 1;

                callPlaceAutocompleteActivityIntentFrom();
                marker_logo.setVisibility(View.VISIBLE);
                destination_marker_logo.setVisibility(View.GONE);
                //Todo needs to clear all the selected view in vehicles
                //choose_vehicle.clearCheck();

            }
        });

        bookarideto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cursorStatus = 2;
                if (fromlatitude == null) {

                } else {

                    callPlaceAutocompleteActivityIntentTo();

                }
                //Todo needs to clear all the selected view in vehicles
                //choose_vehicle.clearCheck();

            }
        });

        later_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (choose_vehicle_value == null) {

                } else {

                    when_required_type = "later";

                    int mYear = c.get(Calendar.YEAR);
                    int mMonth = c.get(Calendar.MONTH);
                    int mDay = c.get(Calendar.DAY_OF_MONTH);

                    Calendar minCal = Calendar.getInstance();
                    minCal.set(Calendar.YEAR, minCal.get(Calendar.YEAR));
                    minCal.set(Calendar.MONTH, minCal.get(Calendar.MONTH));
                    minCal.set(Calendar.DAY_OF_MONTH, minCal.get(Calendar.DAY_OF_MONTH));

                    Calendar maxCal = Calendar.getInstance();
                    maxCal.set(Calendar.YEAR, maxCal.get(Calendar.YEAR));
                    maxCal.set(Calendar.MONTH, maxCal.get(Calendar.MONTH));
                    maxCal.set(Calendar.DAY_OF_MONTH, maxCal.get(Calendar.DAY_OF_MONTH) + 3);

                    DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                            new DatePickerDialog.OnDateSetListener() {

                                @Override
                                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                                    date_time = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                                    //*************Call Time Picker Here ********************
                                    if (dayOfMonth == c.get(Calendar.DAY_OF_MONTH)) {
                                        timePicker();
                                    } else {
                                        timePickerNextDay();
                                    }

                                }
                            }, mYear, mMonth, mDay);

                    datePickerDialog.getDatePicker().setMaxDate(maxCal.getTimeInMillis());
                    datePickerDialog.getDatePicker().setMinDate(minCal.getTimeInMillis());
                    datePickerDialog.show();

                }
            }
        });

    }


    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    private void timePicker() {

        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        /*hourOfDay=c.get(Calendar.HOUR_OF_DAY);*/

                        if (hourOfDay <= (c.get(Calendar.HOUR_OF_DAY)) &&
                                (minute <= (c.get(Calendar.MINUTE)))) {
                            timePicker();

                        } else if (hourOfDay == (c.get(Calendar.HOUR_OF_DAY))) {
                            timePicker();
                        } else if (hourOfDay == (c.get(Calendar.HOUR_OF_DAY) + 1)) {
                            timePickerMinute();
                        } else {
                            mHour = hourOfDay;
                            mMinute = minute;
                            when_required_value = date_time + " " + hourOfDay + ":" + minute + ":" + seconds;
                            getDistanceByServer();
                        }
                    }
                }, mHour, mMinute, false);

        timePickerDialog.show();
    }

    private void timePickerMinute() {

        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        if (minute == (c.get(Calendar.MINUTE))) {
                            timePickerMinute();
                        } else if (minute <= (c.get(Calendar.MINUTE))) {
                            timePickerMinute();
                        } else if (minute > (c.get(Calendar.MINUTE))) {
                            mHour = hourOfDay;
                            mMinute = minute;
                            when_required_value = date_time + " " + hourOfDay + ":" + minute + ":" + seconds;

                            /*timePickerMinute();*/
                            getDistanceByServer();

                        } else {
                            mHour = hourOfDay;
                            mMinute = minute;
                            when_required_value = date_time + " " + hourOfDay + ":" + minute + ":" + seconds;

                            getDistanceByServer();

                        }
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }


    private void timePickerNextDay() {
        // Get Current Time

        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        // Launch Time Picker Dialog
        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        mHour = hourOfDay;
                        mMinute = minute;

                        when_required_value = date_time + " " + hourOfDay + ":" + minute + ":" + seconds;

                        getDistanceByServer();

                    }
                }, mHour, mMinute, false);

        timePickerDialog.show();

    }


    private void getDistanceByServer() {


        loading = ProgressDialog.show(getActivity(), resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequestNotification = new StringRequest(Request.Method.POST, getPriceAndTIme,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String responses) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(responses);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                currency_symbol = jObj.getString("currency_symbol");

                                sessionManager.setCurrency(currency_symbol);

                                String distance = jObj.getString("distance");
                                String time = jObj.getString("time");

                                Bundle bundle = new Bundle();

                                bundle.putString("currency_symbol", currency_symbol);
                                bundle.putString("from", bookaridefrom.getText().toString());
                                bundle.putString("to", bookarideto.getText().toString());
                                bundle.putString("distance", distance);
                                bundle.putString("fromlatitude", fromlatitude);
                                bundle.putString("fromlongitude", fromlongitude);
                                bundle.putString("tolatitude", tolatitude);
                                bundle.putString("tolongitude", tolongitude);
                                bundle.putString("when_required_value", when_required_value);
                                bundle.putString("when_required_type", when_required_type);
                                bundle.putString("comingFromCity", city);
                                bundle.putString("comingFromState", state);

                                FragmentBooking2 nextFragment = new FragmentBooking2();
                                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();

                                String prime_rate = jObj.getString("meter_value");
                                String tax_amount_prime = jObj.getString("tax_amount");
                                String service_charge_prime = jObj.getString("service_charge");
                                String total_amount_prime = jObj.getString("total_amount");
                                String minimum_fare_prime = jObj.getString("minimum_fare");
                                String per_km_prime = jObj.getString("per_km");
                                String min_dist_prime = jObj.getString("min_dist");

                                bundle.putString("vehicle_type", choose_vehicle_value);
                                bundle.putString("rate", prime_rate);
                                bundle.putString("minimum_fare", minimum_fare_prime);
                                bundle.putString("per_km", per_km_prime);
                                bundle.putString("total_rate", total_amount_prime);
                                nextFragment.setArguments(bundle);

                                fragmentManager.beginTransaction()
                                        .replace(R.id.content_frame, nextFragment)
                                        .commit();

                            } else {
                                String errorMsg = jObj.getString("error_msg");
                                android.support.v7.app.AlertDialog.Builder builder1 = new android.support.v7.app.AlertDialog.Builder(getContext(),R.style.MyDialogTheme);
                                builder1.setMessage(errorMsg);
                                builder1.setCancelable(true);
                                builder1.setTitle("Alert !");

                                builder1.setPositiveButton(
                                        "OK",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.cancel();
                                            }
                                        });

                                android.support.v7.app.AlertDialog mDialog = builder1.create();
                                mDialog.show();
                                //Todo needs to clear all the selected view in vehicles
                                //choose_vehicle.clearCheck();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                        //Todo needs to clear all the selected view in vehicles
                        //choose_vehicle.clearCheck();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("from_lat", fromlatitude);
                params.put("from_long", fromlongitude);
                params.put("to_lat", tolatitude);
                params.put("to_long", tolongitude);
                params.put("vehicle_type", choose_vehicle_value);
                params.put("city", city);
                params.put("state_name", state);
                params.put("mobile_no", user.get("mobile"));

                return params;
            }
        };

        stringRequestNotification.setRetryPolicy(new DefaultRetryPolicy(4500, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequestNotification);

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {


        mGoogleMap = googleMap;
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mGoogleMap.setMyLocationEnabled(true);
        
        /*mGoogleMap.getUiSettings().setCompassEnabled(true);*/

        @SuppressWarnings("ConstantConditions") View locationButton = ((View) mapFrag.getView().findViewById(Integer.parseInt("1")).getParent()).findViewById(Integer.parseInt("2"));
        RelativeLayout.LayoutParams rlp = (RelativeLayout.LayoutParams) locationButton.getLayoutParams();
        // position on right bottom
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0);
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        rlp.setMargins(0, 450, 0, 0);


        //Initialize Google Play Services
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mGoogleMap.setMyLocationEnabled(true);
                rlp.setMargins(0, 450, 0, 0);
            }
        } else {
            buildGoogleApiClient();
            mGoogleMap.setMyLocationEnabled(true);
            rlp.setMargins(0, 450, 0, 0);
        }


        mGoogleMap.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener() {
            @Override
            public void onCameraChange(CameraPosition cameraPosition) {

                Log.d("Camera postion change" + "", cameraPosition + "");

                mCenterLatLong = cameraPosition.target;

                if (cursorStatus == 1) {
                    getAddress(mCenterLatLong);
                } else {
                    getAddressTo(mCenterLatLong);
                }
            }
        });


    }

    private void getAddress(final LatLng mCenterLatLong) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    Location mLocation = new Location("");
                    mLocation.setLatitude(mCenterLatLong.latitude);
                    mLocation.setLongitude(mCenterLatLong.longitude);
                    Geocoder geocoder;
                    List<android.location.Address> yourAddresses;
                    geocoder = new Geocoder(getActivity(), Locale.getDefault());
                    yourAddresses = geocoder.getFromLocation(mLocation.getLatitude(), mLocation.getLongitude(), 1);

                    final String yourAddress = yourAddresses.get(0).getAddressLine(0);
                    if (yourAddresses != null && yourAddresses.size() > 0) {
                        android.location.Address address = yourAddresses.get(0);
                        @SuppressWarnings("MismatchedQueryAndUpdateOfStringBuilder") StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                            sb.append(address.getAddressLine(i)).append("\n");
                        }
                        city = address.getLocality();
                        state= address.getAdminArea();
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            bookaridefrom.setText(yourAddress);
                            fromlatitude = Double.toString(mCenterLatLong.latitude);
                            fromlongitude = Double.toString(mCenterLatLong.longitude);
                        }
                    });
                } catch (Exception e) {

                }
            }
        }).start();
    }

    private void getAddressTo(final LatLng mCenterLatLong) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Location mLocation = new Location("");
                    mLocation.setLatitude(mCenterLatLong.latitude);
                    mLocation.setLongitude(mCenterLatLong.longitude);
                    Geocoder geocoder;
                    List<android.location.Address> yourAddresses;
                    geocoder = new Geocoder(getActivity(), Locale.getDefault());
                    yourAddresses = geocoder.getFromLocation(mLocation.getLatitude(), mLocation.getLongitude(), 1);

                    final String yourAddress = yourAddresses.get(0).getAddressLine(0);

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            bookarideto.setText(yourAddress);
                            tolatitude = Double.toString(mCenterLatLong.latitude);
                            tolongitude = Double.toString(mCenterLatLong.longitude);

                        }
                    });
                } catch (Exception e) {

                }
            }
        }).start();
    }


    @Override
    public void onLocationChanged(Location location) {
        {

            Location mLastLocation = location;

            trakingLatitude = mLastLocation.getLatitude();
            trackingLongitude = mLastLocation.getLongitude();
            latLng = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());

            if (count == 1) {
                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));
                count++;
            }
            bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.carmarker);

        }
    }

    private synchronized void buildGoogleApiClient() {
        mClient = new GoogleApiClient.Builder(getActivity())
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .addApi(Places.PLACE_DETECTION_API)
                .build();
        mClient.connect();
    }


    private void getDriversLocations() {


        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!Thread.interrupted())
                    try {
                        Thread.sleep(2000);
                        if (trakingLatitude == null && trackingLongitude == null) {

                        } else {
                            locationRequest();
                        }

                    } catch (InterruptedException ignored) {

                    }
            }
        });

        t.start();

    }


    private void locationRequest() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, updateLocationOfDrivers,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                mGoogleMap.clear();
                                /*mGoogleMap.clear();*/

                                JSONArray contacts = jObj.getJSONArray("user");

                                for (int i = 0; i < contacts.length(); i++) {
                                    JSONObject c = contacts.getJSONObject(i);

                                    String lat = c.getString("lat");
                                    String lng = c.getString("lng");
                                    String vehicle_type = c.getString("vehicle_type");

                                    double value1 = Double.parseDouble(lat);
                                    double value2 = Double.parseDouble(lng);
                                    int height = 70;
                                    int width = 110;

                                    LatLng latLngForNearLocation = new LatLng(value1, value2);

                                    if (vehicle_type.equals("Auto")) {
                                        bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.mipmap.rickshawtopview);
                                    }else if (vehicle_type.equals("Bike")) {
                                        bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.map_bike);
                                    }
                                    else if (vehicle_type.equals("Taxi(4+1)")) {
                                        bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.carmarker);
                                    }else {
                                        bitmapdraw = (BitmapDrawable) view.getResources().getDrawable(R.drawable.carmarker);
                                    }

                                    Bitmap b = bitmapdraw.getBitmap();
                                    Bitmap smallMarker = Bitmap.createScaledBitmap(b, width, height, false);

                                    mk = mGoogleMap.addMarker(new MarkerOptions().position(latLngForNearLocation)
                                            .icon(BitmapDescriptorFactory.fromBitmap((smallMarker))));

                                }

                            } else {

                                String errorMsg = jObj.getString("error_msg");

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();


                params.put("lat", Double.toString(trakingLatitude));
                params.put("lng", Double.toString(trackingLongitude));

                return params;
            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }


    @Override
    public void onAttach(Activity activity){ //todo deprecated
        super.onAttach(activity);
        this.activity = (NavHome) activity;
    }


    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION)) {


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return;
        } else {
            return;
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (ContextCompat.checkSelfPermission(getActivity(),
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mClient == null) {
                            buildGoogleApiClient();
                        }
                    }

                } else {

                }
            }
        }
    }

    private void callPlaceAutocompleteActivityIntentTo() {
        try {

          //  bookarideto.setEnabled(true);
            /*Intent intent =
                    new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN)
                            .build(getActivity());
            startActivityForResult(intent, PLACE_PICKER_REQUEST_TO);*/
            Intent intent = new Intent(getActivity(), SearchActivity.class);
            intent.putExtra("Source","to");
            startActivity(intent);

           /* cdd = new CustomDialogFavorites(getActivity(), "destination");
            cdd.show();
            Window window = cdd.getWindow();
            assert window != null;
            window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);*/

//PLACE_AUTOCOMPLETE_REQUEST_CODE is integer for request code
        } catch (Exception e){ //(GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
            // TODO: Handle the error.
        }

    }

    private void callPlaceAutocompleteActivityIntentFrom() {

        try {

            Intent intent = new Intent(getActivity(), SearchActivity.class);
            intent.putExtra("Source","from");
            startActivity(intent);
            //bookaridefrom.setEnabled(false);
            /*Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN)
                    .build(getActivity());

            startActivityForResult(intent, PLACE_PICKER_REQUEST_FROM);
*/
            /*cdd = new CustomDialogFavorites(getActivity(), "source");
            cdd.setCancelable(false);
            cdd.show();
            Window window = cdd.getWindow();
            assert window != null;
            window.setLayout(AppBarLayout.LayoutParams.MATCH_PARENT, AppBarLayout.LayoutParams.WRAP_CONTENT);*/


        } catch(Exception e) { //(GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
            // TODO: Handle the error.
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PLACE_PICKER_REQUEST_FROM) {
            if (resultCode == RESULT_OK) {

                //cdd.dismiss();

                bookaridefrom.setEnabled(true);
                Place place = PlacePicker.getPlace(data, getActivity());
                @SuppressWarnings("MismatchedQueryAndUpdateOfStringBuilder") StringBuilder stBuilder = new StringBuilder();
                String placename = String.format("%s", place.getName());
                fromlatitude = String.valueOf(place.getLatLng().latitude);
                fromlongitude = String.valueOf(place.getLatLng().longitude);
                String address = String.format("%s", place.getAddress());

                String locale = String.format("%s", place.getLocale());

                stBuilder.append("Name: ");
                stBuilder.append(placename);
                stBuilder.append("\n");
                stBuilder.append("Latitude: ");
                stBuilder.append(fromlatitude);
                stBuilder.append("\n");
                stBuilder.append("Logitude: ");
                stBuilder.append(fromlongitude);
                stBuilder.append("\n");
                stBuilder.append("Address: ");
                stBuilder.append(address);

                stBuilder.append("Locale: ");
                stBuilder.append(locale);

                bookaridefrom.setText(place.getAddress());
                latLngBounds = new LatLngBounds(new LatLng(place.getLatLng().latitude, place.getLatLng().longitude), new LatLng(place.getLatLng().latitude, place.getLatLng().longitude));

                latLng = new LatLng(place.getLatLng().latitude, place.getLatLng().longitude);

                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {

                bookaridefrom.setEnabled(true);
                Status status = PlaceAutocomplete.getStatus(getActivity(), data);
                Log.i(TAG, status.getStatusMessage());
            } else if (resultCode == RESULT_CANCELED) {


                bookaridefrom.setEnabled(true);
                // The user canceled the operation.
            }
        } else if (requestCode == PLACE_PICKER_REQUEST_TO) {

            if (resultCode == RESULT_OK) {

                //cdd.dismiss();

                bookarideto.setEnabled(true);
                Place place = PlaceAutocomplete.getPlace(getActivity(), data);
                @SuppressWarnings("MismatchedQueryAndUpdateOfStringBuilder") StringBuilder stBuilder = new StringBuilder();

                String placename = String.format("%s", place.getName());
                tolatitude = String.valueOf(place.getLatLng().latitude);
                tolongitude = String.valueOf(place.getLatLng().longitude);
                String address = String.format("%s", place.getAddress());
                stBuilder.append("Name: ");
                stBuilder.append(placename);
                stBuilder.append("\n");
                stBuilder.append("Latitude: ");
                stBuilder.append(tolatitude);
                stBuilder.append("\n");
                stBuilder.append("Logitude: ");
                stBuilder.append(tolongitude);
                stBuilder.append("\n");
                stBuilder.append("Address: ");
                stBuilder.append(address);
                bookarideto.setText(place.getAddress());


                latLngBounds = new LatLngBounds(
                        new LatLng(place.getLatLng().latitude, place.getLatLng().longitude), new LatLng(place.getLatLng().latitude, place.getLatLng().longitude));

                startLatitude = Double.parseDouble(fromlatitude);
                startLongitude = Double.parseDouble(fromlongitude);
                endLatitude = Double.parseDouble(tolatitude);
                endLongitude = Double.parseDouble(tolongitude);

                latLng = new LatLng(place.getLatLng().latitude, place.getLatLng().longitude);
                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                bookarideto.setEnabled(true);
                Status status = PlaceAutocomplete.getStatus(getActivity(), data);
                Log.i(TAG, status.getStatusMessage());
            } else if (resultCode == RESULT_CANCELED) {
                bookarideto.setEnabled(true);

            }

        }

        if(requestCode==TAG_RESULT_PICK_BOOK_FOR_OTHER_CONTACT){
            pickedContact(data,requestCode);
        }
    }

    @Subscribe
    public void setLatLongFromFavorite(OttoSelectedFromFavorite ottoSelectedFromFavorite) {

        Double latitude = Double.parseDouble(ottoSelectedFromFavorite.getTolatitude());
        Double longitude = Double.parseDouble(ottoSelectedFromFavorite.getTolongitude());


        if ((ottoSelectedFromFavorite.getSetTo()).equals("from")) {

            fromlatitude = ottoSelectedFromFavorite.getTolatitude();
            fromlongitude = ottoSelectedFromFavorite.getTolongitude();

            bookaridefrom.setText(ottoSelectedFromFavorite.getAddress());
            latLngBounds = new LatLngBounds(new LatLng(latitude, longitude), new LatLng(latitude, longitude));

            latLng = new LatLng(latitude, longitude);

            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

        } else {

            bookarideto.setText(ottoSelectedFromFavorite.getAddress());

            marker_logo.setVisibility(View.VISIBLE);
           // destination_marker_logo.setVisibility(View.VISIBLE);
            tolatitude = ottoSelectedFromFavorite.getTolatitude();
            tolongitude = ottoSelectedFromFavorite.getTolongitude();

            latLngBounds = new LatLngBounds(new LatLng(latitude, longitude), new LatLng(latitude, longitude));

          //  startLatitude = Double.parseDouble(fromlatitude);
          //  startLongitude = Double.parseDouble(fromlongitude);
            endLatitude = Double.parseDouble(ottoSelectedFromFavorite.getTolatitude());
            endLongitude = Double.parseDouble(ottoSelectedFromFavorite.getTolongitude());

            latLng = new LatLng(latitude, longitude);

           // mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
           // mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

        }
    }


  /*  private void getNearByVehicleTime() {


         timeVehicle = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!Thread.interrupted())
                    try {
                        Thread.sleep(10000);
                        if (trakingLatitude == null && trackingLongitude == null) {


                        } else {


                            nearbyVehicleServerCall();

                        }

                    } catch (InterruptedException ignored) {

                    }
            }
        });

        timeVehicle.start();

    }*/

    private void nearbyVehicleServerCall() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, nearbyVehicleUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {


                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");

                            if (!error) {


                                //JSONObject user = jObj.getJSONObject("user");
                                JSONArray auto = jObj.getJSONArray("user");


                                for (int i = 0; i < auto.length(); i++) {
                                    JSONObject c = auto.getJSONObject(i);
                                    String type = c.getString("type");
                                    if(type.equals("Auto")) {
                                        String time = c.getString("time");
                                        if (!time.equals("NA"))
                                            rickshaw_expected_time.setText(time);
                                    }else if(type.equals("Taxi(4+1)")) {
                                        String time = c.getString("time");
                                        if (!time.equals("NA"))
                                            taxi_expected_time.setText(time);
                                    }else if(type.equals("Bike")) {
                                        String time = c.getString("time");
                                        if (!time.equals("NA"))
                                            bike_expected_time.setText(time);
                                    }else if(type.equals("Taxi(3+1)")) {
                                        String time = c.getString("time");
                                        if (!time.equals("NA"))
                                            mini_expected_time.setText(time);
                                    }else if(type.equals("Taxi(7+1)")) {
                                        String time = c.getString("time");
                                        if (!time.equals("NA"))
                                            prime_expected_time.setText(time);
                                    }/*else if(type.equals("Rental")) {
                                        String time = c.getString("time");
                                        if (!time.equals("NA"))
                                            rentel_taxi_expected_time.setText(time);
                                    }*/
                                }

                            } else {


                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        nearbyVehicleServerCall();

                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                LatLng p1=  getLocationFromAddress(getActivity(),bookaridefrom.getText().toString());

                Map<String, String> params = new HashMap<String, String>();


                params.put("from_lat", p1.latitude+""); //todo coming null first time
                params.put("from_long", p1.longitude+"");
                params.put("range", "2");

                return params;
            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }

    public LatLng getLocationFromAddress(Context context,String strAddress) {

        Geocoder coder = new Geocoder(activity);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }

            Address location = address.get(0);
            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }

        return p1;
    }
    @Subscribe
    public void repeatRide(OttoRepeatRide ottoRepeatRide) {

        Utils.stopProgress(getActivity());

        bookaridefrom.setText(ottoRepeatRide.getFrom());
        bookarideto.setText(ottoRepeatRide.getTo());
        fromlatitude = ottoRepeatRide.getFromlatitude();
        fromlongitude = ottoRepeatRide.getFromlongitude();
        tolatitude = ottoRepeatRide.getTolatitude();
        tolongitude = ottoRepeatRide.getTolongitude();
        choose_vehicle_value = ottoRepeatRide.getVehicle_type();

        switch (choose_vehicle_value) {

            case "Taxi(4+1)":
                rental.setBackgroundResource(R.drawable.rentals);
                taxi.setBackgroundResource(R.drawable.radio_logo_taxi_checked);
                auto.setBackgroundResource(R.drawable.auto);
                mini.setBackgroundResource(R.drawable.mini);
                prime.setBackgroundResource(R.drawable.prime);
                bike.setBackgroundResource(R.drawable.bike);
                break;
            case "Auto":

                rental.setBackgroundResource(R.drawable.rentals);
                taxi.setBackgroundResource(R.drawable.micro);
                auto.setBackgroundResource(R.drawable.radio_logo_rickshaw_checked);
                mini.setBackgroundResource(R.drawable.mini);
                prime.setBackgroundResource(R.drawable.prime);
                bike.setBackgroundResource(R.drawable.bike);
                break;

            case "Bike":

                rental.setBackgroundResource(R.drawable.rentals);
                taxi.setBackgroundResource(R.drawable.micro);
                auto.setBackgroundResource(R.drawable.auto);
                mini.setBackgroundResource(R.drawable.mini);
                prime.setBackgroundResource(R.drawable.prime);
                bike.setBackgroundResource(R.drawable.radio_logo_bike_checked);
                break;

            case "Taxi(3+1)":

                rental.setBackgroundResource(R.drawable.rentals);
                taxi.setBackgroundResource(R.drawable.micro);
                auto.setBackgroundResource(R.drawable.auto);
                mini.setBackgroundResource(R.drawable.radio_logo_mini_checked);
                prime.setBackgroundResource(R.drawable.prime);
                bike.setBackgroundResource(R.drawable.bike);
                break;

            case "Taxi(7+1)":

                rental.setBackgroundResource(R.drawable.rentals);
                taxi.setBackgroundResource(R.drawable.micro);
                auto.setBackgroundResource(R.drawable.auto);
                mini.setBackgroundResource(R.drawable.mini);
                prime.setBackgroundResource(R.drawable.radio_logo_prime_checked);
                bike.setBackgroundResource(R.drawable.bike);
                break;

           /* case "Rental":

                rental.setBackgroundResource(R.drawable.radio_logo_rental_checked);
                taxi.setBackgroundResource(R.drawable.micro);
                auto.setBackgroundResource(R.drawable.auto);
                mini.setBackgroundResource(R.drawable.mini);
                prime.setBackgroundResource(R.drawable.prime);
                bike.setBackgroundResource(R.drawable.bike);
                break;*/
        }

    }


    @Override
    public void onClick(View v) {
        int checkedId = v.getId();

        switch (checkedId) {
            case R.id.book_a_ride_taxi:

                choose_vehicle_value = "Taxi(4+1)";
                rental.setBackgroundResource(R.drawable.rentals);
                taxi.setBackgroundResource(R.drawable.car_selected_ic);
                auto.setBackgroundResource(R.drawable.auto_unselected_ic);
                mini.setBackgroundResource(R.drawable.mini);
                prime.setBackgroundResource(R.drawable.suv_unselected_ic);
                bike.setBackgroundResource(R.drawable.bike_unselected_ic);

                break;

            case R.id.book_a_ride_auto:

                choose_vehicle_value = "Auto";

                rental.setBackgroundResource(R.drawable.rentals);
                taxi.setBackgroundResource(R.drawable.car_unselected_ic);
                auto.setBackgroundResource(R.drawable.auto_selected_ic);
                mini.setBackgroundResource(R.drawable.car_unselected_ic);
                prime.setBackgroundResource(R.drawable.suv_unselected_ic);
                bike.setBackgroundResource(R.drawable.bike_unselected_ic);

                break;

            case R.id.book_a_ride_bike:

                choose_vehicle_value = "Bike";
                rental.setBackgroundResource(R.drawable.car_unselected_ic);
                taxi.setBackgroundResource(R.drawable.car_unselected_ic);
                auto.setBackgroundResource(R.drawable.auto_unselected_ic);
                mini.setBackgroundResource(R.drawable.car_unselected_ic);
                prime.setBackgroundResource(R.drawable.suv_unselected_ic);
                bike.setBackgroundResource(R.drawable.bike_selected_ic);

                break;

            case R.id.book_a_ride_prime:

                choose_vehicle_value = "Taxi(7+1)";
                rental.setBackgroundResource(R.drawable.car_unselected_ic);
                taxi.setBackgroundResource(R.drawable.car_unselected_ic);
                auto.setBackgroundResource(R.drawable.auto_unselected_ic);
                mini.setBackgroundResource(R.drawable.car_unselected_ic);
                prime.setBackgroundResource(R.drawable.suv_selected_ic);
                bike.setBackgroundResource(R.drawable.bike_unselected_ic);

                break;

            case R.id.book_a_ride_mini:

                choose_vehicle_value = "Taxi(3+1)";

                rental.setBackgroundResource(R.drawable.rentals);
                taxi.setBackgroundResource(R.drawable.micro);
                auto.setBackgroundResource(R.drawable.auto);
                mini.setBackgroundResource(R.drawable.radio_logo_mini_checked);
                prime.setBackgroundResource(R.drawable.prime);
                bike.setBackgroundResource(R.drawable.bike);

                break;

                    /*case R.id.book_a_ride_rental:

                        choose_vehicle_value = "Rental";
                        rental.setBackgroundResource(R.drawable.radio_logo_rental_checked);
                        taxi.setBackgroundResource(R.drawable.micro);
                        auto.setBackgroundResource(R.drawable.auto);
                        mini.setBackgroundResource(R.drawable.mini);
                        prime.setBackgroundResource(R.drawable.prime);
                        bike.setBackgroundResource(R.drawable.bike);

                        break;*/
        }
    }

}
