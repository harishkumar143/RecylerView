package kouchan.siddhesh.com.BookARideAndroid.Interface.m3withbookarideregistration;

public interface IRegisterPresenter {

    void registerValidation(String firstName, String email, String mobile, String password,String adharNumber);

}
