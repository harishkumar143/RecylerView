package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Adapter.DayWiseRideDetailsAdapter;
import kouchan.siddhesh.com.BookARideAndroid.Adapter.RecyclerTouchListener;
import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.helper.LocaleHelper;
import kouchan.siddhesh.com.BookARideAndroid.models.DateExpand;
import kouchan.siddhesh.com.BookARideAndroid.other.DividerItemDecoration;

public class DateExpandActivity extends AppCompatActivity {

    private List<DateExpand> dateExpandList = new ArrayList<>();
    private String TAG = SplashActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private RecyclerView recyclerView;
    private DayWiseRideDetailsAdapter mAdapter;
    HashMap<String, String> user;
    String passengermobile, type;
    String historyUrl = "";
    SessionManager sessionManager;

    Toolbar mToolbar;
    ImageView date_Expand_BackImageView, date_Expand_HomeImageView;

    TextView booking_date_date_expand,booking_date_expand;
    String languageCode;
    Resources resources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_expand);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view__date_expand);

        mAdapter = new DayWiseRideDetailsAdapter(dateExpandList,getApplicationContext());
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(mAdapter);

        sessionManager = new SessionManager(getApplicationContext());

        booking_date_expand= (TextView) findViewById(R.id.booking_date_expand);

        booking_date_date_expand = (TextView) findViewById(R.id.booking_date_date_expand);

        user = new HashMap<String, String>();
        user = sessionManager.getUserDetails();

        passengermobile = user.get("mobile");

        type = sessionManager.getType();

        historyUrl = Url.PASSENGER_API + "passengerHistoryByDateDetails.php";

        displayHistoyCancel();

        initializeViews();

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                DateExpand dateExpand = dateExpandList.get(position);


                Intent i = new Intent(getApplicationContext(), RideHistoryDeepDatails.class);

                i.putExtra("booking_id", dateExpand.getBooking_id());

                startActivity(i);
                finish();
             /*  *//* Intent i=new Intent(getActivity(),HistoryExpand.class);*//*

                i.putExtra("booking_id",cancel.getId());

                startActivity(i);
                getActivity().finish();*/


            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        booking_date_expand.setText(resources.getString(R.string.date_ride_details));
    }

    public void displayHistoyCancel() {
       // final ProgressDialog loading = ProgressDialog.show(getApplicationContext(), resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, historyUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //               loading.dismiss();
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            String booking_date = jsonObj.getString("booking_date");
                            if (!error) {

                                JSONArray contacts = jsonObj.getJSONArray("user");
                                for (int i = 0; i < contacts.length(); i++) {
                                    JSONObject c = contacts.getJSONObject(i);

                                    int booking_id = c.getInt("booking_id");
                                    String vehicle = c.getString("vehicle");

                                    String actualprice = c.getString("actualprice");
                                    String fromplace = c.getString("fromplace");
                                    String toplace = c.getString("toplace");
                                    String distance = c.getString("distance");
                                    String ride_start_time = c.getString("ride_start_time");
                                    String ride_end_time = c.getString("ride_end_time");
                                    String journey_time = c.getString("journey_time");


                                    DateExpand cancel = new DateExpand(Integer.toString(booking_id), vehicle,
                                            actualprice, booking_date, fromplace, toplace, distance, ride_start_time, ride_end_time, journey_time);
                                    dateExpandList.add(cancel);
                                    mAdapter.notifyDataSetChanged();

                                    booking_date_date_expand.setText(booking_date);

                                    // tmp hash map for single contact
                     /*           HashMap<String, String> contact = new HashMap<>();

                                // adding each child node to HashMap key => value

                                contact.put("id",id);
                                contact.put("paymenttype",paymenttype);
                                contact.put("bookingtime",bookingtime);
                                contact.put("ridestatus",ridestatus);
                                contact.put("actualprice",actualprice);
                                contact.put("vehicle",vehicle);*/


                                    // adding contact to contact list
                                }
                            } else {
                                String errorMsg = jsonObj.getString("error_msg");
                            }
                            //         ListAdapter adapter = new SimpleAdapter(getApplicationContext(), contactList, R.layout.history_list_item, new String[]{"paymenttype", "bookingtime", "ridestatus","actualprice","vehicle"}, new int[]{R.id.paymenttype, R.id.bookingtime, R.id.ridestatus, R.id.actualprice, R.id.vehicle});
//
//                            lv.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //                 loading.dismiss();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();

                params.put("mobile", passengermobile);
                params.put("date", getIntent().getStringExtra("date"));


                return params;
            }
        };

        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);

    }


    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        date_Expand_BackImageView = (ImageView) findViewById(R.id.date_Expand_BackImageView);
        date_Expand_HomeImageView = (ImageView) findViewById(R.id.date_Expand_HomeImageView);

        date_Expand_BackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               onBackPressed();
            }
        });

        date_Expand_HomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DateExpandActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });
    }
}



