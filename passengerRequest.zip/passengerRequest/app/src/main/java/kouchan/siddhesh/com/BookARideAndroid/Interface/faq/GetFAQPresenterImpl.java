package kouchan.siddhesh.com.BookARideAndroid.Interface.faq;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import kouchan.siddhesh.com.BookARideAndroid.View.Activities.NavHome;
import kouchan.siddhesh.com.BookARideAndroid.async.AsyncInteractor;
import kouchan.siddhesh.com.BookARideAndroid.async.OnRequestListener;
import kouchan.siddhesh.com.BookARideAndroid.utils.AppConstants;
import kouchan.siddhesh.com.BookARideAndroid.utils.NetworkStatus;
import kouchan.siddhesh.com.BookARideAndroid.utils.Sharedpreferences;
import kouchan.siddhesh.com.BookARideAndroid.utils.Utils;


public class GetFAQPresenterImpl implements IGetFAQPresnter,OnRequestListener {

    NavHome navHome;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IGetFAQView getFAQView;

    public GetFAQPresenterImpl(IGetFAQView navHome) {
        this.navHome = (NavHome) navHome ;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(this.navHome);
        this.asyncInteractor = new AsyncInteractor(this.navHome);
        this.getFAQView = navHome;
    }

    @Override
    public void getFAQ() {
        if(NetworkStatus.checkNetworkStatus(navHome)){
            //Utils.showProgress(navHome);
            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_FAQ, "https://bookarideworldwide.com/CAB2.V.1/comunicate_api/get_comments.php?user_type=PASSENGER&comment_type=FAQS");
        } else {
            Utils.showToast(navHome, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if(pid==AppConstants.TAG_ID_FAQ){
           // Utils.stopProgress(navHome);
            if(responseJson!=null){
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if(!error) {
                    getFAQView.getFAQSuccess(pid,responseJson);
                }
                else {
                    getFAQView.getFAQError(pid,jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
     //   Utils.stopProgress(navHome);
        getFAQView.getFAQError(pid,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
       // Utils.stopProgress(navHome);
        getFAQView.getFAQError(pid,error);
    }
}
