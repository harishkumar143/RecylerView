package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import kouchan.siddhesh.com.BookARideAndroid.Database.CurrentRide;
import kouchan.siddhesh.com.BookARideAndroid.R;

public class PaymentStatusActivity extends AppCompatActivity {

    TextView amountPaid,mode;
    Button okButton;
    String drivermobile,booking_id,amount,payment_mode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_status);

        amountPaid=(TextView)findViewById(R.id.amountPaid);
        mode=(TextView)findViewById(R.id.mode);
        okButton=(Button)findViewById(R.id.okButton);

        Intent i=getIntent();

        if(i!=null){
            drivermobile = getIntent().getStringExtra("drivermobile");
            booking_id = getIntent().getStringExtra("booking_id");
            amount = getIntent().getStringExtra("amount");
            payment_mode = getIntent().getStringExtra("payment_mode");
        }

        amountPaid.setText("₹ "+amount);

        if(payment_mode.equalsIgnoreCase("CASH")){
            mode.setText("Payment Mode by Cash");
        }
        else{
            mode.setText("Payment Mode by M3 e-wallet");
        }
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(getApplicationContext(), FeedbackActivity.class);
                CurrentRide currentRide = new CurrentRide(getApplicationContext());
                currentRide.setIsRideStarted("ended");
                intent3.putExtra("drivermobile", drivermobile);
                intent3.putExtra("booking_id", booking_id);
                startActivity(intent3);
                finish();
            }
        });
    }
}
