package kouchan.siddhesh.com.BookARideAndroid.Interface.faq;

public interface IGetFAQPresnter {

    void getFAQ();

}

