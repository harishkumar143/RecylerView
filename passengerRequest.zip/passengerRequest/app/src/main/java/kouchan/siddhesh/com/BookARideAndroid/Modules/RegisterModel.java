package kouchan.siddhesh.com.BookARideAndroid.Modules;

public class RegisterModel {

    /**
     * status : OK
     * code : 200
     * sucess : Sucess
     * customerStatus : M_OTP_PENDING
     * step : OTP_SCR
     */

    private String status;
    private String code;
    private String sucess;
    private String customerStatus;
    private String step;
    /**
     * errorType : Unprocessable Entity
     * message : User already exists with mobile number: 917676060664
     * codeMessages : null
     */

    private String errorType;
    private String message;
    private Object codeMessages;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSucess() {
        return sucess;
    }

    public void setSucess(String sucess) {
        this.sucess = sucess;
    }

    public String getCustomerStatus() {
        return customerStatus;
    }

    public void setCustomerStatus(String customerStatus) {
        this.customerStatus = customerStatus;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }


    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getCodeMessages() {
        return codeMessages;
    }

    public void setCodeMessages(Object codeMessages) {
        this.codeMessages = codeMessages;
    }
}