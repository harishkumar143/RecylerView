package com.kouchan.dyutpassenger.View.Activities;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kouchan.dyutpassenger.Adapter.PassengerOfferAdapter;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.IRemoveItem;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.OttoEventFinishedPassengerOffer;
import com.kouchan.dyutpassenger.models.OttoPassengerOffer;
import com.kouchan.dyutpassenger.models.PassengerOffer;
import com.kouchan.dyutpassenger.models.RemovePassengerRequest;
import com.kouchan.dyutpassenger.other.DividerItemDecoration;
import com.kouchan.dyutpassenger.other.TimerForAvailability;
import com.squareup.otto.Subscribe;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PassengerOfferActivity extends AppCompatActivity implements IRemoveItem {


    TextView passengerOfferTimer, passengers_offer_textView,
            itemRowOfPassengerOfferTimeText, itemRowOfPassengerOfferToTextView, itemRowOfPassengerOfferPriceText;

    String languageCode;
    Resources resources;

    private List<PassengerOffer> passengerOfferList = new ArrayList<>();

    private RecyclerView recyclerView;
    private PassengerOfferAdapter mAdapter;
    SessionManager sessionManager;

    String drivermobile, whenrequiredtype;
    String passengername, passengermobile, price, drivername, bookingid, vehicle, rating;
    HashMap<String, String> user;

    Button passengerOfferCancel;
    String cancelRideByDiverUrl = Url.COMUNICATE_API + "cancelledbydriver.php";
    String sendReadReceiptUrl=Url.COMUNICATE_API+"read_track.php";
    String countOfferURL = Url.COMUNICATE_API + "driverOfferToCustomer.php";

    CountDownTimer waitTimer;

    List<String> bookingidList = new ArrayList<String>();

    MediaPlayer mp;

    TimerForAvailability timerForAvailability;
    PassengerOffer passengerOffer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_offer);

        mp = MediaPlayer.create(this, R.raw.musictwo);


        bookingidList = new ArrayList<String>();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

      /*  passengerOfferTimer=(TextView)findViewById(R.id.passengerOfferTimer);*/

        EventBusManager.getInstance().getEventBus().register(this);

        passengerOfferCancel = (Button) findViewById(R.id.PassengerOfferCancel);
        passengers_offer_textView = (TextView) findViewById(R.id.passengers_offer_textView);
        itemRowOfPassengerOfferTimeText = (TextView) findViewById(R.id.itemRowOfPassengerOfferTimeText);
        itemRowOfPassengerOfferToTextView = (TextView) findViewById(R.id.itemRowOfPassengerOfferToTextView);
        itemRowOfPassengerOfferPriceText = (TextView) findViewById(R.id.itemRowOfPassengerOfferPriceText);

        passengerOfferCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cancelRide();
            }
        });

        NotificationManager notificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
        notificationManager.cancelAll();

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view_passengerOffer);

        mAdapter = new PassengerOfferAdapter(passengerOfferList,getApplicationContext());
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());

        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        sessionManager = new SessionManager(getApplicationContext());

        user = new HashMap<String, String>();
        user = sessionManager.getUserDetails();
        passengername = user.get("name");
        drivermobile = user.get("mobile");


        prepareMovieData();

/*        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {


                PassengerOffer passengerOffer = passengerOfferList.get(position);

                Intent intent = new Intent(getApplicationContext(), RideRequestActivity.class);

                intent.putExtra("message", "reached");
                intent.putExtra("stage", passengerOffer.getStage());
                intent.putExtra("bookingid", passengerOffer.getBookingid());
                intent.putExtra("passengername", passengerOffer.getPassengername());
                intent.putExtra("passengermobile", passengerOffer.getPassengermobile());
                intent.putExtra("vehicle", passengerOffer.getVehicle());
                intent.putExtra("whenrequired", passengerOffer.getWhenrequired());
                intent.putExtra("whenrequiredtype", passengerOffer.getWhenrequiredtyp());

                intent.putExtra("typeofrate", passengerOffer.getTypeofrate());
                intent.putExtra("rate", passengerOffer.getRate());
                intent.putExtra("metervalue", passengerOffer.getMetervalue());
                intent.putExtra("from", passengerOffer.getFrom());
                intent.putExtra("to", passengerOffer.getTo());
                intent.putExtra("fromlatitude", passengerOffer.getFromlatitude());
                intent.putExtra("fromlongitude", passengerOffer.getFromlongitude());
                intent.putExtra("tolatitude", passengerOffer.getTolatitude());
                intent.putExtra("tolongitude", passengerOffer.getTolongitude());
                intent.putExtra("distance", passengerOffer.getDistance());

                startActivity(intent);

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));*/

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        passengerOfferCancel.setText(resources.getString(R.string.cancel));
        passengers_offer_textView.setText(resources.getString(R.string.passengers_offer));

        /*itemRowOfPassengerOfferTimeText.setText(resources.getString(R.string.time));
        itemRowOfPassengerOfferToTextView.setText(resources.getString(R.string.to_location));
        itemRowOfPassengerOfferPriceText.setText(resources.getString(R.string.price));*/
    }


    private void cancelRide() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, cancelRideByDiverUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                OttoEventFinishedPassengerOffer ottoEventFinishedPassengerOffer=new OttoEventFinishedPassengerOffer("finished");
                                EventBusManager.getInstance().getEventBus().post(ottoEventFinishedPassengerOffer);

                                Intent c = new Intent(getApplicationContext(), NavHome.class);
                                startActivity(c);
                                finish();

                            } else {

                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                params.put("drivermobile", drivermobile);

                return params;

            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void prepareMovieData() {
        PassengerOffer passengerOffer = new PassengerOffer(getIntent().getStringExtra("message"),
                getIntent().getStringExtra("stage"), getIntent().getStringExtra("bookingid"), getIntent().getStringExtra("passengername"), getIntent().getStringExtra("passengermobile"),
                getIntent().getStringExtra("vehicle"), getIntent().getStringExtra("whenrequired"), getIntent().getStringExtra("whenrequiredtype"),
                getIntent().getStringExtra("typeofrate"), getIntent().getStringExtra("rate"), getIntent().getStringExtra("metervalue")
                , getIntent().getStringExtra("from"), getIntent().getStringExtra("to"), getIntent().getStringExtra("fromlatitude")
                , getIntent().getStringExtra("fromlongitude"), getIntent().getStringExtra("tolatitude"), getIntent().getStringExtra("tolongitude")
                , getIntent().getStringExtra("distance"), getIntent().getStringExtra("finalPriceForSortingOfPassenger"),getIntent().getStringExtra("expiry_time"));

        passengerOfferList.add(passengerOffer);
        mAdapter.notifyDataSetChanged();
        whenrequiredtype = getIntent().getStringExtra("whenrequiredtype");
        bookingidList.add(getIntent().getStringExtra("bookingid"));

       // sendDriverReadREceiptNetworkCall(getIntent().getStringExtra("bookingid"),getIntent().getStringExtra("passengermobile"));

        //   Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        mp.start();

        //removeRequestAfterExpired(getIntent().getStringExtra("bookingid"));
    }



    @Subscribe
    public void onOTPReceivedFromSMS(final OttoPassengerOffer passengerOfferOtto) {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                List<String> list = passengerOfferOtto.getPassengerOffer();
                PassengerOffer passengerOffer = new PassengerOffer(list.get(0), list.get(1), list.get(2), list.get(3), list.get(4), list.get(5), list.get(6), list.get(7), list.get(8), list.get(9)
                        , list.get(10), list.get(11), list.get(12), list.get(13), list.get(14), list.get(15), list.get(16), list.get(17), list.get(18),list.get(19));
                passengerOfferList.add(passengerOffer);
                mAdapter.notifyDataSetChanged();
                bookingidList.add(list.get(2));

               // sendDriverReadREceiptNetworkCall( list.get(2),list.get(4));



                mp.start();
             //   removeRequestAfterExpired(list.get(2));
            }
        }, 500);


    }

    @Subscribe
    public void onRemoverPassengerRequest(final RemovePassengerRequest removePassengerRequest) {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

       int i;

                    for (i = 0; i < passengerOfferList.size(); i++) {

                            String removeObject = removePassengerRequest.getBookingid();

                            if (passengerOfferList.get(i).getBookingid().equals(removeObject)) {
                                passengerOfferList.remove(i);
                                mAdapter.notifyDataSetChanged();

                            }
                        }

                        if(passengerOfferList.isEmpty()){

                            Intent h = new Intent(getApplicationContext(), NavHome.class);
                            startActivity(h);
                            finish();

                        }


            }
        }, 500);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (waitTimer != null) {
            waitTimer.cancel();
            waitTimer = null;
        }
      /*  EventBusManager.getInstance().getEventBus().unregister(this);*/
    }

/*
    public void sendDriverReadReceipt(final String id, final String passengerMobile){

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.i("0000000000000", "" + "----");

                sendDriverReadREceiptNetworkCall(id,passengerMobile,drivermobile);

            }


        }, 500);

    }*/


    private void sendDriverReadREceiptNetworkCall(final String id, final String passengerMobile) {
/*
        if (Utils.isInternetAvailable(PassengerOfferActivity.this)) {

            Utils.showProgress(PassengerOfferActivity.this);*/
            StringRequest stringRequest = new StringRequest(Request.Method.POST, sendReadReceiptUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                            //    Utils.stopProgress(PassengerOfferActivity.this);
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {




                                } else {


                                    String errorMsg = jObj.getString("error_msg");
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                          //  Utils.stopProgress(PassengerOfferActivity.this);
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("bookingid", id);
                    params.put("passengermobile", passengerMobile);
                    params.put("drivermobile", drivermobile);
                    params.put("timestamp", String.valueOf(Calendar.getInstance().getTime()));
                    params.put("status", "2");

                    return params;
                }
            };

            VolleySingleton.getInstance(PassengerOfferActivity.this).addToRequestQueue(stringRequest);

       /* } else {

            Utils.showToast(PassengerOfferActivity.this, "please connect to the internate");
        }*/
    }


    @Override
    public void removeItemAfterTimerFinished() {

       finish();
    }

//    @Override
//    public void acceptButton(View v, final int position) {
//
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, countOfferURL,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        try {
//                           /* loading.dismiss();*/
//                            JSONObject jObj = new JSONObject(response);
//                            boolean error = jObj.getBoolean("error");
//                            if (!error) {
//
//
//
//                                OttoEventFinishedPassengerOffer ottoEventFinishedPassengerOffer=new OttoEventFinishedPassengerOffer("finished");
//                                EventBusManager.getInstance().getEventBus().post(ottoEventFinishedPassengerOffer);
//
//
//                                timerForAvailability = new TimerForAvailability(getApplicationContext());
//                                sessionManager.setUpdateButton("waiting");
//                                timerForAvailability.starTimer();
//
//                                Intent intent1 = new Intent(PassengerOfferActivity.this, NavHome.class);
///*
//                                intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | IntentCompat.FLAG_ACTIVITY_CLEAR_TASK);
//*/
//                                startActivity(intent1);
//
//
//
//                                finish();
//
//                            } else {
//
//
//                                String errorMsg = jObj.getString("error_msg");
//                                //  startActivity(new Intent(RideRequestActivity.this,NavHome.class));
//                            }
//                        } catch (Exception e) {
//                            Log.d("Error", e.toString());
//                           /* loading.dismiss();*/
//                            //    startActivity(new Intent(RideRequestActivity.this,NavHome.class));
//                        }
//                    }
//                }
//                ,
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//
//                        Log.d("Error", error.toString());
//                        //   startActivity(new Intent(RideRequestActivity.this,NavHome.class));
//                      /*  loading.dismiss();*/
//                    }
//                }) {
//
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//
//                Map<String, String> params = new HashMap<String, String>();
//                params.put("drivername",passengername );
//                params.put("drivermobile",drivermobile );
//                params.put("passengername", passengerOfferList.get(position).getPassengername());
//                params.put("passengermobile", passengerOfferList.get(position).getPassengermobile());
//                params.put("vehicle", passengerOfferList.get(position).getVehicle());
//                params.put("whenrequired",passengerOfferList.get(position).getWhenrequired());
//                params.put("whenrequiredtype", passengerOfferList.get(position).getWhenrequiredtyp());
//                params.put("typeofrate", passengerOfferList.get(position).getTypeofrate());
//                params.put("rate", passengerOfferList.get(position).getRate());
//                params.put("metervalue", passengerOfferList.get(position).getMetervalue());
//                params.put("from", passengerOfferList.get(position).getFrom());
//                params.put("to",passengerOfferList.get(position).getTo());
//                params.put("fromlatitude", passengerOfferList.get(position).getFromlatitude());
//                params.put("fromlongitude",  passengerOfferList.get(position).getFromlongitude());
//                params.put("tolatitude",  passengerOfferList.get(position).getTolatitude());
//                params.put("tolongitude", passengerOfferList.get(position).getTolongitude());
//                params.put("bookingid", passengerOfferList.get(position).getBookingid());
//
//                return params;
//
//            }
//        };
//        VolleySingleton.getInstance(PassengerOfferActivity.this).addToRequestQueue(stringRequest);
//    }

    @Subscribe
    public void onAcceptButton(OttoEventFinishedPassengerOffer ottoEventFinishedPassengerOffer) {

        finish();
    }

}

