package com.kouchan.dyutpassenger.Adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.CountDownTimer;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.CurrentRide;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.IRemoveItem;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.NavHome;
import com.kouchan.dyutpassenger.View.Activities.PassengerOfferActivity;
import com.kouchan.dyutpassenger.View.Activities.RideRequestActivity;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.holders.PassengerOfferViewHolder;
import com.kouchan.dyutpassenger.models.OttoEventFinishedPassengerOffer;
import com.kouchan.dyutpassenger.models.PassengerOffer;
import com.kouchan.dyutpassenger.other.TimerForAvailability;
import com.kouchan.dyutpassenger.utils.Utils;
import com.squareup.otto.Subscribe;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

/**
 * Created by KOUCHAN-ADMIN on 12/1/2017.
 */

public class PassengerOfferAdapter extends RecyclerView.Adapter<PassengerOfferViewHolder> {

    private List<PassengerOffer> passengerOfferList;

    String languageCode;
    Resources resources;
    SessionManager sessionManager;
    Context context;
    CountDownTimer timer;
    /*SessionManager sessionManager;*/
    IRemoveItem iRemoveItem;
    long t;
    CountDownTimer waitingTimer;
    String sendRemoveReceiptUrl= Url.COMUNICATE_API+"removePassengerFromDriverOfferList.php";
    String countOfferURL = Url.COMUNICATE_API + "driverOfferToCustomer.php";
    CurrentRide currentRide;

    TimerForAvailability timerForAvailability;
    ProgressDialog progressDialog1;

    View view;


    public PassengerOfferAdapter(final List<PassengerOffer> passengerOfferList, Context context) {
        this.passengerOfferList = passengerOfferList;
        this.context = context;
        iRemoveItem= new PassengerOfferActivity();

        this.passengerOfferList = passengerOfferList;
        currentRide = new CurrentRide(context);
        EventBusManager.getInstance().getEventBus().register(this);
        progressDialog1=new ProgressDialog(context);

        //find out the maximum time the timer
        long maxTime = System.currentTimeMillis();
        long sysTime= System.currentTimeMillis();
       /* for (PassengerOffer item : passengerOfferList) {
            maxTime = Math.max(maxTime, item.getExpiry_time());
        }*/
        //set the timer which will refresh the data every 1 second.
        waitingTimer=   new CountDownTimer(400000, 1000) {
            @Override
            public void onTick(long l) {
                for (int i = 0, dataLength = passengerOfferList.size(); i < dataLength; i++) {
                    PassengerOffer item = passengerOfferList.get(i);
                     t=item.getExpiry_time();
                     item.timeRemaining -= 1000;
                }

                //remove the expired items
                Iterator<PassengerOffer> dataIterator = passengerOfferList.iterator();
                while (dataIterator.hasNext()) {
                    PassengerOffer rd = dataIterator.next();
                    if (rd.timeRemaining  <= 0) {
                        dataIterator.remove();

                        requestRemoved(rd.getPassengermobile(), rd.getBookingid());
                    }
                }
                notifyDataSetChanged();
            }

            @Override
            public void onFinish() {
             /*   passengerOfferList.clear();
                notifyDataSetChanged();*/
            }
        }.start();

    }



    @Override
    public PassengerOfferViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_passenger_offer_list, parent, false);
        view=itemView;
        return new PassengerOfferViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final PassengerOfferViewHolder holder, final int position) {

        final PassengerOffer passengerOffer = passengerOfferList.get(position);
        holder.mItemRowOfPassengerOfferPriceTextView.setText(passengerOffer.finalPriceForSortingOfPassenger());
        holder.mItemRowOfPassengerOfferToTextView.setText(passengerOffer.getTo());


        sessionManager = new SessionManager(context);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();

            Context contexta = LocaleHelper.setLocale(context, languageCode);
            resources = contexta.getResources();
            holder.itemRowOfPassengerOfferTimeText.setText(resources.getString(R.string.time));
            holder.itemRowOfPassengerOfferPriceText.setText(resources.getString(R.string.price));
        }

        holder.itemRowOfPassengerOfferTimeTextView.setText(millToMins(passengerOffer.timeRemaining) + " mins remaining");
        holder.acceptPassengerOffer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    sendCounterOffer(position);
            }
        });

        holder.expandPassengerOffer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                expandCounterOffer(position);
            }
        });
    }


    @Override
    public int getItemCount() {
        
        return passengerOfferList.size();
    }

    public void removeItem(final int position) {


    }


    private String millToMins(long millisec) {
        return millisec / (60000) + ":" + (int) (millisec/1000) % (60);
    }

    private void requestRemoved(final String passengermobile, final String bookingid) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, sendRemoveReceiptUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                                /*Utils.stopProgress(DriverOfferActivity.this);*/
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                               /* if (currentRide.getIsridestarted().equals("started")) {

                                    passengerOfferList.clear();

                                }else*/ if(passengerOfferList.isEmpty()){

                                        Intent openHome= new Intent(context, NavHome.class);
                                        openHome.addFlags(FLAG_ACTIVITY_NEW_TASK);
                                        context.startActivity(openHome);
                                        iRemoveItem.removeItemAfterTimerFinished();
                                    }

                            } else {
                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
/*
                            Utils.stopProgress(DriverOfferActivity.this);
*/
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                params.put("bookingid", bookingid);
                params.put("passengermobile", passengermobile);
                params.put("drivermobile", sessionManager.getUserDetails().get("mobile"));
                return params;
            }
        };

        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);




    }
    @Subscribe
    public void ottoEventActivityFinish(OttoEventFinishedPassengerOffer finish) {
        if(finish.getFinishTimer().equals("finished")){
           waitingTimer.cancel();
        }
    }

    private void sendCounterOffer(final int position) {

        Utils.showProgress(view.getContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, countOfferURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                                /*Utils.stopProgress(DriverOfferActivity.this);*/
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {
                                Utils.stopProgress(view.getContext());

                                OttoEventFinishedPassengerOffer ottoEventFinishedPassengerOffer = new OttoEventFinishedPassengerOffer("finished");
                                EventBusManager.getInstance().getEventBus().post(ottoEventFinishedPassengerOffer);


                                timerForAvailability = new TimerForAvailability(context);
                                sessionManager.setUpdateButton("waiting");
                                timerForAvailability.starTimer();
                                waitingTimer.cancel();

                                Intent intent1 = new Intent(context, NavHome.class);
                                intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                context.startActivity(intent1);





                            } else {
                                String errorMsg = jObj.getString("error_msg");
                                Utils.stopProgress(view.getContext());

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
/*
                            Utils.stopProgress(DriverOfferActivity.this);
*/
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                params.put("drivername", sessionManager.getUserDetails().get("name"));
                params.put("drivermobile", sessionManager.getUserDetails().get("mobile"));
                params.put("passengername", passengerOfferList.get(position).getPassengername());
                params.put("passengermobile", passengerOfferList.get(position).getPassengermobile());
                params.put("vehicle", passengerOfferList.get(position).getVehicle());
                params.put("whenrequired", passengerOfferList.get(position).getWhenrequired());
                params.put("whenrequiredtype", passengerOfferList.get(position).getWhenrequiredtyp());
                params.put("typeofrate", passengerOfferList.get(position).getTypeofrate());
                params.put("rate", passengerOfferList.get(position).getRate());
                params.put("metervalue", passengerOfferList.get(position).getMetervalue());
                params.put("from", passengerOfferList.get(position).getFrom());
                params.put("to", passengerOfferList.get(position).getTo());
                params.put("fromlatitude", passengerOfferList.get(position).getFromlatitude());
                params.put("fromlongitude", passengerOfferList.get(position).getFromlongitude());
                params.put("tolatitude", passengerOfferList.get(position).getTolatitude());
                params.put("tolongitude", passengerOfferList.get(position).getTolongitude());
                params.put("bookingid", passengerOfferList.get(position).getBookingid());
                return params;
            }
        };

        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);

    }




    private void expandCounterOffer(final int position) {

        Intent intent = new Intent(context, RideRequestActivity.class);

        intent.putExtra("message", "reached");
        intent.putExtra("stage", passengerOfferList.get(position).getStage());
        intent.putExtra("bookingid", passengerOfferList.get(position).getBookingid());
        intent.putExtra("passengername", passengerOfferList.get(position).getPassengername());
        intent.putExtra("passengermobile", passengerOfferList.get(position).getPassengermobile());
        intent.putExtra("vehicle", passengerOfferList.get(position).getVehicle());
        intent.putExtra("whenrequired", passengerOfferList.get(position).getWhenrequired());
        intent.putExtra("whenrequiredtype", passengerOfferList.get(position).getWhenrequiredtyp());

        intent.putExtra("typeofrate", passengerOfferList.get(position).getTypeofrate());
        intent.putExtra("rate", passengerOfferList.get(position).getRate());
        intent.putExtra("metervalue", passengerOfferList.get(position).getMetervalue());
        intent.putExtra("from", passengerOfferList.get(position).getFrom());
        intent.putExtra("to", passengerOfferList.get(position).getTo());
        intent.putExtra("fromlatitude", passengerOfferList.get(position).getFromlatitude());
        intent.putExtra("fromlongitude", passengerOfferList.get(position).getFromlongitude());
        intent.putExtra("tolatitude", passengerOfferList.get(position).getTolatitude());
        intent.putExtra("tolongitude", passengerOfferList.get(position).getTolongitude());
        intent.putExtra("distance", passengerOfferList.get(position).getDistance());

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);

    }


}


