package com.kouchan.dyutpassenger.Api;

public interface ServerApiNames {
  String PAYMENT = "paymentintegration.php";
}
