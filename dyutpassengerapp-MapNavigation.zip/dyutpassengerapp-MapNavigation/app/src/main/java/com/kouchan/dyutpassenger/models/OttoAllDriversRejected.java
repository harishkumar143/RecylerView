package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 10/23/2017.
 */

public class OttoAllDriversRejected {

    String rejection;

    public OttoAllDriversRejected(String rejection) {
        this.rejection = rejection;
    }

    public String getRejection() {
        return rejection;
    }
}
