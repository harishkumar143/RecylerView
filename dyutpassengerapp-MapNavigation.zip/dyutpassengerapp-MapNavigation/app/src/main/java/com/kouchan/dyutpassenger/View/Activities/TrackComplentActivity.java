package com.kouchan.dyutpassenger.View.Activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kouchan.dyutpassenger.Adapter.TrackComplentAdapter;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.models.ComplentsModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TrackComplentActivity extends AppCompatActivity {

    RecyclerView trackComplentRecyclerView;
    SessionManager sessionManager;
    String userId, url;
    List<ComplentsModel> complentsModelList = new ArrayList<>();
    TrackComplentAdapter mAdapter;
    ImageView nav_about_usBackImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_complent);
        intailizeViews();
        getComplentsAPICall();


        mAdapter = new TrackComplentAdapter(this, complentsModelList);
        trackComplentRecyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        trackComplentRecyclerView.setLayoutManager(mLayoutManager);
        trackComplentRecyclerView.setAdapter(mAdapter);
    }

    private void intailizeViews() {
        sessionManager = new SessionManager(this);
        trackComplentRecyclerView = (RecyclerView) findViewById(R.id.trackComplentRecyclerView);
        nav_about_usBackImageView = (ImageView) findViewById(R.id.nav_about_usBackImageView);

        nav_about_usBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    public void getComplentsAPICall() {

        url = Url.PASSENGER_API + "getcomplaints.php?user_id=" + sessionManager.getId() + "&user_type=" + sessionManager.getType();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            if (!error) {

                                JSONArray contacts = jsonObj.getJSONArray("complaints");
                                for (int i = 0; i < contacts.length(); i++) {
                                    JSONObject c = contacts.getJSONObject(i);

                                    String complaint_id = c.getString("complaint_id");
                                    String booking_id = c.getString("booking_id");
                                    String complaint_type = c.getString("complaint_type");
                                    String comments = c.getString("comments");
                                    String status = c.getString("status");

                                    ComplentsModel model = new ComplentsModel(complaint_id, booking_id, complaint_type, comments, status);
                                    complentsModelList.add(model);
                                    mAdapter.notifyDataSetChanged();
                                }
                            } else {
                                String errorMsg = jsonObj.getString("error_msg");
                                Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                });

        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);

    }
}
