package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.utils.AppConstants;

public class AutoBookRideActivity extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    RadioGroup radioGroup;
    RadioButton rb_lessprice,rb_lessdistance;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.auto_book_selection );
        setTitle("Auto Mode Book a Cab");
        sharedPreferences=getSharedPreferences(AppConstants.PREF_AUTO_BOOK, Context.MODE_PRIVATE);
        radioGroup = (RadioGroup) findViewById(R.id.radiogroup);
        rb_lessdistance=findViewById(R.id.rb_less_distance);
        rb_lessprice=findViewById(R.id.rb_less_price);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                   if(checkedId==rb_lessdistance.getId()){
                      SharedPreferences.Editor editor = sharedPreferences.edit();
                       editor.putBoolean(AppConstants.PREF_AUTO_LESS_DISTANCE, true);
                       editor.putBoolean(AppConstants.PREF_AUTO_LESS_PRICE, false);
                       editor.commit();
                   }else if(checkedId==rb_lessprice.getId()){
                       SharedPreferences.Editor editor = sharedPreferences.edit();
                       editor.putBoolean(AppConstants.PREF_AUTO_LESS_PRICE, true);
                       editor.putBoolean(AppConstants.PREF_AUTO_LESS_DISTANCE, false);
                       editor.commit();
                   }
            }
        });

    }


}
