package com.kouchan.dyutpassenger.View.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;
import com.kouchan.dyutpassenger.Adapter.AddedMoneyHistoryAdapter;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.models.AddedMoneyHistoryModel;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AddedMoneyHistoryFragment extends Fragment {

    @BindView(R.id.addedMoneyRecyclerView)
    RecyclerView addedMoneyHistoryRecyclerView;

    AddedMoneyHistoryModel addedMoneyHistoryModel;
    String url="https://bookarideworldwide.com/CAB2.V.1/paytmlib/transactionhistory.php?unique_id=";
    SessionManager sessionManager;
    AddedMoneyHistoryAdapter moneyHistoryAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.added_money_history,container,false);
        ButterKnife.bind(this, view);
        sessionManager=new SessionManager(getActivity());
        intializeViews();
        return view;
    }

    private void intializeViews() {
        StringRequest updateDriverLocation = new StringRequest(Request.Method.POST, url+sessionManager.getUniqueId(),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {
                                Gson gson=new Gson();
                                addedMoneyHistoryModel=   gson.fromJson(response.toString(),AddedMoneyHistoryModel.class);

                                moneyHistoryAdapter=new AddedMoneyHistoryAdapter(getActivity(),addedMoneyHistoryModel.getTXNRECORDS());
                                addedMoneyHistoryRecyclerView.setHasFixedSize(true);
                                addedMoneyHistoryRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                                addedMoneyHistoryRecyclerView.setNestedScrollingEnabled(false);
                                addedMoneyHistoryRecyclerView.setItemAnimator(new DefaultItemAnimator());
                                addedMoneyHistoryRecyclerView.setAdapter(moneyHistoryAdapter);

                            } else {
                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(updateDriverLocation);
    }
}
