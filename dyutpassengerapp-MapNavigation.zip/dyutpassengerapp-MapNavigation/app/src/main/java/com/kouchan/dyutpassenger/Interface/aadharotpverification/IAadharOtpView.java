package com.kouchan.dyutpassenger.Interface.aadharotpverification;

public interface IAadharOtpView {

    void aadharOtpSuccess(int pid, String aadharOtpmodel);

    void aadharOtpError(int pid, String error);

}
