package com.kouchan.dyutpassenger.Adapter;

import android.view.View;

public interface CustomItemClickListener {

    public void onItemClick(View v, String position);
}
