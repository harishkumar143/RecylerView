package com.kouchan.dyutpassenger.other;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by KOUCHAN-ADMIN on 1/20/2018.
 */

public class CustomDialogClass extends Dialog implements
        android.view.View.OnClickListener {

    public String latlongtype;
    public Activity c;
    public Dialog d;
    public Button yes, no;
    public EditText customeFavoritEditText;
    public TextView addressFavorit;
    public RadioGroup book_a_ride_fevorit_radiogroup;
    String address;
    public String type="";
    public String mobile;
    public String tolatitude;
    public String tolongitude;
    RadioButton homeFevorit;
    private String favoritStoreApi= Url.PASSENGER_API+"favorites.php";

    public CustomDialogClass(Activity a,String address,String tolatitude, String tolongitude,String mobile,String latlongtype) {
        super(a);

        this.c = a;
        this.address=address;
        this.mobile= mobile;
        this.tolatitude=tolatitude;
        this.tolongitude=tolongitude;
        this.latlongtype=latlongtype;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*requestWindowFeature(Window.FEATURE_NO_TITLE);*/
        setContentView(R.layout.custom_dialog);

        yes = (Button) findViewById(R.id.btn_yes);
        no = (Button) findViewById(R.id.btn_no);
        book_a_ride_fevorit_radiogroup=(RadioGroup)findViewById(R.id.book_a_ride_fevorit_radiogroup);
        customeFavoritEditText= (EditText)findViewById(R.id.customeFavoritEditText);
        addressFavorit=(TextView)findViewById(R.id.addressFavorit);

        addressFavorit.setText(address);

        yes.setOnClickListener(this);
        no.setOnClickListener(this);

        homeFevorit=(RadioButton)findViewById(R.id.homeFevorit);
        homeFevorit.setChecked(true);

/*
        book_a_ride_fevorit_radiogroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.homeFevorit:
                        type="Home";
                        customeFavoritEditText.setVisibility(View.GONE);
                        break;
                    case R.id.workFevorit:
                        type="Work";
                        customeFavoritEditText.setVisibility(View.GONE);
                        break;
                    case R.id.otherFevorit:
                        type="Other";
                        customeFavoritEditText.setVisibility(View.VISIBLE);
                        break;
                }}});*/

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_yes:
                sendFavoritsToServer();
                break;
            case R.id.btn_no:
                dismiss();
                break;



            default:
                break;
        }
        /*dismiss();*/
    }

    private void sendFavoritsToServer() {

        if(addressFavorit.getText().toString().isEmpty()){
            Toast.makeText(c, "Selct address to save", Toast.LENGTH_SHORT).show();
        }
        else if(customeFavoritEditText.getText().toString().isEmpty()){
            Toast.makeText(c, "Name your favourite", Toast.LENGTH_SHORT).show();
        }
        else {
            Utils.showProgress(c);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, favoritStoreApi,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {

                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {

                                    dismiss();
                                    Utils.stopProgress(c);

                                    Toast.makeText(c, "Favourite added successfully", Toast.LENGTH_SHORT).show();
                                } else {
                                    String errorMsg = jObj.getString("error_msg");
                                    Toast.makeText(c, errorMsg, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Utils.stopProgress(c);
                            Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();

                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {

                    Map<String, String> params = new HashMap<String, String>();

                    params.put("mobile", mobile);
                    params.put("address", address);
                    params.put("addresstype", customeFavoritEditText.getText().toString());
                    params.put("tolatitude", tolatitude);
                    params.put("tolongitude", tolongitude);
                    params.put("latlongtype", latlongtype);

                    return params;

                }
            };

            VolleySingleton.getInstance(c).addToRequestQueue(stringRequest);
        }
    }


    @Override
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> data, @Nullable Menu menu, int deviceId) {

    }
}