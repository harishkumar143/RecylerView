package com.kouchan.dyutpassenger.Interface.aadharotpverification;

public interface IAadharOtpPresnter {

    void aadhatOtp(String aadharOTP, String mobile, String password);

}
