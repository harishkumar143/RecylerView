package com.kouchan.dyutpassenger.Interface.deletefavourite;

import com.kouchan.dyutpassenger.View.Activities.SearchActivity;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DeleteFavouritePresenterImpl implements IDeleteFavouritePresnter,OnRequestListener {

    SearchActivity navHome;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IDeleteFavouriteView deleteFavouriteView;

    public DeleteFavouritePresenterImpl(IDeleteFavouriteView deleteFavouriteView) {
        this.navHome =(SearchActivity) deleteFavouriteView;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(navHome);
        this.asyncInteractor = new AsyncInteractor(navHome);
        this.deleteFavouriteView = deleteFavouriteView;
    }

    @Override
    public void deleteFavourite(String id) {
        if(NetworkStatus.checkNetworkStatus(navHome)){
            Utils.showProgress(navHome);
            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_DELETEFAVOURITE, "https://bookarideworldwide.com/CAB2.V.1/passenger_api/favoritesdelete.php?add_id="+id);
        } else {
            Utils.showToast(navHome, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if(pid==AppConstants.TAG_ID_DELETEFAVOURITE){
            Utils.stopProgress(navHome);
            if(responseJson!=null){
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if(!error) {
                    deleteFavouriteView.deleteFavouriteSuccess(pid,jObj.getString("message"));
                }
                else {
                    deleteFavouriteView.deleteFavouriteError(pid,jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(navHome);
        deleteFavouriteView.deleteFavouriteError(pid,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        Utils.stopProgress(navHome);
        deleteFavouriteView.deleteFavouriteError(pid,error);
    }
}
