package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;


public class CancelReceiptActivity extends AppCompatActivity {

    Button okButtonCancelReceipt;
    ImageView cancelReceiptBackImageView, cancelReceiptHomeImageView;
    Toolbar mToolbar;

    TextView cancel_receipt_textView,passenger_cancelled_textView;

    SessionManager sessionManager;
    String languageCode;
    Resources resources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_receipt);


        okButtonCancelReceipt = (Button) findViewById(R.id.okButtonCancelReceipt);

        cancel_receipt_textView = (TextView) findViewById(R.id.cancel_receipt_textView);
        passenger_cancelled_textView = (TextView) findViewById(R.id.passenger_cancelled_textView);

        okButtonCancelReceipt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        cancelReceiptBackImageView = (ImageView) findViewById(R.id.cancelReceiptBackImageView);
        cancelReceiptHomeImageView = (ImageView) findViewById(R.id.cancelReceiptHomeImageView);

        cancelReceiptBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        cancelReceiptHomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        passenger_cancelled_textView.setText(resources.getString(R.string.passenger_cancelled_his_ride_request));
        cancel_receipt_textView.setText(resources.getString(R.string.cancel_receipt));
        okButtonCancelReceipt.setText(resources.getString(R.string.ok));
    }

    @Override
    public void onBackPressed() {

        finish();
    }
}
