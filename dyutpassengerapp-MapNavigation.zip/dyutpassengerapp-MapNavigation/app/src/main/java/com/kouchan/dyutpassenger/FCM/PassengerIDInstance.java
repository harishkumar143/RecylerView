package com.kouchan.dyutpassenger.FCM;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.kouchan.dyutpassenger.Database.SessionManager;

/**
 * Created by KOUCHAN-ADMIN on 2/7/2017.
 */

public class PassengerIDInstance extends FirebaseInstanceIdService
{
    SessionManager sessionManager;

    @Override
    public void onTokenRefresh()
    {
        super.onTokenRefresh();

        storePassengerToken(FirebaseInstanceId.getInstance().getToken());
    }

    public String storePassengerToken(String token) {
        //we will save the token in sharedpreferences later
        sessionManager=new SessionManager(getApplicationContext());

        sessionManager.storeToken(token);

        return token;
    }

}
