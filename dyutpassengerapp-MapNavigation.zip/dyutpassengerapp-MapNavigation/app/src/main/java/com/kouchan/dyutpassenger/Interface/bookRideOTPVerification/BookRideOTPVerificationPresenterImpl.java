package com.kouchan.dyutpassenger.Interface.bookRideOTPVerification;

import android.util.Log;

import com.kouchan.dyutpassenger.View.Activities.VerifyOTP;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class BookRideOTPVerificationPresenterImpl implements OnRequestListener, IBookRideOTPVerificationPresenter {

    IBookRideOTPVerificationView iBookRideOTPView;
    VerifyOTP bookRideOTPVerificationActivity;
    AsyncInteractor asyncInteractor;
    Sharedpreferences prefs;

    public BookRideOTPVerificationPresenterImpl(VerifyOTP bookRideOTPVerificationActivity) {
        this.iBookRideOTPView = bookRideOTPVerificationActivity;
        this.bookRideOTPVerificationActivity = bookRideOTPVerificationActivity;
        prefs = prefs.getUserDataObj(bookRideOTPVerificationActivity);
        asyncInteractor = new AsyncInteractor(bookRideOTPVerificationActivity);
    }

    @Override
    public void getBookRideOTP(String email, String mobile, String password, String name,
                               String otp) {
        Map<String, String> params = new HashMap<String, String>();

        params.put("email", email);
        params.put("mobile", mobile);
        params.put("password", password);
        params.put("name", name);
        params.put("bar_otp", otp);
        asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_VERIFY_BOOKRIDE_OTP, "https://bookarideworldwide.com/CAB2.V.1/driver_api/verify_bar_otp.php", new JSONObject(params));
    }


    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {
    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if (pid == AppConstants.TAG_ID_VERIFY_BOOKRIDE_OTP) {
            Log.e("responseRegistration", responseJson.toString());
            if (responseJson != null) {

                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {

                    iBookRideOTPView.onGetBookRideOTPSuccess(pid, responseJson);

                } else {
                    // Error occurred in registration. Get the error
                    // message
                    String errorMsg = jObj.getString("message");
                    iBookRideOTPView.onGetBookRideOTPError(pid, errorMsg);
                }
            } else {

                iBookRideOTPView.onGetBookRideOTPError(pid, "");
            }
        }

    }

    @Override
    public void onRequestCompletionError(int pid, String error) {

    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        iBookRideOTPView.onGetBookRideOTPError(pid, error);
    }

}
