package com.kouchan.dyutpassenger.Database;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.kouchan.dyutpassenger.View.Activities.LoginActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;


/**
 * Created by Rajan on 12/9/2016.
 */

public class SessionManager {

    SharedPreferences bookARideSession;

    Editor edit;

    Context context;

    int PRIVATE_MODE = 0;

    // Sharedpref file name
    private static final String SESSION_NAME = "BOOKARIDESESSION";

    // All Shared Preferences Keys
    private static final String IS_LOGIN = "IsLoggedIn";

    // User name (make variable public to access from outside)
    public static final String KEY_NAME = "name";
    public static final String USER_NAME = "name";
    public static final String KEY_ID = "id";
    public static final String TAG_OAUTH_TOKEN = "oauthToken";
    public static final String TAG_REFRESH_TOKEN = "refeOauthToken";
    public static final String KEY_EMAIL = "email";

    public static final String KEY_UNIQUEID = "uniqueid";
    public static final String KEY_BLOCKSTATUS = "blockstatus";
    public static final String KEY_M3OTPSTATUS = "m3otpstatus";
    public static final String KEY_M3ADHAROTPSTATUS = "m3adharotpstatus";
    public static final String KEY_PASSWORD = "password";

    // Email address (make variable public to access from outside)
    public static final String KEY_MOBILE = "mobile";

    public static final String KEY_TYPE = "type";

    public static final String KEY_RECYCLEVIEW = "numberOfCount";
    public static final String KEY_RECYCLEVIEW_DRIVER = "numberOfCount";

    public static final String KEY_TIMER = "numberOfCount";

    public static final String KEY_UPDATE_BUTTON_STATUS = "buttonStatus";

    public static final String KEY_VEHICLE_TYPE = "vehicleType";

    public static final String KEY_LANGUAGE_CODE = "languagecode";

    public static final String KEY_CURRENCY_SYSMBOL = "currency";

    public static final String WALLET_BAL = "balance";


    // Constructor
    public SessionManager(Context context) {
        this.context = context;
        bookARideSession = this.context.getSharedPreferences(SESSION_NAME, PRIVATE_MODE);
        edit = bookARideSession.edit();
    }


    public void createTimer(String timer) {
        // Storing name in pref
        edit.putString(KEY_TIMER, timer);
        edit.commit();
    }

    public String getTimer() {
        String type = bookARideSession.getString(KEY_TIMER, null);
        return type;
    }
    /*
     *
     *
     * check login status if true then jump else stay on same page
     * */


    /**
     * Create login session
     */
    public void createLoginSession(String name, String mobile) {
        // Storing login value as TRUE
        edit.putBoolean(IS_LOGIN, true);

        // Storing name in pref
        edit.putString(KEY_NAME, name);


        // Storing email in pref
        edit.putString(KEY_MOBILE, mobile);

        // commit changes
        edit.commit();
    }

    public ArrayList<String> loginData() {
        ArrayList<String> data = new ArrayList<>();
        data.add(bookARideSession.getString(KEY_NAME, null));
        data.add(bookARideSession.getString(KEY_MOBILE, null));
        return data;
    }

    public void setIsLogin(Boolean log) {
        edit.putBoolean(IS_LOGIN, log);
    }

    public void recycleCount() {

        int attepmpt = bookARideSession.getInt(KEY_RECYCLEVIEW, 0) + 1;
        //edit.putInt(KEY_RECYCLEVIEW, attepmpt);
        bookARideSession.edit().putInt(KEY_RECYCLEVIEW, attepmpt).apply();
        edit.commit();
    }

    public int getrecycleCount() {
        int count = bookARideSession.getInt(KEY_RECYCLEVIEW, 0);
        return count;
    }

    public void couterZero() {
        edit.putInt(KEY_RECYCLEVIEW, 0).apply();
        edit.commit();
    }

    public void recycleCountDriver() {

        int attepmpt = bookARideSession.getInt(KEY_RECYCLEVIEW_DRIVER, 0) + 1;
        //edit.putInt(KEY_RECYCLEVIEW, attepmpt);
        bookARideSession.edit().putInt(KEY_RECYCLEVIEW_DRIVER, attepmpt).apply();
        edit.commit();
    }

    public String getOauthToken() {
        return bookARideSession.getString(TAG_OAUTH_TOKEN, "");
    }

    public void setOauthToken(String oauthToken) {
        try {
            edit.putString(TAG_OAUTH_TOKEN, oauthToken);
            edit.commit();
        } catch (Exception e) {
        }
    }

    public String getRefreshToken() {
        return bookARideSession.getString(TAG_REFRESH_TOKEN, "");
    }

    public void setRefreshTokenToken(String refeOauthToken) {
        try {
            edit.putString(TAG_REFRESH_TOKEN, refeOauthToken);
            edit.commit();
        } catch (Exception e) {
        }
    }

    public int getrecycleCountDriver() {
        int count = bookARideSession.getInt(KEY_RECYCLEVIEW_DRIVER, 0);
        return count;
    }

    public void couterZeroDriver() {
        edit.putInt(KEY_RECYCLEVIEW_DRIVER, 0).apply();
        edit.commit();
    }

    public void createType(String type) {
        // Storing name in pref
        edit.putString(KEY_TYPE, type);
        edit.commit();
    }


    public void setCurrency(String currency) {
        edit.putString(KEY_CURRENCY_SYSMBOL, currency);
        edit.commit();
    }

    public String getCurrency() {
        String currency = bookARideSession.getString(KEY_CURRENCY_SYSMBOL, null);
        return currency;
    }


    public String getType() {
        String type = bookARideSession.getString(KEY_TYPE, null);
        return type;
    }

    public void createId(String id) {
        // Storing name in pref
        edit.putString(KEY_ID, id);
        edit.commit();
    }

    public String getId() {
        String id = bookARideSession.getString(KEY_ID, null);
        return id;
    }

    public void createEmail(String email) {
        // Storing name in pref
        edit.putString(KEY_EMAIL, email);
        edit.commit();
    }

    public String getKeyEmail() {
        String email = bookARideSession.getString(KEY_EMAIL, null);
        return email;
    }

    public void setName(String name) {
        // Storing name in pref
        edit.putString(USER_NAME, name);
        edit.commit();
    }

    public String getName() {
        String name = bookARideSession.getString(USER_NAME, null);
        return name;
    }

    public void setWalletBal(String name) {
        // Storing name in pref
        edit.putString(WALLET_BAL, name);
        edit.commit();
    }

    public String getWalletBal() {
        String name = bookARideSession.getString(WALLET_BAL, null);
        return name;
    }

    public void checkLogin() {
        // Check login status
        if (!this.isLoggedIn()) {
            // user is not logged in redirect him to Login Activity
            Intent i = new Intent(context, LoginActivity.class);
            // Closing all the Activities
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            // Add new Flag to start new Activity
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Staring Login Activity
            context.startActivity(i);
        }

    }


    public HashMap<String, String> getUserDetails() {
        HashMap<String, String> user = new HashMap<String, String>();
        // user name
        user.put(KEY_NAME, bookARideSession.getString(KEY_NAME, null));

        // user mobile
        user.put(KEY_MOBILE, bookARideSession.getString(KEY_MOBILE, null));

        // return user
        return user;
    }

    public void logoutUser(Context context) {
        // Clearing all data from Shared Preferences
        /*edit.remove(KEY_MOBILE);*/
        edit.remove(KEY_NAME);
        edit.remove(IS_LOGIN);
        edit.commit();
        String type = getType();

        switch (type) {
            case "passenger":
                Intent p = new Intent(context, LoginActivity.class);
                p.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(p);

                break;

            case "driver":
                Intent d = new Intent(context, LoginActivity.class);
                d.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(d);

                break;

            case "both":

                Intent b = new Intent(context, LoginActivity.class);
                b.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(b);
                break;
        }

    }

    public boolean isLoggedIn() {
        return bookARideSession.getBoolean(IS_LOGIN, false);
    }

    public boolean storeToken(String token) {
        edit.putString("token", token);

        edit.apply();

        return true;
    }

    public String getToken() {
        return bookARideSession.getString("token", null);
    }


    public void setUpdateButton(String ststus) {
        // Storing name in pref
        edit.putString(KEY_UPDATE_BUTTON_STATUS, ststus);
        edit.commit();
    }

    public String getUpdateButton() {
        String type = bookARideSession.getString(KEY_UPDATE_BUTTON_STATUS, "offline");
        return type;
    }

    public void setVehicleType(String vehicleType) {
        // Storing name in pref
        edit.putString(KEY_VEHICLE_TYPE, vehicleType);
        edit.commit();
    }

    public String getVehicleType() {
        String vehicleType = bookARideSession.getString(KEY_VEHICLE_TYPE, "Taxi");
        return vehicleType;
    }


    public void setKeyLanguageCode(String languageCode) {
        edit.putString(KEY_LANGUAGE_CODE, languageCode);
        edit.commit();
    }

    public String getLanguageCode() {
        return bookARideSession.getString(KEY_LANGUAGE_CODE, Locale.getDefault().getDisplayLanguage());
    }

    public void setUniqueId(String uniqueId) {
        // Storing name in pref
        edit.putString(KEY_UNIQUEID, uniqueId);
        edit.commit();
    }

    public String getUniqueId() {
        return bookARideSession.getString(KEY_UNIQUEID, null);
    }

    public void setBlockstatus(String blockstatus) {
        // Storing name in pref
        edit.putString(KEY_BLOCKSTATUS, blockstatus);
        edit.commit();
    }

    public String getBlockstatus() {
        return bookARideSession.getString(KEY_BLOCKSTATUS, null);
    }

    public void setM3otpstatus(String m3otpstatus) {
        // Storing name in pref
        edit.putString(KEY_M3OTPSTATUS, m3otpstatus);
        edit.commit();
    }

    public String getM3otpstatus() {
        return bookARideSession.getString(KEY_M3OTPSTATUS, null);
    }

    public void setM3adharotpstatus(String m3adharotpstatus) {
        // Storing name in pref
        edit.putString(KEY_M3ADHAROTPSTATUS, m3adharotpstatus);
        edit.commit();
    }

    public String getM3adharotpstatus() {
        return bookARideSession.getString(KEY_M3ADHAROTPSTATUS, null);
    }

    public void setPassword(String password) {
        // Storing name in pref
        edit.putString(KEY_PASSWORD, password);
        edit.commit();
    }

    public String getPassword() {
        return bookARideSession.getString(KEY_PASSWORD, null);
    }

}
