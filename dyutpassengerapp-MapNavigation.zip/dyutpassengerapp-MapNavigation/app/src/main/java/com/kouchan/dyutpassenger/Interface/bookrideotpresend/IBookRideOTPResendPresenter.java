package com.kouchan.dyutpassenger.Interface.bookrideotpresend;

public interface IBookRideOTPResendPresenter {

    void getBookRideOTPResend(String stringMobile);

}
