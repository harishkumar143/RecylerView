package com.kouchan.dyutpassenger.models;


public class History {

    private String month, year, total_no_of_rides, total_fare;

    public History(String month, String year, String total_no_of_rides, String total_fare) {
        this.month = month;
        this.year = year;
        this.total_no_of_rides = total_no_of_rides;
        this.total_fare = total_fare;
    }

    public String getMonth() {
        return month;
    }

    public String getYear() {
        return year;
    }

    public String getTotal_no_of_rides() {
        return total_no_of_rides;
    }

    public String getTotal_fare() {
        return total_fare;
    }

}
