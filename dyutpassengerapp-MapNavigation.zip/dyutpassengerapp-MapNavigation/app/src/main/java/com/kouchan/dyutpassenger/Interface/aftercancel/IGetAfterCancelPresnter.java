package com.kouchan.dyutpassenger.Interface.aftercancel;

public interface IGetAfterCancelPresnter {

    void getAfterCancel();

}

