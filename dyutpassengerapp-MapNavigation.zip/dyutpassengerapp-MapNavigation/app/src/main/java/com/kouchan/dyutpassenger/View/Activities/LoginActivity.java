package com.kouchan.dyutpassenger.View.Activities;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.PrefManager;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.functions.Functions;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.utils.Utils;
import com.squareup.otto.Subscribe;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class LoginActivity extends AppCompatActivity {

    private static final String requestForOTP = Url.PASSENGER_API + "forgotPassword.php";
    public static String id, email, vehicleType;

    TextView activity_passenger_login;
    TextView forgotPassword;
    TextView registration_text_passenger, registration_text_passenger1;
    ProgressDialog loading;
    EditText mobile;
    EditText password;
    SessionManager sessionManager;
    PrefManager prefManager;
    String stringPassword,stringMobile;
    Button login;
    Toolbar mToolbar;
    String languageCode;
    Resources resources;
    String mobile_no_session;
    HashMap<String, String> user = new HashMap<String, String>();
    AlertDialog alertDialog1;
    CharSequence[] values = {"Current Mobile Number", "Alternate Mobile Number"};
    String selectedOption;
    private String LOGIN_URL = Url.PASSENGER_API + "login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sessionManager = new SessionManager(getApplicationContext());
        prefManager = new PrefManager(getApplicationContext());


        if (sessionManager.isLoggedIn() && !prefManager.isWaitingForSms()) {
            startActivity(new Intent(getApplicationContext(), NavHome.class));
            finish();
        } else {

            selectedOption = "passenger";
            sessionManager.createType(selectedOption);

            mobile = (EditText) findViewById(R.id.login_mobile);
// Request focus and show soft keyboard automatically
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            user = sessionManager.getUserDetails();
            mobile_no_session = user.get(SessionManager.KEY_MOBILE);
            password = (EditText) findViewById(R.id.login_password);
            login = (Button) findViewById(R.id.login_button);
            forgotPassword = (TextView) findViewById(R.id.forgotPasswordPassenger);
            registration_text_passenger = (TextView) findViewById(R.id.registration_text_passenger);
            registration_text_passenger1 = (TextView) findViewById(R.id.registration_text_passenger1);
            activity_passenger_login = (TextView) findViewById(R.id.activity_passenger_login);


            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isValid(mobile,password)){

                        stringMobile = mobile.getText().toString();
                        stringPassword=password.getText().toString();

                        sendValues();
                    }
                }
            });



            forgotPassword.setOnClickListener(new View.OnClickListener() {
                                                  @Override
                                                  public void onClick(View v) {

                                                      stringMobile = mobile.getText().toString();
                                                      if (!(Functions.isMobileValid(mobile.getText().toString()))) {
                                                          Toast.makeText(LoginActivity.this, "Please enter valid mobile number", Toast.LENGTH_SHORT).show();
                                                      } else {
                                                          CreateAlertDialogWithRadioButtonGroup();
                                                      }
                                                  }
                                              }
            );



            registration_text_passenger.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(LoginActivity.this, Registration.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                    finish();
                }
            });

            registration_text_passenger1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(LoginActivity.this, Registration.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                    finish();
                }
            });

            sessionManager = new SessionManager(this);
            if (sessionManager.getLanguageCode() != null) {
                languageCode = sessionManager.getLanguageCode();
                updateViews(languageCode);
            }

        }

        permission();
    }

    private boolean isValid(EditText mobile,EditText password) {

        if (mobile.getText().toString().trim().length() == 0) {
            mobile.setError("Please enter mobile number");
            mobile.requestFocus();
            return false;
        }

        if (mobile.getText().toString().trim().length() < 10) {
            mobile.setError("Mobile number should be 10 digits");
            mobile.requestFocus();
            return false;
        }

        if (password.getText().toString().trim().length() == 0) {
            Utils.showToast(this, "Please enter password");
            password.setError("Password is empty");
            password.requestFocus();
            return false;
        }

        if (password.getText().toString().trim().length() <6) {
            Utils.showToast(this, "Password to be more than 6 characters");
            password.setError("Password to be more than 6 characters");
            password.requestFocus();
            return false;
        }

        if (password.getText().toString().trim().length() >8) {
            Utils.showToast(this, "Password to be less than 8 characters");
            password.setError("Password to be less than 8 characters");
            password.requestFocus();
            return false;
        }

        return true;
    }


    /*----------------------------------------------------------------------*/

    public void CreateAlertDialogWithRadioButtonGroup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
        builder.setTitle("Did you forget your password?")
                .setPositiveButton(resources.getString(R.string.yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        sendPasswordForOTP();
                    }
                })
                .setNegativeButton(resources.getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing
                        alertDialog1.dismiss();
                    }
                }).setIcon(android.R.drawable.ic_dialog_alert)
                .show();

        alertDialog1 = builder.create();
        alertDialog1.show();
    }

    /*-----------------------------------------------------------------------*/

    private void updateViews(String languageCode) {
            Context context = LocaleHelper.setLocale(this, languageCode);
            resources = context.getResources();

        activity_passenger_login.setText(resources.getString(R.string.login));
        // app_name.setText(resources.getString(R.string.app_name));
        //login_mobile_TextInputLayout.setHint(resources.getString(R.string.mobile_no));
        // login_password_TextInputLayout.setHint(resources.getString(R.string.password));
        login.setText(resources.getString(R.string.login));
        forgotPassword.setText(resources.getString(R.string.forgot_password));
        // changeLanguagePassenger.setText(resources.getString(R.string.select_language));
        // signup_passenger.setText(resources.getString(R.string.registration));

    }


    private void sendPasswordForOTP() {

        if (Utils.isInternetAvailable(LoginActivity.this)) {

            Utils.showProgress(LoginActivity.this);
            final StringRequest stringRequest = new StringRequest(Request.Method.POST, requestForOTP,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                Utils.stopProgress(LoginActivity.this);
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {

                                    Intent i = new Intent(LoginActivity.this, ForgotPassword.class);
                                    i.putExtra("mobile", stringMobile);
                                    startActivity(i);
                                    finish();


                                } else {

                                    String errorMsg = jObj.getString("error_msg");
                                    Toast.makeText(LoginActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Utils.stopProgress(LoginActivity.this);
                        }
                    }) {

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String, String> params = new HashMap<String, String>();

                    params.put("mobile", stringMobile);


                    return params;
                }
            };
            VolleySingleton.getInstance(LoginActivity.this).addToRequestQueue(stringRequest);
        } else {

            Utils.showToast(LoginActivity.this, "please connect to the internate");

        }
    }


    private void sendValues() {

        if (Utils.isInternetAvailable(LoginActivity.this)) {

            Utils.showProgress(LoginActivity.this);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, LOGIN_URL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                Utils.stopProgress(LoginActivity.this);
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {
                                    prefManager.setIsWaitingForSms(false);
                                    sessionManager.setIsLogin(true);

                                    String id = jObj.getString("id");

                                    JSONObject user = jObj.getJSONObject("user");
                                    String stringName = user.getString("name");
                                    String stringMobile = user.getString("mobile");
                                    String email = user.getString("email");
                                    String created_at = user.getString("created_at");

                                    String blockStatus = user.getString("block_status");
                                    String uniqueId = user.getString("unique_id");

                                    sessionManager.createLoginSession(stringName, stringMobile);
                                    sessionManager.createId(id);
                                    sessionManager.createEmail(email);
                                    sessionManager.setUniqueId(uniqueId);
                                    sessionManager.setBlockstatus(blockStatus);
                                    //sessionManager.setM3adharotpstatus(m3adharOtpStatus);
                                 //   sessionManager.setM3otpstatus(m3otpStatus);
                                    sessionManager.setName(stringName);
                                    sessionManager.setPassword(stringPassword);
                                    startActivity(new Intent(LoginActivity.this, NavHome.class));
                                    finish();

                                } else {

                                    // Error occurred in registration. Get the error
                                    // message
                                    String errorMsg = jObj.getString("error_msg");
                                    Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Utils.stopProgress(LoginActivity.this);
                            Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("mobile", stringMobile);
                    params.put("password", stringPassword);

                    if (sessionManager.getToken() != null)
                        params.put("token", sessionManager.getToken());

                    return params;
                }

            };

            stringRequest.setRetryPolicy(new DefaultRetryPolicy(5000, 1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);

        } else {
            Utils.showToast(LoginActivity.this, "Please connect to the internet");
        }
    }



    private void permission() {

        Dexter.withActivity(this)
                .withPermissions(
                        android.Manifest.permission.CAMERA,
                        android.Manifest.permission.READ_CONTACTS,
                        android.Manifest.permission.RECORD_AUDIO,
                        android.Manifest.permission.READ_SMS,
                        android.Manifest.permission.RECEIVE_SMS,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION,
                        android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.GET_ACCOUNTS,
                        android.Manifest.permission.CALL_PHONE
                ).withListener(new MultiplePermissionsListener() {
            @Override
            public void onPermissionsChecked(MultiplePermissionsReport report) {
            }

            @Override
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {/* ... */}
        }).check();

    }
}
