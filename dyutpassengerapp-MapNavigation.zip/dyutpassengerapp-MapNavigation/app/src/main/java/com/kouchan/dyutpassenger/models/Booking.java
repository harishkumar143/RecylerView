package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 10/17/2017.
 */

public class Booking {

    private String booking_id;
    private String passenger_name;
    private String passenger_mobile;
    private String when_required;
    private String rate;
    private String typeofrate;
    private String type;

    public Booking(String booking_id, String passenger_name, String passenger_mobile, String when_required, String typeofrate, String rate, String type) {
        this.booking_id = booking_id;
        this.passenger_name = passenger_name;
        this.passenger_mobile = passenger_mobile;
        this.when_required = when_required;
        this.rate = rate;
        this.typeofrate = typeofrate;
        this.type = type;
    }

    public String getBooking_id() {
        return booking_id;
    }

    public String getPassenger_name() {
        return passenger_name;
    }

    public String getPassenger_mobile() {
        return passenger_mobile;
    }

    public String getWhen_required() {
        return when_required;
    }

    public String getRate() {
        return rate;
    }


    public String getTypeofrate() {
        return typeofrate;
    }

    public String getType() {
        return type;
    }

}
