package com.kouchan.dyutpassenger.Interface.getBalance;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetBalancePresenterImpl implements IGetBalancePresnter,OnRequestListener {


    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IGetBalanceView getBalanceView;
    SessionManager sessionManager;
    Context context;

    public GetBalancePresenterImpl(IGetBalanceView getBalanceView, Context context) {

        this.sharedpreferences = Sharedpreferences.getUserDataObj(context);
        this.asyncInteractor = new AsyncInteractor(context);
        this.getBalanceView = getBalanceView;
        this.context=context;
        sessionManager=new SessionManager(context);
    }

    @Override
    public void getBalance(String mobileNo) {
        if(NetworkStatus.checkNetworkStatus(context)){
        //    asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_GETBALANCE, "https://bookarideworldwide.com/CAB2.V.1/paytmlib/getdyutbalance.php?mobile="+mobileNo+"&user_type="+sessionManager.getType());

            StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://bookarideworldwide.com/CAB2.V.1/paytmlib/getdyutbalance.php?mobile="+mobileNo+"&user_type="+"PASSENGER",
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                //                   loading.dismiss();
                                JSONObject jsonObj = new JSONObject(response);
                                boolean error = jsonObj.getBoolean("error");
                                if (!error) {
                                    getBalanceView.getBalanceSuccess(1,jsonObj.getString("dyut_account_balance"));
                                } else {
                                    getBalanceView.getBalanceError(1,jsonObj.getString("error_msg"));
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //          loading.dismiss();
                        }
                    });
            VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
        } else {
            Utils.showToast(context, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if(pid==AppConstants.TAG_ID_GETBALANCE){
        //    Utils.stopProgress(navHome);
            if(responseJson!=null){
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if(!error) {
                    getBalanceView.getBalanceSuccess(pid,jObj.getString("dyut_account_balance"));
                }
                else {
                    getBalanceView.getBalanceError(pid,jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(context);
        getBalanceView.getBalanceError(pid,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        Utils.stopProgress(context);
        getBalanceView.getBalanceError(pid,error);
    }
}
