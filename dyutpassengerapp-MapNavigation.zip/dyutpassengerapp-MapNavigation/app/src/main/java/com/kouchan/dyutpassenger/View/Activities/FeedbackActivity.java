package com.kouchan.dyutpassenger.View.Activities;

import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kouchan.dyutpassenger.Database.CurrentRide;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.VolleyJsonObjectRequest;
import com.kouchan.dyutpassenger.helper.LocaleHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class FeedbackActivity extends AppCompatActivity {


    RatingBar ratingBar;
    Button button14, button15, button16, button17, button18, button19, button20;
    EditText editText2,bonusAmount;
    ProgressDialog loading;
    SessionManager sessionManager;
    String name, passengermobile, rating, comment="", drivermobile,bonusAmt;
    HashMap<String, String> user = new HashMap<String, String>();

    float rating_float;

    TextView feedback_textView, thanks_for_riding_bookaride_textView,
            give_rating_textView, what_didnt_worked_textView;

    String languageCode;
    Resources resources;

    String Feedback, sendEmail;
    Toolbar mToolbar;
    ImageView feedbackBackImageView, feedbackHomeImageView;

    String type, booking_id;

    CurrentRide currentRide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        addListenerOnButtonClick();

        NotificationManager notificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
        notificationManager.cancelAll();

        sessionManager = new SessionManager(getApplicationContext());
        currentRide = new CurrentRide(getApplicationContext());

        user = sessionManager.getUserDetails();

        feedback_textView = (TextView) findViewById(R.id.feedback_textView);
        thanks_for_riding_bookaride_textView = (TextView) findViewById(R.id.thanks_for_riding_bookaride_textView);
        give_rating_textView = (TextView) findViewById(R.id.give_rating_textView);
        what_didnt_worked_textView = (TextView) findViewById(R.id.what_didnt_worked_textView);

        initializeViews();

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        type = sessionManager.getType();
        switch (type) {
            case "passenger":

                Feedback = Url.PASSENGER_API + "rating.php";
                passengermobile = user.get("mobile");
                drivermobile = getIntent().getStringExtra("drivermobile");
                booking_id = getIntent().getStringExtra("booking_id");

                currentRide.setDrivermobile(getIntent().getStringExtra("drivermobile"));
                currentRide.setFeedbackStatus("notgiven");
                currentRide.setRideid(getIntent().getStringExtra("booking_id"));

                currentRide.setSosStatus("off");

                break;

            case "driver":

                Feedback = Url.DRIVER_API + "driverRatingtoPassenger.php";




                button15.setText(resources.getString(R.string.behaviour));
                button16.setText(resources.getString(R.string.manners));
                button17.setText(resources.getString(R.string.friendliness));
                button18.setText(resources.getString(R.string.not_paid));
                button19.setText(resources.getString(R.string.aggressive));
                button20.setText(resources.getString(R.string.other));

                drivermobile = user.get("mobile");
                passengermobile = getIntent().getStringExtra("passengermobile");

              //  sendEmailToPassenger();

                currentRide.setFeedbackStatus("notgiven");
                break;

            case "both":

                Feedback = Url.PASSENGER_API + "driverRating.php";
                break;
        }


    }
    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        editText2.setHint(resources.getString(R.string.optional_comments));

        feedback_textView.setText(resources.getString(R.string.feedback));
        thanks_for_riding_bookaride_textView.setText(resources.getString(R.string.thanks_for_riding_bookaride));
        give_rating_textView.setText(resources.getString(R.string.give_rating));
        what_didnt_worked_textView.setText(resources.getString(R.string.what_didnt_worked));

        button14.setText(resources.getString(R.string.submit));

        button15.setText(resources.getString(R.string.arrival_time));
        button16.setText(resources.getString(R.string.professionalism));
        button17.setText(resources.getString(R.string.driving));
        button18.setText(resources.getString(R.string.trip_route));
        button19.setText(resources.getString(R.string.car_quality));
        button20.setText(resources.getString(R.string.other));
    }

    private void sendEmailToPassenger() {


        loading = ProgressDialog.show(this, getString(R.string.processing), getString(R.string.please_wait), false, false);
        sendEmail = "https://www.bookarideworldwide.com/CAB2.V.1/PHPMailer-master/email.php?booking_id="+getIntent().getStringExtra("id");
        VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.GET, sendEmail, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            loading.dismiss();
                            boolean error = response.getBoolean("error");
                            if (!error) {


                            } else {

                                String errorMsg = response.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                });
        // Adding request to volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public void addListenerOnButtonClick() {
        ratingBar = (RatingBar) findViewById(R.id.ratingBar);

        button14 = (Button) findViewById(R.id.button14);
        button15 = (Button) findViewById(R.id.button8);
        button16 = (Button) findViewById(R.id.button9);
        button17 = (Button) findViewById(R.id.button10);
        button18 = (Button) findViewById(R.id.button11);
        button19 = (Button) findViewById(R.id.button12);
        button20 = (Button) findViewById(R.id.button13);

        editText2 = (EditText) findViewById(R.id.editText2);
        bonusAmount = (EditText) findViewById(R.id.bonusAmount);

        //Performing action on Button Click
        button14.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                rating = String.valueOf(ratingBar.getRating());

                rating_float = ratingBar.getRating();

                comment = editText2.getText().toString();
                bonusAmt=bonusAmount.getText().toString();

                if (rating_float <= 2) {
                    if (comment.equals("")) {
                        Toast.makeText(FeedbackActivity.this, "Please tell us what goes wrong", Toast.LENGTH_SHORT).show();
                    } else {
                        driverComment();
                    }
                } else {
                    driverComment();
                }

                /*driverComment();*/
            }

        });

        button15.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                editText2.setText(resources.getString(R.string.came_late));

                if (type.equals("driver")) {

                    editText2.setText(resources.getString(R.string.not_good_behaviour));

                }
            }

        });

        button16.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                 editText2.setText(resources.getString(R.string.bad_professionalism));
                if (type.equals("driver")) {

                    editText2.setText(resources.getString(R.string.bad_manners));

                }
            }

        });

        button17.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                editText2.setText(resources.getString(R.string.bad_driving_skills));
                if (type.equals("driver")) {

                    editText2.setText(resources.getString(R.string.friendliness));

                }
            }

        });

        button18.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                 editText2.setText(resources.getString(R.string.wrong_route));
                if (type.equals("driver")) {

                    editText2.setText(resources.getString(R.string.not_paid));

                }
            }

        });

        button19.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                 editText2.setText(resources.getString(R.string.bad_car_quality));
                if (type.equals("driver")) {
                      editText2.setText(resources.getString(R.string.aggressive));

                }

            }

        });

        button20.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                 editText2.setText(resources.getString(R.string.other_reason));
                if (type.equals("driver")) {

                   editText2.setText(resources.getString(R.string.other_reason));

                }

            }

        });

    }


    private void driverComment() {

        comment = editText2.getText().toString();

        loading = ProgressDialog.show(this, getString(R.string.processing), getString(R.string.please_wait), false, false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Feedback,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {

                                if (type.equals("driver")) {

                                    SessionManager sessionManager = new SessionManager(getApplicationContext());
                                    sessionManager.setUpdateButton("started");
                                    startActivity(new Intent(FeedbackActivity.this, NavHome.class));
                                    currentRide.setIsRideStarted("end");
                                    currentRide.setFeedbackStatus("given");
                                    finish();
                                } else {
                                    Intent i = new Intent(FeedbackActivity.this, ThankYouPassengerActivity.class);
                                    i.putExtra("booking_id", booking_id);
                                    startActivity(i);
                                    currentRide.setFeedbackStatus("given");
                                    finish();
                                }

                            } else {

                                String errorMsg = jObj.getString("error_msg");
                                Toast.makeText(FeedbackActivity.this, errorMsg, Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("passengerMobile", passengermobile);
                params.put("driverMobile", drivermobile);
                params.put("rating", rating);
                params.put("comment", comment);
                params.put("bookingid",booking_id);

                if(bonusAmt==null || bonusAmt.equalsIgnoreCase("")){
                    params.put("bonus_amount","NA");
                }
                else{
                    params.put("bonus_amount",bonusAmt);
                }
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(FeedbackActivity.this, NavHome.class);
        startActivity(intent);
        finish();
    }

    private void initializeViews() {
        setSupportActionBar(mToolbar);

        feedbackBackImageView = (ImageView) findViewById(R.id.feedbackBackImageView);
        feedbackHomeImageView = (ImageView) findViewById(R.id.feedbackHomeImageView);

        feedbackBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FeedbackActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });

        feedbackHomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FeedbackActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
