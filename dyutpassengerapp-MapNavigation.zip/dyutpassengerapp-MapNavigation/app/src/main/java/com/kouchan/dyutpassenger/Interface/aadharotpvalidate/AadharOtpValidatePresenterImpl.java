package com.kouchan.dyutpassenger.Interface.aadharotpvalidate;

import com.google.gson.Gson;
import com.kouchan.dyutpassenger.View.Activities.AadharRegistrationActivity;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.models.aatharotp.ValidateAadharOtp;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class AadharOtpValidatePresenterImpl implements IAadharValidateOtpPresnter, OnRequestListener {

    AadharRegistrationActivity verifyOTP;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    ValidateAadharOtp validateAadharOtpModel;
    IAadharValidateOtpView aadharValidateOtpView;

    public AadharOtpValidatePresenterImpl(IAadharValidateOtpView aadharValidateOtpView) {
        this.verifyOTP = (AadharRegistrationActivity) aadharValidateOtpView;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(verifyOTP);
        this.asyncInteractor = new AsyncInteractor(verifyOTP);
        this.validateAadharOtpModel = validateAadharOtpModel;
        this.aadharValidateOtpView = aadharValidateOtpView;
    }

    @Override
    public void validateAadhatOtp(String mobile, String password, String adharnumber) {
        if (NetworkStatus.checkNetworkStatus(verifyOTP)) {
            Utils.showProgress(verifyOTP);
            Map<String, String> params = new HashMap<String, String>();
            params.put("mobile", mobile);
            params.put("password", password);
            params.put("adharno", adharnumber);

            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_VALIDATE_AADHAR_OTP, "https://bookarideworldwide.com/CAB2.V.1/passenger_api/m3aadharregistration.php", new JSONObject(params));
        } else {
            Utils.showToast(verifyOTP, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if (pid == AppConstants.TAG_ID_VALIDATE_AADHAR_OTP) {
            if (responseJson != null) {
                Gson gson = new Gson();

                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    aadharValidateOtpView.aadharOtpSuccess(pid, jObj.getString("next_step"));
                } else {
                    aadharValidateOtpView.aadharOtpError(pid, jObj.getString("error_msg"));
                }

            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {

        aadharValidateOtpView.aadharOtpError(pid, error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
