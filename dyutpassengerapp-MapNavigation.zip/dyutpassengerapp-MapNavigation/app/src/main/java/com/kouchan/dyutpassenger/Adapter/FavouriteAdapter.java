package com.kouchan.dyutpassenger.Adapter;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.models.FavoriteModel;
import com.kouchan.dyutpassenger.other.OttoSelectedFromFavorite;

import java.util.ArrayList;



public class FavouriteAdapter extends RecyclerView.Adapter<FavouriteAdapter.PlaceViewHolder> {

    Context mContext;
    ArrayList<FavoriteModel> listData;
    private int layout;
    private String status;
    CustomItemClickListener listener;

    public FavouriteAdapter(Context context,int resource, String where, ArrayList<FavoriteModel> data,CustomItemClickListener listener){
        this.mContext = context;
        listData = data;
        layout = resource;
        status = where;
        this.listener = listener;
    }

    @Override
    public PlaceViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View convertView = layoutInflater.inflate(layout, viewGroup, false);
        PlaceViewHolder mPredictionHolder = new PlaceViewHolder(convertView);
        return mPredictionHolder;
    }


    @Override
    public void onBindViewHolder(PlaceViewHolder mPredictionHolder, final int i) {
        mPredictionHolder.mAddress.setText(listData.get(i).getFavAddress());
        mPredictionHolder.mName.setText(listData.get(i).getFavType());
        mPredictionHolder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(v,listData.get(i).getId());
                listData.remove(listData.get(i));
                notifyDataSetChanged();
            }
        });
        mPredictionHolder.mParentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FavoriteModel favorite = listData.get(i);

                OttoSelectedFromFavorite ottoSelectedFromFavorite= new OttoSelectedFromFavorite( favorite.getFavAddress(),favorite.getLatitude(),
                        favorite.getLongitude(),status);
                EventBusManager.getInstance().getEventBus().post(ottoSelectedFromFavorite);
                ((Activity)mContext).finish();
            }
        });

    }

    @Override
    public int getItemCount() {
        if(listData != null)
            return listData.size();
        else
            return 0;
    }

    public class PlaceViewHolder extends RecyclerView.ViewHolder {
        //        CardView mCardView;
        public LinearLayout mParentLayout;
        public TextView mAddress;
        public TextView mName;
        public Button delete;

        public PlaceViewHolder(View itemView) {
            super(itemView);
            mParentLayout = (LinearLayout)itemView.findViewById(R.id.predictedRow);
            mAddress = (TextView)itemView.findViewById(R.id.address);
            mName = (TextView)itemView.findViewById(R.id.name);
            delete = (Button)itemView.findViewById(R.id.delete);
        }

    }

}
