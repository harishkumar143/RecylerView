package com.kouchan.dyutpassenger.View.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ChangePasswordActivity extends AppCompatActivity {


    EditText currentPassword, newPassword, confirmNewPassword;
    Button submit_button;
    String stringCurrentPassword, stringNewPassword, stringConfirmNewPassword, passengermobile, type;
    SessionManager sessionManager;
    HashMap<String, String> user;
    String driURL = "";
    Toolbar mToolbar;
    ImageView changepasswordBackImageView, changepasswordHomeImageView;

    TextView change_password_textView, changePasswordLabel;
    TextInputLayout currentPassword_TextInput, newPassword_TextInput, confirmNewPassword_TextInput;
    String languageCode;
    Resources resources;

    public AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);


        initializeWidget();
        /*sendValue();*/
        selection();

        change_password_textView = (TextView) findViewById(R.id.change_password_textView);
        changePasswordLabel = (TextView) findViewById(R.id.changePasswordLabel);
        currentPassword_TextInput = (TextInputLayout) findViewById(R.id.currentPassword_TextInput);
        newPassword_TextInput = (TextInputLayout) findViewById(R.id.newPassword_TextInput);
        confirmNewPassword_TextInput = (TextInputLayout) findViewById(R.id.confirmNewPassword_TextInput);

        submit_button = (Button) findViewById(R.id.changePasswordButton);
        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendValue();
                sendNotification();
            }
        });

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        change_password_textView.setText(resources.getString(R.string.change_password));
        changePasswordLabel.setText(resources.getString(R.string.change_password));

        currentPassword_TextInput.setHint(resources.getString(R.string.enter_current_password));
        newPassword_TextInput.setHint(resources.getString(R.string.enter_new_password));
        confirmNewPassword_TextInput.setHint(resources.getString(R.string.confirm_password));
    }

    private void selection() {
        driURL = Url.PASSENGER_API + "changePassword.php";

    }

    private void initializeWidget() {

        sessionManager = new SessionManager(getApplicationContext());

        currentPassword = (EditText) findViewById(R.id.currentPasswordId);
        newPassword = (EditText) findViewById(R.id.newPasswordId);
        confirmNewPassword = (EditText) findViewById(R.id.confirmNewPasswordId);

        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        changepasswordBackImageView = (ImageView) findViewById(R.id.changepasswordBackImageView);
        changepasswordHomeImageView = (ImageView) findViewById(R.id.changepasswordHomeImageView);


        changepasswordBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ChangePasswordActivity.this, SecurityAndSettingsActivity.class);
                startActivity(intent);
                finish();
            }
        });

        changepasswordHomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ChangePasswordActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        /*String regexPassword = ".{8,}";*/
        String regexPassword = ".{6,8}";
        awesomeValidation.addValidation(this, R.id.newPassword, regexPassword, R.string.passworderror);
       /* awesomeValidation.addValidation(this, R.id.currentPasswordId, regexPassword, R.string.passworderrorold);*/
        awesomeValidation.addValidation(this, R.id.confirmNewPasswordId, R.id.newPasswordId, R.string.invalid_confirm_password);

    }


    private void sendValue() {

        user = new HashMap<String, String>();
        user = sessionManager.getUserDetails();
        passengermobile = user.get("mobile");
        stringCurrentPassword = currentPassword.getText().toString();
        stringNewPassword = newPassword.getText().toString();
        stringConfirmNewPassword = confirmNewPassword.getText().toString();

    }

    public void sendNotification() {
        if (!(awesomeValidation.validate())) {

            //process the data further
        } else {

            final ProgressDialog loading = ProgressDialog.show(this,resources.getString(R.string.processing), resources.getString(R.string.please_wait), false, false);
            StringRequest stringRequestNotification = new StringRequest(Request.Method.POST, driURL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                loading.dismiss();

                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {

                                    String error_msg = jObj.getString("message");
                                    Toast.makeText(ChangePasswordActivity.this, error_msg, Toast.LENGTH_SHORT).show();
                                    Intent i=new Intent(ChangePasswordActivity.this,LoginActivity.class);
                                    startActivity(i);
                                    finish();

                                } else {

                                    String errorMsg = jObj.getString("error_msg");
                                    Toast.makeText(ChangePasswordActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            loading.dismiss();
                         }
                    }) {

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String, String> params = new HashMap<String, String>();

                    params.put("mobile", passengermobile);
                    params.put("oldpassword", stringCurrentPassword);
                    params.put("newpassword", stringNewPassword);

                    return params;
                }
            };
            VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequestNotification);
        }
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(ChangePasswordActivity.this, SecurityAndSettingsActivity.class);
        startActivity(intent);
        finish();
    }

}
