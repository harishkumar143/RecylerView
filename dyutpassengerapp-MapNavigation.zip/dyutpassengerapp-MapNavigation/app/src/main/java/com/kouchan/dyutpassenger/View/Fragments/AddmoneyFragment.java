package com.kouchan.dyutpassenger.View.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.getBalance.GetBalancePresenterImpl;
import com.kouchan.dyutpassenger.Interface.getBalance.IGetBalancePresnter;
import com.kouchan.dyutpassenger.Interface.getBalance.IGetBalanceView;
import com.kouchan.dyutpassenger.Interface.paytm.PaytmApiPresenter;
import com.kouchan.dyutpassenger.Interface.paytm.PaytmApiPresenterImpl;
import com.kouchan.dyutpassenger.Interface.paytm.PaytmApiView;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.VolleyJsonObjectRequest;
import com.kouchan.dyutpassenger.models.PaytmChecksumModel;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Utils;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddmoneyFragment extends Fragment implements PaytmApiView, PaytmPaymentTransactionCallback, IGetBalanceView {

    EditText amount;
    TextView currentBal;
    Button payButton;
    PaytmApiPresenter paytmApiPresenter;
    String merchantMId = "gkbcFz21013902347909";
    String merchantKey = "v1qGOra#katC@P#r";
    IGetBalancePresnter iGetBalancePresnter;
    long orderId;
    SessionManager sessionManager;
    View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.add_money_fragment, container, false);

        sessionManager = new SessionManager(getActivity());
        paytmApiPresenter = new PaytmApiPresenterImpl(this, getActivity());
        intailizeViews();
        return view;

    }

    private void intailizeViews() {

        currentBal = (TextView) view.findViewById(R.id.currentBal);
        amount = (EditText) view.findViewById(R.id.amount);
        payButton = (Button) view.findViewById(R.id.loadMoneyButton);

        iGetBalancePresnter = new GetBalancePresenterImpl(this, getActivity());

        HashMap<String, String> user = sessionManager.getUserDetails();
        iGetBalancePresnter.getBalance(user.get("mobile"));


        payButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Utils.showProgress(getActivity());

                orderId = Utils.uniqIdWithTimeStamp();

                paytmApiPresenter.paytmGenerateChecksum("" + orderId, sessionManager.getUniqueId(), amount.getText().toString());
            }
        });
    }

    @Override
    public void onTransactionResponse(Bundle inResponse) {
        Log.e("checksum ", " respon true " + inResponse.toString());
        Toast.makeText(getActivity(), inResponse.getString("RESPMSG"), Toast.LENGTH_SHORT).show();

        addMoneyToDyutApiCall(inResponse);
    }

    private void addMoneyToDyutApiCall(final Bundle inResponse) {

        if (NetworkStatus.checkNetworkStatus(getActivity())) {

            Map<String, String> params = new HashMap<String, String>();

            params.put("UNIQUE_ID", sessionManager.getUniqueId());
            params.put("STATUS", inResponse.getString("STATUS"));
            params.put("CHECKSUMHASH", inResponse.getString("CHECKSUMHASH"));
            params.put("BANKNAME", inResponse.getString("BANKNAME"));
            params.put("ORDERID", inResponse.getString("ORDERID"));
            params.put("TXNAMOUNT", inResponse.getString("TXNAMOUNT"));
            params.put("TXNDATE", inResponse.getString("TXNDATE"));
            params.put("MID", inResponse.getString("MID"));
            params.put("TXNID", inResponse.getString("TXNID"));
            params.put("RESPCODE", inResponse.getString("RESPCODE"));
            params.put("PAYMENTMODE", inResponse.getString("PAYMENTMODE"));
            params.put("BANKTXNID", inResponse.getString("BANKTXNID"));
            params.put("CURRENCY", inResponse.getString("CURRENCY"));
            params.put("GATEWAYNAME", inResponse.getString("GATEWAYNAME"));
            params.put("RESPMSG", inResponse.getString("RESPMSG"));

            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.POST, "https://bookarideworldwide.com/CAB2.V.1/paytmlib/addmoneytodyut.php", new JSONObject(params),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject responseJson) {
                            if (responseJson != null) {

                                boolean error = false;
                                try {
                                    error = responseJson.getBoolean("error");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                if (!error) {
                                    Toast.makeText(getActivity(), "Money added sucessfully", Toast.LENGTH_SHORT).show();
                                    HashMap<String, String> user = sessionManager.getUserDetails();
                                    iGetBalancePresnter.getBalance(user.get("mobile"));
                                } else {
                                    try {
                                        Toast.makeText(getActivity(), responseJson.getString("error_msg"), Toast.LENGTH_SHORT).show();
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            } else {
                                Toast.makeText(getActivity(), "Error", Toast.LENGTH_SHORT).show();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            try {
                                Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
            // Adding request to volley request queue
            RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
            requestQueue.add(stringRequest);
        } else {
            Utils.showToast(getActivity(), "Please connect to internet");
        }
    }

    @Override
    public void networkNotAvailable() {

    }

    @Override
    public void clientAuthenticationFailed(String inErrorMessage) {

    }

    @Override
    public void someUIErrorOccurred(String inErrorMessage) {
        Log.e("checksum ", " ui fail respon  " + inErrorMessage);
    }

    @Override
    public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {
        Log.e("checksum ", " error loading pagerespon true " + inErrorMessage + "  s1 " + inFailingUrl);
    }

    @Override
    public void onBackPressedCancelTransaction() {

    }

    @Override
    public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {

    }


    @Override
    public void checksumGenerationSucess(PaytmChecksumModel checksumModel) {

        Utils.stopProgress(getActivity());
        PaytmPGService Service = PaytmPGService.getStagingService();
        // when app is ready to publish use production service
        // PaytmPGService  Service = PaytmPGService.getProductionService();
        // now call paytm service here
        //below parameter map is required to construct PaytmOrder object, Merchant should replace below map values with his own values
        HashMap<String, String> paramMap = new HashMap<String, String>();
        //these are mandatory parameters
        paramMap.put("MID", checksumModel.getMERCHANTID()); //MID provided by paytm
        paramMap.put("ORDER_ID", checksumModel.getORDERID());
        paramMap.put("CUST_ID", sessionManager.getUniqueId());
        paramMap.put("CHANNEL_ID", checksumModel.getCHANNELID());
        paramMap.put("TXN_AMOUNT", amount.getText().toString());
        paramMap.put("WEBSITE", checksumModel.getWEBSITE());
        paramMap.put("CALLBACK_URL", checksumModel.getCALLBACKURL());
        //paramMap.put( "EMAIL" , "abc@gmail.com");   // no need
        //paramMap.put( "MOBILE_NO" , "7676060664");  // no need
        paramMap.put("CHECKSUMHASH", checksumModel.getCHECKSUMHASH());
        //  paramMap.put("PAYMENT_TYPE_ID" ,"CC");    // no need
        paramMap.put("INDUSTRY_TYPE_ID", checksumModel.getINDUSTRYTYPEID());

        PaytmOrder Order = new PaytmOrder(paramMap);
        Log.e("checksum ", "param " + paramMap.toString());

        Service.initialize(Order, null);
        // start payment service call here

        Service.startPaymentTransaction(getActivity(), true, true,
                this);
    }

    @Override
    public void checksumGenerationError(String error) {
        Utils.stopProgress(getActivity());
    }

    @Override
    public void getBalanceSuccess(int pid, String balance) {
        currentBal.setText("₹ " + balance);
    }

    @Override
    public void getBalanceError(int pid, String error) {

    }
}
