package com.kouchan.dyutpassenger.Interface.changedestination;

public interface IChangeDestinationView {

    void changeDestinationSuccess(int pid, String response);

    void changeDestinationError(int pid, String error);

}
