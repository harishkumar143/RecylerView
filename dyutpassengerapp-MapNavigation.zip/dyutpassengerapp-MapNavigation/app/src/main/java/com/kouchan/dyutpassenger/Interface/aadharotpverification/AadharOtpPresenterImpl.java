package com.kouchan.dyutpassenger.Interface.aadharotpverification;


import com.kouchan.dyutpassenger.View.Activities.AdharOTPValidationActivity;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.models.aatharotp.AadharOtpModel;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class AadharOtpPresenterImpl implements IAadharOtpPresnter, OnRequestListener {

    AdharOTPValidationActivity registrationPassengerDriverActivity;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    AadharOtpModel aadharOtpModel;
    IAadharOtpView iAadharOtpView;


    public AadharOtpPresenterImpl(IAadharOtpView iAadharOtpView) {
        this.registrationPassengerDriverActivity = (AdharOTPValidationActivity) iAadharOtpView;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(registrationPassengerDriverActivity);
        this.asyncInteractor = new AsyncInteractor(registrationPassengerDriverActivity);
        this.aadharOtpModel = aadharOtpModel;
        this.iAadharOtpView = iAadharOtpView;
    }

    @Override
    public void aadhatOtp(String aadharOTP, String mobile, String password) {
        if (NetworkStatus.checkNetworkStatus(registrationPassengerDriverActivity)) {
            Map<String, String> params = new HashMap<String, String>();
            params.put("mobile", mobile);
            params.put("password", password);
            params.put("adhar_otp", aadharOTP);

            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_AADHAR_OTP, "https://bookarideworldwide.com/CAB2.V.1/passenger_api/m3aadharotpverify.php", new JSONObject(params));
        } else {
            Utils.showToast(registrationPassengerDriverActivity, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {

        if (pid == AppConstants.TAG_ID_AADHAR_OTP) {
            if (responseJson != null) {
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if (!error) {
                    iAadharOtpView.aadharOtpSuccess(pid, jObj.getString("next_step"));
                } else {
                    iAadharOtpView.aadharOtpError(pid, jObj.getString("error_msg"));
                }


            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        iAadharOtpView.aadharOtpError(pid, error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }

}
