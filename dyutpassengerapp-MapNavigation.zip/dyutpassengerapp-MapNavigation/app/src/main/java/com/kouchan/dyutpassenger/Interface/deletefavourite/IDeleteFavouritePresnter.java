package com.kouchan.dyutpassenger.Interface.deletefavourite;

public interface IDeleteFavouritePresnter {

    void deleteFavourite(String id);

}
