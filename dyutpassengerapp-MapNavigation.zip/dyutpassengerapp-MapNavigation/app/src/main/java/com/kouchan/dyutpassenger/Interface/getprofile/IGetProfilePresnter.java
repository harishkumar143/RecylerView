package com.kouchan.dyutpassenger.Interface.getprofile;

public interface IGetProfilePresnter {

    void getProfile(String mobileNumber);

}
