package com.kouchan.dyutpassenger.Interface.m3withbookarideregistration;

public interface IRegisterPresenter {

    void registerValidation(String firstName, String email, String mobile, String password,String adharNumber);

}
