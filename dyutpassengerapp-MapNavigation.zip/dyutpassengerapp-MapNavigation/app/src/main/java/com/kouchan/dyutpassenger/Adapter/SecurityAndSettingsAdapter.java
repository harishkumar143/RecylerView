package com.kouchan.dyutpassenger.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.AutoBookRideActivity;
import com.kouchan.dyutpassenger.View.Activities.ChangePasswordActivity;
import com.kouchan.dyutpassenger.View.Activities.LanguageSelectionActivity;
import com.kouchan.dyutpassenger.View.Activities.WebViewActivity;
import com.kouchan.dyutpassenger.holders.SecurityAndSettingsViewHolder;


/**
 * Created by kouchan on 02-01-2017.
 */

public class SecurityAndSettingsAdapter extends RecyclerView.Adapter<SecurityAndSettingsViewHolder> {

    String[] values;
    private int[] imagesForSecurityAndSettings;
    Context mContext;
    LayoutInflater layoutInflater;

    String URL = "";
    String webview_titel = "";

    public SecurityAndSettingsAdapter(Context mContext, String[] securityAndSettingsArrayList, int[] imagesForSecurityAndSettings) {
        this.mContext = mContext;
        this.layoutInflater = LayoutInflater.from( mContext );
        this.values = securityAndSettingsArrayList;
        this.imagesForSecurityAndSettings = imagesForSecurityAndSettings;
    }


    @Override
    public SecurityAndSettingsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.d( "onCreateViewHolder", "onCreateViewHolder" );
        View v = layoutInflater.inflate( R.layout.item_security_and_settings_list, parent, false );
        SecurityAndSettingsViewHolder viewHolder = new SecurityAndSettingsViewHolder( v );
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(SecurityAndSettingsViewHolder holder, final int position) {
        /*Typeface typeface = Typeface.createFromAsset(mContext.getAssets(), "fonts/GeorgiaRegularfont.ttf");
        holder.mItemRowOfSecurityAndSettingsTextView.setTypeface(typeface);*/


        holder.mItemRowOfSecurityAndSettingsTextView.setText( values[position] );
        holder.mItemRowOfSecurityAndSettingsImageView.setImageDrawable( mContext.getResources().getDrawable( imagesForSecurityAndSettings[position] ) );


        holder.mItemRowOfSecurityAndSettingsLinearLayout.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                if (position == 0) {
                    intent = new Intent( mContext, ChangePasswordActivity.class );
                } else if (position == 1) {
                    intent = new Intent( mContext, LanguageSelectionActivity.class );
                } else if (position == 2) {
                    URL = "https://bookarideworldwide.com/CAB2.V.1/web/p_tnc.html";
                    webview_titel = "Terms & Conditions";
                    intent = new Intent( mContext, WebViewActivity.class );
                    intent.putExtra( "url", URL );
                    intent.putExtra( "action_bar_name", webview_titel );
                } else if (position == 3) {
                    webview_titel = "Privacy Policies";
                    URL = "https://bookarideworldwide.com/CAB2.V.1/web/p_privacy_policy.html";
                    intent = new Intent( mContext, WebViewActivity.class );
                    intent.putExtra( "url", URL );
                    intent.putExtra( "action_bar_name", webview_titel );
                } else if (position == 4) {
                    webview_titel = "Fraud Related Matters";
                    URL = "https://bookarideworldwide.com/CAB2.V.1/web/p_fraud_related.html";
                    intent = new Intent( mContext, WebViewActivity.class );
                    intent.putExtra( "url", URL );
                    intent.putExtra( "action_bar_name", webview_titel );
                }else if (position == 5) {
                    webview_titel = "Fraud Related Matters";
                    URL = "https://bookarideworldwide.com/CAB2.V.1/web/p_fraud_related.html";
                    intent = new Intent( mContext, AutoBookRideActivity.class );
                    intent.putExtra( "url", URL );
                    intent.putExtra( "action_bar_name", webview_titel );
                }
                mContext.startActivity( intent );
            }
        } );
    }

    @Override
    public int getItemCount() {
        return values.length;
    }
}
