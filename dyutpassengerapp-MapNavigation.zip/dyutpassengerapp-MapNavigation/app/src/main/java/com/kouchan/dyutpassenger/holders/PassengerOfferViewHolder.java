package com.kouchan.dyutpassenger.holders;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kouchan.dyutpassenger.R;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by KOUCHAN-ADMIN on 12/1/2017.
 */

public class PassengerOfferViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.itemRowOfPassengerOfferLinearLayout)
    public LinearLayout mItemRowOfPassengerOfferLinearLayout;

    @BindView(R.id.itemRowOfPassengerOfferPriceTextView)
    public TextView mItemRowOfPassengerOfferPriceTextView;

    @BindView(R.id.itemRowOfPassengerOfferToTextView)
    public TextView mItemRowOfPassengerOfferToTextView;

    @BindView(R.id.itemRowOfPassengerOfferTimeTextView)
    public TextView itemRowOfPassengerOfferTimeTextView;

    @BindView(R.id.itemRowOfPassengerOfferTimeText)
    public TextView itemRowOfPassengerOfferTimeText;

    @BindView(R.id.itemRowOfPassengerOfferPriceText)
    public TextView itemRowOfPassengerOfferPriceText;

    @BindView(R.id.acceptPassengerOffer)
    public Button acceptPassengerOffer;

    @BindView(R.id.expandPassengerOffer)
    public Button expandPassengerOffer;

    public PassengerOfferViewHolder(final View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);

    }

}
