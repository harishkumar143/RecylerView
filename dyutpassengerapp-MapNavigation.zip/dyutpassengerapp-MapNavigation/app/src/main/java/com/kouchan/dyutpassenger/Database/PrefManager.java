package com.kouchan.dyutpassenger.Database;


import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Lincoln on 05/05/16.
 */
public class PrefManager {


    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;

    // shared pref mode
    int PRIVATE_MODE = 0;

    // Shared preferences file name
    private static final String PREF_NAME = "androidhive-welcome";

    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";
    private static final String ADD_INFO = "AddInfo";
    private static final String SELECTION_SCREEN = "selectionScreen";
    private static final String KEY_IS_WAITING_FOR_SMS = "IsWaitingForSms";

    public PrefManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void setFirstTimeLaunch(boolean isFirstTime) {
        editor.putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTime);
        editor.commit();
    }

    public boolean isFirstTimeLaunch() {
        return pref.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

    public void setAddInfo(boolean isFirstTime) {
        editor.putBoolean(ADD_INFO, isFirstTime);
        editor.commit();
    }

    public boolean isAddInfo() {
        return pref.getBoolean(ADD_INFO, true);
    }

    public void setSelectionScreen(boolean isFirstTime) {
        editor.putBoolean(SELECTION_SCREEN, isFirstTime);
        editor.commit();
    }

    public boolean isSelectionScreen() {
        return pref.getBoolean(SELECTION_SCREEN, true);
    }


    public void setIsWaitingForSms(boolean isWaiting) {
        editor.putBoolean(KEY_IS_WAITING_FOR_SMS, isWaiting);
        editor.commit();
    }

    public boolean isWaitingForSms() {
        return pref.getBoolean(KEY_IS_WAITING_FOR_SMS, false);
    }
}