/*
package kouchan.siddhesh.com.BookARideAndroid.View.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kouchan.siddhesh.com.BookARideAndroid.Adapter.HistoryAdapter;
import kouchan.siddhesh.com.BookARideAndroid.Adapter.RecyclerTouchListener;
import kouchan.siddhesh.com.BookARideAndroid.Api.VolleySingleton;
import kouchan.siddhesh.com.BookARideAndroid.Database.SessionManager;
import kouchan.siddhesh.com.BookARideAndroid.Interface.Url;
import kouchan.siddhesh.com.BookARideAndroid.R;
import kouchan.siddhesh.com.BookARideAndroid.models.History;
import kouchan.siddhesh.com.BookARideAndroid.other.DividerItemDecoration;

public class HistoryActivity extends AppCompatActivity {

    private List<History> historyList = new ArrayList<>();
    private String TAG = MainActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private RecyclerView recyclerView;
    private HistoryAdapter mAdapter;
    HashMap<String, String> user;
    String passengermobile,type;
    String historyUrl= "";
    SessionManager sessionManager;

    Toolbar mToolbar;
    ImageView historyBackImageView, historyHomeImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
//        contactList = new ArrayList<>();

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view_history);



        mAdapter = new HistoryAdapter(historyList);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

       sessionManager=new SessionManager(getApplicationContext());

        user = new HashMap<String, String>();
        user=sessionManager.getUserDetails();

        passengermobile=user.get("mobile");

        type=sessionManager.getType();

        switch (type){
            case "passenger":

                historyUrl= Url.PASSENGER_API+"passengerHistory.php";
                break;

            case "driver":

                historyUrl= Url.DRIVER_API+"driverHistory.php";
                break;

            case "both":

                historyUrl= Url.DRIVER_API+"driverHistory.php";
                break;
        }
 History movie = new History("Mad Max: Fury Road", "Action & Adventure", "2015","sx","hj","ghhj");
        historyList.add(movie);

        mAdapter.notifyDataSetChanged();

        displayHistoy();

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                History history = historyList.get(position);

                Intent i=new Intent(getApplicationContext(),HistoryExpand.class);

                i.putExtra("booking_id",history.getId());

                startActivity(i);
                finish();


            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        initializeViews();

    }

    public void displayHistoy(){
        final ProgressDialog loading = ProgressDialog.show(this,"Finishing...","Please wait...",false,false);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, historyUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            if (!error) {


                            JSONArray contacts = jsonObj.getJSONArray("user");

                            for (int i = 0; i < contacts.length(); i++) {
                                JSONObject c = contacts.getJSONObject(i);

                                String id = c.getString("booking_id");
                                String paymenttype = c.getString("paymenttype");
                                String bookingtime = c.getString("bookingtime");
                                String ridestatus = c.getString("ridestatus");
                                String actualprice = c.getString("actualprice");
                                String vehicle = c.getString("vehicle");

                                History history=new History(id,paymenttype,bookingtime,vehicle,ridestatus,actualprice);
                                historyList.add(history);
                                mAdapter.notifyDataSetChanged();
                                // tmp hash map for single contact
           HashMap<String, String> contact = new HashMap<>();

                                // adding each child node to HashMap key => value

                                contact.put("id",id);
                                contact.put("paymenttype",paymenttype);
                                contact.put("bookingtime",bookingtime);
                                contact.put("ridestatus",ridestatus);
                                contact.put("actualprice",actualprice);
                                contact.put("vehicle",vehicle);



                                // adding contact to contact list
                            }
                            }else {
                                String errorMsg = jsonObj.getString("error_msg");
                            }
                   //         ListAdapter adapter = new SimpleAdapter(getApplicationContext(), contactList, R.layout.history_list_item, new String[]{"paymenttype", "bookingtime", "ridestatus","actualprice","vehicle"}, new int[]{R.id.paymenttype, R.id.bookingtime, R.id.ridestatus, R.id.actualprice, R.id.vehicle});
//
//                            lv.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {

                Map<String,String> params=new HashMap<String, String>();

                params.put("mobile",passengermobile);


                return params ;
            }
        };

        VolleySingleton.getInstance(HistoryActivity.this).addToRequestQueue(stringRequest);

    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(HistoryActivity.this, NavHome.class);
        startActivity(intent);
        finish();
    }
    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        historyBackImageView = (ImageView) findViewById(R.id.historyBackImageView);
        historyHomeImageView = (ImageView) findViewById(R.id.historyHomeImageView);

        historyBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HistoryActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });

        historyHomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HistoryActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });
    }


}
*/
