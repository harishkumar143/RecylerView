package com.kouchan.dyutpassenger.View.Activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.kouchan.dyutpassenger.R;


public class CounterReceiptActivity extends AppCompatActivity {

  String  bookingid,rate,toplac, typeofrate,fromplace;

    TextView bookidTextView,rateTextView,toplacTextView,typeofrateTextView,fromplaceTextView;
    Button close;

    ImageView counterReceiptBackImageView,counterReceiptHomeImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counter_receipt);

        bookidTextView=(TextView)findViewById(R.id.refNumber) ;

        rateTextView=(TextView)findViewById(R.id.Price) ;
        toplacTextView=(TextView)findViewById(R.id.toPlace) ;
        typeofrateTextView=(TextView)findViewById(R.id.ratType) ;
        fromplaceTextView=(TextView)findViewById(R.id.fromPlace) ;

        counterReceiptBackImageView=(ImageView)findViewById(R.id.counterReceiptBackImageView) ;
        close=(Button)findViewById(R.id.closeButton) ;


        bookidTextView.setText(bookingid=getIntent().getStringExtra("bookingid"));
        rateTextView.setText(rate=getIntent().getStringExtra("rate"));
        toplacTextView.setText(toplac=getIntent().getStringExtra("toplace"));
        typeofrateTextView.setText( typeofrate=getIntent().getStringExtra("typeofrate"));
        fromplaceTextView.setText( fromplace=getIntent().getStringExtra("fromplace"));

        close.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });

        counterReceiptBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();
            }
        });

    }


    @Override
    public void onBackPressed() {

        finish();
    }





}
