package com.kouchan.dyutpassenger.Interface.faq;

public interface IGetFAQPresnter {

    void getFAQ();

}

