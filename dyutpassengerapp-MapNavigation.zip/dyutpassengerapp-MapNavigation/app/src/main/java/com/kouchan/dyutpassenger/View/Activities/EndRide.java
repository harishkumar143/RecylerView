package com.kouchan.dyutpassenger.View.Activities;

import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.kouchan.dyutpassenger.Database.CurrentRide;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class EndRide extends AppCompatActivity {

    EditText actual_amount;
    Button yes, no;
    String paystatusfromdriver, paytype = "";
    ProgressDialog loading;
    RadioButton cash, m3;
    final String END_RIDE = Url.COMUNICATE_API + "actualPriceUpdate.php";
    public AwesomeValidation awesomeValidation;

    TextView select_payment_type_textView, coming_soon_textView, amount_paid_textView;
    String languageCode;
    Resources resources;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_ride);

        NotificationManager notificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
        notificationManager.cancelAll();

        cash = (RadioButton) findViewById(R.id.cash);
        m3 = (RadioButton) findViewById(R.id.m3);
        actual_amount = (EditText) findViewById(R.id.actual_amount);
        yes = (Button) findViewById(R.id.paid);
        no = (Button) findViewById(R.id.notpaid);

        select_payment_type_textView = (TextView) findViewById(R.id.select_payment_type_textView);
        coming_soon_textView = (TextView) findViewById(R.id.coming_soon_textView);
        amount_paid_textView = (TextView) findViewById(R.id.amount_paid_textView);

        actual_amount.setText(getIntent().getStringExtra("rate"));

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        awesomeValidation.addValidation(this, R.id.register_mobile, "^[1-9]$", R.string.paymenterror);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paystatusfromdriver = actual_amount.getText().toString();
                driverComment();
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paystatusfromdriver = "notpaid";
                driverComment();
            }
        });

        cash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paytype = "cash";

            }
        });

        m3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paytype = "m3";
            }
        });

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();

        cash.setText(resources.getString(R.string.cash));
        m3.setText(resources.getString(R.string.m3));
        yes.setText(resources.getString(R.string.paid));
        no.setText(resources.getString(R.string.not_paid));
        select_payment_type_textView.setText(resources.getString(R.string.select_payment_type));
        coming_soon_textView.setText(resources.getString(R.string.coming_soon));
        amount_paid_textView.setText(resources.getString(R.string.amount_paid));
    }

    private void driverComment() {
        if (paytype.equals("")) {


        } else if (!(awesomeValidation.validate())) {
        } else {


            loading = ProgressDialog.show(this,resources.getString(R.string.processing),resources.getString(R.string.please_wait), false, false);

            StringRequest stringRequest = new StringRequest(Request.Method.POST, END_RIDE,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                loading.dismiss();
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {
                                    // User successfully stored in MySQL
                                    Intent intent = new Intent(EndRide.this, FeedbackActivity.class);

                                    intent.putExtra("passengermobile", getIntent().getStringExtra("passengermobile"));

                                    intent.putExtra("id", getIntent().getStringExtra("ids"));


                                    SessionManager sessionManager = new SessionManager(getApplicationContext());
                                    sessionManager.setUpdateButton("started");
                                    CurrentRide currentRide = new CurrentRide(getApplicationContext());
                                    currentRide.setIsRideStarted("end");

                                    startActivity(intent);
                                    finish();


                                } else {

                                    // Error occurred in registration. Get the error
                                    // message
                                    String errorMsg = jObj.getString("error_msg");
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            loading.dismiss();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("actualprice", paystatusfromdriver);
                    params.put("id", getIntent().getStringExtra("ids"));
                    params.put("paytype", paytype);
                    return params;
                }

            };

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }
    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Utils.showToast(getApplicationContext(), resources.getString(R.string.please_submit_all_the_information));
    }

}
