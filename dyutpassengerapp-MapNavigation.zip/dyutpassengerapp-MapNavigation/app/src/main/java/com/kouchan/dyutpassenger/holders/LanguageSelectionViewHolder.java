package com.kouchan.dyutpassenger.holders;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kouchan.dyutpassenger.R;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by kouchan on 22-12-2016.
 */

public class LanguageSelectionViewHolder extends RecyclerView.ViewHolder {


    @BindView(R.id.itemRowOfLanguageSelectionListLinearLayout)
    public LinearLayout mItemRowOfLanguageSelectionLinearLayout;

    @BindView(R.id.languageNameInRespectiveTextView)
    public TextView mLanguageNameInRespectiveTextView;

    @BindView(R.id.languageNameTextView)
    public TextView mLanguageNameTextView;

    public LanguageSelectionViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }
}
