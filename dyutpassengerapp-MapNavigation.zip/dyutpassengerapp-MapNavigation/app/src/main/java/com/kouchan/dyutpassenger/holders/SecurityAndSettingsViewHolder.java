package com.kouchan.dyutpassenger.holders;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.kouchan.dyutpassenger.R;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by kouchan on 02-01-2017.
 */

public class SecurityAndSettingsViewHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.itemRowOfSecurityAndSettingsLinearLayout)
    public RelativeLayout mItemRowOfSecurityAndSettingsLinearLayout;

    @BindView(R.id.itemRowOfSecurityAndSettingsTextView)
    public TextView mItemRowOfSecurityAndSettingsTextView;

    @BindView(R.id.itemRowOfSecurityAndSettingsImageView)
    public ImageView mItemRowOfSecurityAndSettingsImageView;

    public SecurityAndSettingsViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }
}
