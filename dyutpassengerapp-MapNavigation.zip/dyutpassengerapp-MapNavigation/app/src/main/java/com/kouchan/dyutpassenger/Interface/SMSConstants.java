package com.kouchan.dyutpassenger.Interface;

public interface SMSConstants {
  String OTP_SMS_END_STRING = " is Your OTP to proceed on DYUT RIDES. Do not share your OTP to any one.";
}
