package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 10/20/2017.
 */

public class OttoEventActivityFinish {

    String finishActivity;

    public OttoEventActivityFinish(String finishActivity) {
        this.finishActivity = finishActivity;
    }

    public String getFinishActivity(){
        return finishActivity;
    }
}
