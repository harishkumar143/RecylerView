package com.kouchan.dyutpassenger.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;


public class Sharedpreferences {

  public static final String TAG_USER_ID = "userid";
  public static final String TAG_LANGUAGE= "language";
  public static final String TAG_ENCRIPTED_PASSWORD = "encrypted_password";
  public static final String TAG_OAUTH_TOKEN = "oauth_token";
  public static final String TAG_REFRESH_TOKEN = "refresh_token";


  private static final String PREF_NAME = "com.bmsils.tailtales";
  private static final String TAG_SPECIES_ARRAY_SIZE = "speciesSize";
  public static Editor editor;
  private static Sharedpreferences userData = null;
  Context context;
  private SharedPreferences pref; //added private
  private int PRIVATE_MODE = 0;
  private String TAG_TYPE_V_OR_G = "";


  public Sharedpreferences(Context c) {
    this.context = c;
    pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
    editor = pref.edit();
  }

  public static Sharedpreferences getUserDataObj(Context c) {
    if (userData == null) {
      userData = new Sharedpreferences(c);
    }
    return userData;
  }

  public static String getTagSpeciesArraySize() {
    return TAG_SPECIES_ARRAY_SIZE;
  }

  public void clearAll(Context c) {
    this.context = c;
    pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
    editor = pref.edit();
    pref.edit().clear().commit();
  }



  public String getTagTypeVOrG() {
    return pref.getString(TAG_TYPE_V_OR_G, "");
  }

  public void setTagTypeVOrG(String vorg) {
    try {
      editor.putString(TAG_TYPE_V_OR_G, vorg);
      editor.commit();
    } catch (Exception e) {
    }
  }


  public long getUserId() {
    return pref.getLong(TAG_USER_ID, 0);
  }

  public void setUserId(Long userid) {
    try {
      editor.putLong(TAG_USER_ID, userid);
      editor.commit();
    } catch (Exception e) {
    }
  }

  public String getLanguage() {
    return pref.getString(TAG_LANGUAGE, "");
  }

  public void setLanguage(String language) {
    try {
      editor.putString(TAG_LANGUAGE, language);
      editor.commit();
    } catch (Exception e) {
    }
  }

  public String getOauthToken() {
    return pref.getString(TAG_OAUTH_TOKEN, "");
  }

  public void setOauthToken(String oauthToken) {
    try {
      editor.putString(TAG_OAUTH_TOKEN, oauthToken);
      editor.commit();
    } catch (Exception e) {
    }
  }

  public String getRefreshToken() {
    return pref.getString(TAG_REFRESH_TOKEN, "");
  }

  public void setRefreshTokenToken(String refeOauthToken) {
    try {
      editor.putString(TAG_REFRESH_TOKEN, refeOauthToken);
      editor.commit();
    } catch (Exception e) {
    }
  }




  public String getEncriptedPassword(){
    return pref.getString(TAG_ENCRIPTED_PASSWORD,"");
  }

  public void setEncriptedPassword(String encriptedPassword){
    try {
      editor.putString(TAG_ENCRIPTED_PASSWORD, encriptedPassword);
      editor.commit();

    } catch (Exception e) {
    }
  }

  public void setSpeciesArraySize(int speciesArraySize) {
    try {
      editor.putInt(TAG_SPECIES_ARRAY_SIZE, speciesArraySize);
      editor.commit();
    } catch (Exception e) {
    }
  }

}

