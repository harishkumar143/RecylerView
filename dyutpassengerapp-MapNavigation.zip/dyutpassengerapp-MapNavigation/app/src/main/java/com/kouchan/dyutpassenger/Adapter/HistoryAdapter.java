package com.kouchan.dyutpassenger.Adapter;

/**
 * Created by KOUCHAN-ADMIN on 9/13/2017.
 */

import android.content.Context;
import android.content.res.Resources;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.History;

import java.util.List;



public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.MyViewHolder> {

    private List<History> historyList;

    String languageCode;
    Resources resources;
    SessionManager sessionManager;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView month_history, year_history, toatal_rides_history, total_fair, rides_completed_textView;

        public MyViewHolder(View view) {
            super(view);
            month_history = (TextView) view.findViewById(R.id.month_history);
            year_history = (TextView) view.findViewById(R.id.year_history);
            toatal_rides_history = (TextView) view.findViewById(R.id.toatal_rides_history);
            total_fair = (TextView) view.findViewById(R.id.total_fair);
            /*vehicle = (TextView) view.findViewById(R.id.vehicle);*/
            rides_completed_textView = (TextView) view.findViewById(R.id.rides_completed_textView);
        }
    }


    public HistoryAdapter(List<History> historyList,Context context) {
        this.historyList = historyList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.history_list_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        History history = historyList.get(position);

        holder.month_history.setText(history.getMonth());
        holder.year_history.setText(" "+history.getYear());
        holder.toatal_rides_history.setText(" "+history.getTotal_no_of_rides());
        holder.total_fair.setText(" "+history.getTotal_fare());

        sessionManager = new SessionManager(context);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();

            Context contexta = LocaleHelper.setLocale(context, languageCode);
            resources = contexta.getResources();
            holder.rides_completed_textView.setText(resources.getString(R.string.rides_completed));
        }
    }

    @Override
    public int getItemCount() {
        return historyList.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
}