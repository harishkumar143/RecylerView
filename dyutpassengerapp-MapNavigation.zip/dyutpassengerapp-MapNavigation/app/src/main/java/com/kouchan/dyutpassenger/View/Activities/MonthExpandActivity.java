package com.kouchan.dyutpassenger.View.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kouchan.dyutpassenger.Adapter.DateWiseRideDetailsAdapter;
import com.kouchan.dyutpassenger.Adapter.RecyclerTouchListener;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.MonthExpand;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MonthExpandActivity extends AppCompatActivity {


    private List<MonthExpand> monthExpandList = new ArrayList<>();
    private String TAG = SplashActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private RecyclerView recyclerView;
    private DateWiseRideDetailsAdapter mAdapter;
    HashMap<String, String> user;
    String passengermobile,type;
    String historyUrl= "";
    SessionManager sessionManager;

    TextView monthly_ride_details_textView;
    String languageCode;
    Resources resources;

    Toolbar mToolbar;
    ImageView month_Expand_BackImageView, month_Expand_HomeImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_month_expand);

        recyclerView = (RecyclerView)findViewById(R.id.recycler_view_history_month_expand);

        mAdapter = new DateWiseRideDetailsAdapter(monthExpandList,getApplicationContext());
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(mAdapter);

        monthly_ride_details_textView = (TextView) findViewById(R.id.monthly_ride_details_textView);

        sessionManager=new SessionManager(getApplicationContext());

        user = new HashMap<String, String>();
        user=sessionManager.getUserDetails();

        passengermobile=user.get("mobile");

        type=sessionManager.getType();

        initializeViews();

        /*switch (type){
            case "passenger":*/

        historyUrl= Url.PASSENGER_API+"passengerHistoryByMonthDetails.php";
                /*break;

            case "driver":

                historyUrl= Url.DRIVER_API+"driverHistoryByMonthDetails.php";
                break;

            case "both":

                historyUrl= Url.DRIVER_API+"driverHistoryByMonthDetails.php";
                break;
        }*/

        displayHistoyCancel();

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                MonthExpand monthExpand = monthExpandList.get(position);

                Intent i=new Intent(getApplicationContext(),DateExpandActivity.class);
                i.putExtra("date",monthExpand.getDate());
                startActivity(i);

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        monthly_ride_details_textView.setText(resources.getString(R.string.monthly_ride_details));
    }


    public void displayHistoyCancel(){
        // final ProgressDialog loading = ProgressDialog.show(getApplicationContext(),resources.getString(R.string.processing),resources.getString(R.string.please_wait),false,false);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, historyUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
         //                   loading.dismiss();
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            if (!error) {


                                JSONArray contacts = jsonObj.getJSONArray("user");

                                for (int i = 0; i < contacts.length(); i++) {
                                    JSONObject c = contacts.getJSONObject(i);

                                    String date = c.getString("date");
                                    int vehicle = c.getInt("total_no_of_rides");
                                    String total_fare = c.getString("total_fare");

                                    MonthExpand cancel=new MonthExpand(date,Integer.toString(vehicle),total_fare);
                                    monthExpandList.add(cancel);
                                    mAdapter.notifyDataSetChanged();
                                    // tmp hash map for single contact

                                }
                            }else {
                                String errorMsg = jsonObj.getString("error_msg");
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
              //          loading.dismiss();
                    }
                }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {

                Map<String,String> params=new HashMap<String, String>();

                params.put("mobile",passengermobile);
                params.put("month",getIntent().getStringExtra("month"));
                params.put("year",getIntent().getStringExtra("year"));

                return params;
            }
        };

        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);

    }


    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        month_Expand_BackImageView  = (ImageView) findViewById(R.id.month_Expand_BackImageView);
        month_Expand_HomeImageView = (ImageView) findViewById(R.id.month_Expand_HomeImageView);

        month_Expand_BackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               onBackPressed();
            }
        });

        month_Expand_HomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MonthExpandActivity.this, NavHome.class);
                startActivity(intent);
                finish();

            }
        });
    }
}
