package com.kouchan.dyutpassenger.Interface.payment;

public interface IPaymentPresnter {

    void payment(String bookingId,String paymentMode);

}
