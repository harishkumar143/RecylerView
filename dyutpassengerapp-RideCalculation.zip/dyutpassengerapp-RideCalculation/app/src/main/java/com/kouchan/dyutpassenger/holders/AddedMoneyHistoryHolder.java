package com.kouchan.dyutpassenger.holders;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.kouchan.dyutpassenger.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AddedMoneyHistoryHolder extends RecyclerView.ViewHolder {

    @BindView(R.id.trnsType)
    public TextView trnsType;

    @BindView(R.id.dateTime)
    public TextView dateTime;

    @BindView(R.id.txnId)
    public TextView txnId;

    @BindView(R.id.amount)
    public TextView amount;

    public AddedMoneyHistoryHolder(@NonNull View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }
}
