package com.kouchan.dyutpassenger.models;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by siddhesh on 4/20/17.
 */
public class OttoEventDriverList {
    String typeofmeter;
    String extraLessValue;
    String metervalue;
    String otp;
    String drivermobile;
    String prise;
    String bookingid;
    String vehicle;
    String rating;
    String whenrequiredtype;
    String myoffer;
    private String service_tax_val;
    private String service_charge_val;
    private String final_amount_val;
    private String myoffer_service_charge;
    private String myoffer_gst;
    private String vehicle_model;
    private String vehicle_sub_type;


    public OttoEventDriverList(String otp, String prise, String drivermobile, String bookingid, String vehicle, String rating,
                               String metervalue, String extraLessValue, String typeofmeter, String whenrequiredtype, String myoffer
            , String service_tax_val, String service_charge_val, String final_amount_val, String myoffer_service_charge,String myoffer_gst, String vehicle_model,String vehicle_sub_type) {
        this.otp = otp;
        this.prise = prise;
        this.drivermobile = drivermobile;
        this.bookingid = bookingid;
        this.vehicle = vehicle;
        this.rating = rating;
        this.myoffer_service_charge=myoffer_service_charge;
        this.myoffer_gst=myoffer_gst;
        this.metervalue = metervalue;
        this.typeofmeter = typeofmeter;
        this.extraLessValue = extraLessValue;

        this.whenrequiredtype = whenrequiredtype;
        this.myoffer = myoffer;

        this.service_tax_val = service_tax_val;
        this.service_charge_val = service_charge_val;
        this.final_amount_val = final_amount_val;
        this.vehicle_model = vehicle_model;
        this.vehicle_sub_type=vehicle_sub_type;

    }

    public List getOtp() {
        List<String> list = new ArrayList<String>();
        list.add(otp);
        list.add(drivermobile);
        list.add(prise);
        list.add(bookingid);
        list.add(vehicle);
        list.add(rating);
        list.add(metervalue);
        list.add(extraLessValue);
        list.add(typeofmeter);
        list.add(whenrequiredtype);
        list.add(myoffer);

        list.add(service_tax_val);
        list.add(service_charge_val);
        list.add(final_amount_val);
        list.add(myoffer_service_charge);
        list.add(myoffer_gst);
        list.add(vehicle_model);
        list.add(vehicle_sub_type);

        return list;
    }
}


