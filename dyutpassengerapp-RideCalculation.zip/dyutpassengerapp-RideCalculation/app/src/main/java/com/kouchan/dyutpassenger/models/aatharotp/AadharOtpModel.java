package com.kouchan.dyutpassenger.models.aatharotp;

public class AadharOtpModel {

    /**
     * status : null
     * otpTransactionID : 123456
     */

    private Object status;
    private String otpTransactionID;

    public Object getStatus() {
        return status;
    }

    public void setStatus(Object status) {
        this.status = status;
    }

    public String getOtpTransactionID() {
        return otpTransactionID;
    }

    public void setOtpTransactionID(String otpTransactionID) {
        this.otpTransactionID = otpTransactionID;
    }
}
