package com.kouchan.dyutpassenger.Interface.changedestination;

import com.kouchan.dyutpassenger.View.Activities.NavHome;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;


public class ChangeDestinationPresenterImpl implements IChangeDestinationPresnter,OnRequestListener {

    NavHome navHome;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    IChangeDestinationView deleteFavouriteView;

    public ChangeDestinationPresenterImpl(IChangeDestinationView deleteFavouriteView) {
        this.navHome =(NavHome) deleteFavouriteView;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(navHome);
        this.asyncInteractor = new AsyncInteractor(navHome);
        this.deleteFavouriteView = deleteFavouriteView;
    }

    @Override
    public void changeDestination(String bookingid,String current_place,String new_destination_name,
                                  String current_placelatitude,String current_placelongitude
            ,String new_destinationlatitude,String new_destinationlongitude) {
        if(NetworkStatus.checkNetworkStatus(navHome)){
            Utils.showProgress(navHome);
            HashMap<String, String> param = new HashMap<>();
            param.put("bookingid",bookingid);
            param.put("current_place",current_place);
            param.put("new_destination_name",new_destination_name);
            param.put("current_placelatitude",current_placelatitude);
            param.put("current_placelongitude",current_placelongitude);
            param.put("new_destinationlatitude",new_destinationlatitude);
            param.put("new_destinationlongitude",new_destinationlongitude);
            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_CHANGEDESTINATION, "https://bookarideworldwide.com/CAB2.V.1/comunicate_api/destinationchange.php",new JSONObject(param));
        } else {
            Utils.showToast(navHome, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if(pid==AppConstants.TAG_ID_CHANGEDESTINATION){
            Utils.stopProgress(navHome);
            if(responseJson!=null){
                JSONObject jObj = new JSONObject(responseJson);
                boolean error = jObj.getBoolean("error");
                if(!error) {
                    deleteFavouriteView.changeDestinationSuccess(pid,jObj.getString("message"));
                }
                else {
                    deleteFavouriteView.changeDestinationError(pid,jObj.getString("error_msg"));
                }
            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(navHome);
        deleteFavouriteView.changeDestinationError(pid,error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        Utils.stopProgress(navHome);
        deleteFavouriteView.changeDestinationError(pid,error);
    }
}
