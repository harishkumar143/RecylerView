package com.kouchan.dyutpassenger.View.Activities;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.utils.Utils;


public class ContactUsActivity extends AppCompatActivity implements View.OnClickListener {

    Toolbar mToolbar;
    ImageView about_usBackImageView, about_usHomeImageView;

    TextView about_us_textView;
    String languageCode;
    Resources resources;
    SessionManager sessionManager;
    LinearLayout submitYourQueryButton,callToUsButton,trackComplentButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        this.setTitle(getString(R.string.nav_about_us));

        about_us_textView = (TextView) findViewById(R.id.about_us_textView);
        callToUsButton = (LinearLayout) findViewById(R.id.callToUsButton);
        submitYourQueryButton = (LinearLayout) findViewById(R.id.submitYourQueryButton);
        trackComplentButton = (LinearLayout) findViewById(R.id.trackComplentButton);

        submitYourQueryButton.setOnClickListener(this);
        callToUsButton.setOnClickListener(this);
        trackComplentButton.setOnClickListener(this);

        initializeViews();

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }
    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        about_us_textView.setText(resources.getString(R.string.nav_about_us));
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(ContactUsActivity.this, NavHome.class);
        startActivity(intent);
        finish();
    }

    private void initializeViews() {

        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        about_usBackImageView = (ImageView) findViewById(R.id.nav_about_usBackImageView);
        about_usHomeImageView = (ImageView) findViewById(R.id.nav_about_usHomeImageView);

        about_usBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ContactUsActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.submitYourQueryButton:
                Intent i=new Intent(this,MailQueryActivity.class);
                startActivity(i);
                break;

            case R.id.callToUsButton:
                makeCall("+919036008829");
                break;

            case R.id.trackComplentButton:
                Intent intent=new Intent(this,TrackComplentActivity.class);
                startActivity(intent);
                break;
        }
    }

    private void makeCall(String num) {
        if (Utils.checkPermission(this, Manifest.permission.CALL_PHONE)) {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + num));
            startActivity(callIntent);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission
                    .CALL_PHONE}, 0);
        }
    }
}
