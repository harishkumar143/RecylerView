package com.kouchan.dyutpassenger.Database;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by KOUCHAN-ADMIN on 1/7/2018.
 */

public class CurrentRide {

    SharedPreferences bookARideSessionForCurrentRide;
    Context context;
    SharedPreferences.Editor edit;
    int PRIVATE_MODE = 0;
    private static final String SESSION_NAME = "BOOKARIDESESSIONFORCURRENTRIDE";


    private static final String KESY_STAGEOFRIDE = "KESY_STAGEOFRIDE";

    private static final String KESY_DRIVERNAME = "KESY_DRIVERNAME";

    private static final String KESY_DRIVERMOBILE = "KESY_DRIVERMOBILE";

    private static final String KESY_PASSENGERNAME = "KESY_PASSENGERNAME";

    private static final String KESY_PASSENGERMOBILE = "KESY_PASSENGERMOBILE";

    private static final String KESY_VEHICLE = "KESY_VEHICLE";

    private static final String KESY_WHENREQUIRED = "KESY_WHENREQUIRED";

    private static final String KESY_WHENREQUIREDTYPE = "KESY_WHENREQUIREDTYPE";

    private static final String KESY_TYPEOFRATE = "KESY_TYPEOFRATE";

    private static final String KESY_RATE = "KESY_RATE";

    private static final String KESY_FROM = "KESY_FROM";

    private static final String KESY_TO = "KESY_TO";

    private static final String KESY_FROMLATITUDE = "KESY_FROMLATITUDE";

    private static final String KESY_FROMLANGITUDE = "KESY_FROMLANGITUDE";

    private static final String KESY_TOLATITUDE = "KESY_TOLATITUDE";

    private static final String KESY_TOLONGITUDE = "KESY_TOLONGITUDE";

    private static final String KESY_RIDEID = "KESY_RIDEID";

    private static final String KESY_MESSAGE = "KESY_MESSAGE";

    private static final String KESY_ISRIDESTARTED = "KESY_ISRIDESTARTED";

    private static final String KESY_DISTANCE = "KESY_DISTANCE";

    private static final String KESY_TIME = "KESY_TIME";

    private static final String KESY_TOKENSTATUS = "KESY_TOKENSTATUS";

    private static final String KESY_FEEDBACKSTATUS = "KESY_FEEDBACKSTATUS";

    private static final String KESY_PAYMENTSTATUS = "KESY_PAYMENTSTATUS";

    private static final String KESY_SOSSTATUS = "KESY_SOSSTATUS";

    public CurrentRide(Context context) {
        this.context = context;
        bookARideSessionForCurrentRide = this.context.getSharedPreferences(SESSION_NAME, PRIVATE_MODE);
        edit = bookARideSessionForCurrentRide.edit();
    }

    public void setStage(String stage) {
        edit.putString(KESY_STAGEOFRIDE, stage);
        edit.commit();
    }

    public void setDrivername(String drivername) {
        edit.putString(KESY_DRIVERNAME, drivername);
        edit.commit();
    }

    public void setDrivermobile(String drivermobile) {
        edit.putString(KESY_DRIVERMOBILE, drivermobile);
        edit.commit();
    }

    public void setPassengername(String passengername) {
        edit.putString(KESY_PASSENGERNAME, passengername);
        edit.commit();
    }

    public void setPassengermobile(String passengermobile) {
        edit.putString(KESY_PASSENGERMOBILE, passengermobile);
        edit.commit();
    }

    public void setVehicle(String vehicle) {
        edit.putString(KESY_VEHICLE, vehicle);
        edit.commit();
    }

    public void setWhenrequired(String whenrequired) {
        edit.putString(KESY_WHENREQUIRED, whenrequired);
        edit.commit();
    }

    public void setWhenrequiredtype(String whenrequiredtype) {
        edit.putString(KESY_WHENREQUIREDTYPE, whenrequiredtype);
        edit.commit();
    }

    public void setTypeofrate(String typeofrate) {
        edit.putString(KESY_TYPEOFRATE, typeofrate);
        edit.commit();
    }

    public void setRate(String rate) {
        edit.putString(KESY_RATE, rate);
        edit.commit();
    }

    public void setFrom(String from) {
        edit.putString(KESY_FROM, from);
        edit.commit();
    }

    public void setTo(String to) {
        edit.putString(KESY_TO, to);
        edit.commit();
    }

    public void setFromlatitude(String fromlatitude) {
        edit.putString(KESY_FROMLATITUDE, fromlatitude);
        edit.commit();
    }

    public void setFromlongitude(String fromlongitude) {
        edit.putString(KESY_FROMLANGITUDE, fromlongitude);
        edit.commit();
    }

    public void setTolatitude(String tolatitude) {
        edit.putString(KESY_TOLATITUDE, tolatitude);
        edit.commit();
    }

    public void setTolongitude(String tolongitude) {
        edit.putString(KESY_TOLONGITUDE, tolongitude);
        edit.commit();
    }

    public void setRideid(String rideid) {
        edit.putString(KESY_RIDEID, rideid);
        edit.commit();
    }

    public void setMessage(String message) {
        edit.putString(KESY_MESSAGE, message);
        edit.commit();
    }

    public void setIsRideStarted(String message) {
        edit.putString(KESY_ISRIDESTARTED, message);
        edit.commit();
    }

    public void setDistanceInKm(String distanceInKm) {
        edit.putString(KESY_DISTANCE, distanceInKm);
        edit.commit();
    }

    public void setTime(String time) {
        edit.putString(KESY_TIME, time);
        edit.commit();
    }

    public void setTokenStatus(String token) {
        edit.putString(KESY_TOKENSTATUS, token);
        edit.commit();
    }

    public void setFeedbackStatus(String feedback) {
        edit.putString(KESY_FEEDBACKSTATUS, feedback);
        edit.commit();
    }

    public void setPaymentStatus(String payment) {
        edit.putString(KESY_PAYMENTSTATUS, payment);
        edit.commit();
    }

    public void setSosStatus(String status) {
        edit.putString(KESY_SOSSTATUS, status);
        edit.commit();
    }
    /*------------------------------------------------------------------------------------------*/


    public String getStage() {
        String stage = bookARideSessionForCurrentRide.getString(KESY_STAGEOFRIDE, null);
        return stage;
    }

    public String getDrivername() {
        String drivername = bookARideSessionForCurrentRide.getString(KESY_DRIVERNAME, null);
        return drivername;
    }

    public String getDrivermobile() {
        String drivermobile = bookARideSessionForCurrentRide.getString(KESY_DRIVERMOBILE, null);
        return drivermobile;
    }

    public String getPassengername() {
        String passengername = bookARideSessionForCurrentRide.getString(KESY_PASSENGERNAME, null);
        return passengername;
    }

    public String getPassengermobile() {
        String passengermobile = bookARideSessionForCurrentRide.getString(KESY_PASSENGERMOBILE, null);
        return passengermobile;
    }

    public String getVehicle() {
        String vehicle = bookARideSessionForCurrentRide.getString(KESY_VEHICLE, null);
        return vehicle;
    }

    public String getWhenrequired() {
        String whenrequired = bookARideSessionForCurrentRide.getString(KESY_WHENREQUIRED, null);
        return whenrequired;
    }

    public String getWhenrequiredtype() {
        String whenrequiredtype = bookARideSessionForCurrentRide.getString(KESY_WHENREQUIREDTYPE, null);
        return whenrequiredtype;
    }

    public String getTypeofrate() {
        String typeofrate = bookARideSessionForCurrentRide.getString(KESY_TYPEOFRATE, null);
        return typeofrate;
    }

    public String getRate() {
        String rate = bookARideSessionForCurrentRide.getString(KESY_RATE, null);
        return rate;
    }

    public String getFrom() {
        String from = bookARideSessionForCurrentRide.getString(KESY_FROM, null);
        return from;
    }

    public String getTo() {
        String to = bookARideSessionForCurrentRide.getString(KESY_TO, null);
        return to;
    }

    public String getFromlatitude() {
        String fromlatitude = bookARideSessionForCurrentRide.getString(KESY_FROMLATITUDE, null);
        return fromlatitude;
    }

    public String getFromlongitude() {
        String fromlongitude = bookARideSessionForCurrentRide.getString(KESY_FROMLANGITUDE, null);
        return fromlongitude;
    }

    public String getTolatitude() {
        String tolatitude = bookARideSessionForCurrentRide.getString(KESY_TOLATITUDE, null);
        return tolatitude;
    }

    public String getTolongitude() {
        String tolongitude = bookARideSessionForCurrentRide.getString(KESY_TOLATITUDE, null);
        return tolongitude;
    }

    public String getRideid() {
        String rideid = bookARideSessionForCurrentRide.getString(KESY_RIDEID, null);
        return rideid;
    }

    public String getMessage() {
        String message = bookARideSessionForCurrentRide.getString(KESY_MESSAGE, null);
        return message;
    }

    public String getIsridestarted() {
        String status = bookARideSessionForCurrentRide.getString(KESY_ISRIDESTARTED, "end");
        return status;
    }


    public String getDistanceInKm() {
        String distance = bookARideSessionForCurrentRide.getString(KESY_DISTANCE, null);
        return distance;
    }

    public String getTime() {
        String time = bookARideSessionForCurrentRide.getString(KESY_TIME, null);
        return time;
    }

    public String getTokenstatus() {
        String token = bookARideSessionForCurrentRide.getString(KESY_TOKENSTATUS, null);
        return token;
    }

    public String getFeedback() {
        String status = bookARideSessionForCurrentRide.getString(KESY_FEEDBACKSTATUS, "given");
        return status;
    }


    public String getPaymentstatus() {
        String status = bookARideSessionForCurrentRide.getString(KESY_PAYMENTSTATUS, "paid");
        return status;
    }

    public String getSosstatus() {
        String status = bookARideSessionForCurrentRide.getString(KESY_SOSSTATUS, "off");
        return status;
    }
    /*-------------------------------------passenger side setters------------------------------------------------------*/


}
