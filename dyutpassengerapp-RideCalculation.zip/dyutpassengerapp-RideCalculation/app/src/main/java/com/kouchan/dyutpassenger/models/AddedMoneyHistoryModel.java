package com.kouchan.dyutpassenger.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class AddedMoneyHistoryModel {

    /**
     * TXN_RECORDS : [{"id":"611","txt_status":"SUCCESS","transaction_id":"DYUTDBT20190326113203","types":"RIDE FARE","booking_id":"3466","txn_amount":"58.17","txn_type":"DEBITED","paymentgateway":"DYUT","paymentmode":"DYUT","created_at":"2019-03-26 11:32:03"},{"id":"458","txt_status":"SUCCESS","transaction_id":"DYUTDBT20190323024812","types":"RIDE FARE","booking_id":"3333","txn_amount":"125.08","txn_type":"DEBITED","paymentgateway":"DYUT","paymentmode":"DYUT","created_at":"2019-03-23 14:48:12"},{"id":"453","txt_status":"SUCCESS","transaction_id":"DYUTDBT20190323015935","types":"RIDE FARE","booking_id":"3327","txn_amount":"63.13","txn_type":"DEBITED","paymentgateway":"DYUT","paymentmode":"DYUT","created_at":"2019-03-23 13:59:35"},{"id":"450","txt_status":"SUCCESS","transaction_id":"DYUTDBT20190323013941","types":"RIDE FARE","booking_id":"3323","txn_amount":"125.08","txn_type":"DEBITED","paymentgateway":"DYUT","paymentmode":"DYUT","created_at":"2019-03-23 13:39:41"},{"id":"447","txt_status":"SUCCESS","transaction_id":"DYUTDBT20190323013236","types":"RIDE FARE","booking_id":"3322","txn_amount":"75.52","txn_type":"DEBITED","paymentgateway":"DYUT","paymentmode":"DYUT","created_at":"2019-03-23 13:32:36"},{"id":"430","txt_status":"SUCCESS","transaction_id":"DYUTDBT20190323111528","types":"RIDE FARE","booking_id":"3298","txn_amount":"58.17","txn_type":"DEBITED","paymentgateway":"DYUT_WALLET_TO_WALLET","paymentmode":"DYUT","created_at":"2019-03-23 11:15:28"},{"id":"419","txt_status":"SUCCESS","transaction_id":"DYUTDBT20190322074651","types":"RIDE FARE","booking_id":"3292","txn_amount":"125.08","txn_type":"DEBITED","paymentgateway":"DYUT_WALLET_TO_WALLET","paymentmode":"DYUT","created_at":"2019-03-22 19:46:51"},{"id":"416","txt_status":"SUCCESS","transaction_id":"DYUTDBT20190322074554","types":"RIDE FARE","booking_id":"3291","txn_amount":"58.17","txn_type":"DEBITED","paymentgateway":"DYUT_WALLET_TO_WALLET","paymentmode":"DYUT","created_at":"2019-03-22 19:45:54"},{"id":"413","txt_status":"SUCCESS","transaction_id":"DYUTDBT20190322070218","types":"RIDE FARE","booking_id":"3270","txn_amount":"61.96","txn_type":"DEBITED","paymentgateway":"DYUT_WALLET_TO_WALLET","paymentmode":"DYUT","created_at":"2019-03-22 19:02:18"}]
     * error : false
     */

    @SerializedName("error")
    private boolean error;
    @SerializedName("TXN_RECORDS")
    private List<TXNRECORDSBean> TXNRECORDS;

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public List<TXNRECORDSBean> getTXNRECORDS() {
        return TXNRECORDS;
    }

    public void setTXNRECORDS(List<TXNRECORDSBean> TXNRECORDS) {
        this.TXNRECORDS = TXNRECORDS;
    }

    public static class TXNRECORDSBean {
        /**
         * id : 611
         * txt_status : SUCCESS
         * transaction_id : DYUTDBT20190326113203
         * types : RIDE FARE
         * booking_id : 3466
         * txn_amount : 58.17
         * txn_type : DEBITED
         * paymentgateway : DYUT
         * paymentmode : DYUT
         * created_at : 2019-03-26 11:32:03
         */

        @SerializedName("id")
        private String id;
        @SerializedName("txt_status")
        private String txtStatus;
        @SerializedName("transaction_id")
        private String transactionId;
        @SerializedName("types")
        private String types;
        @SerializedName("booking_id")
        private String bookingId;
        @SerializedName("txn_amount")
        private String txnAmount;
        @SerializedName("txn_type")
        private String txnType;
        @SerializedName("paymentgateway")
        private String paymentgateway;
        @SerializedName("paymentmode")
        private String paymentmode;
        @SerializedName("created_at")
        private String createdAt;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTxtStatus() {
            return txtStatus;
        }

        public void setTxtStatus(String txtStatus) {
            this.txtStatus = txtStatus;
        }

        public String getTransactionId() {
            return transactionId;
        }

        public void setTransactionId(String transactionId) {
            this.transactionId = transactionId;
        }

        public String getTypes() {
            return types;
        }

        public void setTypes(String types) {
            this.types = types;
        }

        public String getBookingId() {
            return bookingId;
        }

        public void setBookingId(String bookingId) {
            this.bookingId = bookingId;
        }

        public String getTxnAmount() {
            return txnAmount;
        }

        public void setTxnAmount(String txnAmount) {
            this.txnAmount = txnAmount;
        }

        public String getTxnType() {
            return txnType;
        }

        public void setTxnType(String txnType) {
            this.txnType = txnType;
        }

        public String getPaymentgateway() {
            return paymentgateway;
        }

        public void setPaymentgateway(String paymentgateway) {
            this.paymentgateway = paymentgateway;
        }

        public String getPaymentmode() {
            return paymentmode;
        }

        public void setPaymentmode(String paymentmode) {
            this.paymentmode = paymentmode;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }
    }
}
