package com.kouchan.dyutpassenger.FCM;

import android.content.Intent;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.kouchan.dyutpassenger.Database.CurrentRide;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.View.Activities.CancellationActivity;
import com.kouchan.dyutpassenger.View.Activities.CounterReceiptActivity;
import com.kouchan.dyutpassenger.View.Activities.DriverLocationTracking;
import com.kouchan.dyutpassenger.View.Activities.DriverOfferActivity;
import com.kouchan.dyutpassenger.View.Activities.PaymentActivity;
import com.kouchan.dyutpassenger.View.Activities.PaymentStatusActivity;
import com.kouchan.dyutpassenger.models.OttoAllDriversRejected;
import com.kouchan.dyutpassenger.models.OttoEventActivityFinish;
import com.kouchan.dyutpassenger.models.OttoEventButton;
import com.kouchan.dyutpassenger.models.OttoEventDriverList;
import com.kouchan.dyutpassenger.models.OttoRideStarted;
import com.kouchan.dyutpassenger.models.RemovePassengerRequest;

import org.json.JSONObject;

import static android.content.ContentValues.TAG;

/**
 * Created by KOUCHAN-ADMIN on 2/20/2017.
 */

public class DriverMessagingService extends FirebaseMessagingService {

    SessionManager sessionManager;
    String availabilityUpdateURL = Url.COMUNICATE_API + "driverStatus.php";
    String isAvailable, name, mobile ;
    double finalPriceForSorting;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
            try {
                JSONObject jsonObject = new JSONObject(remoteMessage.getData().toString());
                Log.d(TAG,jsonObject.toString());
                sendPushNotification(jsonObject);
            } catch (Exception e) {
            }
        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }
    }

    public void sendPushNotification(JSONObject jsonObject) {
        try {

            JSONObject data = jsonObject.getJSONObject("data");
            String title = data.getString("title");
            String message = data.getString("message");

            JSONObject values = new JSONObject(message);

            NotificationOperator notificationOperator = new NotificationOperator(getApplicationContext());


            if (values.getString("stage").equals("counter offer")) {
                String drivername = values.getString("drivername");
                String prise = values.getString("rate");
                String meter_value = values.getString("metervalue");
                String typeofrate = values.getString("typeofrate");
                String drivermobile = values.getString("drivermobile");
                String bookingid = values.getString("bookingid");
                String vehicle = values.getString("vehicle");
                String rating = values.getString("rating");
                String whenrequiredtype = values.getString("whenrequiredtype");
                String myoffer = values.getString("myoffer");

                double meterval = Double.parseDouble(meter_value);
                double prisevalu = Double.parseDouble(prise);
                Log.e("Driver Message offer",""+message);

                switch (typeofrate) {
                    case "Meter Plus Extra":
                        finalPriceForSorting = prisevalu;
                        break;

                    case "Meter Minus Extra":
                        finalPriceForSorting = prisevalu;
                        break;

                    case "Permeter":
                        finalPriceForSorting = meterval;
                        break;

                    case "Fixed Amount":
                        finalPriceForSorting = prisevalu;
                        break;
                }

                //stringFinalPriceForSorting = Double.toString(finalPriceForSorting);

                sessionManager = new SessionManager(getApplicationContext());
                sessionManager.recycleCount();
                int count = sessionManager.getrecycleCount();

                if (count == 1) {

                    Intent intent2 = new Intent(getApplicationContext(), DriverOfferActivity.class);


                    OttoAllDriversRejected ottoEventRejected = new OttoAllDriversRejected("Null Timer");
                    EventBusManager.getInstance().getEventBus().post(ottoEventRejected);

                    OttoEventActivityFinish ottoEventActivityFinish = new OttoEventActivityFinish("navhome");
                    EventBusManager.getInstance().getEventBus().post(ottoEventActivityFinish);


                    intent2.putExtra("drivername", drivername);
                    intent2.putExtra("stringFinalPriceForSorting", values.getString("myoffer_total"));
                    intent2.putExtra("drivermobile", drivermobile);
                    intent2.putExtra("bookingid", bookingid);
                    intent2.putExtra("vehicle", vehicle);
                    intent2.putExtra("rating", rating);
                    intent2.putExtra("meter_value", meter_value);
                    intent2.putExtra("prise", prise);
                    intent2.putExtra("typeofrate", typeofrate);
                    intent2.putExtra("whenrequiredtype", whenrequiredtype);
                    intent2.putExtra("myoffer", myoffer);
                    intent2.putExtra("service_tax_val", values.getString("service_tax_val"));
                    intent2.putExtra("service_charge_val", values.getString("service_charge_val"));
                    intent2.putExtra("final_amount_val", values.getString("final_amount_val"));
                    intent2.putExtra("myoffer_service_charge", values.getString("myoffer_service_charge"));
                    intent2.putExtra("myoffer_gst", values.getString("myoffer_gst"));
                    intent2.putExtra("vehicle_model", values.getString("vehicle_model"));
                    intent2.putExtra("vehicle_sub_type", values.getString("vehicle_sub_type"));

                    intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                    startActivity(intent2);
                    notificationOperator.showNotification(title, values.getString("stage"), intent2);


                } else {


                    OttoEventDriverList OttoEventDriverList = new OttoEventDriverList(drivername, values.getString("myoffer_total"), drivermobile, bookingid, vehicle, rating
                            , meter_value, prise, typeofrate, whenrequiredtype, myoffer,
                            values.getString("service_tax_val"), values.getString("service_charge_val"),
                            values.getString("final_amount_val"),values.getString("myoffer_service_charge"),values.getString("myoffer_gst"),values.getString("vehicle_model"),values.getString("vehicle_sub_type"));
                    EventBusManager.getInstance().getEventBus().post(OttoEventDriverList);

                    OttoEventActivityFinish ottoEventActivityFinish = new OttoEventActivityFinish("navhome");
                    EventBusManager.getInstance().getEventBus().post(ottoEventActivityFinish);

                }

            } else if (values.getString("stage").equals("Feedback Request")) {
                Intent intent3 = new Intent(getApplicationContext(), PaymentActivity.class);

                CurrentRide currentRide = new CurrentRide(getApplicationContext());

                currentRide.setIsRideStarted("ended");
                intent3.putExtra("drivermobile", values.getString("drivermobile"));
                intent3.putExtra("booking_id", values.getString("booking_id"));

                intent3.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent3.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent3);

                OttoEventActivityFinish ottoEventActivityFinish = new OttoEventActivityFinish("driverlocationtracking");
                EventBusManager.getInstance().getEventBus().post(ottoEventActivityFinish);

            } else if (values.getString("stage").equals("Advance Journey Started"))

            {
                Intent intent4 = new Intent(getApplicationContext(), DriverLocationTracking.class);

                intent4.putExtra("bookingid", values.getString("bookingid"));
                intent4.putExtra("drivermobile", values.getString("drivermobile"));
                intent4.putExtra("vehicle", values.getString("vehicle"));
                intent4.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent4.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                startActivity(intent4);


            } else if (values.getString("stage").equals("Please Try Again"))

            {

                OttoAllDriversRejected ottoEventRejected = new OttoAllDriversRejected("All Drivers Rejected Please Try Again");
                EventBusManager.getInstance().getEventBus().post(ottoEventRejected);

            } else if (values.getString("stage").equals("Request timeout")) {

                OttoAllDriversRejected ottoEventRejected = new OttoAllDriversRejected("Request timeout");
                EventBusManager.getInstance().getEventBus().post(ottoEventRejected);
            } else if (values.getString("stage").equals("Booking Cancelled By Passenger") || values.getString("stage").equals("Booking Cancelled By Driver")) {
                Intent cancel = new Intent(getApplicationContext(), CancellationActivity.class);
                cancel.putExtra("reason", values.getString("reason"));
                cancel.putExtra("type", values.getString("type"));
                CurrentRide currentRide = new CurrentRide(getApplicationContext());
                currentRide.setIsRideStarted("ended");


                if (values.getString("type").equals("immediate")) {

                    cancel.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                }
                cancel.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(cancel);

            } else if (values.getString("stage").equals("Ride Started")) {
                OttoRideStarted ottoRideStarted = new OttoRideStarted("started");
                EventBusManager.getInstance().getEventBus().post(ottoRideStarted);

            } else if (values.getString("stage").equals("Not Selected")) {

                sessionManager = new SessionManager(getApplicationContext());
                String buttonStatus = sessionManager.getUpdateButton();
                String bookingid = values.getString("bookingid");

                if (buttonStatus.equals("waiting")) {
                    sessionManager = new SessionManager(getApplicationContext());
                    sessionManager.setUpdateButton("started");

                    Intent driverReceipt = new Intent(getApplicationContext(), CounterReceiptActivity.class);

                    OttoEventButton ottoEventButton = new OttoEventButton("started");
                    EventBusManager.getInstance().getEventBus().post(ottoEventButton);

                    driverReceipt.putExtra("bookingid", values.getString("bookingid"));
                    driverReceipt.putExtra("rate", values.getString("rate"));
                    driverReceipt.putExtra("toplace", values.getString("toplace"));
                    driverReceipt.putExtra("fromplace", values.getString("fromplace"));
                    driverReceipt.putExtra("typeofrate", values.getString("typeofrate"));


                    driverReceipt.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(driverReceipt);

                } else {

                    RemovePassengerRequest removePassengerRequest = new RemovePassengerRequest(bookingid);
                    EventBusManager.getInstance().getEventBus().post(removePassengerRequest);
                }
            }
            else if (values.getString("stage").equals("Payment_Notification")) {

                Intent intent3 = new Intent(getApplicationContext(), PaymentStatusActivity.class);

                CurrentRide currentRide = new CurrentRide(getApplicationContext());
                currentRide.setIsRideStarted("ended");

                intent3.putExtra("comingFrom","RideSuccess");
                intent3.putExtra("amount", values.getString("Total_Amount"));
                intent3.putExtra("drivermobile", values.getString("drivermobile"));
                intent3.putExtra("booking_id", values.getString("bookingid"));
                intent3.putExtra("payment_mode", values.getString("payment_mode"));

                intent3.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent3.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent3);
                OttoEventActivityFinish ottoEventActivityFinish = new OttoEventActivityFinish("driverlocationtracking");
                EventBusManager.getInstance().getEventBus().post(ottoEventActivityFinish);
            }else if (true) {

            }
        } catch (Exception e) {

            e.getMessage();
        }
    }
}
