package com.kouchan.dyutpassenger.View.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Adapter.LanguageSelectionAdapter;
import com.kouchan.dyutpassenger.R;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LanguageSelectionActivity extends AppCompatActivity {


    @BindView(R.id.selectLanguageRecyclerView)
    RecyclerView mSelectLanguageRecyclerView;

    ArrayList<String> chooseYourLanguageForM3ArrayList = new ArrayList<>();
    ArrayList<String> chooseYourLanguageForM3ArrayListInRespectiveLanguage = new ArrayList<>();

    LanguageSelectionAdapter mLanguageSelectionAdapter;

    Toolbar mToolbar;
    ImageView language_selection_BackImageView, language_selection_HomeImageView;
    TextView language_selection__textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_selection);
        ButterKnife.bind(this);

        language_selection__textView = (TextView) findViewById(R.id.language_selection__textView);

        setSupportActionBar(mToolbar);

        language_selection_BackImageView = (ImageView) findViewById(R.id.language_selection_BackImageView);
        language_selection_HomeImageView = (ImageView) findViewById(R.id.nav_home);

        language_selection_BackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LanguageSelectionActivity.this, SecurityAndSettingsActivity.class);
                startActivity(intent);
                finish();
            }
        });

        initializeViews();

    }

    private void initializeViews() {

        preparingListOfOtherTransactionsWithM3();
        settingUpLanguageWithM3RecyclerViews();

    }


    private void preparingListOfOtherTransactionsWithM3() {

        chooseYourLanguageForM3ArrayList.add("English");
        chooseYourLanguageForM3ArrayList.add("Hindi");
        chooseYourLanguageForM3ArrayList.add("Kannada");
        chooseYourLanguageForM3ArrayList.add("Telugu");
        chooseYourLanguageForM3ArrayList.add("Tamil");
        chooseYourLanguageForM3ArrayList.add("Malayalam");
        chooseYourLanguageForM3ArrayList.add("Marathi");
        chooseYourLanguageForM3ArrayList.add("Gujarati");
        chooseYourLanguageForM3ArrayList.add("Russian");
        chooseYourLanguageForM3ArrayList.add("Arabic");

        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("हिंदी");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("ಕನ್ನಡ");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("తెలుగు");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("தமிழ்");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("മലയാളം");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("मराठी");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("ગુજરાતી");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("русский");
        chooseYourLanguageForM3ArrayListInRespectiveLanguage.add("عربى");
    }

    private void settingUpLanguageWithM3RecyclerViews() {

        mLanguageSelectionAdapter = new LanguageSelectionAdapter(LanguageSelectionActivity.this, chooseYourLanguageForM3ArrayList, chooseYourLanguageForM3ArrayListInRespectiveLanguage);
        mSelectLanguageRecyclerView.setHasFixedSize(true);

        mSelectLanguageRecyclerView.setLayoutManager(new LinearLayoutManager(LanguageSelectionActivity.this));
        /*for animation*/
        mSelectLanguageRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mSelectLanguageRecyclerView.setAdapter(mLanguageSelectionAdapter);
        //  }
    }

    private void initializeViewsBackHomeButtons() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        language_selection_BackImageView = (ImageView) findViewById(R.id.language_selection_BackImageView);
        language_selection_HomeImageView = (ImageView) findViewById(R.id.nav_home);

        language_selection_BackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LanguageSelectionActivity.this, SecurityAndSettingsActivity.class);
                startActivity(intent);
                finish();
            }
        });

        language_selection_HomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LanguageSelectionActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
