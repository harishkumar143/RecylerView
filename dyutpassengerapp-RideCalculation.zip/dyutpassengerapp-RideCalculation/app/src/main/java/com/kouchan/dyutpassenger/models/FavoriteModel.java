package com.kouchan.dyutpassenger.models;

public class FavoriteModel {

    private String id;

    private String favType;

    private String favAddress;

    private String latitude;

    private String longitude;

    public FavoriteModel(String id,String favType, String favAddress, String latitude, String longitude) {
        this.favType = favType;
        this.favAddress = favAddress;
        this.latitude = latitude;
        this.longitude = longitude;
        this.id = id;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getFavType() {
        return favType;
    }

    public void setFavType(String favType) {
        this.favType = favType;
    }

    public String getFavAddress() {
        return favAddress;
    }

    public void setFavAddress(String favAddress) {
        this.favAddress = favAddress;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
