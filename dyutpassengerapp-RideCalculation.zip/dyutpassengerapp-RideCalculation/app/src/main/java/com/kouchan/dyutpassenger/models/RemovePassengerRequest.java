package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 12/2/2017.
 */

public class RemovePassengerRequest {

    private String bookingid;

    public RemovePassengerRequest(String bookingid) {
        this.bookingid = bookingid;
    }

    public String getBookingid() {
        return bookingid;
    }


}
