package com.kouchan.dyutpassenger.utils;

public class AppConstants {

    public static int TAG_ID_REGISTER = 1;
    public static int TAG_ID_OTP = 2;
    public static int TAG_ID_AADHAR_OTP = 3;
    public static int TAG_ID_VALIDATE_AADHAR_OTP = 4;
    public static int TAG_ID_VERIFY_OTP = 5;
    public static int TAG_ID_GENERATE_TOKEN = 6;
    public static int TAG_ID_PAYMENT = 7;
    public static int TAG_ID_VERIFY_BOOKRIDE_OTP = 8;
    public static int TAG_ID_GETBALANCE = 9;
    public static int TAG_ID_BOOKRIDERESENDOTP = 10;
    public static int TAG_ID_EDITPROFILE = 11;
    public static int TAG_ID_GETPROFILE = 12;
    public static int TAG_ID_AFTERCANCEL = 13;
    public static int TAG_ID_BEFORECANCEL = 14;
    public static int TAG_ID_FAQ = 15;
    public static int TAG_ID_DELETEFAVOURITE = 16;
    public static int TAG_ID_CHANGEDESTINATION = 17;
    public static int TAG_ID_PAYTM_CHECKSUM = 18;

    public static String serverUrl = "http://www.kouchan.in/M3app/";
    public static boolean IS_LIVE_BUILD = false;


    private static String BASE_URL;
    public static String WEBSERVICE_HOST;


    static {
        if (IS_LIVE_BUILD) {
            WEBSERVICE_HOST = "http://www.kouchan.in/M3app/";
        } else {
            WEBSERVICE_HOST = "http://www.kouchan.in/M3app/";

        }
        BASE_URL = WEBSERVICE_HOST;
    }


    public static String PREF_AUTO_BOOK="autobooking";
    public static String PREF_AUTO_LESS_PRICE="lessprice";
    public static String PREF_AUTO_LESS_DISTANCE="lessdistance";

}
