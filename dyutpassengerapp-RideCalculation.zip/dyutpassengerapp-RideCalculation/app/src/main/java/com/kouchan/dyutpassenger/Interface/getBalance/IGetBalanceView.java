package com.kouchan.dyutpassenger.Interface.getBalance;

public interface IGetBalanceView {

    void getBalanceSuccess(int pid, String balance);

    void getBalanceError(int pid, String error);

}
