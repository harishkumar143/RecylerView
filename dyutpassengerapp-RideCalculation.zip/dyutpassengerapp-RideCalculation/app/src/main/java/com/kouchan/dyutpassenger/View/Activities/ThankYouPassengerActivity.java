package com.kouchan.dyutpassenger.View.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.kouchan.dyutpassenger.R;


public class ThankYouPassengerActivity extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thank_you_passenger);

        Thread timer = new Thread(){
            public void run(){
                try{
                    sleep(4000);
                }
                catch(InterruptedException e){
                    e.printStackTrace();
                } finally {
                    Intent intent = new Intent(ThankYouPassengerActivity.this, NavHome.class);
                    startActivity(intent);
                    finish();
                }
            }
        };

        timer.start();
    }
}
