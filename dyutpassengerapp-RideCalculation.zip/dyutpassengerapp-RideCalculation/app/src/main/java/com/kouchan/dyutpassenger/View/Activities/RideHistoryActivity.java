package com.kouchan.dyutpassenger.View.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Fragments.AdvanceBookingFragment;
import com.kouchan.dyutpassenger.View.Fragments.CancelledBookingFragment;
import com.kouchan.dyutpassenger.View.Fragments.CompletedRidesFragment;
import com.kouchan.dyutpassenger.helper.LocaleHelper;

import java.util.ArrayList;
import java.util.List;


public class RideHistoryActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    ImageView historyBackImageView, historyHomeImageView;

    TextView ride_history_textView;
    String languageCode;
    Resources resources;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_tabs);

        this.setTitle("History");

        toolbar = (Toolbar) findViewById(R.id.bookARideToolbar);

        ride_history_textView = (TextView) findViewById(R.id.ride_history_textView);

        setSupportActionBar(toolbar);


       /* getSupportActionBar().setDisplayHomeAsUpEnabled(true);*/

        sessionManager = new SessionManager(this);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        viewPager = (ViewPager) findViewById(R.id.viewpager);
        setupViewPager(viewPager);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);

        initializeViews();

    }

    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(this, languageCode);
        resources = context.getResources();
        ride_history_textView.setText(resources.getString(R.string.rides_history));
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());

        adapter.addFragment(new CompletedRidesFragment(), resources.getString(R.string.completed));
        adapter.addFragment(new CancelledBookingFragment(), resources.getString(R.string.cancelled));
        adapter.addFragment(new AdvanceBookingFragment(),resources.getString(R.string.upcomming));

       /* adapter.addFragment(new TwoFragment(), getString(R.string.completed));
        adapter.addFragment(new ThreeFragment(),getString(R.string.cancelled));
        adapter.addFragment(new OneFragment(),getString(R.string.upcomming)); */

        viewPager.setAdapter(adapter);
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);

        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(RideHistoryActivity.this, NavHome.class);
        startActivity(intent);
        finish();
    }
    private void initializeViews() {
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        historyBackImageView = (ImageView) findViewById(R.id.historyBackImageView);
        historyHomeImageView = (ImageView) findViewById(R.id.historyHomeImageView);

        historyBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RideHistoryActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });

        historyHomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RideHistoryActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
