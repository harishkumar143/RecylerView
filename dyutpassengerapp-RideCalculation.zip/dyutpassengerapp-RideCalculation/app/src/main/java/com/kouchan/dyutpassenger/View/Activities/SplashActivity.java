package com.kouchan.dyutpassenger.View.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;

import com.kouchan.dyutpassenger.BroadcastReceivers.NetworkChangeReceiver;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;


public class SplashActivity extends AppCompatActivity {

    RelativeLayout relativeLayoutFlash;

    String type;

    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        sessionManager = new SessionManager(this);
        type = sessionManager.getType();

        sessionManager.setKeyLanguageCode("en");

        if (sessionManager.getLanguageCode() == null) {
            sessionManager.setKeyLanguageCode("en");
        }

        relativeLayoutFlash = (RelativeLayout) findViewById(R.id.relativeLayoutFlash);
        Animation animation;
        animation = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.fade);
        //relativeLayoutFlash.startAnimation(animation);

        Thread timer = new Thread() {
            public void run() {
                try {
                    sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {

                    Intent intent2 = new Intent(SplashActivity.this, LoginActivity.class);
                    startActivity(intent2);
                    finish();


                }
            }
        };

        NetworkChangeReceiver ncr = new NetworkChangeReceiver();

        timer.start();

    }


}