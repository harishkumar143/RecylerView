package com.kouchan.dyutpassenger.Interface.paytm;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.models.PaytmChecksumModel;
import com.kouchan.dyutpassenger.utils.AppConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class PaytmApiPresenterImpl implements PaytmApiPresenter, OnRequestListener {

    PaytmApiView paytmApiView;
    PaytmChecksumModel paytmChecksumModel;
    AsyncInteractor asyncInteractor;
    Context context;

    public PaytmApiPresenterImpl(PaytmApiView paytmApiView, Context context) {
        this.paytmApiView = paytmApiView;
        this.context=context;
        this.asyncInteractor = new AsyncInteractor(context);
    }

    @Override
    public void paytmGenerateChecksum(final String orderId, final String custId, final String txnAmount) {


        StringRequest updateDriverLocation = new StringRequest(Request.Method.POST, Url.PAYTM_Generate_Checksum_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jObj = new JSONObject(response);

                            boolean error = jObj.getBoolean("error");
                            if (!error) {
                                Gson gson = new Gson();
                                paytmChecksumModel = gson.fromJson(response, PaytmChecksumModel.class);

                                if (paytmChecksumModel != null)
                                    if (paytmChecksumModel.getPaytSTATUS().equalsIgnoreCase("1")) {
                                        paytmApiView.checksumGenerationSucess(paytmChecksumModel);
                                    } else {
                                        paytmApiView.checksumGenerationError("error");
                                    }
                            } else {
                                Toast.makeText(context, jObj.getString("error_msg"), Toast.LENGTH_SHORT).show();
                            }



                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        paytmApiView.checksumGenerationError("error");
                        Toast.makeText(context, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> paytmParams = new HashMap<>();

                paytmParams.put("ORDER_ID", orderId);

                paytmParams.put("CUST_ID", custId);
                paytmParams.put("TXN_AMOUNT", txnAmount);


                return paytmParams;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(updateDriverLocation);
    }


    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
        if (pid == AppConstants.TAG_ID_PAYTM_CHECKSUM) {

            if (responseJson != null) {

                Gson gson = new Gson();
                paytmChecksumModel = gson.fromJson(responseJson, PaytmChecksumModel.class);

                if (paytmChecksumModel != null)
                    if (paytmChecksumModel.getPaytSTATUS().equalsIgnoreCase("1")) {
                        paytmApiView.checksumGenerationSucess(paytmChecksumModel);
                    } else {
                        paytmApiView.checksumGenerationError("error");
                    }

            }
        }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        paytmApiView.checksumGenerationError("error");
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {

    }
}
