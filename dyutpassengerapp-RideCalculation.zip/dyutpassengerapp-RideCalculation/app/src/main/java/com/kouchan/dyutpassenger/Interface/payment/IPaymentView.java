package com.kouchan.dyutpassenger.Interface.payment;


import com.kouchan.dyutpassenger.models.PaymentModel;

public interface IPaymentView {

    void paymentSuccess(int pid, PaymentModel paymentModel);

    void paymentError(int pid, String error);

}
