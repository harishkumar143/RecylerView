package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 8/2/2017.
 */

public class SMSOtpMessage {
    String otp;

    public SMSOtpMessage(String otp) {
        this.otp = otp;
    }

    public String getOtp() {

        return otp;
    }
}
