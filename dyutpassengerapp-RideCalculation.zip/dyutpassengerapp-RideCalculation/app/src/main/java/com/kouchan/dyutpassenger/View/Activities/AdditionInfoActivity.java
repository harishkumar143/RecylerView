package com.kouchan.dyutpassenger.View.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.kouchan.dyutpassenger.Database.PrefManager;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AdditionInfoActivity extends AppCompatActivity {

    EditText father_husband_name, emergency_mobile_no,
            flat_no, building_name, street_name, town_city, pin_no, state,
            aadhar_card, passport, driving_licence_no, occupation,
            wife_name, wife_number;

    RadioButton single,married;

    String  stringfatherHusbandName, stringEmergencyMobileNo, stringFlatNo, stringBuildingName, stringStreetName, stringTownCity,
            stringPinNo, stringState, stringAadharCard, stringName, stringMobile, stringOccupation, stringWifeName, stringWifeNumber,stringMessagingID,address;

    RadioGroup martial_status_options;

    boolean isMartialStatusSelected;

    TextView marital_status;

    public AwesomeValidation awesomeValidation,awesomeValidationA;

    String  stringMartialStatusOptions,type;

    Button submit_button;

    String ADDITIONAL_INFO ="";

    SessionManager sessionManager;

    Toolbar mToolbar;
    ImageView additionalInfoBackImageView, additionalInfoHomeImageView;

    android.app.AlertDialog.Builder ab;

    HashMap<String, String> user = new HashMap<String, String>();
    String name,mobile;

    private PrefManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addition_info);


        sessionManager=new SessionManager(getApplicationContext());
        user=sessionManager.getUserDetails();
        name=user.get("name");
        mobile=user.get("mobile");


        type=sessionManager.getType();
        switch (type){
            case "passenger":

                ADDITIONAL_INFO = Url.PASSENGER_API+"additional_info.php";
                break;

            case "driver":
                ADDITIONAL_INFO = Url.DRIVER_API+"additional_info.php";
                break;

            case "both":

                ADDITIONAL_INFO = Url.DRIVER_API+"additional_info.php";
                break;
        }


        initializeWidgets();
        chooseOptions();

        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    setValuesForSubmisssion();
                    sendValues();
            }
        });

        initializeViews();

    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Intent intent = new Intent(AdditionInfoActivity.this, NavHome.class);
        startActivity(intent);
        finish();
    }
    private void initializeViews() {
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        additionalInfoBackImageView = (ImageView) findViewById(R.id.additionalInfoBackImageView);
        additionalInfoHomeImageView = (ImageView) findViewById(R.id.additionalInfoHomeImageView);

        additionalInfoBackImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdditionInfoActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });

        additionalInfoHomeImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdditionInfoActivity.this, NavHome.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void initializeWidgets() {

        father_husband_name = (EditText)findViewById(R.id.register_father_husband_name);
        emergency_mobile_no = (EditText)findViewById(R.id.register_emergency_mobile_number);
        flat_no = (EditText) findViewById(R.id.register_flat_no);
        building_name = (EditText)findViewById(R.id.register_building_name);
        street_name = (EditText)findViewById(R.id.register_street_name);
        town_city = (EditText) findViewById(R.id.register_town_city);
        pin_no = (EditText) findViewById(R.id.register_pinno);
        state = (EditText)findViewById(R.id.register_state);

        aadhar_card = (EditText)findViewById(R.id.register_aadhar_card);
//        passport = (EditText) findViewById(R.id.register_passport);
//        driving_licence_no = (EditText) findViewById(R.id.register_driving_licence_no);
        occupation = (EditText)findViewById(R.id.register_occupation);

        martial_status_options = (RadioGroup) findViewById(R.id.register_martial_status_options);
        single=(RadioButton)findViewById(R.id.register_single);
        married=(RadioButton)findViewById(R.id.register_married);
        marital_status=(TextView)findViewById(R.id.marital_status);

        wife_name = (EditText) findViewById(R.id.register_wife_name);
        wife_name.setVisibility(View.GONE);
        wife_number = (EditText)findViewById(R.id.register_wife_number);
        wife_number.setVisibility(View.GONE);
        submit_button = (Button) findViewById(R.id.submit_button_add_info);

        awesomeValidation = new AwesomeValidation(ValidationStyle.COLORATION);
        awesomeValidation.setColor(R.color.newtextColor);

        awesomeValidation.addValidation(this, R.id.register_father_husband_name, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.nameerror);
        awesomeValidation.addValidation(this, R.id.register_emergency_mobile_number, "^[7-9]{1}[0-9]{9}$", R.string.mobileerror);
        awesomeValidation.addValidation(this, R.id.register_flat_no, "^[0-9]{5}$", R.string.flatnoerror);
        awesomeValidation.addValidation(this, R.id.register_building_name, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.buildingnoerror);
        awesomeValidation.addValidation(this, R.id.register_street_name, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.statenameerror);
        awesomeValidation.addValidation(this, R.id.register_town_city, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.towncityerror);
        awesomeValidation.addValidation(this, R.id.register_pinno, "^[1-9]{1}[0-9]{5}$", R.string.pincodeerror);
        awesomeValidation.addValidation(this, R.id.register_state, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.statenameerror);
        awesomeValidation.addValidation(this, R.id.register_aadhar_card, "^[2-9]{1}[0-9]{11}$", R.string.aadharcardnoerror);
        awesomeValidation.addValidation(this, R.id.register_occupation, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.occupationerror);

    }

    public void chooseOptions() {
        martial_status_options.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.register_single:
                        stringMartialStatusOptions = "single";
                        isMartialStatusSelected=true;
                        wife_number.setText("");
                        wife_name.setText("");
                        wife_name.setVisibility(View.GONE);
                        wife_number.setVisibility(View.GONE);
                        break;

                    case R.id.register_married:
                        stringMartialStatusOptions = "married";
                        wife_name.setVisibility(View.VISIBLE);
                        wife_number.setVisibility(View.VISIBLE);
                        break;
                }
            }
        });
    }
    private void setValuesForSubmisssion() {

        stringfatherHusbandName = father_husband_name.getText().toString();
        stringEmergencyMobileNo = emergency_mobile_no.getText().toString();
        stringFlatNo = flat_no.getText().toString();
        stringBuildingName = building_name.getText().toString();
        stringStreetName = street_name.getText().toString();
        stringTownCity = town_city.getText().toString();
        stringPinNo = pin_no.getText().toString();
        stringState = state.getText().toString();
        stringAadharCard = aadhar_card.getText().toString();
        stringOccupation = occupation.getText().toString();
        stringWifeName = wife_name.getText().toString();
        stringWifeNumber = wife_number.getText().toString();
        stringMessagingID=sessionManager.getToken();
        address="Flate No- "+stringFlatNo+"Building name- "+stringBuildingName+"Street name- "+stringStreetName+"City- "+stringTownCity;
    }

  public void sendValues() {

        if (!(awesomeValidation.validate())) {
            //process the data further
        } else if (martial_status_options.getCheckedRadioButtonId() <= 0) {//Grp is your radio group object
            marital_status.requestFocus();
            marital_status.setError("Select Marital Status");//Set error to last Radio button
        } else if(stringMartialStatusOptions.equals("married")) {

            awesomeValidationA = new AwesomeValidation(ValidationStyle.COLORATION);
            awesomeValidationA.setColor(R.color.newtextColor);

            awesomeValidationA.addValidation(AdditionInfoActivity.this, R.id.register_wife_name, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.wifenameerror);
            awesomeValidationA.addValidation(AdditionInfoActivity.this, R.id.register_wife_number, "^[7-9]{1}[0-9]{9}$", R.string.wifemobileerror);

            if (!(awesomeValidationA.validate())) {
                //process the data further
            }else
                {sendValuesValidated();
                }
        }
        else {


            sendValuesValidated();

        }
    }

    public void sendValuesValidated(){

                StringRequest stringRequest = new StringRequest(Request.Method.POST, ADDITIONAL_INFO,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject jObj = new JSONObject(response);
                                    boolean error = jObj.getBoolean("error");
                                    if (!error) {

                                        String uid = jObj.getString("uid");

                                        JSONObject user = jObj.getJSONObject("user");
                                        stringName = user.getString("name");
                                        stringMobile = user.getString("mobile");
                                        String created_at = user.getString("created_at");

                                        prefManager = new PrefManager(AdditionInfoActivity.this);
                                        prefManager.setAddInfo(false);
                                        startActivity(new Intent(AdditionInfoActivity.this, AditionalInfoSubmitedActivity.class));
                                        finish();

                                    } else {

                                        // Error occurred in registration. Get the error
                                        // message
                                        String errorMsg = jObj.getString("error_msg");
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                            }
                        }) {
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("mobile", mobile);
                        params.put("fhname", stringfatherHusbandName);
                        params.put("emobile", stringEmergencyMobileNo);
                        params.put("address", address);
                        params.put("pin", stringPinNo);
                        params.put("state", stringState);
                        params.put("adharno", stringAadharCard);
                        params.put("occupation", stringOccupation);
                        params.put("wno", stringWifeNumber);
                        params.put("wname", stringWifeName);
                        return params;
                    }

                };

                RequestQueue requestQueue = Volley.newRequestQueue(AdditionInfoActivity.this);
                requestQueue.add(stringRequest);
            }

        }

