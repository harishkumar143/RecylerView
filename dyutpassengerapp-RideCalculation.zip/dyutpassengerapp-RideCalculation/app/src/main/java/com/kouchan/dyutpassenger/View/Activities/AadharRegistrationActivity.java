package com.kouchan.dyutpassenger.View.Activities;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.kouchan.dyutpassenger.Interface.aadharotpvalidate.AadharOtpValidatePresenterImpl;
import com.kouchan.dyutpassenger.Interface.aadharotpvalidate.IAadharValidateOtpPresnter;
import com.kouchan.dyutpassenger.Interface.aadharotpvalidate.IAadharValidateOtpView;
import com.kouchan.dyutpassenger.Interface.m3withbookarideregistration.IRegisterPresenter;
import com.kouchan.dyutpassenger.Interface.m3withbookarideregistration.IRegisterView;
import com.kouchan.dyutpassenger.Interface.m3withbookarideregistration.RegisterPresenterImp;
import com.kouchan.dyutpassenger.Interface.verifyOtp.VerifyOtpPresenter;
import com.kouchan.dyutpassenger.Interface.verifyOtp.VerifyOtpPresenterImpl;
import com.kouchan.dyutpassenger.Interface.verifyOtp.VerifyOtpView;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.utils.Utils;

public class AadharRegistrationActivity extends AppCompatActivity implements IRegisterView,VerifyOtpView,IAadharValidateOtpView {

    EditText adharNumber;
    Button submit;
    AwesomeValidation awesomeValidation;
    Dialog mDialog;
    VerifyOtpPresenter verifyOtpPresenter;
    IRegisterPresenter registerPresenter;
    IAadharValidateOtpPresnter aadharValidateOtpPresnter;
    private EditText mFirstDigitEdtTxt, mSecondDigitEdtTxt, mThirdDigitEdtTxt, mFourthDigitEdtTxt,mFivthDigitEdtTxt,mSixthDigitEdtTxt;

    private TextView phoneNoView;
    private EditText phoneCodeView;
    private Button phoneVerifyButton;
    private TextView resendOtpButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aadhar_registration);
        adharNumber = (EditText) findViewById(R.id.adharnumber);
        submit = (Button) findViewById(R.id.submitbutton);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        registerPresenter = new RegisterPresenterImp(this);
        aadharValidateOtpPresnter = new AadharOtpValidatePresenterImpl(this);

        awesomeValidation.addValidation(this, R.id.adharnumber, "^[2-9]{1}[0-9]{11}$", R.string.aadharcardnoerror);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    registerPresenter.registerValidation(getIntent().getStringExtra("name"),
                            getIntent().getStringExtra("email"),
                            getIntent().getStringExtra("mobile"),
                            getIntent().getStringExtra("password"),
                            adharNumber.getText().toString().trim(),"");
            }
        });
    }

    @Override
    public void onRegisterSuccess(int pid, String registerModel) {
        Utils.stopProgress(this);
        if(registerModel.equals("M3_OTP_PENDING")) {
            showOTPDialog();
        } else if(registerModel.equals("M3_ADHAR_REGISTRATION")) {
            aadharValidateOtpPresnter.validateAadhatOtp(getIntent().getStringExtra("mobile"),getIntent().getStringExtra("password"),adharNumber.getText().toString().trim());
        } else if(registerModel.equals("MERCHANT")) {
            Toast.makeText(getApplicationContext(), "MERCHANT VERIFICATION PENDING",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(AadharRegistrationActivity.this,NavHome.class);
            startActivity(intent);
            finish();
        }
    }

    @Override
    public void onRegisterError(int pid, String error) {
        Utils.stopProgress(this);
        Toast.makeText(getApplicationContext(), error,Toast.LENGTH_LONG).show();
        Intent intent = new Intent(AadharRegistrationActivity.this,NavHome.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onRegisterServerError(int pid, String error) {
        Utils.stopProgress(this);
        Toast.makeText(getApplicationContext(), error,Toast.LENGTH_LONG).show();
        Intent intent = new Intent(AadharRegistrationActivity.this,NavHome.class);
        startActivity(intent);
        finish();
    }

    private void showOTPDialog() {
        mDialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen);
        mDialog.setCanceledOnTouchOutside(false);
        mDialog.setContentView(R.layout.view_verification);

        phoneNoView = (TextView) mDialog.findViewById(R.id.phone_verify_number_tv);
        phoneCodeView = (EditText) mDialog.findViewById(R.id.phone_verify_code);
        phoneVerifyButton = (Button) mDialog.findViewById(R.id.phone_verification_submit);
        resendOtpButton = (TextView) mDialog.findViewById(R.id.phone_verification_resend_otp_button);

        mFirstDigitEdtTxt = (EditText) mDialog.findViewById(R.id.otp_code_first_digit_edtTxt);
        mSecondDigitEdtTxt = (EditText) mDialog.findViewById(R.id.otp_code_second_digit_edtTxt);
        mThirdDigitEdtTxt = (EditText) mDialog.findViewById(R.id.otp_code_third_digit_edtTxt);
        mFourthDigitEdtTxt = (EditText) mDialog.findViewById(R.id.otp_code_fourth_digit_edtTxt);

        mFivthDigitEdtTxt = (EditText) mDialog.findViewById(R.id.otp_code_fivth_digit_edtTxt);
        mSixthDigitEdtTxt = (EditText) mDialog.findViewById(R.id.otp_code_six_digit_edtTxt);

        String number = phoneCodeView.getText().toString();
        String mask = number.replaceAll("\\w(?=\\w{3})", "*");

        phoneNoView.setText(mask);
        verifyOtpPresenter = new VerifyOtpPresenterImpl(this);
        phoneVerifyButton.setEnabled(true);
        phoneVerifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //String otpEntered = phoneCodeView.getText().toString();
                String firstDigit = mFirstDigitEdtTxt.getText().toString();
                String secondDigit = mSecondDigitEdtTxt.getText().toString();
                String thirdDigit = mThirdDigitEdtTxt.getText().toString();
                String fourthDigit = mFourthDigitEdtTxt.getText().toString();
                String fivthDigit = mFivthDigitEdtTxt.getText().toString();
                String sixthDigit = mSixthDigitEdtTxt.getText().toString();
                String otpEntered = firstDigit + secondDigit + thirdDigit + fourthDigit + fivthDigit + sixthDigit;
                if (!otpEntered.isEmpty()) {
                    verifyOtpPresenter.verifyOtp(otpEntered,getIntent().getStringExtra("mobile"),getIntent().getStringExtra("password"));
                }
                else{
                    Toast.makeText(AadharRegistrationActivity.this, "OTP empty",Toast.LENGTH_LONG).show();
                }
            }
        });

        mFirstDigitEdtTxt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(count == 1)
                    mSecondDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mSecondDigitEdtTxt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(count == 1)
                    mThirdDigitEdtTxt.requestFocus();

                // detect backspace key
                if(count == 0)
                    mFirstDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mThirdDigitEdtTxt.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(count == 1)
                    mFourthDigitEdtTxt.requestFocus();

                // detect backspace key
                if(count == 0)
                    mSecondDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mFourthDigitEdtTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                // detect backspace key
                if(count == 0)
                    mThirdDigitEdtTxt.requestFocus();

                if(count == 1)
                    mFivthDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mFivthDigitEdtTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                // detect backspace key
                if(count == 0)
                    mFourthDigitEdtTxt.requestFocus();

                if(count == 1)
                    mSixthDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mSixthDigitEdtTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                // detect backspace key
                if(count == 0)
                    mFivthDigitEdtTxt.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        resendOtpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // sendOtpRequest();
                // countDownTimer.start();
            }
        });
        mDialog.show();
        // countDownTimer.start();
    }

    @Override
    public void aadharOtpSuccess(int pid, String aadharOtpmodel) {
        Utils.stopProgress(this);
        Intent intent = new Intent(AadharRegistrationActivity.this,AdharOTPValidationActivity.class);
        intent.putExtra("mobile",getIntent().getStringExtra("mobile"));
        intent.putExtra("password",getIntent().getStringExtra("password"));
        startActivity(intent);
        finish();
    }

    @Override
    public void aadharOtpError(int pid, String error) {
        Utils.stopProgress(this);
        Toast.makeText(getApplicationContext(), error,Toast.LENGTH_LONG).show();
        Intent intent = new Intent(AadharRegistrationActivity.this,NavHome.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void verifyOtpSuccess(int pid, String verifyOtpModel) {
        aadharValidateOtpPresnter.validateAadhatOtp(getIntent().getStringExtra("mobile"),getIntent().getStringExtra("password"),adharNumber.getText().toString().trim());
    }

    @Override
    public void verifyOtpError(int pid, String error) {
        Utils.stopProgress(this);
        Toast.makeText(getApplicationContext(), error,Toast.LENGTH_LONG).show();
        Intent intent = new Intent(AadharRegistrationActivity.this,NavHome.class);
        startActivity(intent);
        finish();
    }
}
