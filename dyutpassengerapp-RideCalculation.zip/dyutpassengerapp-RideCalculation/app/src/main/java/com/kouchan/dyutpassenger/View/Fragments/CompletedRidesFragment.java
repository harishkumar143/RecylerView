package com.kouchan.dyutpassenger.View.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kouchan.dyutpassenger.Adapter.HistoryAdapter;
import com.kouchan.dyutpassenger.Adapter.RecyclerTouchListener;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.MonthExpandActivity;
import com.kouchan.dyutpassenger.View.Activities.SplashActivity;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.History;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class CompletedRidesFragment extends Fragment{

    private List<History> historyList = new ArrayList<>();
    private String TAG = SplashActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private RecyclerView recyclerView;
    private HistoryAdapter mAdapter;


    String languageCode;
    Resources resources;

    HashMap<String, String> user;
    String passengermobile,type;
    String historyUrl= "";
    SessionManager sessionManager;

    Toolbar mToolbar;
    ImageView historyBackImageView, historyHomeImageView;

    View view;

    public CompletedRidesFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflate the layout for this fragment

        view= inflater.inflate(R.layout.fragment_two, container, false);
        historyList.clear();
        recyclerView = (RecyclerView)view. findViewById(R.id.recycler_view_history);

        mAdapter = new HistoryAdapter(historyList,getActivity());
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);

        recyclerView.setAdapter(mAdapter);

        sessionManager=new SessionManager(getActivity());

        user = new HashMap<String, String>();
        user=sessionManager.getUserDetails();

        passengermobile=user.get("mobile");

        type=sessionManager.getType();


        historyUrl= Url.PASSENGER_API+"passengerHistoryByMonth.php";

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                History history = historyList.get(position);


                Intent i=new Intent(getActivity(),MonthExpandActivity.class);

                i.putExtra("month",history.getMonth());
                i.putExtra("year",history.getYear());

                startActivity(i);



            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));



        displayHistoy();

        sessionManager = new SessionManager(getActivity());
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();
            updateViews(languageCode);
        }

        return view;
    }



    private void updateViews(String languageCode) {
        Context context = LocaleHelper.setLocale(getActivity(), languageCode);
        resources = context.getResources();

        /*forgot_password_tv.setText(resources.getString(R.string.forgot_password));*/

    }



    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("Ride History");

    }

    public void displayHistoy(){
        final ProgressDialog loading = ProgressDialog.show(getActivity(),getString(R.string.processing),getString(R.string.please_wait),false,false);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, historyUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            loading.dismiss();
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            if (!error) {


                                JSONArray contacts = jsonObj.getJSONArray("user");

                                for (int i = 0; i < contacts.length(); i++) {
                                    JSONObject c = contacts.getJSONObject(i);

                                    String month = c.getString("month");
                                    String year = c.getString("year");
                                    String total_no_of_rides = c.getString("total_no_of_rides");
                                    String total_fare = c.getString("total_fare");
                                   /* String actualprice = c.getString("actualprice");
                                    String vehicle = c.getString("vehicle");*/

                                        History history=new History(month,year,total_no_of_rides,total_fare);
                                        historyList.add(history);
                                        mAdapter.notifyDataSetChanged();
                                        /*listDataHeader.add(month);*/



                                    /*mAdapter.notifyDataSetChanged();*/
                                    // tmp hash map for single contact
                                HashMap<String, String> contact = new HashMap<>();

                                // adding each child node to HashMap key => value

                          /*      contact.put("id",id);
                                contact.put("paymenttype",paymenttype);
                                contact.put("bookingtime",bookingtime);
                                contact.put("ridestatus",ridestatus);
                                contact.put("actualprice",actualprice);
                                contact.put("vehicle",vehicle);*/


                                    // adding contact to contact list
                                }
                            }else {
                                String errorMsg = jsonObj.getString("error_msg");
                            }
                            //         ListAdapter adapter = new SimpleAdapter(getApplicationContext(), contactList, R.layout.history_list_item, new String[]{"paymenttype", "bookingtime", "ridestatus","actualprice","vehicle"}, new int[]{R.id.paymenttype, R.id.bookingtime, R.id.ridestatus, R.id.actualprice, R.id.vehicle});
//
//                            lv.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                    }
                }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {

                Map<String,String> params=new HashMap<String, String>();

                params.put("mobile",passengermobile);


                return params ;
            }
        };

        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        historyList.clear();
        mAdapter.notifyDataSetChanged();
    }
}
