package com.kouchan.dyutpassenger.Adapter;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.CountDownTimer;
import android.support.v7.util.SortedList;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.IButtonAcceptOffer;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.DriverOfferActivity;
import com.kouchan.dyutpassenger.View.Activities.NavHome;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.DriverOffer;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

public class DriverOfferAdapter extends RecyclerView.Adapter<DriverOfferAdapter.MyViewHolder> {

    private List<DriverOffer> moviesList;

    String languageCode;
    Resources resources;
    SessionManager sessionManager;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title, year, vehicle, bookingId, typeofmeter, myoffer;

        public TextView  total_price_textView,taxAndFees, totalFair,vehicleType,driverOfferTimer;

        public Button acceptCounterOffer,reject;
        public RatingBar ratingBar;
        public ImageView vehicleIv;

        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.title);
            year = (TextView) view.findViewById(R.  id.year);
            vehicle = (TextView) view.findViewById(R.id.vehicleTextView);

            ratingBar = (RatingBar) view.findViewById(R.id.ratingBar);
            reject = (Button) view.findViewById(R.id.reject);
            typeofmeter = (TextView) view.findViewById(R.id.typeofmeter);

            vehicleIv = (ImageView) view.findViewById(R.id.vehicleIv);
            myoffer = (TextView) view.findViewById(R.id.myoffer);
            vehicleType = (TextView) view.findViewById(R.id.vehicleType);

            total_price_textView = (TextView) view.findViewById(R.id.total_price_textView);
            acceptCounterOffer = (Button) view.findViewById(R.id.acceptCounterOffer);

            taxAndFees = (TextView) view.findViewById(R.id.taxAndFees);
            totalFair = (TextView) view.findViewById(R.id.totalFair);

            driverOfferTimer = (TextView) view.findViewById(R.id.driverOfferTimer);
        }
    }

    private Context mContext;
    private LayoutInflater mLayoutInflater;
    private SortedList<DriverOffer> mPersons;
    IButtonAcceptOffer iButtonAcceptOffer;
    DriverOfferActivity offerActivity;
    CountDownTimer waitingTimer;
    long t;
    ProgressDialog  loading;
    String cancelRideUrl=Url.COMUNICATE_API+"passengerCancel.php";

    public DriverOfferAdapter(Context context, final List<DriverOffer> moviesList, DriverOfferActivity offerActivity) {
        mContext = context;
        this.moviesList = moviesList;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mPersons = new SortedList<>(DriverOffer.class, new DriverListCallback());
        mPersons.addAll(moviesList);
        this.context = context;
        iButtonAcceptOffer=offerActivity;
        this.offerActivity=offerActivity;



        //set the timer which will refresh the data every 1 second.
        waitingTimer = new CountDownTimer(400000, 1000) {
            @Override
            public void onTick(long l) {
                for (int i = 0, dataLength = moviesList.size(); i < dataLength; i++) {
                    DriverOffer item = moviesList.get(i);
                    item.timeRemaining -= 1000;

                }

                //remove the expired items
                Iterator<DriverOffer> dataIterator = moviesList.iterator();
                while (dataIterator.hasNext()) {
                    DriverOffer rd = dataIterator.next();
                    if (rd.timeRemaining <= 0) {
                        dataIterator.remove();

                        requestRemoved( rd.getBookingid());
                    }
                }
                notifyDataSetChanged();
            }

            @Override
            public void onFinish() {
            }
        }.start();
    }

    private void requestRemoved( final String bookingid) {

          //  loading = ProgressDialog.show(context, resources.getString(R.string.processing),resources.getString(R.string.please_wait), false, false);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, cancelRideUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                      //          loading.dismiss();
                                JSONObject jObj = new JSONObject(response);
                                boolean error = jObj.getBoolean("error");
                                if (!error) {

                                    if (moviesList.isEmpty()) {

                                        Intent openHome = new Intent(context, NavHome.class);
                                        openHome.addFlags(FLAG_ACTIVITY_NEW_TASK);
                                        context.startActivity(openHome);

                                    }

                                } else {

                                    String errorMsg = jObj.getString("error_msg");
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                        //    loading.dismiss();

                        }
                    }){
                @Override
                protected Map<String,String> getParams(){
                    Map<String,String> params = new HashMap<String, String>();

                    HashMap<String, String> user;
                    user = new HashMap<String, String>();
                    user=sessionManager.getUserDetails();

                    params.put("bookingid",bookingid);
                    params.put("passengermobile",user.get("mobile"));

                    return params;

                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(context);
            requestQueue.add(stringRequest);

    }

    public void addPerson(DriverOffer driverOffer) {
        mPersons.add(driverOffer);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.driver_offer_list_row, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        DriverOffer driverOffer = moviesList.get(position);
        holder.title.setText(driverOffer.getDrivername());

        holder.driverOfferTimer.setText(millToMins(driverOffer.timeRemaining));
        holder.year.setText(driverOffer.getPrice());
        holder.vehicle.setText(driverOffer.getVehicle());

        try {
            holder.ratingBar.setRating(Float.parseFloat(driverOffer.getRating()));
            switch (driverOffer.getVehicle()) {

                case "Taxi(4+1)":
                    holder.vehicleIv.setImageResource(R.drawable.ic_car_passenger);
                    break;

                case "Auto":
                    holder.vehicleIv.setImageResource(R.drawable.ic_auto_passenger);
                    break;

                case "Bike":
                    holder.vehicleIv.setImageResource(R.drawable.ic_bike_passenger);
                    break;

                case "Taxi(7+1)":
                    holder.vehicleIv.setImageResource(R.drawable.suv_unselected_ic);
                    break;

            }

        }catch (Exception e){
            e.printStackTrace();
        }
        holder.typeofmeter.setText(moviesList.get(position).getTypeofmeter());

        holder.vehicleType.setText(moviesList.get(position).getVehicle_model()+" "+moviesList.get(position).getVehicle_sub_type());

        holder.myoffer.setText("My Fare including tax: ₹ "+moviesList.get(position).getMyoffer());
        // holder.bookingId.setText(driverOffer.getBookingid());

        String myOffer = moviesList.get(position).getMyoffer();

       String serviceCharge= moviesList.get(position).getMyoffer_service_charge();
       String gst = moviesList.get(position).getMyoffer_gst();

        double d = Double.parseDouble(serviceCharge);
        double d1 = Double.parseDouble(gst);
        double d2 = Double.parseDouble(myOffer);
        double sum=d+d1;
       // String serviceChAndGst = Double.toString(sum);

        BigDecimal big= Utils.roundTo(new BigDecimal(sum),2);

        double totalFare = sum+d2;

        holder.totalFair.setText("My Total Fare Incl Tax: ₹  "+Utils.roundTo(BigDecimal.valueOf(totalFare),2));
        holder.taxAndFees.setText("Taxes & Fees: ₹ "+big);

        sessionManager = new SessionManager(context);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();

            Context contexta = LocaleHelper.setLocale(context, languageCode);
            resources = contexta.getResources();


            holder.total_price_textView.setText(resources.getString(R.string.driver_offer));
            holder.acceptCounterOffer.setText(resources.getString(R.string.accept_counter_offer));

        }

        holder.acceptCounterOffer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Dialog dialog = new Dialog(offerActivity);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setCancelable(false);
                dialog.setContentView(R.layout.custom_alert_dialog);
                Window window = dialog.getWindow();
                window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                TextView text = (TextView) dialog.findViewById(R.id.txt_dia);
                text.setText("Do you want to select this offer");
                Button okButton = (Button) dialog.findViewById(R.id.btn_yes);
                Button cancleButton = (Button) dialog.findViewById(R.id.btn_no);

                okButton.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        //Perfome Action

                        if (waitingTimer!=null) {
                            waitingTimer.cancel();
                            waitingTimer = null;
                        }
                        iButtonAcceptOffer.acceptButton(v,position);
                        dialog.dismiss();
                    }
                });
                cancleButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();

            }
        });

        holder.reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Coming soon!", Toast.LENGTH_SHORT).show();
            }
        });



    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }

    private String millToMins(long millisec) {
        return millisec / (60000) + ":" + (int) (millisec / 1000) % (60);
    }
}


class DriverListCallback extends SortedList.Callback<DriverOffer> {

    @Override
    public int compare(DriverOffer p1, DriverOffer p2) {

        String[] rank1 = p1.getPrice().split("\n");
        String[] rank2 = p2.getPrice().split("\n");
        int diff = Integer.parseInt(rank1[0]) - Integer.parseInt(rank2[0]);
        return (diff == 0) ? p1.getDrivername().compareTo(p2.getDrivername()) : diff;
    }

    @Override
    public void onInserted(int position, int count) {
        //notifyItemInserted(position);
    }

    @Override
    public void onRemoved(int position, int count) {
        //notifyItemRemoved(position);
    }

    @Override
    public void onMoved(int fromPosition, int toPosition) {

    }

    @Override
    public void onChanged(int position, int count) {
    }

    @Override
    public boolean areContentsTheSame(DriverOffer oldItem, DriverOffer newItem) {
        return false;
    }

    @Override
    public boolean areItemsTheSame(DriverOffer item1, DriverOffer item2) {
        return false;
    }

}


