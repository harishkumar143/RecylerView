package com.kouchan.dyutpassenger.other;

/**
 * Created by KOUCHAN-ADMIN on 07-Apr-18.
 */

public class OttoDialogGeneric {

    String value;
    String type;

    public  OttoDialogGeneric(String value,String type){
        this.value=value;
        this.type=type;

    }

    public String getValue() {
        return value;
    }

    public String getType() {
        return type;
    }

}
