package com.kouchan.dyutpassenger.BroadcastReceivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;
import android.util.Log;

/*
 * jarvis working here by God's Grace*/
public class NetworkChangeReceiver extends BroadcastReceiver {

    private static String LOG_TAG = "NetworkChangeReceiver";
    private boolean isConnected = false;
    android.support.v7.app.AlertDialog.Builder ad;

    ConnectivityManager connectivityManager;
    NetworkInfo wifiInfo, mobileInfo;
    boolean connected = false;

    LocationManager locationManager = null;
    boolean gps_enabled = false, network_enabled = false;

    @Override
    public void onReceive(final Context context, Intent intent) {
        Log.v(LOG_TAG, "Receieved notification about network status");

        isNetworkAvailable(context);
        /*isGpsEnabled(context);*/
    }

    private void isNetworkAvailable(final Context context) {
        try {

            connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager != null) {

                NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
                isConnected = networkInfo != null && networkInfo.isAvailable() && networkInfo.isConnected();
                if (isConnected) {

                    isConnected = true;

                    if (locationManager == null)
                        locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
                }
            }

            if (!isConnected) {
                Log.v(LOG_TAG, "You are not connected to Internet!");

                ad = new android.support.v7.app.AlertDialog.Builder(context);
                ad.setTitle("Connectivity issue");
                ad.setMessage("Please make sure that the internet or application will close");
                ad.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        isNetworkAvailable(context);
                    }
                });
                ad.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        android.os.Process.killProcess(android.os.Process.myPid());
                    }
                });
                ad.setCancelable(false);
                ad.show();
                isConnected = false;
            }


        } catch (Exception e) {

            System.out.println("CheckConnectivity Exception: " + e.getMessage());
            Log.v("connectivity", e.toString());
        }
    }


    private void isGpsEnabled(final Context context) {
        if (locationManager == null)
            locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        try {
            gps_enabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ex) {
            //do nothing...
        }

        if (!gps_enabled) {

            ad = new android.support.v7.app.AlertDialog.Builder(context);
            ad.setTitle("GPS ");
            ad.setMessage("Please make sure that the GPS or application will close");
            ad.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    isGpsEnabled(context);
                }
            });
            ad.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    /* android.os.Process.killProcess(android.os.Process.myPid());*/
                    Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    context.startActivity(myIntent);
                }
            });
            ad.setCancelable(false);
            ad.show();


        }

    }
}
