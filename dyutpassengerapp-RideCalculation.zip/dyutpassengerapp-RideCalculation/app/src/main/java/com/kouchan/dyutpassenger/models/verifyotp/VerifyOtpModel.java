package com.kouchan.dyutpassenger.models.verifyotp;

public class VerifyOtpModel {

    /**
     * status : OK
     * code : 200
     * sucess : Sucess
     * step : AADHAR_SCR
     */

    private String status;
    private String code;
    private String sucess;
    private String step;
    private String message;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.status = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSucess() {
        return sucess;
    }

    public void setSucess(String sucess) {
        this.sucess = sucess;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }
}
