package com.kouchan.dyutpassenger.models;

/**
 * Created by KOUCHAN-ADMIN on 1/12/2018.
 */

public class MonthExpand {

    private String date;
    private String total_no_of_rides;
    private String total_fare;

    public MonthExpand(String date, String total_no_of_rides, String total_fare) {
        this.date = date;
        this.total_no_of_rides = total_no_of_rides;
        this.total_fare = total_fare;
    }


    public String getDate() {
        return date;
    }

    public String getTotal_no_of_rides() {
        return total_no_of_rides;
    }

    public String getTotal_fare() {
        return total_fare;
    }


}
