package com.kouchan.dyutpassenger.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.RideHistoryItemClick;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.View.Activities.MailQueryActivity;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.DateExpand;

import java.util.List;


/**
 * Created by KOUCHAN-ADMIN on 1/12/2018.
 */

public class DayWiseRideDetailsAdapter extends RecyclerView.Adapter<DayWiseRideDetailsAdapter.MyViewHolder> {

    private List<DateExpand> dateExpandList;
    RideHistoryItemClick rideHistoryItemClick;

    String languageCode;
    Resources resources;
    SessionManager sessionManager;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView booking_id_date_expand, booking_date_date_expand, vehicle_date_expand, actual_price_date_expand,
                from_date_expand, to_date_expand, distance_date_expand, start_time_date_expand, end_time_date_expand,
                total_time_date_expand;

        public TextView ref_no_textView, from_textView, to_textView, distance_covered_textView,
                journey_time_textView, to_time_textView, total_time_textView;

        public ImageView taxi_date_expand, rickshaw_date_expand;

        public LinearLayout rideLinearLayout;

        public Button helpButton;

        public MyViewHolder(View view) {
            super(view);
            booking_id_date_expand = (TextView) view.findViewById(R.id.booking_id_date_expand);
            booking_date_date_expand = (TextView) view.findViewById(R.id.booking_date_date_expand);
            vehicle_date_expand = (TextView) view.findViewById(R.id.vehicle_date_expand);
            taxi_date_expand = (ImageView) view.findViewById(R.id.taxi_date_expand);
            rickshaw_date_expand = (ImageView) view.findViewById(R.id.rickshaw_date_expand);
            actual_price_date_expand = (TextView) view.findViewById(R.id.actual_price_date_expand);
            from_date_expand = (TextView) view.findViewById(R.id.from_date_expand);
            to_date_expand = (TextView) view.findViewById(R.id.to_date_expand);
            distance_date_expand = (TextView) view.findViewById(R.id.distance_date_expand);
            start_time_date_expand = (TextView) view.findViewById(R.id.start_time_date_expand);
            end_time_date_expand = (TextView) view.findViewById(R.id.end_time_date_expand);
            total_time_date_expand = (TextView) view.findViewById(R.id.total_time_date_expand);

            ref_no_textView = (TextView) view.findViewById(R.id.ref_no_textView);
            from_textView = (TextView) view.findViewById(R.id.from_textView);
            to_textView = (TextView) view.findViewById(R.id.to_textView);
            distance_covered_textView = (TextView) view.findViewById(R.id.distance_covered_textView);
            journey_time_textView = (TextView) view.findViewById(R.id.journey_time_textView);
            to_time_textView = (TextView) view.findViewById(R.id.to_time_textView);
            total_time_textView = (TextView) view.findViewById(R.id.total_time_textView);

            rideLinearLayout = (LinearLayout) view.findViewById(R.id.rideLinearLayout);
            helpButton = (Button) view.findViewById(R.id.finishSendHelp);
        }
    }


    public DayWiseRideDetailsAdapter(List<DateExpand> dateExpandList, Context context, RideHistoryItemClick rideHistoryItemClick) {
        this.dateExpandList = dateExpandList;
        this.context = context;
        this.rideHistoryItemClick=rideHistoryItemClick;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.date_expand_list, parent, false);

        return new MyViewHolder(itemView);
    }


    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {

        final DateExpand dateExpand = dateExpandList.get(position);

        holder.booking_id_date_expand.setText(dateExpand.getBooking_id());
        holder.booking_date_date_expand.setText(dateExpand.getBookingdate());
        holder.vehicle_date_expand.setText(dateExpand.getVehicle());
        if (dateExpand.getVehicle().equalsIgnoreCase("Taxi(4+1)")) {

            holder.taxi_date_expand.setImageResource(R.drawable.car_selected_ic);
        } else if(dateExpand.getVehicle().equalsIgnoreCase("Auto")){
            holder.taxi_date_expand.setImageResource(R.drawable.auto_selected_ic);
        }
        else if(dateExpand.getVehicle().equalsIgnoreCase("Bike")){
            holder.taxi_date_expand.setImageResource(R.drawable.bike_selected_ic);
        }
        else if(dateExpand.getVehicle().equalsIgnoreCase("Taxi(7+1)")){
            holder.taxi_date_expand.setImageResource(R.drawable.suv_selected_ic);
        }
        holder.actual_price_date_expand.setText(" "+dateExpand.getActualPrice());
        holder.from_date_expand.setText(dateExpand.getFromplace());
        holder.to_date_expand.setText(dateExpand.getToplace());
        holder.distance_date_expand.setText(dateExpand.getDistance());
        holder.start_time_date_expand.setText(dateExpand.getStarttime());
        holder.end_time_date_expand.setText(dateExpand.getEndtime());
        holder.total_time_date_expand.setText(dateExpand.getTotaltime());

        sessionManager = new SessionManager(context);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();

            Context contexta = LocaleHelper.setLocale(context, languageCode);
            resources = contexta.getResources();
            holder.ref_no_textView.setText(resources.getString(R.string.ref_no));
            holder.from_textView.setText(resources.getString(R.string.from));
            holder.to_textView.setText(resources.getString(R.string.to));
            holder.distance_covered_textView.setText(resources.getString(R.string.distance_covered));
            holder.journey_time_textView.setText(resources.getString(R.string.journey_time));
            holder.to_time_textView.setText(resources.getString(R.string.to));
            holder.total_time_textView.setText(resources.getString(R.string.total_time));
        }

        holder.rideLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rideHistoryItemClick.onItemClick(position);
            }
        });

        holder.helpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context,MailQueryActivity.class);
                intent.putExtra("bookingId",dateExpand.getBooking_id());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dateExpandList.size();
    }
}