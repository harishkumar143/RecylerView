package com.kouchan.dyutpassenger.View.Activities;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.VolleyJsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;

public class EmergancyContactDeatilsActivity extends AppCompatActivity implements View.OnClickListener {

    @BindView(R.id.contactPersonMobile)
    EditText contactPersonMobile;

    @BindView(R.id.contactPersonName)
    EditText contactPersonName;

    @BindView(R.id.emergancyBackImage)
    ImageView emergancyBackImage;

    @BindView(R.id.contactPersonPhoneBookImage)
    ImageView contactPersonPhoneBookImage;

    @BindView(R.id.submit_button)
    Button submit_button;

    SessionManager sessionManager;

    String getUrl;
    String updateUrl = Url.PASSENGER_API+"updateemrgencydetails.php";
    private static final int TAG_RESULT_PICK__CONTACT = 1001;
    Cursor cursor;
    int phonePosIndex, namePosIndex;
    String userNameValue, userPhoneNumberValue = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergancy_contact_deatils);
        ButterKnife.bind(this);
        sessionManager=new SessionManager(this);
         getUrl = Url.PASSENGER_API+"getemergencydetails.php?mobile="+sessionManager.getUserDetails().get("mobile");

         submit_button.setOnClickListener(this);
         emergancyBackImage.setOnClickListener(this);
         contactPersonPhoneBookImage.setOnClickListener(this);

        getContactDetails();

    }

    private void getContactDetails() {
        StringRequest updateDriverLocation = new StringRequest(Request.Method.GET, getUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jObj = new JSONObject(response);
                            boolean error = jObj.getBoolean("error");
                            if (!error) {
                                contactPersonMobile.setText(jObj.getString("emergency_contact_mobile"));
                                contactPersonName.setText(jObj.getString("emergency_contact_name"));
                            } else {
                                String errorMsg = jObj.getString("error_msg");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(updateDriverLocation);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.emergancyBackImage:
                onBackPressed();
                break;

            case R.id.submit_button:
                updateApiCall();
                break;

            case R.id.contactPersonPhoneBookImage:
                pickContact(TAG_RESULT_PICK__CONTACT);
                break;
        }

    }

    private void pickContact(int type) {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(intent, type);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==TAG_RESULT_PICK__CONTACT){
            pickedContact(data,requestCode);
        }
    }

    private void pickedContact(Intent data, int requestCode) {
        try {

            // getData() method will have the Content Uri of the selected contact
            Uri uri = data.getData();

            //Query the content uri
            cursor = getContentResolver().query(uri, null, null, null, null);
            cursor.moveToFirst();

            phonePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            // column index of the contact name
            namePosIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

            userPhoneNumberValue = cursor.getString(phonePosIndex);
            userNameValue = cursor.getString(namePosIndex);
            String[] splitStrPhoneNumber = cursor.getString(phonePosIndex).split("\\s+");

            String refinedNumber = "";

            for (int i = 0; i < splitStrPhoneNumber.length; i++) {

                StringBuilder sb = new StringBuilder();
                sb.append(refinedNumber).append(splitStrPhoneNumber[i]);
                refinedNumber = sb.toString();
            }


            if (userPhoneNumberValue != null && userNameValue != null) {

                if (refinedNumber.length() == 10) {
                    refinedNumber = refinedNumber;
                } else if (refinedNumber.length() > 10) {
                    refinedNumber=refinedNumber.replaceAll("[^0-9]+", "");
                    refinedNumber = refinedNumber.substring(refinedNumber.length() - 10);
                    //
                } else {
                    // whatever is appropriate in this case
                    throw new IllegalArgumentException("Enter A Correct Number!");
                }

                if (requestCode == TAG_RESULT_PICK__CONTACT) {
                    contactPersonName.setText(userNameValue);
                    contactPersonMobile.setText(refinedNumber);
                }

            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void updateApiCall() {

        if(isValid(contactPersonMobile,contactPersonName)){

            Map<String, String> params = new HashMap<String, String>();

            params.put("mobile", sessionManager.getUserDetails().get("mobile"));
            params.put("emergency_contact_name", contactPersonName.getText().toString());
            params.put("emergency_contact_mobile", contactPersonMobile.getText().toString());

            VolleyJsonObjectRequest stringRequest = new VolleyJsonObjectRequest(Request.Method.PUT, updateUrl, new JSONObject(params),

                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                JSONObject jObj = new JSONObject(response.toString());
                                boolean error = jObj.getBoolean("error");
                                if (!error) {
                                    Toast.makeText(getApplicationContext(),  jObj.getString("message"), Toast.LENGTH_LONG).show();
                                    Intent intent=new Intent(EmergancyContactDeatilsActivity.this,NavHome.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    String errorMsg = jObj.getString("error_msg");
                                    Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_LONG).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    });
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    5000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }
    }

    private boolean isValid(EditText contactPersonMobile, EditText contactPersonName) {

        if (contactPersonMobile.getText().toString().trim().length() == 0) {
            contactPersonMobile.setError("Please Enter Contact Person Mobile");
            contactPersonMobile.requestFocus();
            return false;
        }

        if (contactPersonMobile.getText().toString().trim().length() < 10) {
            contactPersonMobile.setError("Mobile Num Should be 10 Digits");
            contactPersonMobile.requestFocus();
            return false;
        }

        if (contactPersonName.getText().toString().trim().length() == 0) {
            contactPersonName.setError("Please Enter Contact Person Name");
            contactPersonName.requestFocus();
            return false;
        }

        return true;
    }
}
