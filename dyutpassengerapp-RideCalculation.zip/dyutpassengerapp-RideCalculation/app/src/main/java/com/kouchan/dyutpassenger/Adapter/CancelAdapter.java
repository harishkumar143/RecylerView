package com.kouchan.dyutpassenger.Adapter;

import android.content.Context;
import android.content.res.Resources;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.kouchan.dyutpassenger.Database.SessionManager;
import com.kouchan.dyutpassenger.R;
import com.kouchan.dyutpassenger.helper.LocaleHelper;
import com.kouchan.dyutpassenger.models.Cancel;

import java.util.List;



/**
 * Created by KOUCHAN-ADMIN on 11/4/2017.
 */

public class CancelAdapter extends RecyclerView.Adapter<CancelAdapter.MyViewHolder> {

    private List<Cancel> cancelList;

    String languageCode;
    Resources resources;
    SessionManager sessionManager;
    Context context;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView paymenttype, bookingtime, ridestatus, actualprice, vehicle, fromplace, toplace;

        public TextView booking_time_textView, payment_type_textView, ride_status_textView,
                vehicle_type_textView, actual_price_textView, fromplace_text, toplace_text, refNumber;

        public MyViewHolder(View view) {
            super(view);
            paymenttype = (TextView) view.findViewById(R.id.paymenttype);
            bookingtime = (TextView) view.findViewById(R.id.bookingtime);
            ridestatus = (TextView) view.findViewById(R.id.ridestatus);
            actualprice = (TextView) view.findViewById(R.id.actualprice);
            vehicle = (TextView) view.findViewById(R.id.vehicle);

            fromplace = (TextView) view.findViewById(R.id.fromplacecancel);
            toplace = (TextView) view.findViewById(R.id.toplacecancel);

            booking_time_textView = (TextView) view.findViewById(R.id.booking_time_textView);
            payment_type_textView = (TextView) view.findViewById(R.id.payment_type_textView);
            ride_status_textView = (TextView) view.findViewById(R.id.ride_status_textView);
            vehicle_type_textView = (TextView) view.findViewById(R.id.vehicle_type_textView);
            actual_price_textView = (TextView) view.findViewById(R.id.actual_price_textView);
            fromplace_text = (TextView) view.findViewById(R.id.fromplace_text);
            toplace_text = (TextView) view.findViewById(R.id.toplace_text);
            refNumber = (TextView) view.findViewById(R.id.refNumber);
        }
    }


    public CancelAdapter(List<Cancel> cancelList, Context context) {
        this.cancelList = cancelList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cancel_list_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        Cancel cancel = cancelList.get(position);
        holder.paymenttype.setText(cancel.getPaymenttype());
        holder.bookingtime.setText(cancel.getBookingtime());
        holder.ridestatus.setText(cancel.getRidestatus());
        holder.vehicle.setText(cancel.getVehicle());

        holder.fromplace.setText(cancel.getFromplace());
        holder.toplace.setText(cancel.getToplace());
        holder.actualprice.setText(cancel.getPrice());
        holder.refNumber.setText(cancel.getId());
        sessionManager = new SessionManager(context);
        if (sessionManager.getLanguageCode() != null) {
            languageCode = sessionManager.getLanguageCode();

            Context contexta = LocaleHelper.setLocale(context, languageCode);
            resources = contexta.getResources();
            holder.booking_time_textView.setText(resources.getString(R.string.booking_time));
            holder.payment_type_textView.setText(resources.getString(R.string.payment_type));
            holder.ride_status_textView.setText(resources.getString(R.string.ride_status));
            holder.vehicle_type_textView.setText(resources.getString(R.string.vehicle_type));
            holder.actual_price_textView.setText(resources.getString(R.string.actual_price));
            holder.fromplace_text.setText(resources.getString(R.string.from_place));
            holder.toplace_text.setText(resources.getString(R.string.to_place));
        }

    }

    @Override
    public int getItemCount() {
        return cancelList.size();
    }
}