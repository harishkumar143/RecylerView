package com.kouchan.dyutpassenger.View.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kouchan.dyutpassenger.Api.VolleySingleton;
import com.kouchan.dyutpassenger.Database.CurrentRide;
import com.kouchan.dyutpassenger.R;

import org.json.JSONException;
import org.json.JSONObject;

public class PaymentStatusActivity extends AppCompatActivity {

    TextView amountPaid,mode,paymentStatusText;
    Button okButton;
    ImageView shareImage;
    String drivermobile,booking_id,amount,payment_mode,comingFrom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_status);

        amountPaid=(TextView)findViewById(R.id.amountPaid);
        paymentStatusText=(TextView)findViewById(R.id.paymentStatusText);
        mode=(TextView)findViewById(R.id.mode);
        okButton=(Button)findViewById(R.id.okButton);
        shareImage=(ImageView) findViewById(R.id.shareImage);

        Intent i=getIntent();

        if(i!=null){

            if(getIntent().getStringExtra("comingFrom")!=null){
                comingFrom=getIntent().getStringExtra("comingFrom");
            }

            if(comingFrom!=null){
                if(getIntent().getStringExtra("comingFrom").equalsIgnoreCase("CancelRide")){
                    booking_id = getIntent().getStringExtra("booking_id");
                    amount = getIntent().getStringExtra("amount");
                    payment_mode = getIntent().getStringExtra("payment_mode");
                }
                else{
                    drivermobile = getIntent().getStringExtra("drivermobile");
                    booking_id = getIntent().getStringExtra("booking_id");
                    amount = getIntent().getStringExtra("amount");
                    payment_mode = getIntent().getStringExtra("payment_mode");
                }
            }


        }

        amountPaid.setText("₹ "+amount);

        if(payment_mode.equalsIgnoreCase("CASH")){
            mode.setText("Payment Mode : Cash");
            paymentStatusText.setText("Pay to driver");
        }
        else{
            mode.setText("Payment Mode : DYUT wallet");
            paymentStatusText.setText("Payment successful");
        }


        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(comingFrom.equalsIgnoreCase("CancelRide")){
                    Intent intent3 = new Intent(getApplicationContext(), NavHome.class);
                    CurrentRide currentRide = new CurrentRide(getApplicationContext());
                    currentRide.setIsRideStarted("ended");
                    startActivity(intent3);
                    finish();
                }

                else{
                    apiCall();
                    Intent intent3 = new Intent(getApplicationContext(), FeedbackActivity.class);
                    CurrentRide currentRide = new CurrentRide(getApplicationContext());
                    currentRide.setIsRideStarted("ended");
                    intent3.putExtra("drivermobile", drivermobile);
                    intent3.putExtra("booking_id", booking_id);
                    startActivity(intent3);
                    finish();
                }

            }
        });

        shareImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, "My app name");
                String strShareMessage = "Amount paid to driver :"+amount + "\nPayment mode :"+payment_mode ;
                //  Uri screenshotUri = Uri.parse("android.resource://packagename/drawable/image_name");
                // i.setType("image/png");
                //  i.putExtra(Intent.EXTRA_STREAM, screenshotUri);
                i.putExtra(Intent.EXTRA_TEXT, strShareMessage);
                startActivity(Intent.createChooser(i, "Share Vai"));

            }
        });
    }

    private void apiCall() {


        String emailUrl = "https://bookarideworldwide.com/CAB2.V.1/PHPMailer-master/email.php?booking_id="+booking_id;

        StringRequest stringRequest=new StringRequest(Request.Method.POST, emailUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObj = new JSONObject(response);
                            boolean error = jsonObj.getBoolean("error");
                            if (!error) {

                            }else {
                                String errorMsg = jsonObj.getString("error_msg");
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
}
