package com.kouchan.dyutpassenger.other;



import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.kouchan.dyutpassenger.BroadcastReceivers.NetworkChangeReceiver;
import com.kouchan.dyutpassenger.Otto.EventBusManager;
import com.kouchan.dyutpassenger.R;

import java.util.List;
//
//import org.com.kouchan.dyutpassenger.BroadcastReceivers.NetworkChangeReceiver;
//import org.com.kouchan.dyutpassenger.Otto.EventBusManager;

/**
 * Created by KOUCHAN-ADMIN on 1/20/2018.
 */

public class CustomeDialogGeneric extends Dialog implements
        android.view.View.OnClickListener {


    public Activity c;
    public Dialog d;

    public Button yes, no;
    public TextView dialogbox_title,dialog_msg;
    NetworkChangeReceiver receiver;
    String title,msg,positiveButtonText,negativeButtonText,type;

    public CustomeDialogGeneric(Activity a, String title, String msg, String positiveButtonText, String negativeButtonText, String type, NetworkChangeReceiver receiver) {
        super(a);
        this.c = a;
        this.title=title;
        this.msg=msg;
        this.positiveButtonText=positiveButtonText;
        this.negativeButtonText=negativeButtonText;
        this.type=type;
        this.receiver = receiver;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*requestWindowFeature(Window.FEATURE_NO_TITLE);*/
        setContentView(R.layout.custom_dialog_generic);

        yes = (Button) findViewById(R.id.btn_yes);
        no = (Button) findViewById(R.id.btn_no);

        dialogbox_title=(TextView)findViewById(R.id.dialogbox_title);
        dialog_msg=(TextView)findViewById(R.id.dialog_msg);
        yes.setText(positiveButtonText);
        no.setText(negativeButtonText);

        dialogbox_title.setText(title);
        dialog_msg.setText(msg);

        yes.setOnClickListener(this);
        no.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_yes:

                OttoDialogGeneric ottoDialogGeneric = new OttoDialogGeneric("yes",type);
                EventBusManager.getInstance().getEventBus().post(ottoDialogGeneric);
                c.unregisterReceiver(receiver);

                break;
            case R.id.btn_no:
                dismiss();
                break;



            default:
                break;
        }

    }


    @Override
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> data, @Nullable Menu menu, int deviceId) {

    }
}