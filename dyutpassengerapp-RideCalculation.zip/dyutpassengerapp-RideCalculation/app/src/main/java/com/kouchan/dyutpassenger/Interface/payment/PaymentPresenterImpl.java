package com.kouchan.dyutpassenger.Interface.payment;

import android.widget.Toast;

import com.google.gson.Gson;
import com.kouchan.dyutpassenger.Api.ServerApiNames;
import com.kouchan.dyutpassenger.Interface.Url;
import com.kouchan.dyutpassenger.View.Activities.PaymentActivity;
import com.kouchan.dyutpassenger.async.AsyncInteractor;
import com.kouchan.dyutpassenger.async.OnRequestListener;
import com.kouchan.dyutpassenger.models.PaymentModel;
import com.kouchan.dyutpassenger.utils.AppConstants;
import com.kouchan.dyutpassenger.utils.NetworkStatus;
import com.kouchan.dyutpassenger.utils.Sharedpreferences;
import com.kouchan.dyutpassenger.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class PaymentPresenterImpl implements IPaymentPresnter, OnRequestListener {

    PaymentActivity paymentActivity;
    Sharedpreferences sharedpreferences;
    AsyncInteractor asyncInteractor;
    PaymentModel paymentModel;
    IPaymentView paymentView;

    public PaymentPresenterImpl(IPaymentView paymentView) {
        this.paymentActivity = (PaymentActivity) paymentView;
        this.sharedpreferences = Sharedpreferences.getUserDataObj(paymentActivity);
        this.asyncInteractor = new AsyncInteractor(paymentActivity);
        this.paymentView = paymentView;
    }

    @Override
    public void payment(String bookingId,String paymentMode) {
        if (NetworkStatus.checkNetworkStatus(paymentActivity)) {
            Utils.showProgress(paymentActivity);
            Map<String, String> params = new HashMap<String, String>();
            params.put("b_id", bookingId);
            params.put("payment_mode", paymentMode);
            asyncInteractor.validateCredentialsAsync(this, AppConstants.TAG_ID_PAYMENT, Url.COMUNICATE_API + ServerApiNames.PAYMENT, new JSONObject(params));
        } else {
            Utils.showToast(paymentActivity, "Please connect to internet");
        }
    }

    @Override
    public void onRequestCompletion(int pid, JSONObject responseJson, JSONArray responseArray) {

    }

    @Override
    public void onRequestCompletion(int pid, String responseJson) throws JSONException {
            if (pid == AppConstants.TAG_ID_PAYMENT) {
                Utils.stopProgress(paymentActivity);
                if (responseJson != null) {
                    Gson gson = new Gson();

                    paymentModel = gson.fromJson(responseJson, PaymentModel.class);
                    if (paymentModel.getError() == false) {

                        paymentView.paymentSuccess(pid, paymentModel);
                    } else {
                        paymentView.paymentError(pid, paymentModel.getError_msg());
                        Toast.makeText( paymentActivity,paymentModel.getError_msg() , Toast.LENGTH_SHORT ).show();
                    }
                }
            }
    }

    @Override
    public void onRequestCompletionError(int pid, String error) {
        Utils.stopProgress(paymentActivity);
        paymentView.paymentError(pid, error);
    }

    @Override
    public void onRequestCompletionHomeError(int pid, String error) {
        Utils.stopProgress(paymentActivity);
    }
}
